# 三国争霸 · 架构总纲（Architecture Standard）

> 本文是全部技术标准的**根文件**。其余标准（Event / Effect / Card / Skill / Character /
> AI / Game_Flow / UI / Development）均为本总纲在各子系统的展开，**不得与本文冲突**。
> 任何代码若违反本文条款，视为架构缺陷，合入前必须修复。
>
> 引擎：Godot 4.6.3 · 语言：GDScript · 适用：内核重写后的全部代码
> 版本：v3.0（内核重写基线）

---

## 〇、本文的地位

- 本文定义**不可协商的架构契约**（标记为 `[MUST]`）与**强烈建议**（标记为 `[SHOULD]`）。
- 评审任何 PR / 提交时，先核对本文第三章「九条架构铁律」。
- 标准之间出现矛盾时，**以本总纲为准**，并提 issue 修订下游标准。

---

## 一、分层与依赖方向

系统分为 5 层，**依赖只能从上往下，严禁反向或跨层回指**：

```
┌──────────────────────────────────────────────────────────┐
│  L5  表现层 (Presentation)                                │
│      src/ui/*  ·  scenes/*                                 │
│      只读 L1~L4 的状态，只通过「控制器接口」回写意图        │
├──────────────────────────────────────────────────────────┤
│  L4  决策层 (Controllers)                                 │
│      src/ai/*（SmartAI / HumanController …）              │
│      实现 IPlayerController；不直接改状态，只返回「意图」   │
├──────────────────────────────────────────────────────────┤
│  L3  规则层 (Rules / Orchestration)                       │
│      回合引擎 TurnSystem/PhaseSystem · 卡牌效果 CardEffect*│
│      技能 Skill* · 胜负判定 · 触发管道 TriggerBroker       │
│      只能通过 L2 的 Effect 改状态；通过 L1 的事件管道协作   │
├──────────────────────────────────────────────────────────┤
│  L2  状态变更层 (Effects)                                 │
│      src/effects/* · src/actions/*                        │
│      **唯一允许写运行时状态的层**。每次变更必发精确事件     │
├──────────────────────────────────────────────────────────┤
│  L1  内核 (Kernel)                                        │
│      EventBus · GameEvent · CardLocationRegistry          │
│      BattleContext(数据) · ActionQueue · RNG              │
│      不认识任何具体卡牌 / 技能 / 武将                       │
└──────────────────────────────────────────────────────────┘
```

**依赖规则 `[MUST]`**：
- L1 内核**不得** `import` / 引用任何 L2~L5 的具体类型（不认识"杀""奸雄""battle_table"）。
- L3 规则层之间通过事件协作，**不得**直接 `import` 兄弟模块的具体实现去硬调（见铁律 6）。
- L5 表现层**只读**状态，写操作一律经 L4 控制器返回意图 → L3 编排 → L2 执行。

---

## 二、单一真值原则（Single Source of Truth）

`[MUST]` 每一类运行时状态有且仅有一个权威持有者与一个写入入口：

| 状态 | 权威持有者 | 唯一写入入口 |
|------|-----------|-------------|
| 体力 / 存活 / 翻面 / 连环 | `PlayerState` | `DamageEffect`/`HealEffect`/`LoseHpEffect`/`FlipEffect`/`ChainEffect` |
| **一张牌当前在哪个区域** | `CardLocationRegistry` | `CardLocationRegistry.move_card()` |
| 手牌 / 装备区 / 判定区 / 牌堆 内容 | 由 `move_card` 同步维护 | 同上（**禁止**直接 `hand_cards.erase/append`） |
| 技能跨步骤状态 | `PlayerState` 的 meta | `set_skill_meta()`（命名空间见铁律 8） |
| 随机性 | `RngService`（带种子） | 见第六章 |

**严禁**任何代码用"遍历全场猜测一张牌在哪"的方式判断归属（这是旧内核 bug 之源）。牌的位置查询一律 `CardLocationRegistry.locate(card)`。

---

## 三、九条架构铁律（Red Lines）

> 这是评审 checklist 的第一关。逐条对照见各子标准的「审核清单」。

### 铁律 1 — Effect 垄断状态变更
任何运行时状态变更**必须**经 L2 的 Effect/GameAction 完成。Skill / CardEffect / 回合引擎**禁止**直接写 `current_hp`、手牌数组、`discard_pile` 等。
- 豁免（只读）：`can_trigger`/`can_activate`/`modify_attribute`/目标枚举。

### 铁律 2 — 事件具备因果链 ID
每个 `GameEvent` **必须**带全局唯一 `event_id`（自增），并支持 `parent_event_id`。子事件由父事件触发时必须串上父 ID，形成可追溯链路（用于日志、回放、调试）。

### 铁律 3 — 统一异步结算契约
凡可能引发"等待"（玩家响应、嵌套结算、濒死求桃）的接口**必须**是 `async` 且调用方**必须** `await`。
- `Effect.resolve()` / `GameAction.execute()` / `Skill.execute()` / 触发询问 一律 async。
- **禁止** fire-and-forget：不允许在同步上下文里启动一个会 await 的协程而不接其结果（旧"断链"bug 之源）。

### 铁律 4 — 事件双通道，反应必须可等待
事件分两类，不得混用：
- **通知（notify，同步）**：纯观察者（UI、日志、计数）。回调**不得** await、不得改状态。
- **反应（dispatch，异步）**：会触发技能/响应链。由 `TriggerBroker` 收集合法反应者，**按固定顺序逐一 `await`** 询问与执行。
触发技的"是否发动"询问**必须**走异步反应通道，以支持人类弹窗等待。

### 铁律 5 — 纯函数判定
`can_trigger` / `can_activate` / `modify_attribute` / `get_*_targets` **必须**是纯函数：只读状态、无副作用、不发事件、不建 Effect、可被多次调用且结果一致。

### 铁律 6 — 核心与规则不得硬编码具体技能/卡牌
L1 内核与 L3 编排器**禁止**按类名引用具体技能（如 `SkillWuJing.xxx()`）或具体卡牌字符串分支去实现规则扩展。技能对核心流程的影响一律通过：
- 订阅事件（反应通道），或
- 注册**属性修正钩子** `modify_attribute(attr, base, ctx)`，或
- 提供标准化的**查询契约**（如转化牌 `get_convertible_cards`）。
> 加一个新技能/新卡，**不应**需要修改内核或 PlayCardEffect 主流程。

### 铁律 7 — 精确语义事件，禁止万能事件
**禁止** `CARD_LOST`/`CARD_OBTAINED` 等笼统事件。每种状态迁移用语义精确的专用事件（`CARD_USED`/`CARD_STOLEN`/`CARD_GIVEN`/`CARD_DISCARDED`/`CARD_CONSUMED`/`EQUIP_*` …），且 data 带 `reason`/`source`/`card(s)`。

### 铁律 8 — Meta 命名空间
跨技能/跨步骤状态经 `PlayerState.set_skill_meta(skill_id, field, v)` 存取，底层 key 强制 `skill.<skill_id>.<field>`。**禁止**裸 key（如 `"hezhong_bonus"`）。

### 铁律 9 — 确定性与可序列化
内核状态**必须**可完整序列化（为存档/回放/未来联机预留）。所有随机一律走 `RngService(seed)`，**禁止**直接 `randi()`/`Array.shuffle()` 于规则层。相同种子 + 相同输入 → 相同结果。

---

## 四、固定优先级表（事件反应顺序）

`dispatch` 的反应者按 priority 降序执行，**只允许**下列固定档位：

| Priority | 用途 | 例 |
|---------:|------|----|
| `100` | 防御性拦截（伤害前阻断） | 藤甲、仁王盾 |
| `50` | 参数修改（结算前改值） | 青釭剑、雌雄 |
| `10` | 标准触发（结算后反应） | 奸雄、反馈 |
| `0` | 默认 | 一般触发技 |
| `-10` | 延迟触发（需在他者之后） | 链式反应 |
| `-50` | UI 通知 | battle_table 动画/音效 |
| `-100` | 日志 | BattleLogger |
同档内按**座位顺序**（当前回合角色起顺时针）裁决。禁止使用档位之间的中间值。

---

## 五、命名与代码规约（摘要，详见 Development_Standards.md）

- 类名 `PascalCase`；文件 `snake_case.gd`；变量/函数 `snake_case`；私有 `_` 前缀；常量 `UPPER_SNAKE_CASE`。
- 布尔 `is_/has_/can_` 前缀；回调 `_on_`；信号用过去式（已发生）或动词原形（请求）。
- 每文件顶部文件头注释（职责一句话）。`[MUST]` 公共 API 用 `##` 文档注释。
- `[SHOULD]` 去除历史 `Gemini:change.N` 流水注释，改为「说明为什么」而非「改了什么」。

---

## 六、随机性与确定性

- `[MUST]` 内核持有 `RngService`，构造时注入 `seed`（默认取系统随机，记录入存档）。
- 洗牌、判定翻牌、AI 抖动等一律 `rng.shuffle()/rng.randi()`。
- `[MUST]` 不在 `_process`/帧轮询里推进游戏逻辑；回合推进用显式 `await`，不得用 `await process_frame` 当节拍器。

---

## 七、错误处理与不变量

- `[MUST]` 关键不变量用断言守护，至少包含：
  1. **牌守恒**：抽牌堆 + 弃牌堆 + 全体手牌 + 装备 + 判定区 + 结算中 = 牌库总数（恒定）。
  2. **单所有权**：任一 `CardData` 在 `CardLocationRegistry` 中只出现一次。
  3. **HP 边界**：`0 ≤ current_hp ≤ max_hp`（濒死瞬时可 <0，求桃后必回正或死亡）。
- `[SHOULD]` 提供 `debug_validate()` 在每回合结束校验上述不变量（开发期开启）。
- 非法意图（越界目标、不在手牌的牌）由 L3 校验并安全拒绝，**不得**让 L2 崩溃。

---

## 八、目录结构（与真实工程对齐）

```
src/
├── core/        # L1 内核：event_bus, game_event, card_location, rng_service,
│                #          response_request, turn_system, phase_system, trigger_broker …
├── managers/    # battle_context（数据）, deck_manager, game_manager（装配+胜负）
├── data/        # card_data, hero_data, skill_data, identity, json_data_loader, hero_pool
├── effects/     # L2：damage/heal/draw/discard/equip/transfer/chain/flip/lose_hp …
├── actions/     # L2：game_action 基类, action_queue, play_card_effect
├── cards/       # L3：card_effect_*（各卡牌结算）
├── skills/      # L3：skill 基类 + skill_context + 各武将技能；equip/ 装备技能
├── ai/          # L4：smart_ai, human_controller（IPlayerController）
└── ui/          # L5：battle_table, card_view, *_screen, ui_theme, anim_helper
```

---

## 九、审核清单（架构层，强制）

提交前逐条核对（细化清单见各子标准）：

- [ ] 铁律 1：未绕过 Effect 直接改状态
- [ ] 铁律 2：事件带 `event_id`，链式事件串 `parent_event_id`
- [ ] 铁律 3：会等待的接口均 async 且被 await，无 fire-and-forget
- [ ] 铁律 4：反应走 dispatch 异步通道，通知走 notify 同步通道
- [ ] 铁律 5：判定/修正函数为纯函数
- [ ] 铁律 6：内核/编排器无具体技能类名硬编码分支
- [ ] 铁律 7：用精确语义事件，data 含 reason/source
- [ ] 铁律 8：meta 走命名空间 API
- [ ] 铁律 9：随机走 RngService，状态可序列化
- [ ] 牌守恒 / 单所有权 不变量未被破坏
