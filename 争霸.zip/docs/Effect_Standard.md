# 三国争霸 · Effect 标准（Effect Standard）

> 上位文件：`00_Architecture_Standard.md`（铁律 1/3）。
> 本文定义 L2 状态变更层：`Effect` / `GameAction` / `ActionQueue` 的契约。
> **Effect 是唯一允许写运行时状态的层。**
> 版本：v3.0

---

## 一、两层职责

```
┌───────────────────────────────────────────────────────────┐
│ Effect（原子操作，继承 Effect→RefCounted）                 │
│   resolve(ctx) async → Dictionary                          │
│   职责：一次原子状态变更 + BEFORE/AFTER 事件               │
│   例：Damage / Heal / Draw / Discard / Equip / LoseHp /    │
│       Flip / Chain                                          │
├───────────────────────────────────────────────────────────┤
│ GameAction（编排器，继承 GameAction→RefCounted）           │
│   execute(ctx, queue) async → Dictionary                   │
│   职责：编排多个 Effect + 生命周期（声明→执行→清理）        │
│   例：PlayCardEffect / TransferCardEffect                  │
└───────────────────────────────────────────────────────────┘
```

`[MUST]`：牌的移动（手牌↔弃堆↔装备↔判定↔牌堆）一律经
`CardLocationRegistry.move_card()`（见 Card_Standard.md），**禁止** Effect 内部直接
`hand_cards.erase/append` 或 `discard_pile.append`。

---

## 二、统一异步契约（铁律 3）

`[MUST]` **所有** Effect 的 `resolve` 与 GameAction 的 `execute` 一律声明为可 await，
调用方一律 `await`，无例外。即便某 Effect 当前不 await，也保持同一签名，
以免调用方"分类记忆哪个要 await"（旧内核断链根因）。

```gdscript
# 统一调用范式
await DamageEffect.create(src, tgt, 1, DamageType.NORMAL, card).resolve(ctx)
await DrawCardEffect.create(src, tgt, 2).resolve(ctx)
```

### 2.1 标准返回结构

`[MUST]` 返回 `Dictionary`，至少含 `resolved: bool`；失败带 `reason: String`。

```gdscript
{ "resolved": true,  "amount": 2, "current_hp": 1, "died": false }
{ "resolved": false, "reason": "cancelled" }
```

---

## 三、Effect 基类

```gdscript
class_name Effect
extends RefCounted

var effect_type: EffectType = EffectType.CUSTOM
var source_index: int = -1
var target_index: int = -1
var related_card: CardData = null
var is_cancelled: bool = false
var context: Dictionary = {}
var parent_event_id: int = -1     ## [MUST] 因果链：发出的事件串此 ID

func resolve(_ctx) -> Dictionary:  ## 子类重写（async-safe）
    push_error("Effect.resolve() 未重写")
    return {"resolved": false, "reason": "not_implemented"}
```

### 3.1 标准 resolve 模板（铁律 1/2/3/7）

```gdscript
func resolve(ctx) -> Dictionary:
    # 1) 守卫
    var target = ctx.get_player(target_index)
    if target == null: return {"resolved": false, "reason": "invalid_target"}

    # 2) BEFORE：可被技能拦截/改值（异步反应通道）
    var before := GameEvent.create(GameEvent.Type.XXX_BEFORE, source_index, target_index, data)
    await EventBus.dispatch(before)
    if before.is_cancelled or is_cancelled:
        return {"resolved": false, "reason": "cancelled"}
    var amount = before.data.get("amount", amount)   # 取回被修改值

    # 3) EXECUTE：写状态（仅此层允许）
    target.current_hp -= amount

    # 4) AFTER：通知 + 触发后续技能（异步）
    var after := GameEvent.create(GameEvent.Type.XXX_AFTER, source_index, target_index, result, before)
    await EventBus.dispatch(after)

    # 5) 返回
    return {"resolved": true, ...}
```

---

## 四、标准 Effect 清单

| Effect | 文件 | 关键事件 | 备注 |
|--------|------|----------|------|
| `DamageEffect` | damage_effect.gd | DAMAGE_BEFORE/AFTER | 含连环传递、扣血后 await 濒死求桃 |
| `HealEffect` | heal_effect.gd | HEAL_BEFORE/AFTER | 守卫 `hp<max` |
| `LoseHpEffect` | lose_hp_effect.gd | LOSE_HP_*  | 失去体力≠受伤（防护技不挡） |
| `DrawCardEffect` | draw_card_effect.gd | CARD_DRAWN | 经 move_card 从牌堆入手 |
| `DiscardCardEffect` | discard_card_effect.gd | CARD_DISCARDED | reason 枚举见下 |
| `EquipEffect` | equip_effect.gd | EQUIP_INSTALLED/REMOVED | 替换旧装备 + 卸技能 |
| `FlipEffect` / `ChainEffect` | *.gd | FLIP_*/CHAIN_TOGGLED | 翻面/连环 |
| `TransferCardEffect` | transfer_card_effect.gd（GameAction） | CARD_STOLEN/GIVEN | 手↔手、堆→手等 |

### 4.1 枚举

```gdscript
DamageEffect.DamageType = { NORMAL, FIRE, THUNDER, NONE }
DiscardCardEffect.DiscardReason = { PHASE_DISCARD, SKILL_COST, FORCED, USAGE }
```

`[MUST]` `DamageEffect.resolve` 在 `current_hp <= 0` 时 `await DeathResolver.resolve_dying()`
（扣血→求桃→救回/死亡为一条串行链，不得断链）。

---

## 五、GameAction 基类与 ActionQueue

```gdscript
class_name GameAction
extends RefCounted

enum ActionState { PENDING, EXECUTING, COMPLETED, CANCELLED }
var state: ActionState = ActionState.PENDING
var source_index: int = -1
var target_index: int = -1
var priority: int = 0
var description: String = ""
var parent_event_id: int = -1

func execute(_ctx, _queue) -> Dictionary: ...   ## async-safe，子类重写
func can_execute(_ctx) -> bool: return true     ## 纯函数
func cancel() -> void: ...                       ## 递归取消子动作
```

### 5.1 ActionQueue

| 方法 | 说明 |
|------|------|
| `push_action(a)` | 入队（priority 降序） |
| `push_front(a)` | 紧急插队首 |
| `execute_next()` | 出队 → `can_execute` → `await execute` |
| `execute_all()` | 循环 await 直到空（支持执行中嵌套入队） |
| `clear()` | 取消并清空 |

`[MUST]` `execute_all` 全程 await；动作在执行中可 `push` 新动作，后续迭代自动处理。

---

## 六、审核清单（Effect 层，强制）

- [ ] 继承 `Effect` 或 `GameAction`，提供 `static func create(...)`
- [ ] `resolve/execute` 为 async-safe，调用方均 `await`
- [ ] 牌移动经 `CardLocationRegistry.move_card`，无裸数组增删
- [ ] BEFORE 用 `dispatch` 并检查 `is_cancelled`；AFTER 通知后续
- [ ] 发出的事件串了 `parent_event_id`
- [ ] 返回含 `resolved`；失败带 `reason`
- [ ] 守卫：target 存在、card 非空、数量合法
- [ ] 未破坏牌守恒 / 单所有权不变量
