# 三国争霸 · 角色卡制作标准（Character Standard）

> 上位文件：`00_Architecture_Standard.md`。本文定义武将 **JSON 数据规范**。
> 技能脚本编写规范见 `Skill_Standard.md`。
> 版本：v3.0

---

## 一、文件规范
- 路径：`data/heroes/<hero_id>.json`；`hero_id` 全小写拼音、无空格/特殊字符。
- 一武将一文件；`JsonDataLoader` 启动扫描加载。

### JSON 结构
```json
{
    "id": "feiyi", "name": "费祎", "camp": "蜀", "hp": 3, "gender": "male",
    "skills": [
        {
            "id": "yanru", "name": "晏如", "type": "active",
            "timing": "on_phase_play", "script": "res://src/skills/skill_yanru.gd",
            "limit": 1, "desc": "出牌阶段各限一次……"
        }
    ]
}
```

---

## 二、字段定义

### 2.1 基础
| 字段 | 类型 | 必填 | 约束 |
|------|------|:--:|------|
| `id` | string | ✅ | 唯一、英文小写 |
| `name` | string | ✅ | 非空 |
| `camp` | string | ✅ | `魏/蜀/吴/群` |
| `hp` | int | ✅ | 1~5（标准 3/4） |
| `gender` | string | ✅ | `male/female` |
| `skills` | array | ✅ | 可空 `[]` |

### 2.2 技能字段
| 字段 | 类型 | 必填 | 说明 |
|------|------|:--:|------|
| `id`/`name`/`desc` | string | ✅ | 标识/中文名/玩家向描述 |
| `type` | string | ✅ | `active/trigger/compulsory/passive/awaken` |
| `timing` | string | ✅ | 触发时机枚举（主动/被动填 `none`） |
| `script` | string | ✅ | `res://src/skills/skill_<id>.gd`，无脚本填 `""` |
| `limit` | int | ❌ | 每回合次数（-1=无限，默认 -1） |

### 2.3 触发时机枚举
`none / on_phase_play / on_phase_draw / on_phase_judge / on_turn_start / on_turn_end /
on_take_damage / on_deal_damage / on_card_used / on_become_target / on_equip_removed /
on_dying / on_death / on_recover_hp`（映射事件见 `Event_System_Standard.md`）。

---

## 三、制作流程
1. 建 `data/heroes/<id>.json`，填基础字段 + 技能数组。
2. 如含主动/触发/锁定技：建 `src/skills/skill_<skill_id>.gd`，遵 `Skill_Standard.md`。
3. 验证：准备界面点将 → 选该武将开局 → 逐技能测试发动条件与效果。

---

## 四、审核标准

### 4.1 数据完整性
- [ ] `id` 唯一；`name` 非空；`camp` 合法；`hp∈[1,5]`；`gender` 合法
- [ ] 每技能 `script` 指向真实存在文件或为 `""`
- [ ] `timing` 与 `type` 搭配合理（主动/被动用 `none`）

### 4.2 平衡性
- [ ] 3 血武将通常 2~3 技；4 血通常 1~2 技
- [ ] 主动技有回合次数限制；无限技有其他代价/苛刻条件

### 4.3 技能脚本交叉检查（对照 Skill_Standard 铁律）
- [ ] 类名正确、继承 `Skill`
- [ ] 铁律 1：无裸 `hand_cards.erase` / 直接改 HP；改状态经 Effect/move_card
- [ ] 铁律 5：`can_trigger/can_activate` 纯函数
- [ ] 铁律 6：技能未被核心按类名硬调；影响核心走事件/属性钩子
- [ ] 铁律 8：跨步骤态走 `ctx.set_skill_meta`，无裸 meta key
- [ ] 使用 `SkillContext`，无实例临时状态字段

---

## 五、示例
**单主动技**（孙权制衡）、**三技能复杂武将**（诸葛亮 知天/武靖/智绝）、**无技能**（无名氏 `"skills": []`）。
完整示例保留于各 `data/heroes/*.json`。
