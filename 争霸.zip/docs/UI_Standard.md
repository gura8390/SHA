# 三国争霸 · UI 标准（UI Standard）

> 上位文件：`00_Architecture_Standard.md`（L5 表现层：只读状态，写操作经控制器意图）。
> 本文是**唯一 UI 标准**（原 UI_Standard.md 主题已过时、已删除；本文由 UI.MD v2.0 升格）。
> 主题：墨色漆器 · 描金 · 朱砂 · 宣纸 ｜ 与代码 `src/ui/ui_theme.gd` 一致。
> 实现：所有样式经 `UITheme` 静态方法统一产出，界面禁止就地写死颜色/尺寸。
> 版本：v3.0

## L5 表现层铁律（摘要，详见架构总纲）
- `[MUST]` UI 只读 L1~L4 状态；任何写操作经 `IPlayerController` 返回意图，不直接改战局。
- `[MUST]` UI 监听事件用 `EventBus.observe`（同步通知，优先级 -50），**不得** await、不得改状态。
- `[MUST]` 触发技/响应弹窗经 `HumanController` 信号驱动异步等待（见 `AI_Standard.md` 第六章）。

---

## 第一部分：设计令牌（Design Tokens）

这是整套系统的「原子层」，所有界面只能引用这里的值，不允许就地写死颜色或尺寸。

### 1.1 色彩令牌

```gdscript
class_name UITheme

# ── 背景层次：靠明度差建立纵深，三档明显拉开 ──
const BG_DEEP     = Color(0.08, 0.075, 0.085)  # 墨色牌桌（根背景）
const BG_PANEL    = Color(0.135, 0.13, 0.145)  # 深石板面板
const BG_PANEL_HI = Color(0.19, 0.18, 0.20)    # 高亮面板/按钮默认态

# ── 边框与金 ──
const BORDER      = Color(0.52, 0.43, 0.27)    # 古铜描金边（常规）
const GOLD        = Color(0.83, 0.68, 0.40)    # 高亮描金（标题/重点/选中）

# ── 强调 ──
const ACCENT      = Color(0.78, 0.22, 0.18)    # 朱砂（主按钮/指向/危机）
const ACCENT_DIM  = Color(0.58, 0.19, 0.16)    # 暗朱砂（按下态）

# ── 文字：暖白，不用纯白 ──
const TEXT        = Color(0.92, 0.89, 0.83)    # 主文字（米白）
const TEXT_DIM    = Color(0.60, 0.58, 0.55)    # 次文字/禁用提示

# ── 状态色：提亮以适配深底 ──
const DANGER      = Color(0.86, 0.28, 0.24)
const OK          = Color(0.42, 0.72, 0.46)
const WARN        = Color(0.85, 0.70, 0.30)    # 受损中间态（黄）

# ── 卡牌：染色旧纸，明度统一压在 ~0.8 ──
const CARD_BASIC  = Color(0.90, 0.86, 0.77)    # 暖宣纸（基本牌）
const CARD_TRICK  = Color(0.83, 0.79, 0.85)    # 黛紫旧纸（锦囊）
const CARD_EQUIP  = Color(0.79, 0.83, 0.79)    # 旧青纸（装备）

# ── 罩层 ──
const SCRIM       = Color(0.0, 0.0, 0.0, 0.70) # 覆盖面板半透黑罩
```

色彩使用铁律：

- 深底 + 描金 + 朱砂三者权重为 80% / 15% / 5%，朱砂只给「最该被点的那一个」按钮或最危急的状态。
- 任何界面的暖色（金/朱砂）面积不超过画面 1/5，留白靠墨底。
- 文字一律 `TEXT` / `TEXT_DIM`，不允许纯白纯黑。

### 1.2 字体令牌

```gdscript
# 字体族
const FONT_SERIF = preload("res://assets/fonts/NotoSerifCJKsc-Bold.otf")   # 书法/衬线：标题、武将名、数字
const FONT_SANS  = preload("res://assets/fonts/NotoSansCJKsc-Regular.otf") # 黑体：正文、按钮、UI

# 字号
const FS_TITLE = 64   # 主标题（书法体）
const FS_HEAD  = 32   # 大标题（书法体）
const FS_SUB   = 22   # 副标题/武将名（书法体）
const FS_BODY  = 18   # 正文（黑体）
const FS_SMALL = 14   # 辅助（黑体）

# 字体分配规则（make_label 内部据此自动选族）
# size >= FS_SUB        → FONT_SERIF
# size <  FS_SUB        → FONT_SANS
# 例外：所有数字弹出（伤害/治疗/体力）强制 FONT_SERIF
```

### 1.3 间距与圆角令牌

```gdscript
# 8px 基准网格
const SP_XS = 4
const SP_S  = 8
const SP_M  = 16   # 面板内边距默认
const SP_L  = 24   # 分区间距
const SP_XL = 32
const SP_XXL = 48

# 圆角（中式偏方正）
const RADIUS      = 6
const RADIUS_CARD = 6

# 投影
const SHADOW_COLOR  = Color(0, 0, 0, 0.35)
const SHADOW_OFFSET = Vector2(0, 4)
const SHADOW_SIZE   = 6
```

---

## 第二部分：核心样式工厂（UITheme 方法）

所有控件必须由这些方法产出，保证零样式漂移。

### 2.1 panel_style — 面板样式

```gdscript
# 标准面板：填充 + 描金边 + 向下投影
static func panel_style(
        bg: Color = BG_PANEL,
        border: Color = BORDER,
        radius: int = RADIUS,
        with_shadow: bool = true) -> StyleBoxFlat:
    var sb := StyleBoxFlat.new()
    sb.bg_color = bg
    sb.set_corner_radius_all(radius)
    sb.set_border_width_all(1)
    sb.border_color = border
    sb.content_margin_left = SP_M
    sb.content_margin_right = SP_M
    sb.content_margin_top = SP_M
    sb.content_margin_bottom = SP_M
    if with_shadow:
        sb.shadow_color = SHADOW_COLOR
        sb.shadow_size = SHADOW_SIZE
        sb.shadow_offset = SHADOW_OFFSET
    return sb

# 重点面板：金边，用于结算/标题/设置
static func panel_style_gold() -> StyleBoxFlat:
    return panel_style(BG_PANEL_HI, GOLD, RADIUS, true)
```

重点面板的「四角描金角饰（◣ ◢）」由界面层额外贴 4 个 `TextureRect` 实现，不在 StyleBox 内。

### 2.2 style_button — 按钮四态

```gdscript
# accent=true → 朱砂主按钮；false → 描边次按钮
static func style_button(btn: Button, accent: bool = false) -> void:
    var normal := panel_style(BG_PANEL_HI, BORDER, RADIUS, false)
    var hover  := panel_style(BG_PANEL_HI, GOLD, RADIUS, false)   # hover 边框转金
    var pressed := panel_style(ACCENT_DIM, GOLD, RADIUS, false)
    var disabled := panel_style(BG_PANEL, BORDER, RADIUS, false)

    if accent:
        normal  = panel_style(ACCENT, GOLD, RADIUS, false)
        hover   = panel_style(ACCENT.lightened(0.08), GOLD, RADIUS, false)
        pressed = panel_style(ACCENT_DIM, GOLD, RADIUS, false)

    btn.add_theme_stylebox_override("normal", normal)
    btn.add_theme_stylebox_override("hover", hover)
    btn.add_theme_stylebox_override("pressed", pressed)
    btn.add_theme_stylebox_override("disabled", disabled)
    btn.add_theme_color_override("font_color", TEXT)
    btn.add_theme_color_override("font_disabled_color", TEXT_DIM)
    btn.add_theme_font_override("font", FONT_SANS)
    btn.add_theme_font_size_override("font_size", FS_BODY)
```

### 2.3 make_label / make_button / make_bg

```gdscript
static func make_label(text: String, size: int = FS_BODY,
        color: Color = TEXT) -> Label:
    var lb := Label.new()
    lb.text = text
    lb.add_theme_font_override("font",
        FONT_SERIF if size >= FS_SUB else FONT_SANS)  # 自动选族
    lb.add_theme_font_size_override("font_size", size)
    lb.add_theme_color_override("font_color", color)
    return lb

static func make_button(text: String, accent: bool = false) -> Button:
    var btn := Button.new()
    btn.text = text
    style_button(btn, accent)
    return btn

static func make_bg(color: Color = BG_DEEP) -> ColorRect:
    var cr := ColorRect.new()
    cr.color = color
    cr.set_anchors_preset(Control.PRESET_FULL_RECT)
    cr.mouse_filter = Control.MOUSE_FILTER_IGNORE
    return cr

# 羽化分隔线（两端渐隐，水墨笔触收尾）
static func make_divider(width: int = 200) -> Control:
    # 用 GradientTexture1D：透明→BORDER→透明
    ...
```

### 2.4 覆盖面板骨架（统一入口）

所有弹出面板共用此骨架，只注入内容节点：

```gdscript
# 返回一个全屏 Control：SCRIM 罩 + 居中(或指定位置)金边面板
static func make_overlay(content: Control,
        pos := "center",  # "center" / "bottom" / "right"
        gold := true) -> Control:
    ...
```

---

## 第三部分：逐屏规范

记号：`█墨底  ▓面板  ▒高亮  ═描金  ◆朱砂  □宣纸卡`

### 3.1 主菜单

```
█████████████████████████████████████████████████████████
█                  ░ 淡墨山峦剪影（顶深底隐）░             █
█                    三  國  爭  霸                       █
█                  ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾                      █
█                ╔═══════════════════╗                   █
█                ║     开 始 对 局     ║                   █
█                ╚═══════════════════╝                   █
█                ╔═══════════════════╗                   █
█                ║       设  置        ║                  █
█                ╚═══════════════════╝                   █
█                ╔═══════════════════╗                   █
█                ║       退  出        ║                  █
█                ╚═══════════════════╝                   █
█  v0.3.1                                        ◆印章    █
█████████████████████████████████████████████████████████
```

| 元素 | 规范 |
|------|------|
| 背景 | `make_bg(BG_DEEP)` + 山峦剪影 `TextureRect`（顶 alpha 0.25 → 底 0，垂直渐隐） |
| 标题 | `make_label("三國爭霸", FS_TITLE, GOLD)`，居中偏上（屏高 28% 处） |
| 标题入场 | `AnimHelper.ink_reveal()` 从左到右晕染，1.2s |
| 按钮组 | 竖排居中，宽 280px，间距 `SP_M`，`make_button(...)` 非 accent |
| 印章 | 右下角 `TextureRect`，朱砂 alpha 0.5，旋转 -8° |
| 版本号 | 左下角 `make_label(v, FS_SMALL, TEXT_DIM)` |
| 音效 | 进场 `game_start`，按钮点击 `button_click` |

### 3.2 设置 / 暂停面板

```
█▓▒░ 背景压暗 SCRIM ░▒▓████████████████████████
█        ╔════════════════════════════════╗    █
█        ║◣            设  置            ◢║    █
█        ║  BGM 音量   ●━━━━━━━━○────  72  ║    █
█        ║  音效 SFX   ●━━━━━━━━━━━○──  85 ║    █
█        ║  AI 速度    ●━━━━○─────────  40 ║    █
█        ║   ┌──────────┐  ┌──────────┐  ║    █
█        ║   │  继 续    │  │ 返回主菜单 │  ║    █
█        ║   └──────────┘  └──────────┘  ║    █
█        ╚════════════════════════════════╝    █
█████████████████████████████████████████████
```

| 元素 | 规范 |
|------|------|
| 骨架 | `make_overlay(content, "center", gold=true)` |
| 标题 | `make_label("设置", FS_HEAD, GOLD)` + 四角角饰 |
| 每行 | `HBoxContainer`：标签(左,固定120) + `HSlider`(expand) + 数值(右,固定40) |
| 滑块 | 轨道 `BORDER`，grabber 区 `ACCENT`，grabber 头描金圆 |
| 按钮 | 「继续」非 accent；「返回主菜单」边框 `DANGER`（自定义 stylebox） |
| 进场 | `pop_in` 0.25s；罩层 `fade_in` |

### 3.3 对局主界面

```
┌─────────────────────────────────────────────────────────────┐
│ ▓ 出牌阶段        │      [日志] 🂠38 [设置] ▓                  │
├─────────────────────────────────────────────────────────────┤
│█          ②张飞      ③吕蒙      ④司马懿                     █│
│█          ┌──────┐  ┌──────┐  ┌──────┐                     █│
│█          │❤❤❤❤  │  │❤❤❤   │  │❤❤❤❤❤ │                     █│
│█          └──────┘  └──────┘  └──────┘                     █│
│█  ⑤      ╭ ··· 描金回纹圆环 ··· ╮      ⑥                    █│
│█┌──────┐ ·    [ 请 选 择 目 标 ]   ·  ┌──────┐              █│
│█│ 黄 月 │ ·        (主舞台)        ·  │ 貂 蝉 │              █│
│█└──────┘ ╰ ······················· ╯  └──────┘              █│
├─────────────────────────────────────────────────────────────┤
│ ▓技能▓  ┌─手牌滚动区──────────────┐  ┌操作──┐                │
│ ┌────┐  │ ╱□╲ ╱□╲ ╱▣╲ ╱□╲ ╱□╲  │  │结束 │                │
│ │武圣│  │ □杀 □闪 □桃 □无 □顺   │  │出牌 │                │
│ └────┘  └─────────────────────────┘  │确认◆│  ① 关羽(我)    │
└─────────────────────────────────────────────────────────────┘
```

布局节点树（沿用原规范，标注样式）：

```
根 MarginContainer (margin = SP_M)  ← make_bg(BG_DEEP) 铺底
└── VBoxContainer (separation = SP_L)
    ├── 顶部信息条 HBox (固定高 48, panel_style)
    │   ├── 阶段标签 (make_label FS_BODY)
    │   ├── Spacer (expand)
    │   ├── 日志按钮 / 🂠牌堆数标签 / 设置按钮
    ├── 中央牌桌区 Control (expand-fill)
    │   ├── 描金回纹圆环 (TextureRect, 居中, alpha 0.3)
    │   ├── AI 座位面板 ×N (环形布局，见 3.4)
    │   └── 提示药丸 (顶部居中)
    └── 底部操作区 VBox (min 240)
        └── HBox
            ├── 技能列 VBox (固定 110)
            ├── 手牌滚动区 ScrollContainer (expand, 弧形排布)
            └── 操作按钮区 VBox (固定 130)
```

| 元素 | 规范 |
|------|------|
| 回纹圆环 | 居中 `TextureRect`，描金 alpha 0.3，标记主舞台 |
| 提示药丸 | 半透深底 + 1px 描金边，圆角=高/2；文字 `typewriter` |
| 牌堆数 | 小卡背图标 `🂠` + 数字，`make_label FS_BODY` |

### 3.4 座位面板（含座位号 — 本次新增）

```
当前行动者(金脉冲)        普通AI座位            濒死              阵亡
╔══════════════╗      ┌──────────────┐   ┌──────────────┐  ┌ ─ ─ ─ ─ ─ ┐
║①关 羽  [魏]◆ ║      │②张 飞   [魏] │   │⑥貂 蝉   [蜀] │  ·④司马懿 翻开·
║  ↑座位号 身份 ║      │ ↑座位 ↑身份  │   │              │  · ╳ 已阵亡 ·
║ ❤ ❤ ♡ ♡      ║      │ 4/4          │   │ ◆(呼吸闪)    │  · 身份:反贼 ·
║ 🂠 ×4         ║      │ 🂠 ×3        │   │ 1/4 朱砂      │  └ ─ ─ ─ ─ ─ ┘
║ ┌──┐┌──┐    ║      │ ┌──┐         │   │ 🂠 ×2        │
║ │马││刀│    ║      │ │盾│         │   │              │
║ └──┘└──┘    ║      │ └──┘         │   │              │
║ 判定: ┄┄      ║      │ 判定:⚡乐    │   │ 判定: ┄┄     │
╚══════════════╝      └──────────────┘   └──────────────┘
```

座位面板信息位（自上而下、自左而右）：

| 位置 | 内容 | 规范 |
|------|------|------|
| 左上角 | 座位号 `①②③…` | 描金小圆标，`FS_SMALL` GOLD，圆底 `BORDER`，直径 22px。新增项，AI 与人类统一 |
| 右上角 | 身份印章 | 明=朱砂印 / 暗=灰印 / 死亡=翻开真实身份。`TextureRect` 印章纹 |
| 标题行 | 武将名 | `make_label(name, FS_SUB)` 书法体暖白 |
| 体力行 | 人类=心形排；AI=「当前/上限」数字 | 心形：满 `OK`、空 `TEXT_DIM` 描边；数字按比例 `OK→WARN→DANGER`；濒死(≤1)朱砂呼吸闪 |
| 手牌行 | `🂠 ×N` | 小卡背 + 数字 |
| 装备区 | 武器/防具/±1马 槽位 | 空位描金虚线框；有牌显微缩卡 |
| 判定区 | 延时锦囊 | 空 `┄┄`；有牌显图标(⚡乐/闪电) |

座位号常量与生成：

```gdscript
const SEAT_GLYPHS = ["①","②","③","④","⑤","⑥","⑦","⑧"]

# 在座位面板构建时：
var seat_badge := make_label(SEAT_GLYPHS[seat_index], FS_SMALL, GOLD)
# 套描金圆底 panel_style(BORDER, GOLD, radius=11)，固定 22×22，锚定左上角
```

状态机视觉：

| 状态 | 边框 | 动画 |
|------|------|------|
| 普通 | `BORDER` | 无 |
| 当前行动 | `GOLD` | `seat_pulse_border` 金脉冲 |
| 濒死 (HP≤1) | `BORDER` | 体力区朱砂呼吸闪 + `screen_shake`(触发时) |
| 阵亡 | 虚线灰框 | 整面板降至 alpha 0.45 去饱和，身份翻开 |

体力变化时序：`hp_bar_smooth` / `number_roll` 过渡 + `damage_popup`(朱砂上跳) / `heal_popup`(绿上浮)。

### 3.5 CardView 卡牌（120×170）

```
基本牌(暖纸)   锦囊(黛紫)    装备(旧青)    不可出(灰50%)
╔═════════╗   ╔═════════╗  ╔═════════╗  ┌ ─ ─ ─ ┐
║♥ 7      ║   ║♠ K      ║  ║♦ A      ║  ┊♣ 2    ┊
║   杀    ║   ║ 无中生有 ║  ║ 青釭剑  ║  ┊  闪   ┊
║基础攻击 ║   ║摸两张牌  ║  ║ +1距离  ║  ┊       ┊
╚═════════╝   ╚═════════╝  ╚═════════╝  └ ─ ─ ─ ┘
```

| 项 | 规范 |
|------|------|
| 尺寸 | `CARD_SIZE = Vector2(120, 170)`，圆角 `RADIUS_CARD` |
| 底色 | 按类型 `CARD_BASIC/TRICK/EQUIP` + 1px 描金边 |
| 花色点数 | 左上角；红桃/方块用 `ACCENT`，黑桃/梅花用近墨 `Color(0.15,0.15,0.17)` |
| 卡名 | 居中 `make_label(name, FS_SUB)` 书法体 |
| 描述 | 底部 `make_label(desc, FS_SMALL, TEXT_DIM)` |
| 选中 | Y -20 + 缩放 1.05 (TRANS_BACK) + `GOLD` 外发光描边 |
| hover | 缩放 1.08 上浮，邻卡让位 |
| 不可出 | modulate alpha 0.5 + 去饱和（着色到灰），禁点击 |
| 排布 | 手牌微弧形（中间高两端低，旋转 ±2°/张），像真人持牌 |

信号：`card_clicked(CardData)` / `card_hovered(CardData)` / `card_unhovered(CardData)`。

### 3.6 覆盖面板（统一骨架）

全部经 `make_overlay`，共用 SCRIM + 金边面板，只换内容与弹出位。

```
【响应面板】底部 slide_up           【选牌面板】中央
█▒░░░░░░░░░░░░░░░░░░░░░▒█        █▒░░░░░░░░░░░░░░░░░░░░░▒█
█  ╔════════════════════╗ █       █  ╔══ 拆 司马懿 的牌 ══╗ █
█  ║ 张飞对你使用【杀】  ║ █       █  ║ 手牌(背): ▣▣▣▣ ←金║ █
█  ║ 是否打出【闪】?     ║ █       █  ║ 装备: □马 □刀  ←亮 ║ █
█  ║ │打出◆││跳过││全跳│║ █       █  ║ 判定: ⚡乐     ←亮 ║ █
█  ╚════════════════════╝ █       █  ╚════════════════════╝ █
██████████████████████████       ██████████████████████████
```

| 面板 | 触发信号 | 位置 | 内容与按钮 |
|------|----------|------|-----------|
| 响应面板 | `response_requested` | bottom (slide_up) | 提示 `typewriter` + 打出(accent)/跳过/全部跳过 |
| 选牌面板 | `card_pick_requested` | center | 按手牌/装备/判定分区，可点描金、不可点灰 |
| 日志面板 | 日志按钮 | right (抽屉滑出) | `RichTextLabel`；伤害朱砂/治疗绿/技能金 |
| 结算面板 | `game_over` | center (scene_transition) | 胜方大标题 + 印章动画 + 身份存活列表 + 再来一局(accent)/返回 |
| 技能提示 | hover 技能按钮 | 跟随鼠标 | 名(GOLD)+类型标签+描述+剩余次数；深底金边 |
| 暂停面板 | 设置按钮 | center | 见 3.2 |

```
【日志面板】右侧抽屉              【结算面板】最隆重
████████████████┌──────────┐    █████████████████████████████
█   牌桌(推暗)   │═ 对局日志 │    █     ╔═══════════════════╗  █
█               │◆张飞 受伤2│    █     ║◣  魏 国 胜 利    ◢║  █
█               │ 关羽 摸2张 │    █     ║    ◆ 印章盖下     ║  █
█               │█技能:咆哮  │    █     ╠═══════════════════╣  █
█               │ 貂蝉 回血1 │    █     ║①关羽[主公] 存活   ║  █
████████████████└──────────┘    █     ║②张飞[忠臣] 阵亡   ║  █
                                █     ║ │再来一局◆││返回 │║  █
                                █     ╚═══════════════════╝  █
                                █████████████████████████████
```

---

## 第四部分：动画规范

### 4.1 AnimHelper 调性约定

| 分类 | 方法 | 视觉调性 |
|------|------|---------|
| 过渡 | `fade_in/out`, `slide_*`, `pop_in/out` | 时长 0.2~0.3s，缓动 TRANS_QUAD/BACK |
| 按钮 | `btn_hover_enter/exit`, `click_ripple` | hover 边框转金；ripple 朱砂扩散 |
| 文字 | `typewriter`, `ink_reveal`, `number_roll` | ink_reveal 用于标题；typewriter 用于提示 |
| 卡牌 | `card_fly/dissolve/flip` | fly 走贝塞尔曲线；dissolve 墨色溶解 |
| 战斗 | `damage_popup/heal_popup/skill_popup` | 伤害朱砂上跳、治疗绿上浮、技能名书法体描金底 |
| 战斗 | `center_announce/screen_shake` | 全屏公告书法体；shake 仅濒死/重大事件 |
| 战斗 | `seat_pulse_border/equip_flash/aoe_ripple` | 金脉冲/装备金闪/中心墨色涟漪 |
| 转场 | `scene_transition/hp_bar_smooth` | 转场水墨推拉；血条平滑插值 |

### 4.2 事件→动画接入表

| 事件 | 动画 | 优先级 |
|------|------|--------|
| `DAMAGE_AFTER` | `damage_popup` + (濒死)`screen_shake` | -190 |
| `HEAL_AFTER` | `heal_popup` | -190 |
| `CARD_TARGETED` | 金色 Line2D 指向线 + 箭头 | -150 |
| `SKILL_RESOLVED` | `skill_popup` | -180 |
| `PLAYER_DYING` | `screen_shake` + 朱砂暗角 | -185 |
| `EQUIP_INSTALLED` | `equip_flash` 金光 | -200 |
| `CARD_RESOLVED`(AOE) | `aoe_ripple` 墨色涟漪 | -200 |

---

## 第五部分：音效规范

```gdscript
# AudioManager（Autoload，8 路 AudioStreamPlayer 池）
AudioManager.play_sfx("card_play")
AudioManager.stop_all()
```

| 音效名 | 触发时机 |
|--------|----------|
| `card_play` / `card_draw` / `card_discard` | 出牌 / 摸牌 / 弃牌 |
| `damage` / `heal` / `dying` / `death` | 受伤 / 回血 / 濒死 / 死亡 |
| `skill_activate` / `equip` | 技能发动 / 装备 |
| `game_start` / `turn_start` | 游戏开始 / 回合开始 |
| `button_click` / `target_line` | 按钮点击 / 选目标 |

---

## 第六部分：开发规范

### 6.1 新增界面

1. 在 `src/ui/` 建脚本，`scenes/ui/` 建场景（或纯代码）。
2. 背景 `UITheme.make_bg()`，面板 `panel_style()`，控件 `make_*`，弹窗 `make_overlay()`。
3. 颜色/字号/间距只引用第一部分令牌，禁止就地写死。
4. 通过 `EventBus` 监听事件刷新显示。

### 6.2 新增动画

1. `AnimHelper` 加静态方法（遵守 4.1 调性）。
2. `battle_table._connect_event_bus()` 订阅事件。
3. 回调内调用并传节点引用，设好优先级。

### 6.3 新增音效

1. `.wav` 放 `assets/audio/sfx/`。
2. `AudioManager.SFX_MAP` 加映射。
3. 事件回调内 `AudioManager.play_sfx("name")`。

### 6.4 交互模式（Mode）

| 模式 | 用户操作 |
|------|----------|
| `IDLE` | 无（非人类时段） |
| `PLAY_SELECT_CARD` | 点手牌 / 技能 / 结束出牌 |
| `PLAY_SELECT_TARGET` | 点高亮座位（多目标+确认） |
| `DISCARD_SELECT` | 点手牌选/取消 + 确认 |
| `RESPONSE` | 打出 / 跳过 / 全部跳过 |
| `CARD_PICK` | 点目标区域的牌 |

信号流：`HumanController 请求 → battle_table 回调 → 切 Mode → 显示 UI → 用户操作 → battle_table 处理 → submit_* → 恢复 Mode`。

---

## 验收清单

落地后逐项核对，确保「同一种语言」：

- [ ] 全界面背景 `BG_DEEP`，面板与背景明度差肉眼可分（三档层次）
- [ ] 暖色（金/朱砂）总面积 ≤ 1/5，朱砂只给最该点的按钮
- [ ] 标题/武将名/数字为书法体，正文为黑体
- [ ] 所有面板有 1px 描金边 + 向下投影
- [ ] 每个座位左上角显示座位号 ①②③…（含人类）
- [ ] 体力：人类心形、AI 数字，均按健康度染色，濒死朱砂呼吸闪
- [ ] 卡牌为压低明度的「旧纸」三色，非糖果色
- [ ] 所有覆盖面板共用 SCRIM + 金边骨架
- [ ] 不可出的牌灰掉去饱和且禁点

