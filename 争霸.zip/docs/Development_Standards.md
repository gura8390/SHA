# 三国争霸 · 开发与命名规范（Development Standards）

> 上位文件：`00_Architecture_Standard.md`。本文定义工程结构、GDScript 命名、注释、
> 版本控制规范。**目录结构以本文为准（已对齐重写后真实工程）。**
> 版本：v3.0

---

## 一、项目目录结构（真实工程）

```
D:\codex\争霸\
├── project.godot
├── assets/                 # 静态资源
│   └── audio/sfx/          # 音效（已接入）；bgm/ 预留
├── data/                   # JSON 数据
│   ├── cards/              # 卡牌定义
│   └── heroes/             # 武将定义
├── docs/                   # 文档（标准 + 路线 + 参考）
├── resources/              # .tres 预留
├── scenes/
│   ├── ui/                 # title/main_menu/settings/game_setup
│   ├── game/               # battle_table
│   └── cards/              # card_view
└── src/                    # 见 00_Architecture_Standard.md 第八章分层
    ├── core/   managers/   data/
    ├── effects/ actions/   cards/
    ├── skills/ (equip/)    ai/   ui/
```

> 分层与依赖方向（L1~L5）以 `00_Architecture_Standard.md` 为准。
> 已注册 Autoload：`EventBus` / `SettingsManager` / `GameSetup` / `JsonDataLoader` / `AudioManager`。
> `GameManager` 为对局场景内子节点（非 autoload）。

---

## 二、GDScript 命名规范

| 元素 | 规则 | 例 |
|------|------|----|
| 类名 `class_name` | PascalCase | `CardData` `TurnSystem` |
| 变量 / 函数 | snake_case | `current_hp` `draw_cards()` |
| 私有 | `_` 前缀 | `_draw_pile` `_shuffle()` |
| 布尔 | `is_/has_/can_` | `is_alive` `can_trigger` |
| 回调 | `_on_` | `_on_card_played` |
| 常量 | UPPER_SNAKE | `MAX_PLAYERS` |
| 枚举类型/值 | PascalCase / UPPER_SNAKE | `enum CardType { BASIC, TRICK }` |
| 文件 | snake_case.gd / .tscn | `game_manager.gd` |
| 节点 | PascalCase | `HandPanel` |
| 信号 | snake_case，过去式(已发生)/原形(请求) | `card_played` / `response_requested` |

---

## 三、注释规范

### 3.1 文件头（一句话职责）
```gdscript
# ============================================================
# turn_system.gd
# 回合引擎：迭代驱动回合与四阶段流转
# ============================================================
```

### 3.2 注释写"为什么"，不写"改了什么"
`[MUST]` 不再使用历史流水账 `# Gemini:change.N: ...`。注释解释意图、不变量、边界。
公共 API 用 `##` 文档注释（Godot 可识别）。

```gdscript
## 从牌堆顶摸一张牌。牌堆空时自动回收弃牌堆并洗牌（RngService）。
## 返回 null 仅当抽+弃都空（极端情况）。
func draw_from_pile() -> CardData:
    var drawn = _draw_pile.pop_back()  # 顶部 = 数组末尾
```

---

## 四、版本控制规范

### 4.1 .gitignore
```
.godot/
*.import
Thumbs.db
.DS_Store
.vscode/
```

### 4.2 提交信息
```
<类型>(<范围>): <简述>
类型: feat / fix / refactor / docs / test / chore
范围: core / effects / cards / skills / ai / ui / data / docs
```
例：`refactor(core): EventBus 拆分 notify/dispatch 双通道`

### 4.3 分支
- `[SHOULD]` 默认分支不直接提交；功能用 `feat/<topic>`、修复用 `fix/<topic>` 分支。
- 大型重构按里程碑分支，合入前过审核清单（各标准末章）。

---

## 五、死代码与归档
- `[MUST]` 不参与构建的脚本目录加 `.gdignore`（如 `src/skills/_archived/`），
  避免带 `class_name` 的存根污染全局类缓存。
- `[SHOULD]` 长期无用的归档直接删除，依赖 Git 历史而非保留死文件。

---

## 六、审核清单（工程规范）
- [ ] 目录/分层符合本文与架构总纲
- [ ] 命名符合第二章
- [ ] 无 `Gemini:change.N` 流水注释；公共 API 有 `##` 注释
- [ ] 提交信息符合格式；大改走分支
- [ ] 非构建目录有 `.gdignore`
