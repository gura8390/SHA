# 三国争霸 · 游戏流程标准（Game Flow Standard）

> 上位文件：`00_Architecture_Standard.md`。本文定义对局生命周期、回合/阶段引擎、
> 身份系统、胜负判定、牌堆管理。回合引擎在重写后从 GameManager 抽出为
> `TurnSystem` / `PhaseSystem`。
> 版本：v3.0（含原 Architecture_Review 身份设计）

---

## 一、对局生命周期

```
配置(GameSetup) → 装配(GameManager.setup_game) → 进行(TurnSystem.run) → 结束(胜负判定)
```

- **配置**：人数(4~12)、人类武将、明/暗身份，存 `GameSetup`(Autoload) 跨场景传递。
- **装配**：建 `BattleContext`/`CardLocationRegistry`/`RngService`/`ActionQueue`/
  `DeckManager`/`CardResolver`/`DeathResolver`/`JudgeSystem`/`TriggerBroker`/
  `TurnSystem`/`PhaseSystem`/控制器；分配身份与武将；建牌堆、发初始 4 张；装技能。
- **进行**：`TurnSystem` 迭代驱动回合（铁律 9：不用 `await process_frame` 当节拍器）。
- **结束**：胜负判定 → `game_over` 信号 → UI 结算面板。

`[MUST]` 装配顺序保证：信号连接早于第一回合发起（避免旧"开局死锁"）。

---

## 二、回合 / 阶段引擎

### 2.1 TurnSystem（迭代，非递归）

```
run():
  while not game_over and turn < MAX_ROUNDS:
      p = current_alive_player
      若翻面：翻回正面、跳过本回合
      turn_index += 1; p.reset_turn_state()
      await dispatch(TURN_START)
      for phase in [JUDGE, DRAW, PLAY, DISCARD]:
          await PhaseSystem.run(p, phase)
          if game_over: return
      await dispatch(TURN_END)
      advance_to_next_alive()
```

`[MUST]` 用循环推进，不在结尾递归调用自身；不用帧轮询当节拍。

### 2.2 四阶段
| 阶段 | 核心 |
|------|------|
| 判定 | 逆序结算判定区延时锦囊（规则在各 CardEffect，**不在** GameManager） |
| 摸牌 | `DrawCardEffect` 摸 2（兵粮寸断可跳过） |
| 出牌 | 循环 `await controller.decide_play_action` → `PlayCardEffect`/技能发动（上限 50） |
| 弃牌 | 超手牌上限部分 `DiscardCardEffect(PHASE_DISCARD)` |

每阶段始/末 `await dispatch(PHASE_START/END, {phase})`。技能监听 `PHASE_START` +
按 `phase` 枚举（**非魔法数字**）过滤。

### 2.3 出牌阶段意图
| 意图 | 判断 | 处理 |
|------|------|------|
| 结束 | `is_end_play()` | break |
| 技能发动 | `is_skill_activation()` | `await skill.activate(ctx)` |
| 使用牌 | 默认 | `await PlayCardEffect`（统一生命周期） |

---

## 三、身份系统（原 Architecture_Review 并入）

### 3.1 四身份与胜利条件
| 身份 | 说明 | 胜利 |
|------|------|------|
| 主公 LORD | 座位 0，体力上限 +1 | 消灭所有反贼与内奸 |
| 忠臣 LOYALIST | 保护主公 | 同主公阵营 |
| 反贼 REBEL | 推翻主公 | 主公死亡（场上仍有反贼） |
| 内奸 TRAITOR | 笑到最后 | 清空反贼后仅剩内奸收主公 |

### 3.2 标准配置表（主公恒 1）
| 人数 | 忠 | 反 | 内 |  | 人数 | 忠 | 反 | 内 |
|---|---|---|---|---|---|---|---|---|
| 4 | 1 | 2 | 0 | | 9 | 3 | 4 | 1 |
| 5 | 1 | 2 | 1 | | 10 | 3 | 5 | 1 |
| 6 | 1 | 3 | 1 | | 11 | 3 | 6 | 1 |
| 7 | 2 | 3 | 1 | | 12 | 4 | 6 | 1 |
| 8 | 2 | 4 | 1 | | | | | |

### 3.3 分配与可见性
- `Identity.assign(count)`：座位 0 主公；其余按表入池 → `rng.shuffle()` → 依次分配。
  `[MUST]` 用 `RngService`（铁律 9），不用裸 `Array.shuffle()`。
- 明局：开局全公开；暗局：仅主公公开，其余显示「？」，**死亡时翻开**。人类始终见己方身份。

### 3.4 胜负判定（每回合末 + 死亡后）
```
主公死: 有反贼→反贼胜; 仅剩内奸→内奸胜; 否则无胜者(极端)
主公存活: 反贼与内奸清空→主公阵营胜
```
结算时翻开全部身份，`game_over` 携带 `{winner_camp, winner_name, winners[]}`。

### 3.5 击杀奖惩
杀反贼→击杀者摸 3 张；主公杀忠臣→主公弃所有手牌与装备；其余无。

### 3.6 AI 身份倾向
身份未公开取中性；公开后按敌我矩阵给目标打分（详见 `AI_Standard.md`）。

---

## 四、牌堆管理（单一真值，见 Card_Standard.md）

- 区域：`DRAW_PILE / DISCARD_PILE / HAND / EQUIP / JUDGE / PROCESSING`，
  全部由 `CardLocationRegistry` 持有，唯一入口 `move_card`。
- 摸牌耗尽：`draw_from_pile` 自动把弃牌堆整体转为抽牌堆并 `rng.shuffle()`。
- `[MUST]` 每回合末断言**牌守恒**与**单所有权**（`debug_validate`）。

---

## 五、关键常量
| 常量 | 值 | 说明 |
|------|----|------|
| `MAX_ROUNDS` | 200 | 死循环硬上限 |
| `MAX_PLAYS_PER_TURN` | 50 | 单回合出牌上限 |
| 初始手牌 | 4 | 开局每人 |

---

## 六、审核清单（流程层）
- [ ] 回合用迭代推进，无递归自调、无帧轮询节拍
- [ ] 阶段事件经 `dispatch`；技能按 `phase` 枚举过滤（非魔法数字）
- [ ] 延时锦囊规则在 CardEffect，不在 GameManager
- [ ] 身份分配用 RngService；胜负判定覆盖主公死/存活分支
- [ ] 每回合末牌守恒 / 单所有权断言通过
