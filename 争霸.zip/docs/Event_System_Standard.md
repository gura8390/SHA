# 三国争霸 · 事件系统标准（Event System Standard）

> 上位文件：`00_Architecture_Standard.md`（铁律 2/3/4/7 与固定优先级表）。
> 本文定义事件对象 `GameEvent`、双通道事件总线 `EventBus`、触发管道 `TriggerBroker`
> 与全部事件类型。**这是内核重写的核心，旧的"纯同步广播"已废弃。**
> 版本：v3.0

---

## 一、为什么是双通道（设计动机）

旧内核的根本缺陷：`EventBus.publish()` 是**同步广播**，但技能反应需要**异步等待**
（人类弹窗、响应链、濒死求桃、嵌套结算）。同步通道里 `await` 无人接管 → "断链"、
顺序错乱、人类触发技无法弹窗。

新内核把事件拆成两条语义清晰的通道：

| 通道 | 方法 | 同异步 | 用途 | 回调可否 await / 改状态 |
|------|------|--------|------|------------------------|
| **通知** | `EventBus.notify(event)` | 同步 | 纯观察：UI 刷新、日志、计数 | ❌ 不可 await，❌ 不可改状态 |
| **反应** | `await EventBus.dispatch(event)` | 异步 | 触发技、响应链、拦截/改值 | ✅ 可 await，✅ 经 Effect 改状态 |

`[MUST]`：会引发玩家决策或嵌套结算的时机，**必须**用 `dispatch` 并 `await`。
纯展示用 `notify`。**禁止**在 `notify` 回调里 await 或建 Effect。

---

## 二、GameEvent 数据结构

```gdscript
class_name GameEvent
extends RefCounted

var event_id: int = -1          ## [MUST] 全局唯一自增（由 EventBus 分配）
var parent_event_id: int = -1   ## [MUST] 父事件 ID，根事件为 -1
var event_type: Type            ## 事件类型枚举
var source: int = -1            ## 来源玩家索引（-1=系统）
var target: int = -1            ## 目标玩家索引（-1=无）
var data: Dictionary = {}       ## 附加上下文
var is_cancelled: bool = false  ## 仅 *_BEFORE 类可被置 true
var stage: Stage = Stage.AFTER  ## BEFORE / EXECUTE / AFTER / RESOLVED
```

### 2.1 创建与因果链（铁律 2）

```gdscript
# 根事件
var ev := GameEvent.create(GameEvent.Type.CARD_USED, src, tgt, {...})

# 由某事件派生的子事件：必须串父 ID
var dmg := GameEvent.create(GameEvent.Type.DAMAGE_BEFORE, src, tgt, {...}, parent=ev)
```

`EventBus` 在分发时若发现 `event_id == -1` 自动分配；`create(..., parent)` 自动写
`parent_event_id = parent.event_id`。**禁止**手工复用旧 ID。

### 2.2 stage 字段（铁律 3 生命周期）

| stage | 含义 | 可取消 | 典型 |
|-------|------|:----:|------|
| `BEFORE` | 即将发生，可拦截/改值 | ✅ | `DAMAGE_BEFORE` |
| `EXECUTE` | 正在写状态（内部） | ❌ | — |
| `AFTER` | 已发生，仅触发后续 | ❌ | `DAMAGE_AFTER` |
| `RESOLVED` | 整条结算链结束 | ❌ | `CARD_RESOLVED` |

`[MUST]`：在 `AFTER`/`RESOLVED` 阶段**禁止**取消操作；在 `BEFORE` 阶段**禁止**改写已完成状态。

---

## 三、EventBus（双通道总线）

### 3.1 订阅

```gdscript
# 通知订阅（同步、纯观察）
EventBus.observe(event_type, callback, priority, owner)

# 反应订阅（异步、可触发技能/响应）
EventBus.react(event_type, async_callback, priority, owner)
```

- `priority` **必须**取固定档位（见总纲第四章：100/50/10/0/-10/-50/-100）。
- `owner` 用于 `unsubscribe_all(owner)`（技能移除/对局重置时清理）。
- 同档位按**座位顺序**（当前回合角色起顺时针）裁决。

### 3.2 发布

```gdscript
# 同步通知：立即依次调用全部 observe 回调，不 await
func notify(event: GameEvent) -> GameEvent

# 异步反应：依次 await 每个 react 回调；任一回调可改 event 或置 is_cancelled
func dispatch(event: GameEvent) -> GameEvent      # 调用方必须 await
```

`dispatch` 规则 `[MUST]`：
1. 分配 `event_id`；按 priority 降序、同档座位序遍历 react 订阅者**快照**。
2. 逐个 `await callback.call(event)`。回调内对状态的改动一律经 Effect。
3. `*_BEFORE` 事件：高优先级回调可 `event.is_cancelled = true`；后续回调仍会收到，
   自行判断是否跳过。发布方在 `await dispatch` 返回后检查 `is_cancelled`。
4. 失效回调（owner 已释放）自动清理。

### 3.3 禁止事项

- ❌ `notify` 回调里 `await` 或建 Effect。
- ❌ 在同步上下文 `dispatch(...)` 而不 `await`（fire-and-forget，铁律 3）。
- ❌ 直接 `connect` 引擎 Signal 跨层通信（统一走 EventBus / 控制器接口）。

---

## 四、TriggerBroker（触发技管道）

触发技的"是否发动"必须可等待玩家（铁律 4）。`TriggerBroker` 是反应通道之上的协调器。

### 4.1 职责

```
某时机 dispatch(event)
        │
        ▼  Skill.react 回调里，技能判定 can_trigger(event)==true 时，
           不直接 execute，而是向 TriggerBroker 登记一个「待发动触发项」
        ▼
TriggerBroker.resolve(event)            # 由 dispatch 末尾统一 await
        ├── 收集本次 event 所有合法触发项
        ├── 按 优先级 → 座位序 排序
        └── 逐一：
            ├── 锁定技(COMPULSORY)：直接 await skill.execute(ctx)
            └── 可选技：await controller.decide_skill_activation(...)
                         同意 → record_use + await skill.execute(ctx)
```

### 4.2 关键保证

- `[MUST]` 人类玩家的可选触发技通过 `await controller.decide_skill_activation` 弹窗等待，
  AI 同步返回——两者统一在异步管道里，无需分支。
- `[MUST]` 同一事件的多个触发技按固定顺序裁决，结果可复现（铁律 9）。
- `[MUST]` 触发项登记/发动全程 await，杜绝旧内核 `SkillTriggerPipeline` 的同步断链。

---

## 五、事件类型总表

> 铁律 7：精确语义，禁止万能事件。`CARD_LOST`/`CARD_OBTAINED` 已从枚举**移除**。

### 5.1 回合 / 阶段
| 类型 | 时机 | data |
|------|------|------|
| `TURN_START` / `TURN_END` | 回合始/末 | `turn_index` |
| `PHASE_START` / `PHASE_END` | 阶段始/末 | `phase` |

### 5.2 卡牌
| 类型 | stage | 时机 | data |
|------|-------|------|------|
| `CARD_USED` | BEFORE | 声明使用（可被无懈/技能取消） | `card,targets,reason` |
| `CARD_TARGETED` | BEFORE | 成为目标（逐目标） | `card` |
| `CARD_RESOLVED` | RESOLVED | 结算完成 | `card,effect_result` |
| `CARD_CANCELLED` | AFTER | 被无懈/技能取消 | `card,reason` |

### 5.3 牌的位置迁移（由 CardLocationRegistry.move_card 发出）
| 类型 | 含义 | data |
|------|------|------|
| `CARD_DRAWN` | 摸牌入手 | `cards,reason` |
| `CARD_DISCARDED` | 进入弃牌堆 | `cards,reason,source` |
| `CARD_STOLEN` | 被夺取（顺手/反馈） | `card,source,target` |
| `CARD_GIVEN` | 被给予（仁德） | `card,source,target` |
| `CARD_CONSUMED` | 被技能消耗（非入弃堆） | `card,skill_id` |
| `EQUIP_INSTALLED` / `EQUIP_REMOVED` | 装备装/卸 | `card,slot,reason` |
| `JUDGE_CARD_ADDED` | 延时锦囊入判定区 | `card` |

### 5.4 伤害 / 体力
| 类型 | stage | 可取消 | data |
|------|-------|:---:|------|
| `DAMAGE_BEFORE` | BEFORE | ✅ | `amount,damage_type,card,ignore_armor` |
| `DAMAGE_AFTER` | AFTER | ❌ | `amount,damage_type,card,current_hp` |
| `HEAL_BEFORE`/`HEAL_AFTER` | B/A | ✅/❌ | `amount,current_hp` |
| `LOSE_HP_BEFORE`/`LOSE_HP_AFTER` | B/A | ✅/❌ | `amount,current_hp` |

### 5.5 状态 / 生死 / 判定
| 类型 | 时机 | data |
|------|------|------|
| `FLIP_BEFORE`/`FLIP_AFTER` | 翻面 | `face_up` |
| `CHAIN_TOGGLED` | 连环切换 | `is_chained,reason` |
| `PLAYER_DYING` | 濒死 | `damage_source` |
| `PLAYER_DEAD` | 阵亡 | `dead_player,killer` |
| `PLAYER_REVIVED` | 被救回 | `savior` |
| `JUDGE_START`/`JUDGE_RESULT`/`JUDGE_FINISH` | 判定 | `player,judge_card,result` |

### 5.6 响应 / 技能
| 类型 | 时机 | data |
|------|------|------|
| `RESPONSE_REQUESTED`/`RESPONSE_RECEIVED` | 请求/收到响应 | `required,request_id,context` |
| `SKILL_TRIGGERED` | 触发项登记（内部，供 Broker） | `skill,original_event` |
| `SKILL_RESOLVED` | 技能结算完成 | `skill_id,skill_name,effect` |

---

## 六、审核清单（事件层，强制）

- [ ] 每个 `GameEvent` 经总线分配了 `event_id`；派生事件串了 `parent_event_id`
- [ ] 会等待的时机用 `await dispatch`，纯展示用 `notify`
- [ ] `notify` 回调无 await、无状态变更
- [ ] 触发技经 `TriggerBroker` 异步裁决（人类可弹窗），未在同步回调里 execute
- [ ] `subscribe.priority` 取固定档位，同档座位序
- [ ] 未使用 `CARD_LOST/CARD_OBTAINED`；牌位置迁移事件由 `move_card` 统一发出
- [ ] `*_BEFORE` 才检查/置 `is_cancelled`，发布方 await 后检查
- [ ] 技能/对象释放时 `unsubscribe_all(owner)`
