# 三国争霸 · 文档索引与项目现状

> 项目：三国争霸（三国背景纯单机卡牌策略）
> 引擎：Godot v4.6.3 ｜ 语言：GDScript
> 最近更新：2026-06-17（内核重写基线 v3.0）

本文件是文档总入口与「当前真实进度」快照。内核正按 v3.0 标准激进重写中。

---

## 一、文档清单

| 文档 | 类别 | 内容 |
|------|------|------|
| `README.md`（本文件） | 索引/进度 | 文档索引 + 真实进度 + 目录结构 |
| **`00_Architecture_Standard.md`** | **标准·根** | 架构总纲：分层、九条铁律、固定优先级、确定性 |
| `Event_System_Standard.md` | 标准 | 双通道事件总线、event_id 因果链、TriggerBroker |
| `Effect_Standard.md` | 标准 | 统一 async Effect 契约、ActionQueue |
| `Card_Standard.md` | 标准 | CardData、**CardLocation 牌位真值**、PlayCardEffect、转化牌 |
| `Skill_Standard.md` | 标准 | SkillContext、五类技能、解耦钩子、Meta 命名空间 |
| `Character_Standard.md` | 标准 | 武将 JSON 规范与审核 |
| `AI_Standard.md` | 标准 | IPlayerController 异步契约、SmartAI、身份评估 |
| `Game_Flow_Standard.md` | 标准 | 回合/阶段引擎、身份系统、胜负、牌堆 |
| `UI_Standard.md` | 标准 | 墨色漆器主题、UITheme、布局/交互/动效 |
| `Development_Standards.md` | 标准 | 目录结构、命名、注释、版本控制 |
| `Technical_Roadmap.md` | 路线 | 三阶段路线图 + 内核重写里程碑 + 架构评审 |
| `Glossary.md` | 参考 | 术语表 |

> 阅读顺序：先 `00_Architecture_Standard.md`（根），再按子系统看对应标准。
> 标准间冲突一律以架构总纲为准。

---

## 二、当前进度快照

### 已实现（旧内核功能基线）
> 这些功能在旧内核上可跑通；正按 v3.0 标准重写底层，功能将逐里程碑迁移。

- 完整单局：动态 4~12 人、回合四阶段、距离/目标校验、濒死求桃、角色死亡、按身份判胜负。
- 身份系统：主公/忠臣/反贼/内奸，标准配置表（4~12），明/暗身份。
- 技能系统：五类技能；**20 名武将全部有技能脚本**（魏蜀吴群全套 +
  关羽武圣/赵云龙胆/诸葛亮知天·武靖·智绝/吕布无双/貂蝉离间·闭月/华佗急救·青囊/袁绍乱击）。
- 装备系统：5 槽位，12 件装备技能全部实现（4 件武器逻辑整合于杀结算）。
- 判定系统 + 延时锦囊（乐/兵/闪电）。
- 全卡牌标准版全集；卡牌(`data/cards`,36)与武将(`data/heroes`,20) JSON 外部化。
- 无懈可击（含连环无懈）、过拆/顺手/五谷选择器。
- UI：墨色漆器主题、容器化布局、对局日志、设置持久化。
- AI：SmartAI（威胁+手牌价值+身份倾向+无懈决策）、HumanController。
- 音效：AudioManager + 12 个 SFX 已接入；动画 anim_helper 已接入。

### 内核重写进行中（v3.0，里程碑详见 Technical_Roadmap.md）
- 🔧 M0 牌位真值 CardLocationRegistry + 事件因果链(event_id) + 数据层去重
- 🔧 M1 双通道事件总线(notify/dispatch) + TriggerBroker（修"人类触发技无法弹窗 / 同步断链"）
- 🔧 M2 统一 async Effect 契约
- 🔧 M3 Skill 基类重写（SkillContext / 解耦核心硬编码 / Meta 命名空间）
- 🔧 M4 回合引擎拆分（TurnSystem/PhaseSystem，GameManager 瘦身）
- 🔧 M5 迁移 20 武将 + 全卡牌；归档死代码加 `.gdignore`
- 🔧 M6 UI/AI 适配异步触发；M7 headless 回归

### 抛光层待做
存档/读档、新手教学、BGM、AI 难度分级、本地化、平衡调优。

---

## 三、目录结构

```
D:\codex\争霸\
├── project.godot
├── data/   cards/(36) heroes/(20)        # JSON 数据
├── docs/                                  # 文档（标准 + 路线 + 参考）
├── resources/                            # .tres 预留
├── scenes/ ui/ game/ cards/
└── src/
    ├── core/      # L1 内核：EventBus/GameEvent/CardLocation/RNG/TurnSystem/TriggerBroker…
    ├── managers/  # BattleContext / DeckManager / GameManager(装配+胜负)
    ├── data/      # CardData/HeroData/SkillData/Identity/JsonDataLoader/HeroPool
    ├── effects/ actions/   # L2 状态变更 + GameAction/ActionQueue/PlayCardEffect
    ├── cards/     # L3 卡牌结算 CardEffect*
    ├── skills/ (equip/)    # L3 技能
    ├── ai/        # L4 SmartAI / HumanController
    └── ui/        # L5 battle_table / card_view / *_screen / ui_theme
```

> 分层与依赖方向以 `00_Architecture_Standard.md` 第八章为准。
> 已注册 autoload：`EventBus` / `SettingsManager` / `GameSetup` / `JsonDataLoader` / `AudioManager`。
> `GameManager` 为对局场景内子节点（非 autoload）。

---

## 四、术语（速查，详见 Glossary.md）

| 术语 | 说明 |
|------|------|
| 开始界面 / 主菜单 / 准备界面 / 游戏界面 / 结算界面 | 五个主要界面 |
| 点将 | 从全武将池指定武将 |
| 回合 / 阶段 | 玩家完整行动周期 / 回合内子步骤（判定/摸牌/出牌/弃牌） |
