# 三国争霸 · 卡牌标准（Card Standard）

> 上位文件：`00_Architecture_Standard.md`（单一真值原则、铁律 1/6/7）。
> 本文定义 `CardData` 结构、**CardLocationRegistry 牌位真值**、卡牌分类、
> `PlayCardEffect` 生命周期、结算路由、转化牌机制。
> 版本：v3.0

---

## 一、CardLocationRegistry（牌位真值 · 本次重写核心）

### 1.1 动机

旧内核没有"牌在哪"的真值，`PlayCardEffect` 靠**遍历全场手牌/装备/判定区**猜测一张牌
是否被技能认领——这是"卡牌泄漏 / 复制 / 凭空消失"系列 bug 的根因。

新内核引入 `CardLocationRegistry`：每张 `CardData` 的位置是唯一、可查询、可校验的真值。

### 1.2 区域模型

```gdscript
enum Zone { DRAW_PILE, DISCARD_PILE, HAND, EQUIP, JUDGE, PROCESSING }
# PROCESSING = 结算中间态（已离开原区、尚未入目标区）
```

```gdscript
class_name CardLocationRegistry
# 内部：card -> { "zone": Zone, "owner": int }  （owner 对牌堆/弃堆为 -1）

func locate(card) -> Dictionary           ## 查询牌位（唯一真值）
func move_card(card, to_zone, to_owner, reason, parent_event_id=-1) -> void
func cards_in(zone, owner=-1) -> Array     ## 列举某区域的牌
func validate_conservation(total:int) -> bool  ## 牌守恒断言
```

### 1.3 唯一移动入口（铁律 1 / 单一真值）

`[MUST]` 所有牌的区域迁移**必须**经 `move_card`：它从源区移除、登记到目标区、
并发出对应精确事件（铁律 7）。**禁止**任何代码直接操作
`hand_cards`/`discard_pile`/`equip_*`/`judge_cards`/`draw_pile` 数组。

```gdscript
# 摸牌：牌堆 → 手牌
registry.move_card(card, Zone.HAND, player_idx, "draw")        # 发 CARD_DRAWN
# 使用：手牌 → 结算中
registry.move_card(card, Zone.PROCESSING, -1, "usage")
# 入弃堆：结算中 → 弃堆
registry.move_card(card, Zone.DISCARD_PILE, -1, "usage")       # 发 CARD_DISCARDED
# 被夺取：手牌 → 别人手牌
registry.move_card(card, Zone.HAND, thief_idx, "snatch")       # 发 CARD_STOLEN
```

技能"获得伤害牌"（奸雄）= 一次 `move_card(... Zone.HAND, owner, "skill")`。
`PlayCardEffect` **不再**需要"扫全场猜认领"——结算末尾只需检查该牌是否仍在
`PROCESSING`，是则入弃堆，否则说明已被某 Effect 合法移走。

---

## 二、CardData 数据结构

### 2.1 枚举
| 枚举 | 值 |
|------|-----|
| `Suit` | SPADE, HEART, CLUB, DIAMOND |
| `CardColor` | BLACK, RED |
| `CardType` | BASIC, TRICK, EQUIPMENT |
| `TrickType` | NONE, INSTANT, DELAYED, AOE |
| `EquipType` | NONE, WEAPON, ARMOR, HORSE_DEF, HORSE_ATK, TREASURE |

### 2.2 字段（静态只读，运行态不写入 CardData）
| 字段 | 类型 | 说明 |
|------|------|------|
| `card_id` | String | 唯一标识 `"sha_spade_7"` |
| `card_name` | String | 显示名 `"杀"` |
| `card_type`/`trick_type`/`equip_type` | enum | 分类 |
| `suit`/`rank` | enum/int | 花色/点数(1=A..13=K) |
| `weapon_range` | int | 武器攻击范围 |
| `need_target`/`target_count`/`can_target_self`/`range_limit` | — | 目标规则 |
| `equip_effect_script`/`effect_script_path` | String | 脚本路径 |
| `description` | String | 描述 |

`[MUST]` `CardData` 是静态数据；运行时状态（在谁手里）属 `CardLocationRegistry`，
**禁止**往 `CardData` 上挂 owner 等可变字段。

### 2.3 查询方法
`get_color()` / `is_red()` / `is_black()` / `get_rank_display()` / `get_suit_display()` /
`get_full_display_name()`（如 `♠7 杀`）。

---

## 三、卡牌分类（标准版全集）

### 3.1 基本牌
| 牌 | 量 | 需目标 | 结算 |
|----|---|:---:|------|
| 杀/火杀/雷杀 | 20/4/4 | ✅ | `card_effect_sha.gd` |
| 闪 | 15 | ❌ | 响应专用 |
| 桃 | 8 | ❌ | `card_effect_tao.gd` |
| 酒 | 5 | ❌ | `card_effect_wine.gd` |

### 3.2 锦囊
即时（决斗/过拆/顺手/无中/火攻/借刀）、AOE（南蛮/万箭/桃园/五谷）、
延时（乐/兵/闪电）、无懈（响应专用）。结算类见路由表（第五章）。

### 3.3 装备
武器×8、防具×4、防御马×2、进攻马×2。装备技能见 `Skill_Standard.md` 的 `equip/`。

---

## 四、PlayCardEffect 生命周期（GameAction）

`[MUST]` 严格遵循总纲铁律 3 的「声明→执行→清理」，全程 async：

```
0  校验：使用者存活、牌在 HAND（转化牌校验转化来源在 HAND）、目标合法
1  声明：move_card(实际牌 → PROCESSING, "usage")
2  CARD_USED (BEFORE)：await dispatch；若 is_cancelled（无懈/技能）→ 跳到 6 并发 CARD_CANCELLED
3  计数：若为杀且无"无次数限制"修正 → kill_count += 1（修正经属性钩子查询，非硬编码技能类）
4  执行：await card_resolver.create_effect(card,...).execute(ctx)
        （效果内部可 await 响应链：杀等闪、决斗、AOE、求桃）
5  清理：若该牌仍在 PROCESSING → move_card(→ DISCARD_PILE, "usage")
        （已被技能合法移走则跳过——靠牌位真值判断，非扫全场）
6  CARD_RESOLVED：notify/或 dispatch（视是否需触发）
```

### 4.1 与技能的解耦（铁律 6）

旧代码在此硬调 `SkillWuJing.consume_unlimited` / `SkillHeZhong.check_and_consume_bonus`。
新规范 `[MUST]`：
- "下一张牌无次数限制"→ 查询属性钩子 `ctx.query_attr(src, "card_use_unlimited", false)`。
- "锦囊额外结算次数"→ 查询 `ctx.query_attr(src, "extra_resolve_count", 0)`。
- 这些钩子由对应技能通过 `modify_attribute` 提供，`PlayCardEffect` **不认识**具体技能。

### 4.2 PlayIntent 结构
| 字段 | 说明 |
|------|------|
| `card` | 要使用的牌（null=结束出牌） |
| `target_indices` | 目标索引 |
| `source_index` | 使用者 |
| `skill` | 非空=技能发动意图 |
| `convert_card` / `convert_cards` | 单张 / 多张转化来源 |

---

## 五、结算路由与目标校验

### 5.1 CardResolver.create_effect 路由
装备→`CardEffectEquip`；杀/火/雷→`CardEffectSha`；桃→`Tao`；酒→`Wine`；决斗→`Duel`；
南蛮→`Nanman`；万箭→`Wanjian`；无中→`Wuzhong`；桃园→`Taoyuan`；五谷→`Wugu`；
过拆/顺手→`Dismantle`；火攻→`Huogong`；乐/兵/闪电→`Delayed`；借刀→`Jiedao`；未知→`null`。

### 5.2 目标合法性（纯函数，铁律 5）
| 牌 | 规则 |
|----|------|
| 杀/火/雷 | 距离 ≤ 攻击范围 |
| 顺手牵羊 | 距离 ≤ 1 且目标有牌 |
| 兵粮寸断 | 距离 = 1 |
| 过河拆桥 | 目标有牌 |
| 火攻 | 目标有手牌 |
| 借刀杀人 | A 有武器 + B 在 A 范围 + 三者互异 |
| 方天画戟（最后一张杀） | target_count = 3 |

---

## 六、转化牌机制

将手牌 A 视为牌 B 使用，**消耗 A，虚拟 B 用于结算**。
- 单张转化（武圣红牌当杀、龙胆、急救）：`convert_card`。
- 多张转化（丈八两张当杀）：`convert_cards`。
- 查询链：`BattleContext.get_convertible_cards(idx, target_name, phase)` 遍历技能的
  纯函数 `get_convertible_cards(...)`，按技能类型优先级排序返回。

`[MUST]` 转化产生的虚拟牌不进入任何 Zone；真正参与 `move_card` 的是被消耗的实体牌 A。

---

## 七、JSON 数据
- 卡牌：`data/cards/*.json`；武将：`data/heroes/*.json`。
- `JsonDataLoader`（Autoload）启动加载，提供 `get_card_def/get_all_card_defs/...`。

---

## 八、审核清单（卡牌层，强制）
- [ ] 一切牌移动经 `CardLocationRegistry.move_card`，无裸数组增删
- [ ] 未用"扫全场"判断归属；归属查询走 `locate`
- [ ] `PlayCardEffect` 全程 async；CARD_USED 取消分支处理正确
- [ ] 次数/额外结算等经属性钩子查询，未硬编码技能类（铁律 6）
- [ ] 目标校验为纯函数；距离/范围正确
- [ ] 转化牌只消耗实体牌，虚拟牌不入区
- [ ] 牌守恒不变量通过
