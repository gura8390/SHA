# 三国争霸 · 技能制作标准（Skill Standard）

> 上位文件：`00_Architecture_Standard.md`。本文是 L3 技能层的实现契约。
> 配套：`Event_System_Standard.md`（双通道/TriggerBroker）、`Effect_Standard.md`、
> `Card_Standard.md`（牌位真值/转化）、`Character_Standard.md`（JSON）。
> 版本：v3.0（内核重写基线）

---

## 〇、技能必须遵守的铁律映射

| 总纲铁律 | 在技能层的含义 |
|----------|----------------|
| 1 Effect 垄断 | 技能改状态只能建 Effect；`can_trigger` 等只读 |
| 2 因果链 | 技能发出的事件串 `parent_event_id = ctx.trigger_event.event_id` |
| 3 异步契约 | `execute(ctx)` async；调用方（Broker）await |
| 4 反应通道 | 触发/锁定技经 `EventBus.react` + `TriggerBroker` 裁决 |
| 5 纯函数 | `can_trigger/can_activate/modify_attribute/get_*_targets` 无副作用 |
| 6 解耦 | 技能影响核心流程只经"事件/属性钩子/查询契约"，不被核心按类名硬调 |
| 8 命名空间 | 跨步骤态走 `ctx.set_skill_meta()`，key=`skill.<id>.<field>` |

违反任一条 = 架构缺陷，合入前必须修复。

---

## 一、SkillContext（强制上下文，铁律 6）

`[MUST]` 技能执行的全部上下文经 `SkillContext` 传入，**禁止**在 Skill 实例上挂临时状态字段
（如 `var _temp_target`）——避免技能间隐式串扰、便于隔离与（未来）并发结算。

```gdscript
class_name SkillContext
extends RefCounted

var owner_index: int = -1          ## 技能持有者
var trigger_event: GameEvent = null ## 触发本次执行的事件（根因）
var battle_context = null           ## 战场数据/查询
var skill: Skill = null             ## 技能实例
var extra: Dictionary = {}          ## 特定技能附加数据

# 便捷封装（强制走这些，禁止裸操作）
func owner():                       ## -> PlayerState
func ask_controller():              ## -> IPlayerController
func set_skill_meta(field, v):      ## key=skill.<id>.<field>
func get_skill_meta(field, default=null)
func has_skill_meta(field) -> bool
func remove_skill_meta(field)
func query_attr(idx, attr, base):   ## 走属性钩子链
```

---

## 二、Skill 基类 API

```gdscript
class_name Skill
extends RefCounted

var skill_data: SkillData
var owner_index: int
var battle_context
var is_enabled: bool = true
var is_awakened: bool = false
# 次数计数（基类维护，子类只读）
var _used_this_turn: int
var _used_this_game: int

# —— 生命周期 ——
func setup(data, owner_idx, ctx) -> void      ## 绑定 + register_events()
func register_events() -> void                ## 子类订阅（react/observe，固定优先级）
func unregister_events() -> void              ## EventBus.unsubscribe_all(self)

# —— 触发技/锁定技 ——
func can_trigger(event) -> bool               ## [MUST] 纯函数
func execute(ctx: SkillContext) -> Dictionary ## [MUST] async，经 Effect 改状态

# —— 主动技 ——
func can_activate() -> bool                   ## [MUST] 纯函数
func get_active_targets() -> Array            ## 纯函数
func activate(ctx: SkillContext) -> Dictionary ## async

# —— 被动/属性修正 ——
func modify_attribute(attr, base, ctx_data) -> Variant  ## [MUST] 纯函数

# —— 觉醒技 ——
func should_awaken(event) -> bool             ## 纯函数
func awaken(ctx) -> void                      ## async

# —— 工具 ——
func record_use(); func _check_use_limit() -> bool; func reset_turn_count()
func make_context(trigger_event=null) -> SkillContext   ## 构造 SkillContext
```

`[MUST]` 基类**不再**在事件回调里同步 `execute`。回调只做：`can_trigger` 纯判定 →
向 `TriggerBroker` 登记触发项；实际发动由 Broker 异步裁决（见 Event 标准第四章）。

---

## 三、五类技能实现要求

### 3.1 主动技 ACTIVE（出牌阶段手动发动）
必实现：`can_activate()`（纯函数：次数/条件/手牌）、`activate(ctx)`（async，经 Effect）。
可选：`get_active_targets()`。

```gdscript
func can_activate() -> bool:
    if not is_enabled or not _check_use_limit(): return false
    var p = battle_context.get_player(owner_index)
    return p != null and p.hand_cards.size() > p.current_hp   # 仁德示例

func activate(ctx: SkillContext) -> Dictionary:
    # 经 DiscardCardEffect/DrawCardEffect/TransferCardEffect 实现，禁止裸改手牌
    ...
    await EventBus.dispatch(GameEvent.create(GameEvent.Type.SKILL_RESOLVED,
        owner_index, -1, {"skill_id": skill_data.id}))
    return {"resolved": true}
```

### 3.2 触发技 TRIGGER（条件满足→询问）
必实现：`register_events()`（`EventBus.react(...,固定优先级,self)`）、
`can_trigger(event)`（纯函数）、`execute(ctx)`（async）。

```gdscript
func register_events() -> void:
    EventBus.react(GameEvent.Type.DAMAGE_AFTER, _on_damage_after, 10, self)  # 奸雄

func _on_damage_after(event) -> void:
    if can_trigger(event):
        TriggerBroker.enlist(self, event)     # 仅登记，Broker 异步裁决

func can_trigger(event) -> bool:
    return event.target == owner_index        # 纯函数

func execute(ctx: SkillContext) -> Dictionary:
    var card = ctx.trigger_event.data.get("card")
    if card != null:
        # 经 move_card 获得（CARD_STOLEN/skill），禁止裸 append
        ctx.battle_context.registry.move_card(card, Zone.HAND, owner_index, "skill",
            ctx.trigger_event.event_id)
    return {"resolved": true}
```

### 3.3 锁定技 COMPULSORY
同触发技，但 `SkillData.skill_type=COMPULSORY`。Broker 裁决时**不询问**，直接 `await execute`。
锁定技对自身静态属性的修正（如咆哮无限杀）应经 `modify_attribute`（"card_use_unlimited"）
而非直接改 `kill_limit`（铁律 6/单一真值）。

### 3.4 被动技 PASSIVE
**方式 A 属性修正**（马术/武器）：
```gdscript
func register_events() -> void: skill_data.modifies_attributes = true
func modify_attribute(attr, base, ctx_data):
    if attr == "distance_from": return maxi(1, base - 1)   # 马术
    return base
```
**方式 B 牌转化**（武圣/龙胆/急救）——提供纯函数静态/实例方法供转化系统调用：
```gdscript
func can_convert(target_name, phase=-1) -> Variant       # 返回虚拟牌或 null
func get_convertible_cards(hand, target_name, phase, owner_idx, cur_idx) -> Array
func create_virtual_card(target_name) -> CardData
```

### 3.5 觉醒技 AWAKEN
`should_awaken(event)`（纯函数）、`awaken(ctx)`（async，设 `is_awakened=true` 并经 Effect 落效果）。

---

## 四、实现模式库

- **模式 A 选择器**：`await ctx.ask_controller().decide_card_pick(...)` → 经 Effect 落地。
- **模式 B 转换技（阴/阳交替）**：状态走 `ctx.set_skill_meta("mode", ...)`（命名空间）。
- **模式 C 虚拟牌使用**：构造虚拟 CardData → `PlayIntent.converted_single(...)` →
  `PlayCardEffect` 统一结算（不自行 move_card 虚拟牌）。
- **模式 D 跨技能查询**：优先用属性钩子 `ctx.query_attr(...)` 或 meta；
  确需类型判断时 `for sk in owner.skills: if sk is SkillX`，但**核心流程禁止**这样硬调（铁律 6）。
- **模式 E 静态查询契约**：对外暴露纯函数（如转化），由通用系统调用，不被核心按名硬接。

---

## 五、文件 / 命名
- 脚本：`src/skills/skill_<id>.gd`；装备技：`src/skills/equip/skill_<name>.gd`。
- 类名 `SkillXxx extends Skill`（PascalCase）。
- 文件头一句话职责注释；公共方法 `##` 文档注释；不写流水账 `change.N`。

---

## 六、审核清单（技能层，强制）
- [ ] 铁律 1：未裸改 `hand_cards/current_hp/discard_pile`，全经 Effect / move_card
- [ ] 铁律 2：发出事件串了 `parent_event_id`
- [ ] 铁律 3：`execute/activate/awaken` async，发动经 Broker await（无同步 execute）
- [ ] 铁律 4：触发/锁定技经 `react`+`TriggerBroker`；人类可选技可弹窗
- [ ] 铁律 5：`can_trigger/can_activate/modify_attribute/get_*_targets` 纯函数
- [ ] 铁律 6：技能影响核心只经 事件/属性钩子/查询契约；核心未按类名硬调本技能
- [ ] 铁律 8：跨步骤态经 `ctx.set_skill_meta`，无裸 key
- [ ] 用 `SkillContext` 传上下文，Skill 实例无临时状态字段
- [ ] `register_events` 订阅在 `unregister_events` 注销；用固定优先级
- [ ] 边界：持有者死亡 / 手牌空 / context 为 null 不崩溃；次数限制生效
