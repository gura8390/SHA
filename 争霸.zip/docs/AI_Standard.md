# 三国争霸 · AI / 控制器标准（AI & Controller Standard）

> 上位文件：`00_Architecture_Standard.md`（L4 决策层）。
> 本文定义 `IPlayerController` 接口契约、SmartAI 决策架构、身份评估、扩展规范，
> 以及 HumanController 的异步交互。
> 版本：v3.0

---

## 一、IPlayerController 接口（L4 契约）

`[MUST]` 控制层**只返回意图，绝不直接改状态**（铁律 1）。AI 与人类共用同一接口
（duck typing），由 `BattleContext.controllers` 注册表管理。

```gdscript
func setup(context, resolver=null) -> void
func decide_play_action(player_index) -> PlayIntent          ## 出牌阶段循环
func decide_response(request: ResponseRequest) -> ResponseResult  ## 被杀/锦囊/求桃
func decide_discard(player_index, count) -> Array            ## 弃牌
func decide_skill_activation(skill, event) -> bool           ## 触发技是否发动
func decide_card_pick(p_index, t_index, cards, ctx="") -> CardData ## 选牌
func cleanup() -> void
```

`[MUST]` 这些方法**必须** async-safe：AI 同步返回、人类 await UI，调用方（回合引擎 /
TriggerBroker / 响应管道）统一 `await`，无 `is_human` 分支（铁律 3/4）。

注册：`context.register_controller(player_index, controller)`。

---

## 二、SmartAI 决策架构

### 2.1 出牌优先级链（decide_play_action）
1 主动技 → 2 危急回血(HP≤1 有桃) → 3 装备空栏(武器>进攻马>防御马>防具>宝物) →
4 无中生有 → 5 杀(火>雷>普;含转化/丈八) → 6 单体锦囊(决斗/过拆/顺手) →
7 延时锦囊(乐/兵) → 8 借刀 → 9 AOE(敌≥友) → 10 群益(桃园/五谷,有伤时) →
11 非危急回血(差≥2 且手牌>2) → 12 结束。

### 2.2 响应（decide_response）
桃/酒(濒死)必出；闪按"是否致命/手牌充裕"决策；无懈走 `_should_wuxie` 身份评估；
转化牌检查(龙胆/急救)；决斗出杀。

### 2.3 弃牌
按 `_card_value` 升序弃最便宜的 N 张。

---

## 三、卡牌价值表（_card_value）
桃100 / 无懈80 / 闪60 / 酒40 / 火雷杀38 / 杀35 / 装备32 / 无中30 / 决斗28 /
过拆顺手26 / AOE24 / 延时22 / 借刀20 / 五谷桃园18 / 默认15。

---

## 四、身份评估

### 4.1 敌意矩阵 `_hostility(attacker, target)`
| 攻\目 | 主 | 忠 | 反 | 内 |
|---|---|---|---|---|
| 主 | — | -10 | 12 | 5 |
| 忠 | -10 | -10 | 12 | 5 |
| 反 | 12 | 7 | -10 | 2 |
| 内 | 2 | 6 | 8 | 1 |
身份未公开返回中性。`>0` 敌对，`<0` 友好。

### 4.2 目标综合评分
`score = hostility×10 + (8-min(HP,8))×3 + (6-min(hand,6))`；友方目标 `hostility×100`（强避误伤）。

### 4.3 无懈评估 `_should_wuxie`
计算锦囊来源/目标与己方敌意，若锦囊伤害友方则出无懈保护。

---

## 五、扩展规范

### 5.1 难度分级
新增控制器类实现 `IPlayerController`：`src/ai/easy_ai.gd`（随机/不评估身份）、
`src/ai/hard_ai.gd`（深度搜索/精算）。在 `GameManager.setup_game` 按难度选类。

### 5.2 思考延迟
`await RngService` 抖动或 `SettingsManager.ai_play_delay`（0~3 秒）控制可观察性。
`[MUST]` 延迟用 `create_timer`，不影响逻辑确定性。

### 5.3 新增卡牌/技能时的 AI 适配点
出牌(`decide_play_action`)、响应(`decide_response`)、价值(`_card_value`)、
目标(`_target_score`)、技能(`decide_skill_activation`)——逐项检查。

---

## 六、HumanController（异步交互）

### 6.1 信号驱动（与 UI 解耦）
请求(→UI)：`play_requested / response_requested / discard_requested / card_pick_requested`
提交(UI→)：`submit_play / submit_response / submit_discard / submit_card_pick`

### 6.2 异步等待
```gdscript
func decide_play_action(idx) -> PlayIntent:
    (func(): play_requested.emit(idx)).call_deferred()  # 避免信号早于 await 注册
    return await _play_submitted
```
`[MUST]` 触发技询问 `decide_skill_activation` 对人类同样 await UI（弹窗），由 TriggerBroker
在异步通道里调用——这是新内核相对旧版的关键修复。

---

## 七、审核清单（控制器层）
- [ ] 只返回意图，未直接改状态
- [ ] 全部 decide_* async-safe，被调用方 await
- [ ] 人类触发技经 await 弹窗（不在同步回调里）
- [ ] 新卡/新技已补 AI 适配点
- [ ] 思考延迟不破坏逻辑确定性
