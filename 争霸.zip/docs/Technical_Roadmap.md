# 三国争霸 · 技术路线图与架构评审（Technical Roadmap）

> 项目：三国争霸（单机卡牌策略）｜ 引擎：Godot v4.6.3 ｜ 语言：GDScript
> 版本：v3.0（内核重写基线）
> 本文含：三阶段总览 + **内核重写里程碑 M0~M7** + 架构评审（原 Architecture_Review 并入）。
> 标准类文档见各 `*_Standard.md`，以 `00_Architecture_Standard.md` 为根。

---

## 一、三阶段总览

```
阶段一 原型期    跑通核心单局，验证架构              —— 已达成（旧内核）
阶段二 完善期    身份/技能/装备/锦囊/AI/UI           —— 功能已达成（旧内核）
阶段三 抛光期    动画/音效/平衡/教学/存档            —— 部分（SFX+动画已接入）
─────────────────────────────────────────────────────────────
阶段 R 内核重写  按 v3.0 企业级标准重写底层并迁移     —— 进行中（本文件重点）
```

> 阶段一/二的功能目标已在旧内核达成；但底层架构无法支撑超大规模扩展（见第三章评审），
> 故插入「阶段 R」对内核做激进重写，再把现有 20 武将/全卡牌/UI/AI 迁移上去。

---

## 二、内核重写里程碑（阶段 R）

> 原则：逐里程碑收口，每个里程碑结束跑 headless 验证；保留技能/卡牌资产，按新基类迁移。

| 里程碑 | 内容 | 对应标准 | 解决的架构缺陷 |
|--------|------|----------|----------------|
| **M0 地基** | `GameEvent` 加 `event_id/parent_event_id`；新建 `CardLocationRegistry`（唯一 `move_card`）+ `RngService`；数据层去重（HeroPool 单表示、删重复兜底） | Event/Card/总纲铁律 2/9 | 无牌位真值、无因果链、数据双表示 |
| **M1 异步事件管道** | `EventBus` 拆 `notify`(同步)+`dispatch`(异步)；新建 `TriggerBroker` 异步裁决触发技；重写触发管道 | Event 标准 | **同步广播 vs 异步反应**（人类触发技无法弹窗、同步断链）|
| **M2 Effect 契约** | 所有 Effect/GameAction 改 async；牌移动经 `move_card`；标准返回 | Effect 标准 | async 契约不统一（断链 bug）|
| **M3 Skill 重写** | 引入 `SkillContext`；Meta 命名空间；**解耦核心硬编码技能类**（武靖/和衷→属性钩子）；去相位魔法数字 | Skill 标准/铁律 6/8 | 核心硬调具体技能、裸 meta、临时态 |
| **M4 回合引擎拆分** | 抽出 `TurnSystem`/`PhaseSystem`（迭代非递归）；延时锦囊规则移入 CardEffect；GameManager 瘦身为装配+胜负 | Game_Flow 标准 | GameManager 上帝对象、递归+帧轮询 |
| **M5 迁移** | 20 武将 + 全卡牌效果适配新内核；`_archived/` 加 `.gdignore` | 各标准 | 死代码污染类缓存 |
| **M6 UI/AI 适配** | battle_table/HumanController 对接异步触发弹窗；SmartAI 适配 | AI/UI 标准 | — |
| **M7 回归** | headless 跑通 4~12 人局；牌守恒/求桃/触发技(含人类)/无懈/连环逐项验证 | — | — |

### 阶段 R 验收标准
- [ ] 内核不引用任何具体技能/卡牌类名（铁律 6 通过）
- [ ] 人类可选触发技可弹窗等待（异步管道生效）
- [ ] 牌守恒 / 单所有权不变量每回合断言通过
- [ ] 20 武将 + 全卡牌在新内核跑通一局至分胜负
- [ ] 全部代码过各标准末章审核清单

---

## 三、架构评审（原 Architecture_Review 并入）

### 3.1 旧内核为何"撑不起超大项目"
| # | 缺陷 | 位置 | 重写对策 |
|---|------|------|----------|
| 1 | 事件纯同步，反应需异步 → 断链、人类触发技无法弹窗 | event_bus / skill_trigger_pipeline | M1 双通道 + TriggerBroker |
| 2 | 无牌位真值，靠"扫全场猜认领" | play_card_effect | M0 CardLocationRegistry |
| 3 | 核心硬编码具体技能类 | play_card_effect | M3 属性钩子解耦 |
| 4 | 事件无 event_id/因果链 | game_event | M0 因果链 |
| 5 | 红线在代码被违反（裸 meta、无 SkillContext、相位魔法数字） | 多处 | M3 |
| 6 | `CARD_USED` 声称可取消但从不检查 | play_card_effect | M2/Card 标准 |
| 7 | GameManager 上帝对象（含延时锦囊规则） | game_manager | M4 拆分 |
| 8 | Effect async 契约不统一 | effects/* | M2 |
| 9 | 数据双表示 / 重复兜底 / 死代码编译 | hero_pool/game_manager/_archived | M0/M5 |
| 10 | 回合递归 + 帧轮询节拍 | game_manager | M4 迭代引擎 |

### 3.2 健康的部分（保留并强化）
- 事件驱动 + Effect 垄断 + 控制器接口（`IPlayerController`）方向正确，为联机/回放预留位置。
- 五类技能模型、身份系统、距离/装备/判定的玩法逻辑成熟，迁移即可。

---

## 四、Autoload（真实注册）

| 单例 | 脚本 | 职责 |
|------|------|------|
| `EventBus` | core/event_bus.gd | 双通道事件总线（notify/dispatch） |
| `SettingsManager` | core/settings_manager.gd | 音量/分辨率/全屏，持久化 |
| `GameSetup` | core/game_setup.gd | 跨场景开局配置 |
| `JsonDataLoader` | data/json_data_loader.gd | 启动加载卡牌/武将 JSON |
| `AudioManager` | core/audio_manager.gd | SFX 播放（已接入 12 个）|

> `GameManager` 为对局场景内子节点（非 autoload），负责装配 + 胜负判定。

---

## 五、技术风险与应对
| 风险 | 应对 |
|------|------|
| 重写期"中途不可玩" | 按里程碑收口，每步 headless 验证 |
| 响应链死锁（目标已死） | 异步管道内死亡玩家自动跳过 + 守卫检查 |
| 状态机复杂度爆炸 | 事件驱动 + 属性钩子，禁止硬编码分支（铁律 6） |
| 牌堆耗尽 | 弃牌堆自动回收洗入（RngService） |
| 确定性/未来联机 | 状态可序列化 + RNG 种子（铁律 9） |
