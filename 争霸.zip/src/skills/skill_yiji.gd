# ============================================================
# skill_yiji.gd
# 法正/郭嘉风格技能：遗计（触发技）
# 描述：当你受到 1 点伤害后，你可以摸两张牌。
# 触发时机：DAMAGE_AFTER（受到伤害后，按点数次数简化为每次触发摸2张）
# 同步执行。
# ============================================================

class_name SkillYiJi
extends Skill


func register_events() -> void:
	EventBus.subscribe(GameEvent.Type.DAMAGE_AFTER, _on_event_received, 0, self)


func can_trigger(event: GameEvent) -> bool:
	return event.target == owner_index


func execute(event: GameEvent) -> void:
	# 受到的伤害点数（默认 1），每点摸 2 张
	var dmg: int = int(event.data.get("amount", 1))
	if dmg < 1:
		dmg = 1
	var draw_count: int = dmg * 2
	var eff = DrawCardEffect.create(owner_index, owner_index, draw_count)
	eff.resolve(battle_context)

	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.yiji.name": "遗计", "drawn": draw_count}
	))
