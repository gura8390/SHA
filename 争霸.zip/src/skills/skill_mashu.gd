# ============================================================
# skill_mashu.gd
# 马超技能：马术（锁定技 / 持续被动）
# 描述：锁定技，你计算与其他角色的距离时始终 -1。
# 实现：被动属性修正——修正 "distance_from"，使本武将到他人的距离 -1。
# ============================================================

class_name SkillMaShu
extends Skill


# 被动技：不订阅事件，只声明会修正属性
func register_events() -> void:
	if skill_data != null:
		skill_data.modifies_attributes = true


# 修正"本武将到他人的距离"：-1（最小 1 由 BattleContext 兜底）
func modify_attribute(attr_name: String, base_value, _ctx_data: Dictionary = {}):
	if attr_name == "distance_from":
		return base_value - 1
	return base_value
