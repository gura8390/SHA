# ============================================================
# skill_zhiheng.gd
# 孙权技能：制衡（主动技）
# 描述：出牌阶段，你可以弃置至多 X 张牌，然后摸等量的牌（每回合限一次）。
#       （AI 简化：弃掉手中价值最低的若干张冗余牌再等量补摸。）
# 类型：ACTIVE（出牌阶段主动发动，activate 被 await）
# ============================================================

class_name SkillZhiHeng
extends Skill


func can_activate() -> bool:
	if not is_enabled or not _check_use_limit():
		return false
	if skill_data.skill_type != SkillData.SkillType.ACTIVE:
		return false
	# 有可弃的冗余牌时才发动
	return not _cards_to_toss().is_empty()


# 主动技无需选目标
func get_active_targets() -> Array:
	return []


func activate(_targets: Array) -> Dictionary:
	var owner_player = get_owner_player()
	if owner_player == null:
		return {"resolved": false}

	var toss := _cards_to_toss()
	if toss.is_empty():
		return {"resolved": false}

	# 弃置选中的牌
	var discard_eff = DiscardCardEffect.create(
		owner_index, owner_index, toss, DiscardCardEffect.DiscardReason.USAGE
	)
	discard_eff.resolve(battle_context)

	# 摸等量
	var draw_eff = DrawCardEffect.create(owner_index, owner_index, toss.size())
	draw_eff.resolve(battle_context)

	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.zhiheng.name": "制衡", "count": toss.size()}
	))
	return {"resolved": true, "count": toss.size()}


# 选出值得换掉的牌：花色重复的杀/低价值锦囊等（简化：留桃/闪/无懈，其它最多弃2张）
func _cards_to_toss() -> Array:
	var owner_player = get_owner_player()
	if owner_player == null:
		return []
	var keep := {"桃": true, "闪": true, "无懈可击": true}
	var toss: Array = []
	for card in owner_player.hand_cards:
		if keep.has(card.card_name):
			continue
		if card.card_type == CardData.CardType.EQUIPMENT:
			continue
		toss.append(card)
		if toss.size() >= 2:
			break
	return toss
