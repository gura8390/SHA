# ============================================================
# skill_luanji.gd
# 武将技能：乱击（主动技/转化型）
#
# 描述：出牌阶段，你可以将两张相同花色的手牌当【万箭齐发】使用。
#
# 实现方式：
#   1. 选择两张同花色手牌
#   2. 创建虚拟万箭齐发牌
#   3. 通过 PlayCardEffect 的 convert_cards 模式执行（复用丈八蛇矛模式）
#
# Gemini:change.12: 新建——袁绍乱击
# ============================================================

class_name SkillLuanJi
extends Skill


func register_events() -> void:
	# 主动技，不订阅事件
	pass


func can_activate() -> bool:
	if not is_enabled:
		return false
	if not _check_use_limit():
		return false
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	# 需要有至少两张同花色手牌
	return _has_same_suit_pair(owner.hand_cards)


func get_active_targets() -> Array:
	# 万箭齐发无特定目标（AOE）
	return []


func activate(_targets: Array) -> Dictionary:
	var owner = get_owner_player()
	if owner == null:
		return {"resolved": false, "reason": "no_owner"}

	# 选两张同花色手牌
	var pair: Array = await _pick_same_suit_pair(owner)
	if pair.size() < 2:
		return {"resolved": false, "reason": "no_pair"}

	# 创建虚拟万箭齐发牌
	var virtual_wanjian = CardData.new()
	virtual_wanjian.card_id = "wanjian_luanji"
	virtual_wanjian.card_name = "万箭齐发"
	virtual_wanjian.card_type = CardData.CardType.TRICK
	virtual_wanjian.trick_type = CardData.TrickType.AOE
	virtual_wanjian.need_target = false
	virtual_wanjian.target_count = 0
	virtual_wanjian.description = "乱击转化的万箭齐发"

	# 通过 PlayCardEffect 的 convert_cards 模式执行
	var intent = PlayIntent.new()
	intent.source_index = owner_index
	intent.card = virtual_wanjian
	intent.convert_cards = pair
	intent.target_indices = []

	if battle_context.card_resolver == null:
		return {"resolved": false, "reason": "no_card_resolver"}

	var play_action = PlayCardEffect.create_from_intent(intent, battle_context.card_resolver)
	battle_context.action_queue.push_action(play_action)
	await battle_context.action_queue.execute_all()

	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, -1,
		{"skill.luanji.name": "乱击", "skill.luanji.effect": "wanjian"}
	))
	return {"resolved": true}


## 检查手牌中是否有同花色的一对
static func _has_same_suit_pair(hand_cards: Array) -> bool:
	var suit_count: Dictionary = {}
	for card in hand_cards:
		if card == null:
			continue
		var s = card.suit
		suit_count[s] = suit_count.get(s, 0) + 1
		if suit_count[s] >= 2:
			return true
	return false


## 选两张同花色手牌（AI：选最低价值的一对；人类：通过控制器选）
func _pick_same_suit_pair(player) -> Array:
	if player.is_human:
		var controller = battle_context.get_controller(owner_index)
		if controller != null and controller.has_method("decide_card_pick"):
			# 人类玩家：先选第一张，再选同花色的第二张
			var first = await controller.decide_card_pick(owner_index, owner_index, player.hand_cards.duplicate(), "luanji_first")
			if first != null:
				var same_suit: Array = []
				for c in player.hand_cards:
					if c != first and c.suit == first.suit:
						same_suit.append(c)
				if not same_suit.is_empty():
					var second = await controller.decide_card_pick(owner_index, owner_index, same_suit, "luanji_second")
					if second != null:
						return [first, second]
		# 兜底：自动选
		return _ai_pick_pair(player)
	else:
		return _ai_pick_pair(player)


## AI 选两张同花色低价值手牌
static func _ai_pick_pair(player) -> Array:
	var best_pair: Array = []
	var best_val: int = 99999
	var suit_cards: Dictionary = {}
	for card in player.hand_cards:
		if card == null:
			continue
		var s = card.suit
		if not suit_cards.has(s):
			suit_cards[s] = []
		suit_cards[s].append(card)
	for s in suit_cards:
		var cards = suit_cards[s]
		if cards.size() >= 2:
			cards.sort_custom(func(a, b): return _card_val(a) < _card_val(b))
			var val = _card_val(cards[0]) + _card_val(cards[1])
			if val < best_val:
				best_val = val
				best_pair = [cards[0], cards[1]]
	return best_pair


static func _card_val(card: CardData) -> int:
	if card == null:
		return 0
	match card.card_name:
		"桃": return 100
		"无懈可击": return 80
		"闪": return 60
		"酒": return 40
		"火杀", "雷杀": return 38
		"杀": return 35
		_: return 15
