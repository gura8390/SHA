# ============================================================
# skill_wusheng.gd
# 武将技能：武圣（被动技/转化型）
#
# 描述：你可以将一张红色手牌当【杀】使用或打出。
#
# 实现方式：
#   通过 can_convert() / get_convertible_cards() / create_virtual_card()
#   三个静态方法，供 BattleContext.get_card_conversion() 和
#   ResponseRequest 的转化查询调用。
#
# Gemini:change.12: 新建——关羽武圣
# ============================================================

class_name SkillWuSheng
extends Skill


func register_events() -> void:
	# 转化型被动技，不订阅事件
	pass


func can_trigger(_event: GameEvent) -> bool:
	return false


func execute(_event: GameEvent) -> void:
	pass


## 转化查询：是否可将牌转化为目标牌名
## @param target_card_name: 目标牌名（如 "杀"）
## @param phase: 当前阶段（-1=不限）
## @return: true 表示支持此转化
static func can_convert(target_card_name: String, _phase: int = -1) -> bool:
	return target_card_name == "杀"


## 获取可转化为目标牌名的手牌列表
## @param hand_cards: 玩家手牌
## @param target_card_name: 目标牌名
## @param phase: 当前阶段
## @return: 可转化的牌列表
static func get_convertible_cards(hand_cards: Array, target_card_name: String, _phase: int = -1) -> Array:
	if target_card_name != "杀":
		return []
	var result: Array = []
	for card in hand_cards:
		if card != null and card.is_red():
			result.append(card)
	return result


## 创建虚拟杀牌
## @param _source_card: 被转化的源牌（用于继承花色点数，可选）
## @return: 虚拟杀 CardData
static func create_virtual_card(_target_name: String = "杀") -> CardData:
	var virtual_sha = CardData.new()
	virtual_sha.card_id = "sha_wusheng"
	virtual_sha.card_name = "杀"
	virtual_sha.card_type = CardData.CardType.BASIC
	virtual_sha.need_target = true
	virtual_sha.target_count = 1
	virtual_sha.can_target_self = false
	virtual_sha.description = "武圣转化的杀"
	return virtual_sha
