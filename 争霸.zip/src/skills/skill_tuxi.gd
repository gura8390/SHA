# ============================================================
# skill_tuxi.gd
# 张辽技能：突袭（触发技）
# 描述：摸牌阶段，你可以放弃摸牌，改为获得至多两名其他角色各一张手牌。
#       （简化：摸牌阶段触发，自动从最近的有手牌的敌对角色各抢一张，最多两名；
#        若发动，则不再走常规摸牌——通过取消摸牌事件实现。）
# 触发时机：摸牌阶段（PHASE_START → DRAW），这里监听 DRAW_CARD before。
# 同步执行。
# ============================================================

class_name SkillTuXi
extends Skill


func register_events() -> void:
	EventBus.subscribe(GameEvent.Type.DRAW_CARD, _on_event_received, 0, self)


func can_trigger(event: GameEvent) -> bool:
	# 仅自己的摸牌阶段、摸牌前
	if event.target != owner_index:
		return false
	if event.data.get("phase", "") != "before":
		return false
	if battle_context.current_phase != BattleContext.Phase.PHASE_DRAW:
		return false
	# 至少有一名其他角色有手牌才值得突袭
	return not _victims().is_empty()


func execute(event: GameEvent) -> void:
	var owner_player = get_owner_player()
	if owner_player == null:
		return
	var victims := _victims()
	if victims.is_empty():
		return

	# 放弃常规摸牌
	event.data["amount"] = 0

	# 红线 1：通过 TransferCardEffect 转移牌，禁止直接修改状态
	var stolen: int = 0
	for v_idx in victims:
		var v = battle_context.get_player(v_idx)
		if v == null or v.hand_cards.is_empty():
			continue
		var idx: int = randi() % v.hand_cards.size()
		var card: CardData = v.hand_cards[idx]
		TransferCardEffect.hand_to_hand(v_idx, owner_index, [card], "tuxi").execute(battle_context, null)
		stolen += 1
		if stolen >= 2:
			break

	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.tuxi.name": "突袭", "stolen": stolen}
	))


# 最多取两名"有手牌"的其他存活角色
func _victims() -> Array:
	var result: Array = []
	for p in battle_context.get_alive_players():
		if p.index == owner_index:
			continue
		if not p.hand_cards.is_empty():
			result.append(p.index)
		if result.size() >= 2:
			break
	return result
