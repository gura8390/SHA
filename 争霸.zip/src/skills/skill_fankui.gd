# ============================================================
# skill_fankui.gd
# 郭嘉技能：反馈
# 描述：当你受到伤害后，你可以获得伤害来源的一张手牌。
# 触发时机：DAMAGE_AFTER
# 流程：
#   1. 监听 DAMAGE_AFTER 事件
#   2. 检查自己是否为伤害目标
#   3. 从伤害来源的手牌中随机获取一张
# Gemini:change.1: 初始创建——实现"反馈"技能
# ============================================================

class_name SkillFanKui
extends Skill


# Gemini:change.1: 重写事件注册，监听 DAMAGE_AFTER
func register_events() -> void:
	EventBus.subscribe(GameEvent.Type.DAMAGE_AFTER, _on_event_received, 0, self)


# Gemini:change.1: 条件检查
## 满足条件：自己是伤害目标，伤害来源存在且有手牌
func can_trigger(event: GameEvent) -> bool:
	# 必须是自己受到伤害
	if event.target != owner_index:
		return false
	# 伤害来源必须存在
	var source_idx = event.source
	if source_idx < 0:
		return false
	# 伤害来源必须有手牌
	var source_player = battle_context.get_player(source_idx)
	if source_player == null or source_player.hand_cards.is_empty():
		return false
	return true


# Gemini:change.1: 执行技能效果
## 从伤害来源的手牌中随机获取一张
func execute(event: GameEvent) -> void:
	var owner_player = get_owner_player()
	if owner_player == null:
		return

	var source_idx = event.source
	var source_player = battle_context.get_player(source_idx)
	if source_player == null or source_player.hand_cards.is_empty():
		return

	# 红线 1：通过 TransferCardEffect 转移牌，禁止直接修改状态
	var random_idx = randi() % source_player.hand_cards.size()
	var stolen_card = source_player.hand_cards[random_idx]
	TransferCardEffect.hand_to_hand(source_idx, owner_index, [stolen_card], "fankui").execute(battle_context, null)

	# 发布技能结算完成事件
	var skill_event = GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED,
		owner_index,
		source_idx,
		{
			"skill.fankui.name": "反馈",
			"stolen_card": stolen_card,
			"from_player": source_idx,
		}
	)
	EventBus.publish(skill_event)
