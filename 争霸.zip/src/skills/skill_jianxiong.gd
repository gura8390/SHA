# ============================================================
# skill_jianxiong.gd
# 曹操技能：奸雄
# 描述：当你受到伤害后，你可以获得造成该伤害的牌。
# 触发时机：DAMAGE_AFTER
# 流程：
#   1. 通过 EventBus 监听 DAMAGE_AFTER 事件
#   2. 检查自己是否为伤害目标
#   3. 如果是，获取造成伤害的卡牌加入手牌
# Gemini:change.1: 初始创建——实现"奸雄"技能
# ============================================================

class_name SkillJianXiong
extends Skill


# Gemini:change.1: 重写事件注册，监听 DAMAGE_AFTER
func register_events() -> void:
	EventBus.subscribe(GameEvent.Type.DAMAGE_AFTER, _on_event_received, 0, self)


# Gemini:change.1: 条件检查
## 满足条件：自己是伤害目标，且有造成伤害的卡牌
func can_trigger(event: GameEvent) -> bool:
	# 必须是自己受到伤害
	if event.target != owner_index:
		return false
	# 必须有关联的卡牌（如"杀"造成的伤害有卡牌，失去体力无卡牌）
	var related_card = event.data.get("card", null)
	if related_card == null:
		return false
	return true


# Gemini:change.1: 执行技能效果
## 将造成伤害的牌加入自己的手牌
func execute(event: GameEvent) -> void:
	var owner_player = get_owner_player()
	if owner_player == null:
		return

	var related_card = event.data.get("card", null)
	if related_card == null:
		return

	# 红线 1：通过 TransferCardEffect 从弃牌堆获取牌，禁止直接修改状态
	if battle_context.discard_pile.has(related_card):
		TransferCardEffect.discard_to_hand(owner_index, [related_card], "jianxiong").execute(battle_context, null)
	else:
		# 牌可能还在结算中（limbo 状态），尝试从牌堆获取
		TransferCardEffect.pile_to_hand(owner_index, [related_card], "jianxiong").execute(battle_context, null)

	# 发布技能结算完成事件
	var skill_event = GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED,
		owner_index,
		owner_index,
		{
			"skill.jianxiong.name": "奸雄",
			"obtained_card": related_card,
		}
	)
	EventBus.publish(skill_event)
