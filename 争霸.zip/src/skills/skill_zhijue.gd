# ============================================================
# skill_zhijue.gd
# 诸葛亮技能：智绝（主动技，转换技）
#
# 效果（交替发动）：
#   阳：将牌堆顶的一张牌当【火攻】使用
#   阴：将一种颜色的手牌置入弃牌堆（每色每回合限1次），
#       然后视为使用其中一张基本或普通锦囊牌
#       若未造成伤害：知天可见牌数-1（至少1），摸2张
#
# 转换技：首次发动为"阳"，之后每次发动交替
# ============================================================

class_name SkillZhiJue
extends Skill

## 当前模式：true=阳，false=阴
var _is_yang: bool = true

## 本回合已弃过的颜色（阴模式用）
var _discarded_red_this_turn: bool = false
var _discarded_black_this_turn: bool = false

## 本回合是否造成过伤害（阴模式用）
var _dealt_damage_this_turn: bool = false


func register_events() -> void:
	EventBus.subscribe(GameEvent.Type.DAMAGE_AFTER, _on_event_received, 0, self)


func _on_event_received(event: GameEvent) -> void:
	# 追踪是否造成伤害（智绝阴模式用）
	if event.source == owner_index:
		_dealt_damage_this_turn = true


func can_activate() -> bool:
	if not is_enabled or not _check_use_limit():
		return false
	var owner = get_owner_player()
	if owner == null:
		return false

	if _is_yang:
		# 阳：牌堆顶需要有牌
		return battle_context.draw_pile.size() > 0
	else:
		# 阴：需要有手牌可弃，且至少一种颜色未弃过
		if owner.hand_cards.is_empty():
			return false
		var has_red := false
		var has_black := false
		for c in owner.hand_cards:
			if c.is_red():
				has_red = true
			else:
				has_black = true
		# 至少有一种颜色可弃（且该颜色本回合未弃过）
		return (has_red and not _discarded_red_this_turn) or (has_black and not _discarded_black_this_turn)


func activate(_targets: Array) -> Dictionary:
	var owner = get_owner_player()
	if owner == null:
		return {"resolved": false}

	if _is_yang:
		return await _activate_yang(owner)
	else:
		return await _activate_yin(owner)


## 阳模式：牌堆顶1张当火攻使用
func _activate_yang(owner) -> Dictionary:
	if battle_context.draw_pile.is_empty():
		return {"resolved": false}

	# 红线 1：通过 draw_from_pile 获取牌堆顶牌，禁止直接 pop_back
	var top_card: CardData = battle_context.draw_from_pile()

	# 创建虚拟火攻
	var virtual_huogong = CardData.new()
	virtual_huogong.card_id = "huogong_zhijue"
	virtual_huogong.card_name = "火攻"
	virtual_huogong.card_type = CardData.CardType.TRICK
	virtual_huogong.trick_type = CardData.TrickType.INSTANT
	virtual_huogong.need_target = true
	virtual_huogong.target_count = 1
	virtual_huogong.suit = top_card.suit
	virtual_huogong.rank = top_card.rank

	# 选目标（AI选最优，人类通过控制器）
	var target_idx := _pick_target(owner)
	if target_idx == -1:
		# 无合法目标，牌入弃牌堆
		battle_context.add_to_discard_pile(top_card)
		return {"resolved": false, "no_target": true}

	# 记录使用前状态（用于判断是否造成伤害）
	_dealt_damage_this_turn = false

	# 执行火攻
	var effect = CardEffectHuogong.create_action(owner.index, target_idx, virtual_huogong)
	var result = await effect.execute(battle_context, null)

	# 牌入弃牌堆
	battle_context.add_to_discard_pile(top_card)

	# 切换到阴模式
	_is_yang = false

	# 阴模式检查：若未造成伤害
	if not _dealt_damage_this_turn and not result.get("damage", false):
		_apply_no_damage_penalty(owner)

	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner.index, owner.index,
		{"skill.zhijue.name": "智绝", "skill.zhijue.effect": "yang", "card": top_card}
	))

	return {"resolved": true, "mode": "yang"}


## 阴模式：弃一种颜色的手牌，然后视为使用其中一张
func _activate_yin(owner) -> Dictionary:
	# 让玩家选择弃红色还是黑色
	var color_choice := await _ask_color_choice(owner)
	if color_choice == "":
		return {"resolved": false}

	# 收集该颜色的手牌
	var same_color: Array = []
	for c in owner.hand_cards:
		if (color_choice == "red" and c.is_red()) or (color_choice == "black" and c.is_black()):
			same_color.append(c)

	if same_color.is_empty():
		return {"resolved": false}

	# 标记已弃该颜色
	if color_choice == "red":
		_discarded_red_this_turn = true
	else:
		_discarded_black_this_turn = true

	# 从同色手牌中选一张基本或普通锦囊视为使用（其余弃置）
	var usable: Array = []
	for c in same_color:
		if c.card_type == CardData.CardType.BASIC:
			usable.append(c)
		elif c.card_type == CardData.CardType.TRICK and c.trick_type != CardData.TrickType.DELAYED:
			usable.append(c)

	if usable.is_empty():
		# 红线 1：通过 DiscardCardEffect 弃置手牌，禁止先 erase 再 Effect
		DiscardCardEffect.create(
			owner.index, owner.index, same_color, DiscardCardEffect.DiscardReason.SKILL_COST
		).resolve(battle_context)
		_is_yang = true
		return {"resolved": true, "mode": "yin", "no_usable": true}

	# 让玩家选择使用哪张
	var use_card: CardData = null
	if usable.size() == 1:
		use_card = usable[0]
	else:
		var controller = battle_context.get_controller(owner.index)
		if controller != null and controller.has_method("decide_card_pick"):
			use_card = await controller.decide_card_pick(owner.index, owner.index, usable, "zhijue_yin")
		if use_card == null:
			use_card = usable[0]

	# 记录使用前状态
	_dealt_damage_this_turn = false

	# 红线 1：通过 DiscardCardEffect 弃置其余同色牌，禁止先 erase 再 Effect
	var discard_pile: Array = []
	for c in same_color:
		if c != use_card:
			discard_pile.append(c)
	if not discard_pile.is_empty():
		DiscardCardEffect.create(
			owner.index, owner.index, discard_pile, DiscardCardEffect.DiscardReason.SKILL_COST
		).resolve(battle_context)

	# 视为使用选中的牌（通过 PlayIntent + PlayCardEffect，牌仍在手中）
	if use_card.card_type == CardData.CardType.BASIC:
		if use_card.card_name == "杀" or use_card.card_name == "火杀" or use_card.card_name == "雷杀":
			var target_idx := _pick_target(owner)
			if target_idx != -1:
				var intent = PlayIntent.single_target(owner.index, use_card, target_idx)
				var play_action = PlayCardEffect.create_from_intent(intent, battle_context.card_resolver)
				battle_context.action_queue.push_action(play_action)
				await battle_context.action_queue.execute_all()
		elif use_card.card_name == "桃":
			if owner.current_hp < owner.max_hp:
				var intent = PlayIntent.no_target(owner.index, use_card)
				var play_action = PlayCardEffect.create_from_intent(intent, battle_context.card_resolver)
				battle_context.action_queue.push_action(play_action)
				await battle_context.action_queue.execute_all()
		elif use_card.card_name == "酒":
			var intent = PlayIntent.no_target(owner.index, use_card)
			var play_action = PlayCardEffect.create_from_intent(intent, battle_context.card_resolver)
			battle_context.action_queue.push_action(play_action)
			await battle_context.action_queue.execute_all()
	else:
		if use_card.need_target:
			var target_idx := _pick_target(owner)
			if target_idx != -1:
				var intent = PlayIntent.single_target(owner.index, use_card, target_idx)
				var play_action = PlayCardEffect.create_from_intent(intent, battle_context.card_resolver)
				battle_context.action_queue.push_action(play_action)
				await battle_context.action_queue.execute_all()
		else:
			var intent = PlayIntent.no_target(owner.index, use_card)
			var play_action = PlayCardEffect.create_from_intent(intent, battle_context.card_resolver)
			battle_context.action_queue.push_action(play_action)
			await battle_context.action_queue.execute_all()

	# 切换到阳模式
	_is_yang = true

	# 若未造成伤害
	if not _dealt_damage_this_turn:
		_apply_no_damage_penalty(owner)

	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner.index, owner.index,
		{"skill.zhijue.name": "智绝", "skill.zhijue.effect": "yin", "color": color_choice}
	))

	return {"resolved": true, "mode": "yin"}


## 未造成伤害惩罚：知天可见牌数-1，摸2张
func _apply_no_damage_penalty(owner) -> void:
	for sk in owner.skills:
		if sk is SkillZhiTian:
			sk.reduce_visible_count(1)
			break
	DrawCardEffect.create(owner.index, owner.index, 2).resolve(battle_context)
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner.index, owner.index,
		{"skill.zhijue.name": "智绝", "skill.zhijue.effect": "no_damage_penalty"}
	))


## 询问玩家选择弃红色还是黑色
func _ask_color_choice(owner) -> String:
	var has_red := false
	var has_black := false
	for c in owner.hand_cards:
		if c.is_red():
			has_red = true
		else:
			has_black = true

	# 如果只有一种颜色可选，自动选
	if has_red and not has_black:
		return "red"
	if has_black and not has_red:
		return "black"

	# 检查哪些颜色本回合未弃过
	var can_red := has_red and not _discarded_red_this_turn
	var can_black := has_black and not _discarded_black_this_turn

	if can_red and not can_black:
		return "red"
	if can_black and not can_red:
		return "black"

	# 两种都可选：选手牌更多颜色的（AI和人类都用此策略）
	# 人类玩家可通过后续UI增强手动选择
	var red_count := 0
	var black_count := 0
	for c in owner.hand_cards:
		if c.is_red():
			red_count += 1
		else:
			black_count += 1
	return "red" if red_count >= black_count else "black"


## 选最优目标
func _pick_target(owner) -> int:
	if battle_context == null or battle_context.card_resolver == null:
		return -1
	var virtual_sha = CardData.new()
	virtual_sha.card_name = "杀"
	virtual_sha.need_target = true
	virtual_sha.target_count = 1
	var targets = battle_context.card_resolver.get_valid_targets(battle_context, owner.index, virtual_sha)
	if targets.is_empty():
		return -1
	return targets[0]
