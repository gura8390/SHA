# ============================================================
# skill_ganglie.gd
# 夏侯惇技能：刚烈（触发技）
# 描述：当你受到伤害后，你可以进行判定，若结果不为红桃，则伤害来源
#       随机弃置一张手牌（简化：弃一张随机手牌）。
# 触发时机：DAMAGE_AFTER（受到伤害后）
# 同步执行：判定 + 弃牌均为同步操作。
# ============================================================

class_name SkillGangLie
extends Skill


func register_events() -> void:
	EventBus.subscribe(GameEvent.Type.DAMAGE_AFTER, _on_event_received, 0, self)


func can_trigger(event: GameEvent) -> bool:
	# 必须是自己受到伤害
	if event.target != owner_index:
		return false
	# 伤害来源存在且非自己
	var src = event.source
	if src < 0 or src == owner_index:
		return false
	var src_player = battle_context.get_player(src)
	return src_player != null and src_player.is_alive


func execute(event: GameEvent) -> void:
	var src = event.source
	var src_player = battle_context.get_player(src)
	if src_player == null:
		return

	# 判定：需要判定系统
	if battle_context.judge_system == null:
		return
	var judge: Dictionary = battle_context.judge_system.perform_judge(owner_index, "刚烈")
	var card: CardData = judge.get("card", null)

	# 判定结果为红桃 → 不生效
	if card != null and card.suit == CardData.Suit.HEART:
		_publish_resolved(src, "judge_heart_no_effect")
		return

	# 红线 1：通过 DiscardCardEffect 弃置手牌，禁止直接修改状态
	if not src_player.hand_cards.is_empty():
		var idx: int = randi() % src_player.hand_cards.size()
		var lost: CardData = src_player.hand_cards[idx]
		DiscardCardEffect.create(src, src, [lost], DiscardCardEffect.DiscardReason.FORCED).resolve(battle_context)
	_publish_resolved(src, "force_discard")


func _publish_resolved(src: int, effect: String) -> void:
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, src,
		{"skill.ganglie.name": "刚烈", "skill.ganglie.effect": effect}
	))
