# ============================================================
# skill_luoshen.gd
# 甄姬技能：洛神（触发技）
# 描述：回合开始时，你可以进行判定，若结果为黑色，你获得此判定牌，
#       并可再次发动（简化：连续判定，黑色则收入手牌，直到非黑色或上限）。
# 触发时机：TURN_START（回合开始时）
# 同步执行。
# ============================================================

class_name SkillLuoShen
extends Skill

const MAX_TIMES: int = 4   # 防止极端情况无限循环


func register_events() -> void:
	EventBus.subscribe(GameEvent.Type.TURN_START, _on_event_received, 0, self)


func can_trigger(event: GameEvent) -> bool:
	# 仅自己的回合开始
	return event.source == owner_index


func execute(_event: GameEvent) -> void:
	var owner_player = get_owner_player()
	if owner_player == null or battle_context.judge_system == null:
		return

	var gained: int = 0
	for _i in range(MAX_TIMES):
		var judge: Dictionary = battle_context.judge_system.perform_judge(owner_index, "洛神")
		var card: CardData = judge.get("card", null)
		if card == null:
			break
		# 红线 1：通过 TransferCardEffect 从弃牌堆获取判定牌，禁止直接修改状态
		if card.is_black():
			if battle_context.discard_pile.has(card):
				TransferCardEffect.discard_to_hand(owner_index, [card], "luoshen").execute(battle_context, null)
			gained += 1
		else:
			break

	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.luoshen.name": "洛神", "gained": gained}
	))
