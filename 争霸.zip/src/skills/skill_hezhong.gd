# ============================================================
# skill_hezhong.gd
# 费祎技能：和衷（触发技）
#
# 描述：每回合各限一次，当你的手牌数变为1后，你可以展示之并摸一张牌，
#       然后令你本回合下次使用点数大于/小于此牌点数的锦囊牌各多结算一次。
#
# 流程：
#   1. 手牌数变为1 → 触发
#   2. 展示手牌，摸1张
#   3. 弹出选择：「大于 X」或「小于 X」（X = 展示牌的点数）
#   4. 存储标记：选择的方向 + 点数
#   5. 下次使用锦囊时，若点数匹配方向，额外结算一次
#   6. 匹配后消耗标记（大于/小于各自独立，各限一次）
#
# 每回合限一次（limit=1），但大于/小于标记可以分别使用。
# 例如：选了"大于4"，用8号南蛮→额外结算；手牌再次变1，选"小于9"，用3号无中→额外结算。
# ============================================================

class_name SkillHeZhong
extends Skill

## 当前持有的 bonus 标记列表
## 每个元素: {"direction": "greater"/"less", "rank": int, "used": bool}
var _bonus_marks: Array = []


func register_events() -> void:
	# 订阅手牌变化事件
	EventBus.subscribe(GameEvent.Type.DRAW_CARD, _on_event_received, 0, self)
	EventBus.subscribe(GameEvent.Type.DISCARD_CARD, _on_event_received, 0, self)
	EventBus.subscribe(GameEvent.Type.CARD_STOLEN, _on_event_received, 0, self)
	EventBus.subscribe(GameEvent.Type.CARD_GIVEN, _on_event_received, 0, self)


func reset_turn_count() -> void:
	super.reset_turn_count()
	_bonus_marks.clear()
	var owner = get_owner_player()
	if owner != null and owner.has_meta("skill.hezhong.bonus"):
		owner.remove_meta("skill.hezhong.bonus")


func can_trigger(event: GameEvent) -> bool:
	# 只关注自己的手牌变化
	if event.target != owner_index and event.source != owner_index:
		return false

	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false

	# 手牌数必须恰好为1
	if owner.hand_cards.size() != 1:
		return false

	return true


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or owner.hand_cards.is_empty():
		return

	# 展示手牌
	var shown_card: CardData = owner.hand_cards[0]
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.hezhong.name": "和衷", "skill.hezhong.effect": "reveal", "card": shown_card}
	))

	# 摸1张牌
	DrawCardEffect.create(owner_index, owner_index, 1).resolve(battle_context)

	# 让玩家选择"大于"或"小于"
	var direction: String = await _ask_direction(shown_card.rank)

	# 存储 bonus 标记
	var mark = {"direction": direction, "rank": shown_card.rank, "used": false}
	_bonus_marks.append(mark)

	# 同步到玩家 meta（供 PlayCardEffect 查询）
	_sync_bonus_to_meta(owner)

	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.hezhong.name": "和衷", "skill.hezhong.effect": "mark_added", "direction": direction, "rank": shown_card.rank}
	))


## 询问玩家选择"大于"还是"小于"
func _ask_direction(rank: int) -> String:
	var owner = get_owner_player()
	if owner == null:
		return "greater"

	if owner.is_human:
		# 人类玩家：通过控制器请求选择
		var controller = battle_context.get_controller(owner_index)
		if controller != null and controller.has_method("decide_hezhong_direction"):
			return await controller.decide_hezhong_direction(owner_index, rank)
		# 兜底：默认选大于
		return "greater"
	else:
		# AI：根据剩余手牌和局势选择最优方向
		return _ai_choose_direction(rank)


## AI 选择方向：倾向于选择更可能触发的方向
func _ai_choose_direction(rank: int) -> String:
	# 简单策略：如果点数偏高(>7)，选"小于"更容易触发；否则选"大于"
	if rank > 7:
		return "less"
	return "greater"


## 将 bonus 标记同步到玩家 meta（供 PlayCardEffect 查询）
func _sync_bonus_to_meta(owner) -> void:
	# 清除已使用的标记
	var active_marks: Array = []
	for mark in _bonus_marks:
		if not mark.get("used", false):
			active_marks.append(mark)

	if active_marks.is_empty():
		if owner.has_meta("skill.hezhong.bonus"):
			owner.remove_meta("skill.hezhong.bonus")
	else:
		owner.set_meta("skill.hezhong.bonus", active_marks)


## 静态方法：检查并消耗和衷 bonus（由 PlayCardEffect 调用）
## @return: 需要额外结算的次数（0 或 1）
static func check_and_consume_bonus(player, card: CardData) -> int:
	if player == null or not player.has_meta("skill.hezhong.bonus"):
		return 0

	var marks = player.get_meta("skill.hezhong.bonus")
	if marks == null or marks.is_empty():
		return 0

	# 必须是锦囊牌
	if card.card_type != CardData.CardType.TRICK:
		return 0

	var card_rank: int = card.rank
	var extra_count: int = 0

	# 遍历所有未使用的标记，检查是否有匹配
	for mark in marks:
		if mark.get("used", false):
			continue
		var direction: String = mark.get("direction", "")
		var mark_rank: int = mark.get("rank", 0)

		if direction == "greater" and card_rank > mark_rank:
			mark["used"] = true
			extra_count += 1
		elif direction == "less" and card_rank < mark_rank:
			mark["used"] = true
			extra_count += 1

	# 同步回 meta（移除已使用的）
	var active_marks: Array = []
	for mark in marks:
		if not mark.get("used", false):
			active_marks.append(mark)
	if active_marks.is_empty():
		player.remove_meta("skill.hezhong.bonus")
	else:
		player.set_meta("skill.hezhong.bonus", active_marks)

	return extra_count
