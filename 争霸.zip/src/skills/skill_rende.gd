# ============================================================
# skill_rende.gd
# 刘备技能：仁德（主动技）
# 描述：出牌阶段，你可以将至多 X 张手牌交给其他角色（每回合不限次，简化为限一次）。
#       AI 简化：把多余的手牌（超过体力值的部分）送给体力最低的友方。
# 类型：ACTIVE（activate 被 await）
# ============================================================

class_name SkillRenDe
extends Skill


func can_activate() -> bool:
	if not is_enabled or not _check_use_limit():
		return false
	if skill_data.skill_type != SkillData.SkillType.ACTIVE:
		return false
	var owner_player = get_owner_player()
	if owner_player == null:
		return false
	# 手牌富余（多于体力）且有友方可送才发动
	return owner_player.hand_cards.size() > owner_player.current_hp and _pick_ally() != -1


func get_active_targets() -> Array:
	var t := _pick_ally()
	return [t] if t != -1 else []


func activate(targets: Array) -> Dictionary:
	var owner_player = get_owner_player()
	if owner_player == null:
		return {"resolved": false}
	var ally_idx: int = targets[0] if not targets.is_empty() else _pick_ally()
	if ally_idx == -1:
		return {"resolved": false}
	var ally = battle_context.get_player(ally_idx)
	if ally == null:
		return {"resolved": false}

	# 红线 1：通过 TransferCardEffect 转移牌，禁止直接修改状态
	var surplus: int = owner_player.hand_cards.size() - owner_player.current_hp
	var give_count: int = min(surplus, 2)
	var given: int = 0
	var cards_to_give: Array = []
	for _i in range(give_count):
		if owner_player.hand_cards.is_empty():
			break
		cards_to_give.append(owner_player.hand_cards.back())
	if not cards_to_give.is_empty():
		TransferCardEffect.hand_to_hand(owner_index, ally_idx, cards_to_give, "rende").execute(battle_context, null)
		given = cards_to_give.size()

	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, ally_idx,
		{"skill.rende.name": "仁德", "given": given}
	))
	return {"resolved": true, "given": given}


# 找体力最低的友方（身份未公开则不算友方，避免资敌）
func _pick_ally() -> int:
	var me = battle_context.get_player(owner_index)
	if me == null:
		return -1
	var best := -1
	var best_hp := 999
	for p in battle_context.get_alive_players():
		if p.index == owner_index:
			continue
		# 仅送已知友方
		if not p.identity_revealed:
			continue
		if not Identity.is_ally(me.identity, p.identity):
			continue
		if p.current_hp < best_hp:
			best_hp = p.current_hp
			best = p.index
	return best
