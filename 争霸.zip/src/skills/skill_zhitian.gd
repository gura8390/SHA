# ============================================================
# skill_zhitian.gd
# 诸葛亮技能：知天（被动技）
#
# 效果：
#   - 出牌阶段，牌堆顶 N 张牌对你可见（默认 N=7）
#   - 火攻结算中，可从可见牌中选一张代替弃牌
#
# 实现：
#   - 提供 get_visible_cards(ctx, owner_idx) 静态方法供外部查询
#   - 火攻效果中调用此方法获取可见牌
#   - 智绝技能可修改可见牌数（_visible_count）
# ============================================================

class_name SkillZhiTian
extends Skill

## 可见牌数量（智绝可修改）
var visible_count: int = 7
const MIN_VISIBLE: int = 1


func register_events() -> void:
	# 知天是被动能力，不需要订阅事件
	pass


func can_trigger(_event: GameEvent) -> bool:
	return false


func execute(_event: GameEvent) -> void:
	pass


## 减少可见牌数（智绝技能调用）
func reduce_visible_count(amount: int = 1) -> void:
	visible_count = maxi(MIN_VISIBLE, visible_count - amount)


## 静态方法：获取牌堆顶 N 张可见牌（不移除）
static func get_visible_cards(ctx, owner_idx: int) -> Array:
	var player = ctx.get_player(owner_idx)
	if player == null:
		return []
	# 查找知天技能实例
	for sk in player.skills:
		if sk is SkillZhiTian:
			var count: int = sk.visible_count
			var result: Array = []
			for i in range(mini(count, ctx.draw_pile.size())):
				result.append(ctx.draw_pile[i])
			return result
	return []


## 静态方法：从可见牌中选一张移除（用于火攻代替弃牌）
## 红线 1：通过 TransferCardEffect 移除牌，禁止直接修改 draw_pile
static func pick_visible_card(ctx, owner_idx: int, card: CardData) -> bool:
	if ctx.draw_pile.has(card):
		TransferCardEffect.pile_to_hand(owner_idx, [card], "zhitian").execute(ctx, null)
		return true
	return false
