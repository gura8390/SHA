# ============================================================
# skill_xiaoji.gd
# 孙尚香技能：枭姬（触发技）
# 描述：当你失去装备区里的一张牌时，你可以摸两张牌。
# 触发时机：EQUIP_REMOVED（装备被移除时）
# 同步执行。
# ============================================================

class_name SkillXiaoJi
extends Skill


func register_events() -> void:
	EventBus.subscribe(GameEvent.Type.EQUIP_REMOVED, _on_event_received, 0, self)


func can_trigger(event: GameEvent) -> bool:
	# 仅自己失去装备时
	return event.target == owner_index or event.source == owner_index


func execute(_event: GameEvent) -> void:
	var eff = DrawCardEffect.create(owner_index, owner_index, 2)
	eff.resolve(battle_context)
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.xiaoji.name": "枭姬", "drawn": 2}
	))
