# ============================================================
# skill_longdan.gd
# 武将技能：龙胆（被动技/转化型）
#
# 描述：你可以将【杀】当【闪】、【闪】当【杀】使用或打出。
#
# 实现方式：
#   通过 can_convert() / get_convertible_cards() / create_virtual_card()
#   三个静态方法，供转化系统调用。
#
# Gemini:change.12: 新建——赵云龙胆
# ============================================================

class_name SkillLongDan
extends Skill


func register_events() -> void:
	# 转化型被动技，不订阅事件
	pass


func can_trigger(_event: GameEvent) -> bool:
	return false


func execute(_event: GameEvent) -> void:
	pass


## 转化查询：支持杀↔闪互转
static func can_convert(target_card_name: String, _phase: int = -1) -> bool:
	return target_card_name == "杀" or target_card_name == "闪"


## 获取可转化的手牌列表
## 杀当闪：手牌中的杀类可以当闪
## 闪当杀：手牌中的闪可以当杀
static func get_convertible_cards(hand_cards: Array, target_card_name: String, _phase: int = -1) -> Array:
	var result: Array = []
	match target_card_name:
		"闪":
			# 杀当闪
			for card in hand_cards:
				if card != null and (card.card_name == "杀" or card.card_name == "火杀" or card.card_name == "雷杀"):
					result.append(card)
		"杀":
			# 闪当杀
			for card in hand_cards:
				if card != null and card.card_name == "闪":
					result.append(card)
	return result


## 创建虚拟牌
static func create_virtual_card(target_name: String = "杀") -> CardData:
	var virtual = CardData.new()
	match target_name:
		"杀":
			virtual.card_id = "sha_longdan"
			virtual.card_name = "杀"
			virtual.card_type = CardData.CardType.BASIC
			virtual.need_target = true
			virtual.target_count = 1
			virtual.can_target_self = false
			virtual.description = "龙胆转化的杀"
		"闪":
			virtual.card_id = "shan_longdan"
			virtual.card_name = "闪"
			virtual.card_type = CardData.CardType.BASIC
			virtual.need_target = false
			virtual.target_count = 0
			virtual.description = "龙胆转化的闪"
	return virtual
