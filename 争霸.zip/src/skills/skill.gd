# ============================================================
# skill.gd
# 技能运行时基类：所有武将技能的逻辑实现基类
# 每个具体武将技能继承此类，重写 can_trigger / execute
# 技能通过 EventBus 订阅感兴趣的事件，在事件发生时检查并触发
#
# 武将技能实现示例（如关羽"武圣"）：
#   class_name SkillWuSheng extends Skill
#   func can_trigger(event: GameEvent) -> bool:
#       return 检查是否需要出杀或闪的时机
#   func execute(event: GameEvent) -> void:
#       将一张红色手牌当杀使用
#
# Gemini:change.1: 初始创建——定义技能运行时逻辑基类
# ============================================================

class_name Skill
extends RefCounted

# Gemini:change.1: 技能关联的静态配置数据
var skill_data: SkillData = null

# Gemini:change.1: 技能持有者的玩家索引
var owner_index: int = -1

# Gemini:change.1: 战场上下文引用
var battle_context = null

# Gemini:change.1: 本回合已使用次数
var _used_count_this_turn: int = 0

# Gemini:change.1: 本局已使用次数
var _used_count_this_game: int = 0

# Gemini:change.1: 技能是否启用（某些情况下技能会被封印）
var is_enabled: bool = true

# Gemini:change.7: 觉醒技是否已觉醒（一次性永久）
var is_awakened: bool = false


# Gemini:change.1: 初始化技能
## 在武将加入战场时调用，绑定数据并注册事件
func setup(data: SkillData, owner_idx: int, ctx) -> void:
	skill_data = data
	owner_index = owner_idx
	battle_context = ctx
	register_events()


# Gemini:change.1: 注册事件监听
## 子类可重写以订阅额外事件
## 基类默认根据 SkillData.trigger_timing 自动映射到对应事件
func register_events() -> void:
	var event_type = _get_event_type_from_timing()
	if event_type != -1:
		EventBus.subscribe(event_type, _on_event_received, 0, self)


# Gemini:change.1: 注销事件监听
## 在技能持有者死亡或技能被移除时调用
func unregister_events() -> void:
	EventBus.unsubscribe_all(self)


# Gemini:change.1: 事件接收入口（内部）
## 当订阅的事件发生时，由 EventBus 调用此方法
func _on_event_received(event: GameEvent) -> void:
	# 技能未启用则跳过
	if not is_enabled:
		return

	# 相位过滤：ON_PHASE_DRAW/PLAY/DISCARD 映射到 PHASE_START，需过滤
	if event.event_type == GameEvent.Type.PHASE_START:
		var phase = event.data.get("phase", -1)
		match skill_data.trigger_timing:
			SkillData.TriggerTiming.ON_PHASE_DRAW:
				if phase != 1:  # PHASE_DRAW = 1
					return
			SkillData.TriggerTiming.ON_PHASE_PLAY:
				if phase != 2:  # PHASE_PLAY = 2
					return
			SkillData.TriggerTiming.ON_PHASE_DISCARD:
				if phase != 3:  # PHASE_DISCARD = 3
					return

	# Gemini:change.7: 觉醒技——满足条件则觉醒（一次性，不走次数限制）
	if skill_data.skill_type == SkillData.SkillType.AWAKEN:
		if not is_awakened and should_awaken(event):
			awaken()
		return

	# 检查使用次数限制
	if not _check_use_limit():
		return
	# 调用子类的条件检查
	if can_trigger(event):
		if skill_data.skill_type == SkillData.SkillType.COMPULSORY:
				# 锁定技：直接执行，不询问
				record_use()
				execute(event)
		else:
			# 非锁定技：需要询问持有者是否发动
			# 此处由 GameManager 或 AI 系统处理询问逻辑
			# 通过发布 SKILL_TRIGGERED 事件通知
			var trigger_event = GameEvent.create(
				GameEvent.Type.SKILL_TRIGGERED,
				owner_index,
				-1,
				{
					"skill": self,
					"skill_data": skill_data,
					"original_event": event,
				}
			)
			EventBus.publish(trigger_event)


# Gemini:change.1: 条件检查——是否满足触发条件
## 子类必须重写此方法
## @param event: 触发此检查的游戏事件
## @return: true 表示可以触发
func can_trigger(_event: GameEvent) -> bool:
	push_error("Skill.can_trigger() 必须由子类重写！技能: %s" % skill_data.skill_name)
	return false


# Gemini:change.1: 执行技能效果
## 子类必须重写此方法
## @param event: 触发技能的游戏事件
func execute(_event: GameEvent) -> void:
	push_error("Skill.execute() 必须由子类重写！技能: %s" % skill_data.skill_name)


# ============================================================
# Gemini:change.7: 五类技能地基钩子
# ============================================================

# ----- 主动技（ACTIVE）-----
# 出牌阶段，玩家可主动发动。SkillManager / 出牌入口调用以下接口。

## 主动技：当前是否可发动（次数、条件、手牌等）。子类重写。
func can_activate() -> bool:
	if not is_enabled:
		return false
	if not _check_use_limit():
		return false
	return skill_data.skill_type == SkillData.SkillType.ACTIVE


## 主动技：获取合法目标列表（need_target 时）。子类重写。
func get_active_targets() -> Array:
	return []


## 主动技：执行发动。targets 为玩家索引数组。子类重写。
## 返回结果字典（可含 resolved 等）。可为 async。
func activate(_targets: Array) -> Dictionary:
	push_error("主动技 %s 未实现 activate()" % skill_data.skill_name)
	return {"resolved": false}


# ----- 持续/被动技（PASSIVE）-----

## 被动技：修正某项属性查询。被 PlayerState/BattleContext 在查询时调用。
## @param attr_name: 属性名（"attack_range" / "hand_limit" / "draw_count" /
##                    "max_distance_to" / "distance_from" 等）
## @param base_value: 当前（可能已被其他技能修正过的）值
## @param ctx_data: 附加上下文（如距离查询的 from/to）
## @return: 修正后的值（默认原样返回）
func modify_attribute(_attr_name: String, base_value, _ctx_data: Dictionary = {}):
	return base_value


# ----- 觉醒技（AWAKEN）-----

## 觉醒技：是否满足觉醒条件。子类重写。
func should_awaken(_event: GameEvent) -> bool:
	return false


## 觉醒技：执行觉醒（一次性）。子类重写实现觉醒效果（如减体力、获新技、转锁定）。
func awaken() -> void:
	is_awakened = true



# Gemini:change.1: 重置回合计数（每回合开始时由 GameManager 调用）
func reset_turn_count() -> void:
	_used_count_this_turn = 0


# Gemini:change.2: 记录一次发动（由 SkillTriggerPipeline 在确认发动后调用）
func record_use() -> void:
	_used_count_this_turn += 1
	_used_count_this_game += 1


# Gemini:change.1: 检查使用次数限制
func _check_use_limit() -> bool:
	# 检查每回合限制
	if skill_data.use_limit_per_turn >= 0:
		if _used_count_this_turn >= skill_data.use_limit_per_turn:
			return false
	# 检查每局限制
	if skill_data.use_limit_per_game >= 0:
		if _used_count_this_game >= skill_data.use_limit_per_game:
			return false
	return true


# Gemini:change.1: 根据 TriggerTiming 映射到 GameEvent.Type
func _get_event_type_from_timing() -> int:
	match skill_data.trigger_timing:
		SkillData.TriggerTiming.ON_TURN_START:
			return GameEvent.Type.TURN_START
		SkillData.TriggerTiming.ON_TURN_END:
			return GameEvent.Type.TURN_END
		SkillData.TriggerTiming.ON_PHASE_DRAW:
			return GameEvent.Type.PHASE_START  # 需在 _on_event_received 中过滤 phase
		SkillData.TriggerTiming.ON_PHASE_PLAY:
			return GameEvent.Type.PHASE_START  # 需在 _on_event_received 中过滤 phase
		SkillData.TriggerTiming.ON_PHASE_DISCARD:
			return GameEvent.Type.PHASE_START  # 需在 _on_event_received 中过滤 phase
		SkillData.TriggerTiming.ON_DEAL_DAMAGE:
			return GameEvent.Type.DAMAGE_BEFORE
		SkillData.TriggerTiming.ON_TAKE_DAMAGE:
			return GameEvent.Type.DAMAGE_AFTER
		SkillData.TriggerTiming.ON_CARD_USED:
			return GameEvent.Type.CARD_USED
		SkillData.TriggerTiming.ON_BECOME_TARGET:
			return GameEvent.Type.CARD_TARGETED
		SkillData.TriggerTiming.ON_DYING:
			return GameEvent.Type.PLAYER_DYING
		SkillData.TriggerTiming.ON_DEATH:
			return GameEvent.Type.PLAYER_DEAD
		SkillData.TriggerTiming.ON_DRAW_CARD:
			return GameEvent.Type.DRAW_CARD
		SkillData.TriggerTiming.ON_DISCARD_CARD:
			return GameEvent.Type.DISCARD_CARD
		SkillData.TriggerTiming.ON_JUDGE:
			return GameEvent.Type.JUDGE_RESULT
		SkillData.TriggerTiming.ON_RECOVER_HP:
			return GameEvent.Type.HEAL_AFTER
		SkillData.TriggerTiming.ON_EQUIP_CHANGE:
			return GameEvent.Type.EQUIP_INSTALLED
		SkillData.TriggerTiming.ON_LOSE_HP:
			return GameEvent.Type.LOSE_HP_AFTER  # 失去体力独立事件（区别于受到伤害）
		_:
			if skill_data.trigger_timing != SkillData.TriggerTiming.NONE:
				push_warning("Skill '%s' timing '%d' 无自动映射，请重写 register_events()" % skill_data.skill_name)
			return -1


# Gemini:change.1: 获取技能持有者的玩家实体
func get_owner_player():
	if battle_context:
		return battle_context.get_player(owner_index)
	return null
