# ============================================================
# skill_jijiu.gd
# 武将技能：急救（被动技/转化型）
#
# 描述：你的回合外，你可以将一张红色牌当【桃】使用。
#
# 实现方式：
#   通过 can_convert() / get_convertible_cards() / create_virtual_card()
#   三个静态方法，供转化系统调用。
#   注意：仅在回合外生效（phase != PHASE_PLAY）
#
# Gemini:change.12: 新建——华佗急救
# ============================================================

class_name SkillJiJiu
extends Skill


func register_events() -> void:
	# 转化型被动技，不订阅事件
	pass


func can_trigger(_event: GameEvent) -> bool:
	return false


func execute(_event: GameEvent) -> void:
	pass


## 转化查询：回合外可将红色牌当桃
## owner_index: 技能持有者索引（用于判断是否在自己回合）
## current_player_index: 当前回合玩家索引
static func can_convert(target_card_name: String, phase: int = -1, owner_idx: int = -1, current_player_idx: int = -1) -> bool:
	if target_card_name != "桃":
		return false
	# 仅在自己回合外可用
	if owner_idx >= 0 and current_player_idx >= 0 and owner_idx == current_player_idx:
		return false
	return true


## 获取可转化的手牌列表：回合外的红色牌
static func get_convertible_cards(hand_cards: Array, target_card_name: String, phase: int = -1, owner_idx: int = -1, current_player_idx: int = -1) -> Array:
	if target_card_name != "桃":
		return []
	# 仅在自己回合外可用
	if owner_idx >= 0 and current_player_idx >= 0 and owner_idx == current_player_idx:
		return []
	var result: Array = []
	for card in hand_cards:
		if card != null and card.is_red():
			result.append(card)
	return result


## 创建虚拟桃牌
static func create_virtual_card(_target_name: String = "桃") -> CardData:
	var virtual = CardData.new()
	virtual.card_id = "tao_jijiu"
	virtual.card_name = "桃"
	virtual.card_type = CardData.CardType.BASIC
	virtual.need_target = false
	virtual.target_count = 0
	virtual.can_target_self = true
	virtual.description = "急救转化的桃"
	return virtual
