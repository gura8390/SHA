# ============================================================
# skill_lijian.gd
# 武将技能：离间（主动技）
#
# 描述：出牌阶段，你可以弃置一张牌，令一名男性角色视为对另一名男性角色
#       使用一张【决斗】。
#
# 实现方式：
#   1. 弃置一张手牌作为代价
#   2. 选择两名男性角色 A（使用者）和 B（目标）
#   3. 创建虚拟决斗牌，通过 CardEffectDuel 执行
#
# Gemini:change.12: 新建——貂蝉离间
# ============================================================

class_name SkillLiJian
extends Skill


func register_events() -> void:
	# 主动技，不订阅事件
	pass


func can_activate() -> bool:
	if not is_enabled:
		return false
	if not _check_use_limit():
		return false
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	if owner.hand_cards.is_empty():
		return false
	# 场上需要至少两名男性角色
	var male_count := 0
	for player in battle_context.get_alive_players():
		if player.hero_data != null and player.hero_data.gender == "male":
			male_count += 1
	return male_count >= 2


func get_active_targets() -> Array:
	# 返回所有男性角色的索引（需要选两个：A 对 B 决斗）
	var males: Array = []
	for player in battle_context.get_alive_players():
		if player.hero_data != null and player.hero_data.gender == "male":
			males.append(player.index)
	return males


func activate(targets: Array) -> Dictionary:
	var owner = get_owner_player()
	if owner == null:
		return {"resolved": false, "reason": "no_owner"}

	# 需要两个目标：male_A（决斗使用者）和 male_B（决斗目标）
	if targets.size() < 2:
		return {"resolved": false, "reason": "need_two_targets"}

	var male_a: int = targets[0]
	var male_b: int = targets[1]

	# 校验两名男性角色
	for idx in [male_a, male_b]:
		var p = battle_context.get_player(idx)
		if p == null or not p.is_alive:
			return {"resolved": false, "reason": "invalid_target"}
		if p.hero_data == null or p.hero_data.gender != "male":
			return {"resolved": false, "reason": "target_not_male"}
	if male_a == male_b:
		return {"resolved": false, "reason": "same_target"}

	# 选一张手牌弃置（代价）
	var discard_card: CardData = null
	if owner.is_human:
		var controller = battle_context.get_controller(owner_index)
		if controller != null and controller.has_method("decide_card_pick"):
			discard_card = await controller.decide_card_pick(owner_index, owner_index, owner.hand_cards.duplicate(), "lijian_cost")
		if discard_card == null and not owner.hand_cards.is_empty():
			discard_card = owner.hand_cards[0]
	else:
		# AI：弃最低价值牌
		var min_val: int = 99999
		for c in owner.hand_cards:
			var val = _simple_card_value(c)
			if val < min_val:
				min_val = val
				discard_card = c

	if discard_card == null:
		return {"resolved": false, "reason": "no_card"}

	# 红线 1：通过 DiscardCardEffect 弃置手牌，禁止先 erase 再 Effect（双重操作）
	DiscardCardEffect.create(
		owner_index, owner_index, [discard_card], DiscardCardEffect.DiscardReason.SKILL_COST
	).resolve(battle_context)

	# 创建虚拟决斗牌
	var virtual_duel = CardData.new()
	virtual_duel.card_id = "duel_lijian"
	virtual_duel.card_name = "决斗"
	virtual_duel.card_type = CardData.CardType.TRICK
	virtual_duel.trick_type = CardData.TrickType.INSTANT
	virtual_duel.need_target = true
	virtual_duel.target_count = 1
	virtual_duel.description = "离间转化的决斗"

	# 执行决斗：male_A 对 male_B 决斗
	var duel_action = CardEffectDuel.create_action(male_a, male_b, virtual_duel)
	await duel_action.execute(battle_context, null)

	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, male_a,
		{"skill.lijian.name": "离间", "skill.lijian.effect": "duel", "duel_a": male_a, "duel_b": male_b}
	))
	return {"resolved": true}


static func _simple_card_value(card: CardData) -> int:
	if card == null:
		return 0
	match card.card_name:
		"桃": return 100
		"无懈可击": return 80
		"闪": return 60
		"酒": return 40
		"火杀", "雷杀": return 38
		"杀": return 35
		_: return 15
