# ============================================================
# skill_wujing.gd
# 诸葛亮技能：武靖（锁定技）
#
# 效果：
#   1. 回合内，有牌不因使用而进入弃牌堆后，下一张牌无次数限制
#   2. 回合内，首次有非手牌的牌进入弃牌堆后，摸一张牌
#
# 实现：
#   - 监听 DISCARD_CARD 事件
#   - 检查是否在 owner 的回合内
#   - 检查弃牌原因是否为"非使用"（如拆、顺、装备替换等）
#   - 设置标记：下一张牌无次数限制 + 摸牌
# ============================================================

class_name SkillWuJing
extends Skill

## 本回合是否有牌不因使用进入弃牌堆
var _card_discarded_this_turn: bool = false

## 本回合是否已触发过"非手牌牌入弃牌堆摸牌"
var _non_hand_draw_triggered: bool = false

## 标记：下一张牌无次数限制
var _next_card_unlimited: bool = false


func register_events() -> void:
	EventBus.subscribe(GameEvent.Type.DISCARD_CARD, _on_event_received, 0, self)


func reset_turn_count() -> void:
	super.reset_turn_count()
	_card_discarded_this_turn = false
	_non_hand_draw_triggered = false
	_next_card_unlimited = false


func can_trigger(event: GameEvent) -> bool:
	# 只在 owner 的回合内触发
	if battle_context == null:
		return false
	if battle_context.current_player_index != owner_index:
		return false

	# 检查弃牌事件
	var reason = event.data.get("reason", -1)
	var cards = event.data.get("cards", [])

	# 条件1：有牌不因使用进入弃牌堆
	if reason != 0 and not cards.is_empty():
		return true

	return false


func execute(event: GameEvent) -> void:
	var cards = event.data.get("cards", [])

	# 在 execute 中设置状态（而非 can_trigger）
	_card_discarded_this_turn = true
	_next_card_unlimited = true

	# 条件2：首次有非手牌的牌进入弃牌堆 → 摸1张
	if not _non_hand_draw_triggered:
		# 检查是否有非手牌来源的牌（装备区/判定区）
		var from_equip := false
		for c in cards:
			# 简化判断：如果弃牌原因是装备替换或拆顺，认为是非手牌
			var reason = event.data.get("reason", -1)
			if reason != 0:  # 非使用
				from_equip = true
				break
		if from_equip:
			_non_hand_draw_triggered = true
			DrawCardEffect.create(owner_index, owner_index, 1).resolve(battle_context)
			EventBus.publish(GameEvent.create(
				GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
				{"skill.wujing.name": "武靖", "skill.wujing.effect": "draw"}
			))

	# 通知：下一张牌无次数限制
	if _next_card_unlimited:
		EventBus.publish(GameEvent.create(
			GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
			{"skill.wujing.name": "武靖", "skill.wujing.effect": "unlimited_next"}
		))


## 静态方法：检查并消耗"无次数限制"标记
static func consume_unlimited(ctx, owner_idx: int) -> bool:
	var player = ctx.get_player(owner_idx)
	if player == null:
		return false
	for sk in player.skills:
		if sk is SkillWuJing and sk._next_card_unlimited:
			sk._next_card_unlimited = false
			return true
	return false
