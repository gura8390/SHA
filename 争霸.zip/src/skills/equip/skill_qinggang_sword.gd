# ============================================================
# skill_qinggang_sword.gd
# 装备技：青釭剑——锁定技（武器）
#   - 你使用【杀】时，目标的防具无效
#
# 实现：监听 DAMAGE_BEFORE，当 owner 是伤害来源且伤害牌为杀时，
# 在 event.data 中标记 ignore_armor = true。
# 藤甲/仁王盾/白银狮子 在其 can_trigger 开头检查此标记。
#
# 优先级 10（高于所有防具），确保先于防具的 can_trigger 执行。
#
# Gemini:change.10: 新建——青釭剑武器装备技
# ============================================================

class_name SkillQinggangSword
extends Skill


func register_events() -> void:
	EventBus.subscribe(GameEvent.Type.DAMAGE_BEFORE, _on_event_received, 10, self)


func can_trigger(event: GameEvent) -> bool:
	# 只在 owner 造成伤害时生效（来源 = owner）
	if event.source != owner_index:
		return false
	# 伤害牌必须是杀（含火杀/雷杀）
	var card = event.data.get("card", null)
	if card == null:
		return false
	return card.card_name == "杀" or card.card_name == "火杀" or card.card_name == "雷杀"


func execute(event: GameEvent) -> void:
	# 标记：目标防具对此伤害无效
	event.data["ignore_armor"] = true
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, event.target,
		{"skill.qinggang_sword.name": "青釭剑", "skill.qinggang_sword.effect": "ignore_armor"}
	))
