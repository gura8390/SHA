# ============================================================
# skill_cixiong_sword.gd
# 装备技：雌雄双股剑——锁定技（武器）
#   - 当你使用【杀】指定一名异性角色为该【杀】的目标后，令其选择一项：
#     ① 弃置一张手牌；② 令你摸一张牌。
#
# 监听 CARD_TARGETED：owner 出杀指定目标后触发
#
# Gemini:change.10: 新建——雌雄双股剑武器装备技（含性别判定）
# ============================================================

class_name SkillCixiongSword
extends Skill


func register_events() -> void:
	EventBus.subscribe(GameEvent.Type.CARD_TARGETED, _on_event_received, 0, self)


func can_trigger(event: GameEvent) -> bool:
	# 只在 owner 使用牌时触发
	if event.source != owner_index:
		return false
	# 必须是杀（含火杀/雷杀）
	var card = event.data.get("card", null)
	if card == null:
		return false
	if card.card_name != "杀" and card.card_name != "火杀" and card.card_name != "雷杀":
		return false
	# 性别判定：只对异性目标触发
	var owner = battle_context.get_player(owner_index)
	var target = battle_context.get_player(event.target)
	if owner == null or target == null:
		return false
	if owner.hero_data == null or target.hero_data == null:
		return false
	# 同性别不触发
	if owner.hero_data.gender == target.hero_data.gender:
		return false
	return true


func execute(event: GameEvent) -> void:
	var target = battle_context.get_player(event.target)
	if target == null or not target.is_alive:
		return

	var owner = battle_context.get_player(owner_index)
	if owner == null:
		return

	if not target.hand_cards.is_empty():
		# 目标弃一张最低价值手牌
		var worst: CardData = null
		var worst_value: int = 99999
		for c in target.hand_cards:
			var v = _simple_card_value(c)
			if v < worst_value:
				worst_value = v
				worst = c
		if worst != null:
			# 红线 1：通过 DiscardCardEffect 弃置手牌，禁止直接 erase + add_to_discard_pile
			DiscardCardEffect.create(
				event.target, event.target, [worst], DiscardCardEffect.DiscardReason.FORCED
			).resolve(battle_context)
	else:
		# 目标无手牌：令 owner 摸一张牌
		# 红线 1：通过 DrawCardEffect 摸牌，禁止直接 draw_from_pile + append
		DrawCardEffect.create(owner_index, owner_index, 1).resolve(battle_context)

	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, event.target,
		{"skill.cixiong_sword.name": "雌雄双股剑", "skill.cixiong_sword.effect": "discard_or_draw"}
	))


## 简化的卡牌价值评估（用于选弃哪张）
func _simple_card_value(card: CardData) -> int:
	if card == null:
		return 0
	match card.card_name:
		"桃": return 100
		"无懈可击": return 80
		"闪": return 60
		"酒": return 40
		"火杀", "雷杀": return 38
		"杀": return 35
		"无中生有": return 30
		"决斗": return 28
		"过河拆桥", "顺手牵羊": return 26
		"万箭齐发", "南蛮入侵": return 24
		"乐不思蜀", "兵粮寸断", "闪电": return 22
		_: return 15
