# ============================================================
# skill_fangtian_halberd.gd
# 装备技：方天画戟——锁定技（武器）
#
# 标准规则：当你使用的【杀】是你的最后一张手牌时，你可以为此【杀】
#           指定至多三个目标（而非默认的一个）。
#
# 实现方式：在 card_resolver.gd 的 get_effective_target_count 中
#           检查 source 是否装备了方天画戟且手牌仅剩1张。
#           UI 通过 get_effective_target_count 获取目标数上限。
#
# Gemini:change.10: 实现——方天画戟武器装备技
# ============================================================

class_name SkillFangtianHalberd
extends Skill


func register_events() -> void:
	# 方天画戟的逻辑在 card_resolver.get_effective_target_count 中触发
	pass


func can_trigger(_event: GameEvent) -> bool:
	return false


func execute(_event: GameEvent) -> void:
	pass
