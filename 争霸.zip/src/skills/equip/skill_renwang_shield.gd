# ============================================================
# skill_renwang_shield.gd
# 装备技：仁王盾——锁定技，黑色【杀】对你无效（防具）
# 监听 DAMAGE_BEFORE：若伤害来源是黑色杀，取消伤害。
# Gemini:change.8: 新建——防具装备技样例
# ============================================================

class_name SkillRenwangShield
extends Skill


func register_events() -> void:
	EventBus.subscribe(GameEvent.Type.DAMAGE_BEFORE, _on_event_received, 100, self)


func can_trigger(event: GameEvent) -> bool:
	# 只防自己受到的伤害
	if event.target != owner_index:
		return false
	var card = event.data.get("card", null)
	if card == null:
		return false
	# 必须是黑色的【杀】（含火杀/雷杀）
	if card.card_name != "杀" and card.card_name != "火杀" and card.card_name != "雷杀":
		return false
	return card.is_black()


func execute(event: GameEvent) -> void:
	# 取消这次伤害（黑杀无效）
	event.is_cancelled = true
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.renwang_shield.name": "仁王盾", "skill.renwang_shield.effect": "negate_black_sha"}
	))
