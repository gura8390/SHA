# ============================================================
# skill_qinglong_dao.gd
# 装备技：青龙偃月刀——锁定技（武器）
#
# 标准规则：当你使用的【杀】被目标的【闪】抵消后，你可以对该角色再使用一张【杀】。
#
# 实现方式：在 card_effect_sha.gd 的 _try_weapon_follow_through 中
#           检查 source 是否装备了青龙偃月刀，并询问是否追加杀。
#
# Gemini:change.10: 实现——青龙偃月刀武器装备技
# ============================================================

class_name SkillQinglongDao
extends Skill


func register_events() -> void:
	# 青龙偃月刀的逻辑在 card_effect_sha._try_weapon_follow_through 中触发
	pass


func can_trigger(_event: GameEvent) -> bool:
	return false


func execute(_event: GameEvent) -> void:
	pass
