# ============================================================
# skill_baiyin_shizi.gd
# 装备技：白银狮子——锁定技（防具）
#   - 当你受到伤害时，若该伤害大于1点，防止多余的伤害（即每次受伤最多扣1点HP）
#
# 监听 DAMAGE_BEFORE：
#   - amount > 1 → amount = 1
#
# 青釭剑互斥：检查 event.data.get("ignore_armor")，若为 true 则不生效。
#
# Gemini:change.10: 新建——白银狮子防具装备技
# ============================================================

class_name SkillBaiyinShizi
extends Skill


func register_events() -> void:
	EventBus.subscribe(GameEvent.Type.DAMAGE_BEFORE, _on_event_received, 100, self)


func can_trigger(event: GameEvent) -> bool:
	if event.target != owner_index:
		return false
	# 青釭剑无视防具
	if event.data.get("ignore_armor", false):
		return false
	# 只有伤害 > 1 时才有意义
	return event.data.get("amount", 1) > 1


func execute(event: GameEvent) -> void:
	event.data["amount"] = 1
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.baiyin_shizi.name": "白银狮子", "skill.baiyin_shizi.effect": "cap_damage_at_1"}
	))
