# ============================================================
# skill_zhuge_crossbow.gd
# 装备技：诸葛连弩——出牌阶段使用【杀】无次数限制（被动技）
# 由 EquipEffect 在装上诸葛连弩时安装，卸下时移除。
# Gemini:change.8: 新建——装备技样例（接入技能地基）
# ============================================================

class_name SkillZhugeCrossbow
extends Skill


func register_events() -> void:
	# 红线 1：通过 modify_attribute 修改 kill_limit，禁止直接赋值
	skill_data.modifies_attributes = true


func modify_attribute(attr_name: String, base_value, _ctx_data: Dictionary = {}):
	match attr_name:
		"kill_limit":
			return 999  # 杀无次数限制
	return base_value


func can_trigger(_event: GameEvent) -> bool:
	return false


func execute(_event: GameEvent) -> void:
	pass
