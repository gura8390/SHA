# ============================================================
# skill_qilin_bow.gd
# 装备技：麒麟弓——锁定技（武器）
#   - 当你使用【杀】对目标造成伤害后，可弃置目标装备区里的一匹马（+1马或-1马）
#
# 监听 DAMAGE_AFTER：
#   - owner 为伤害来源 + 伤害牌为杀 + 目标有坐骑
#   - 优先弃 +1马（防御马），其次 -1马（进攻马）
#
# Gemini:change.10: 新建——麒麟弓武器装备技
# ============================================================

class_name SkillQilinBow
extends Skill


func register_events() -> void:
	EventBus.subscribe(GameEvent.Type.DAMAGE_AFTER, _on_event_received, 0, self)


func can_trigger(event: GameEvent) -> bool:
	# 只在 owner 造成伤害时触发
	if event.source != owner_index:
		return false
	# 伤害牌必须是杀
	var card = event.data.get("card", null)
	if card == null:
		return false
	if card.card_name != "杀" and card.card_name != "火杀" and card.card_name != "雷杀":
		return false
	# 目标必须有坐骑可弃
	var target = battle_context.get_player(event.target)
	if target == null:
		return false
	return target.equip_horse_def != null or target.equip_horse_atk != null


func execute(event: GameEvent) -> void:
	var target = battle_context.get_player(event.target)
	if target == null:
		return

	# 红线 1：通过 DiscardCardEffect 弃置装备，禁止直接 null + add_to_discard_pile
	var removed_card: CardData = null
	var slot_name: String = ""
	if target.equip_horse_def != null:
		removed_card = target.equip_horse_def
		slot_name = "horse_def"
	elif target.equip_horse_atk != null:
		removed_card = target.equip_horse_atk
		slot_name = "horse_atk"

	if removed_card != null:
		# 清空装备槽
		match slot_name:
			"horse_def": target.equip_horse_def = null
			"horse_atk": target.equip_horse_atk = null
		# 通过 Effect 弃置装备牌
		DiscardCardEffect.create(event.target, event.target, [removed_card], DiscardCardEffect.DiscardReason.FORCED).resolve(battle_context)
		# 发布装备移除事件（触发枭姬等技能）
		EventBus.publish(GameEvent.create(
			GameEvent.Type.EQUIP_REMOVED, event.target, event.target,
			{"card": removed_card, "slot": slot_name}
		))
		EventBus.publish(GameEvent.create(
			GameEvent.Type.SKILL_RESOLVED, owner_index, event.target,
			{"skill.qilin_bow.name": "麒麟弓", "skill.qilin_bow.effect": "discard_horse", "card": removed_card}
		))
