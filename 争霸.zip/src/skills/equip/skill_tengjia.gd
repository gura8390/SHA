# ============================================================
# skill_tengjia.gd
# 装备技：藤甲——锁定技（防具）
#   - 【南蛮入侵】【万箭齐发】和普通【杀】对你无效
#   - 你受到火焰伤害时，该伤害+1
#
# 监听 DAMAGE_BEFORE：
#   - 普通杀（NORMAL + 来源卡牌为杀/火杀/雷杀）→ is_cancelled
#   - 南蛮/万箭的 AOE 伤害（card_name 为杀 且 来源 context 为 aoe）→ 同样免疫
#   - 火焰伤害（FIRE）→ amount += 1
#
# 青釭剑互斥：检查 event.data.get("ignore_armor")，若为 true 则不生效。
#
# Gemini:change.10: 新建——藤甲防具装备技
# ============================================================

class_name SkillTengjia
extends Skill


func register_events() -> void:
	EventBus.subscribe(GameEvent.Type.DAMAGE_BEFORE, _on_event_received, 100, self)


func can_trigger(event: GameEvent) -> bool:
	# 只对自己受到的伤害生效
	if event.target != owner_index:
		return false
	# 青釭剑无视防具
	if event.data.get("ignore_armor", false):
		return false

	var dmg_type: int = event.data.get("damage_type", 0)
	var card = event.data.get("card", null)

	# 火焰伤害：伤害+1
	if dmg_type == DamageEffect.DamageType.FIRE:
		return true

	# 普通杀/雷杀（基本牌为杀）→ 藤甲免疫
	## 注意：火杀的 dmg_type=FIRE，不在这里处理（走上面 +1 分支）
	if card != null and (card.card_name == "杀" or card.card_name == "雷杀"):
		return true

	# 南蛮入侵/万箭齐发的 AOE 伤害（card 为杀 且 来源卡牌为 南蛮/万箭）
	## AOE 结算时 card 一般为 null 或来源锦囊牌，此处检查 dmg_type=NORMAL 即可
	## 实际上南蛮/万箭的 DamageEffect card 为 null（见 nanman/wanjian effect），所以
	## 用"card 为 null 且 NORMAL"来判断是 AOE 伤害（保守判断，不影响其他逻辑）
	if card == null and dmg_type == DamageEffect.DamageType.NORMAL:
		return true

	return false


func execute(event: GameEvent) -> void:
	var dmg_type: int = event.data.get("damage_type", 0)
	if dmg_type == DamageEffect.DamageType.FIRE:
		# 火焰伤害+1
		event.data["amount"] = event.data.get("amount", 1) + 1
		EventBus.publish(GameEvent.create(
			GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
			{"skill.tengjia.name": "藤甲", "skill.tengjia.effect": "fire_damage_increase"}
		))
	else:
		# 免疫（普通杀/雷杀/南蛮/万箭）
		event.is_cancelled = true
		EventBus.publish(GameEvent.create(
			GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
			{"skill.tengjia.name": "藤甲", "skill.tengjia.effect": "negate_damage"}
		))
