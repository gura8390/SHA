# ============================================================
# skill_bagua.gd
# 装备技：八卦阵——锁定技，当你需要使用或打出【闪】时可判定，红则视为打出闪（防具）
#
# 实现方式：由 card_effect_sha.gd 在请求"闪"之前主动调用 try_judge_dodge()。
# 若判定为红色（红心/方块），视为打出一张虚拟"闪"，不消耗手牌。
# 若判定为黑色（黑桃/梅花），不出闪，继续正常询问流程。
#
# Gemini:change.8: 新建
# Gemini:change.10: 补全判定逻辑（接入 JudgeSystem）
# ============================================================

class_name SkillBagua
extends Skill


## 注册事件——八卦阵不通过事件触发，而是由杀的结算直接调用 try_judge_dodge()
func register_events() -> void:
	pass


func can_trigger(_event: GameEvent) -> bool:
	return false


func execute(_event: GameEvent) -> void:
	pass


## 八卦阵核心：判定一次，红则视为出闪。
## @return: true = 八卦阵生效（视为出闪），false = 判定为黑（未出闪）
func try_judge_dodge() -> bool:
	if battle_context == null:
		return false
	var judge_sys = battle_context.judge_system
	if judge_sys == null:
		return false

	# 执行判定（reason="八卦阵"供改判技能识别）
	var result: Dictionary = judge_sys.perform_judge(owner_index, "八卦阵")
	var is_red: bool = result.get("is_red", false)

	if is_red:
		# 八卦阵生效：视为打出闪
		EventBus.publish(GameEvent.create(
			GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
			{"skill.bagua.name": "八卦阵", "skill.bagua.effect": "dodge_by_judge"}
		))
		return true
	return false
