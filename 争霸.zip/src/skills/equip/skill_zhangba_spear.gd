# ============================================================
# skill_zhangba_spear.gd
# 装备技：丈八蛇矛——锁定技（武器）
#
# 标准规则：你可以将两张手牌当做一张【杀】使用或打出。
#
# 实现方式：
#   在 SmartAI.decide_play_action 中，当 AI 装备了丈八蛇矛且无杀但有2+手牌时，
#   将两张手牌合并为一张虚拟杀使用。
#   在 HumanController 中，提供"丈八蛇矛"出牌选项。
#
# Gemini:change.10: 实现——丈八蛇矛武器装备技
# ============================================================

class_name SkillZhangbaSpear
extends Skill


func register_events() -> void:
	# 丈八蛇矛的逻辑在 AI/控制器层触发
	pass


func can_trigger(_event: GameEvent) -> bool:
	return false


func execute(_event: GameEvent) -> void:
	pass


## 检查某玩家是否装备了丈八蛇矛
static func is_equipped(battle_context, player_index: int) -> bool:
	var player = battle_context.get_player(player_index)
	if player == null:
		return false
	for sk in player.skills:
		if sk is SkillZhangbaSpear:
			return true
	return false


## 创建虚拟杀（由两张手牌转化）
## 返回一个 PlayIntent，source_index 使用选中的两张牌当杀
static func create_sha_from_two_cards(player_index: int, two_cards: Array, target_index: int) -> PlayIntent:
	# 创建一张虚拟杀
	var virtual_sha = CardData.new()
	virtual_sha.card_id = "sha_zhangba"
	virtual_sha.card_name = "杀"
	virtual_sha.card_type = CardData.CardType.BASIC
	virtual_sha.need_target = true
	virtual_sha.target_count = 1
	virtual_sha.description = "丈八蛇矛转化的杀"

	var intent = PlayIntent.new()
	intent.source_index = player_index
	intent.card = virtual_sha
	intent.target_indices = [target_index]
	intent.convert_cards = two_cards  # 标记为转化牌
	return intent
