# ============================================================
# skill_guanshi_axe.gd
# 装备技：贯石斧——锁定技（武器）
#
# 标准规则：当你使用的【杀】被目标的【闪】抵消后，你可以弃置两张手牌，
#           令此【杀】依然造成伤害（强制命中）。
#
# 实现方式：在 card_effect_sha.gd 的 _try_weapon_follow_through 中
#           检查 source 是否装备了贯石斧，并询问是否弃2张手牌。
#
# Gemini:change.10: 实现——贯石斧武器装备技
# ============================================================

class_name SkillGuanshiAxe
extends Skill


func register_events() -> void:
	# 贯石斧的逻辑在 card_effect_sha._try_weapon_follow_through 中触发
	# 通过检查 source 的 skills 中是否有 SkillGuanshiAxe 实例
	pass


func can_trigger(_event: GameEvent) -> bool:
	return false


func execute(_event: GameEvent) -> void:
	pass
