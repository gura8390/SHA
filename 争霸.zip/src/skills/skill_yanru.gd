# ============================================================
# skill_yanru.gd
# 费祎技能：晏如（主动技）
#
# 描述：出牌阶段各限一次，若你的手牌数为：
#   奇数 → 摸三张牌并弃置至少半数手牌
#   偶数 → 弃置至少半数手牌并摸三张牌
#
# 关键：奇数/偶数各限一次。即一回合内最多发动2次（一次奇数、一次偶数）。
# ============================================================

class_name SkillYanRu
extends Skill

## 记录本回合已发动的条件（奇数/偶数各自独立计数）
var _used_odd_this_turn: bool = false
var _used_even_this_turn: bool = false


func reset_turn_count() -> void:
	super.reset_turn_count()
	_used_odd_this_turn = false
	_used_even_this_turn = false


func can_activate() -> bool:
	if not is_enabled:
		return false
	var owner = get_owner_player()
	if owner == null:
		return false

	var hand_count: int = owner.hand_cards.size()
	var is_odd: bool = (hand_count % 2) == 1

	# 奇数/偶数各限一次
	if is_odd and _used_odd_this_turn:
		return false
	if not is_odd and _used_even_this_turn:
		return false

	return true


func activate(_targets: Array) -> Dictionary:
	var owner = get_owner_player()
	if owner == null:
		return {"resolved": false}

	var hand_count: int = owner.hand_cards.size()
	var is_odd: bool = (hand_count % 2) == 1

	# 标记已发动
	if is_odd:
		_used_odd_this_turn = true
	else:
		_used_even_this_turn = true

	if is_odd:
		# 奇数：先摸3张，再弃至少半数
		DrawCardEffect.create(owner_index, owner_index, 3).resolve(battle_context)

		var new_hand_count: int = owner.hand_cards.size()
		var discard_min: int = ceili(float(new_hand_count) / 2.0)
		var to_discard := _pick_lowest_cards(owner, discard_min)

		if not to_discard.is_empty():
			# 红线 1：通过 DiscardCardEffect 弃置手牌，禁止先 erase 再 Effect
			DiscardCardEffect.create(
				owner_index, owner_index, to_discard,
				DiscardCardEffect.DiscardReason.PHASE_DISCARD
			).resolve(battle_context)

		EventBus.publish(GameEvent.create(
			GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
			{"skill.yanru.name": "晏如", "mode": "odd", "discarded": to_discard.size()}
		))
	else:
		# 偶数：先弃至少半数，再摸3张
		var discard_min: int = ceili(float(hand_count) / 2.0)
		var to_discard := _pick_lowest_cards(owner, discard_min)

		if not to_discard.is_empty():
			# 红线 1：通过 DiscardCardEffect 弃置手牌，禁止先 erase 再 Effect
			DiscardCardEffect.create(
				owner_index, owner_index, to_discard,
				DiscardCardEffect.DiscardReason.PHASE_DISCARD
			).resolve(battle_context)

		DrawCardEffect.create(owner_index, owner_index, 3).resolve(battle_context)

		EventBus.publish(GameEvent.create(
			GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
			{"skill.yanru.name": "晏如", "mode": "even", "discarded": to_discard.size()}
		))

	return {"resolved": true}


## 选取最低价值的 n 张牌
func _pick_lowest_cards(player, n: int) -> Array:
	var sorted_cards = player.hand_cards.duplicate()
	sorted_cards.sort_custom(func(a, b): return _card_value(a) < _card_value(b))
	var result: Array = []
	for i in range(min(n, sorted_cards.size())):
		result.append(sorted_cards[i])
	return result


func _card_value(card: CardData) -> int:
	if card == null:
		return 0
	match card.card_name:
		"桃": return 100
		"无懈可击": return 80
		"闪": return 60
		"酒": return 40
		"火杀", "雷杀": return 38
		"杀": return 35
		"无中生有": return 30
		"决斗": return 28
		"过河拆桥", "顺手牵羊": return 26
		"万箭齐发", "南蛮入侵": return 24
		"乐不思蜀", "兵粮寸断", "闪电": return 22
		"借刀杀人": return 20
		"五谷丰登", "桃园结义": return 18
		_:
			if card.card_type == CardData.CardType.EQUIPMENT:
				return 32
			return 15
