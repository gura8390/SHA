# ============================================================
# skill_paoxiao.gd
# 张飞技能：咆哮
# 描述：出牌阶段，你使用【杀】无次数限制。
# 类型：被动技（通过 modify_attribute 修改 kill_limit）
# Gemini:change.1: 初始创建——实现"咆哮"技能
# ============================================================

class_name SkillPaoXiao
extends Skill


func register_events() -> void:
	# 红线 1：通过 modify_attribute 修改 kill_limit，禁止直接赋值
	skill_data.modifies_attributes = true


func modify_attribute(attr_name: String, base_value, _ctx_data: Dictionary = {}):
	match attr_name:
		"kill_limit":
			return 999  # 杀无次数限制
	return base_value


func can_trigger(_event: GameEvent) -> bool:
	return false


func execute(_event: GameEvent) -> void:
	pass
