# ============================================================
# skill_juece.gd
# 武将技能：绝策（触发技）
#
# 描述：其他角色失去最后的手牌后，你可对其造成1点伤害。
#
# Gemini:change.12: 批量生成——李儒绝策
# ============================================================

class_name SkillJuece
extends Skill


func register_events() -> void:
	pass


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index  # 自己受到伤害


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	# TODO: 实现具体效果
	var source_idx = event.source
	if source_idx < 0:
		return
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.juece.name": "绝策", "skill.juece.effect": "juece"}
	))
