# ============================================================
# skill_guzheng.gd
# 武将技能：固政（触发技）
#
# 描述：其他角色弃牌阶段结束时，你可获得其中1张牌。
#
# Gemini:change.12: 批量生成——张昭张纮固政
# ============================================================

class_name SkillGuzheng
extends Skill


func register_events() -> void:
	pass


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index  # 自己受到伤害


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	# TODO: 实现具体效果
	var source_idx = event.source
	if source_idx < 0:
		return
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.guzheng.name": "固政", "skill.guzheng.effect": "guzheng"}
	))
