# ============================================================
# skill_yicong.gd
# 武将技能：义从（被动技）
#
# 描述：锁定技，你计算与其他角色的距离-1。
#
# Gemini:change.12: 批量生成——公孙瓒义从
# ============================================================

class_name SkillYicong
extends Skill


func register_events() -> void:
	pass


func can_trigger(_event: GameEvent) -> bool:
	return false


func execute(_event: GameEvent) -> void:
	pass
