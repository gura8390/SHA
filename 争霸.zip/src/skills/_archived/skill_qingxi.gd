# ============================================================
# skill_qingxi.gd
# 武将技能：倾袭（触发技）
#
# 描述：使用杀造成伤害后可弃1张牌令此伤害+1。
#
# Gemini:change.12: 批量生成——曹休倾袭
# ============================================================

class_name SkillQingxi
extends Skill


func register_events() -> void:
	EventBus.subscribe(GameEvent.Type.DAMAGE_BEFORE, _on_event_received, 0, self)


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index  # 自己受到伤害


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	# TODO: 实现具体效果
	var source_idx = event.source
	if source_idx < 0:
		return
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.qingxi.name": "倾袭", "skill.qingxi.effect": "qingxi"}
	))
