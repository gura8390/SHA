# ============================================================
# skill_moubian.gd
# 武将技能：谋变（触发技）
#
# 描述：判定牌生效前，可用一张手牌代替之，若改判牌与原判定颜色不同，你摸一张牌。
#
# Gemini:change.12: 批量生成——司马懿谋变
# ============================================================

class_name SkillMoubian
extends Skill


func register_events() -> void:
	pass


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index  # 自己受到伤害


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	# TODO: 实现具体效果
	var source_idx = event.source
	if source_idx < 0:
		return
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.moubian.name": "谋变", "skill.moubian.effect": "moubian"}
	))
