# ============================================================
# skill_zhuangkong.gd
# 武将技能：惴恐（触发技）
#
# 描述：受到伤害后可令伤害来源进行判定，若不为红桃其受到1点伤害。
#
# Gemini:change.12: 批量生成——伏皇后惴恐
# ============================================================

class_name SkillZhuangkong
extends Skill


func register_events() -> void:
	EventBus.subscribe(GameEvent.Type.DAMAGE_AFTER, _on_event_received, 0, self)


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index  # 自己受到伤害


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	# TODO: 实现具体效果
	var source_idx = event.source
	if source_idx < 0:
		return
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.zhuangkong.name": "惴恐", "skill.zhuangkong.effect": "zhuangkong"}
	))
