# ============================================================
# skill_jueqing.gd
# 武将技能：绝情（锁定技）
#
# 描述：锁定技，你造成的伤害均视为失去体力。
#
# Gemini:change.12: 批量生成——张春华绝情
# ============================================================

class_name SkillJueqing
extends Skill


func register_events() -> void:
	pass


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index  # 自己受到伤害


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	# TODO: 实现具体效果
	var source_idx = event.source
	if source_idx < 0:
		return
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.jueqing.name": "绝情", "skill.jueqing.effect": "jueqing"}
	))
