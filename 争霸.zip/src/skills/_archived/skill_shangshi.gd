# ============================================================
# skill_shangshi.gd
# 武将技能：伤逝（被动技）
#
# 描述：手牌数小于X时，可将手牌摸至X张（X为已损失体力值）。
#
# Gemini:change.12: 批量生成——张春华伤逝
# ============================================================

class_name SkillShangshi
extends Skill


func register_events() -> void:
	pass


func can_trigger(_event: GameEvent) -> bool:
	return false


func execute(_event: GameEvent) -> void:
	pass
