# ============================================================
# skill_pingkou.gd
# 武将技能：平寇（触发技）
#
# 描述：回合结束时，可对一名手牌数小于你的角色造成1点伤害。
#
# Gemini:change.12: 批量生成——朱桓平寇
# ============================================================

class_name SkillPingkou
extends Skill


func register_events() -> void:
	EventBus.subscribe(GameEvent.Type.TURN_END, _on_event_received, 0, self)


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index  # 自己受到伤害


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	# TODO: 实现具体效果
	var source_idx = event.source
	if source_idx < 0:
		return
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.pingkou.name": "平寇", "skill.pingkou.effect": "pingkou"}
	))
