# ============================================================
# skill_tianyi.gd
# 武将技能：天翊（被动技）
#
# 描述：觉醒技，准备阶段所有存活角色均受过伤害时，增加2点体力上限、回复1点体力，令一名角色获得佐幸技能。
#
# Gemini:change.12: 批量生成——郭嘉天翊
# ============================================================

class_name SkillTianyi
extends Skill


func register_events() -> void:
	pass


func can_trigger(_event: GameEvent) -> bool:
	return false


func execute(_event: GameEvent) -> void:
	pass
