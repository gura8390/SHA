# ============================================================
# skill_yuejian.gd
# 武将技能：约俭（被动技）
#
# 描述：手牌上限等于体力上限；进入濒死状态时，弃2张牌可回复1点体力。
#
# Gemini:change.12: 批量生成——卞夫人约俭
# ============================================================

class_name SkillYuejian
extends Skill


func register_events() -> void:
	pass


func can_trigger(_event: GameEvent) -> bool:
	return false


func execute(_event: GameEvent) -> void:
	pass
