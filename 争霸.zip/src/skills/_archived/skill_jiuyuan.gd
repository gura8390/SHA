# ============================================================
# skill_jiuyuan.gd
# 武将技能：救援（触发技）
#
# 描述：主公技，其他吴势力角色对你使用【桃】时，若其体力值大于你，可改为令你回复1点体力，然后其摸1张牌。
#
# Gemini:change.12: 批量生成——孙权救援
# ============================================================

class_name SkillJiuyuan
extends Skill


func register_events() -> void:
	EventBus.subscribe(GameEvent.Type.CARD_USED, _on_event_received, 0, self)


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index  # 自己受到伤害


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	# TODO: 实现具体效果
	var source_idx = event.source
	if source_idx < 0:
		return
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.jiuyuan.name": "救援", "skill.jiuyuan.effect": "jiuyuan"}
	))
