# ============================================================
# skill_tuisheng.gd
# 武将技能：蜕生（主动技）
#
# 描述：限定技，准备阶段或进入濒死时，重置赂存使用过的牌名，选择一项并回复1点体力。
#
# Gemini:change.12: 批量生成——张让蜕生
# ============================================================

class_name SkillTuisheng
extends Skill


func register_events() -> void:
	pass


func can_activate() -> bool:
	if not is_enabled:
		return false
	if not _check_use_limit():
		return false
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return not owner.hand_cards.is_empty()


func get_active_targets() -> Array:
	var result: Array = []
	for p in battle_context.get_alive_players():
		if p.index != owner_index:
			result.append(p.index)
	return result


func activate(targets: Array) -> Dictionary:
	var owner = get_owner_player()
	if owner == null:
		return {"resolved": false, "reason": "no_owner"}
	if targets.is_empty():
		return {"resolved": false, "reason": "no_target"}
	var target_idx = targets[0]
	HealEffect.create(owner_index, target_idx, 1, null).resolve(battle_context)
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, -1,
		{"skill.tuisheng.name": "蜕生", "skill.tuisheng.effect": "tuisheng"}
	))
	return {"resolved": true}
