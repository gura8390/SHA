# ============================================================
# skill_guifu.gd
# 武将技能：诡伏（触发技）
#
# 描述：受到伤害后可获得伤害来源一张手牌。
#
# Gemini:change.12: 批量生成——司马懿诡伏
# ============================================================

class_name SkillGuifu
extends Skill


func register_events() -> void:
	EventBus.subscribe(GameEvent.Type.DAMAGE_AFTER, _on_event_received, 0, self)


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	var source_idx = event.source
	if source_idx < 0:
		return
	var source_player = battle_context.get_player(source_idx)
	if source_player != null and not source_player.hand_cards.is_empty():
		# 红线 1：通过 TransferCardEffect 转移牌，禁止直接修改状态
		var stolen = source_player.hand_cards.back()
		TransferCardEffect.hand_to_hand(source_idx, owner_index, [stolen], "guifu").execute(battle_context, null)
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.guifu.name": "诡伏", "skill.guifu.effect": "guifu"}
	))
