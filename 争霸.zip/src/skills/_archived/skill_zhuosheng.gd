# ============================================================
# skill_zhuosheng.gd
# 武将技能：擢升（被动技）
#
# 描述：出牌阶段使用本轮获得的牌时，按类型触发效果：基本牌不计入使用次数且无距离限制；普通锦囊牌目标可+1或-1；装备牌可摸1张牌。
#
# Gemini:change.12: 批量生成——石苞擢升
# ============================================================

class_name SkillZhuosheng
extends Skill


func register_events() -> void:
	pass


func can_trigger(_event: GameEvent) -> bool:
	return false


func execute(_event: GameEvent) -> void:
	pass
