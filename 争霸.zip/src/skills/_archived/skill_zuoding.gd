# ============================================================
# skill_zuoding.gd
# 武将技能：佐定（触发技）
#
# 描述：其他角色使用基本牌指定目标后，你可令其摸1张牌。
#
# Gemini:change.12: 批量生成——钟繇佐定
# ============================================================

class_name SkillZuoding
extends Skill


func register_events() -> void:
	EventBus.subscribe(GameEvent.Type.CARD_USED, _on_event_received, 0, self)


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index  # 自己受到伤害


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	# TODO: 实现具体效果
	var source_idx = event.source
	if source_idx < 0:
		return
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.zuoding.name": "佐定", "skill.zuoding.effect": "zuoding"}
	))
