# ============================================================
# skill_weiba.gd
# 武将技能：威霸（锁定技）
#
# 描述：锁定技，准备阶段选一名其他角色，直到你下回合开始：其用杀指定你时需弃1张牌或受你1点伤害。
#
# Gemini:change.12: 批量生成——孙策威霸
# ============================================================

class_name SkillWeiba
extends Skill


func register_events() -> void:
	pass


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index  # 自己受到伤害


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	# TODO: 实现具体效果
	var source_idx = event.source
	if source_idx < 0:
		return
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.weiba.name": "威霸", "skill.weiba.effect": "weiba"}
	))
