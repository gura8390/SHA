# ============================================================
# skill_tianzuo.gd
# 武将技能：天佐（锁定技）
#
# 描述：锁定技，游戏开始时将8张【奇正相生】加入牌堆；【奇正相生】对你无效。
#
# Gemini:change.12: 批量生成——荀彧天佐
# ============================================================

class_name SkillTianzuo
extends Skill


func register_events() -> void:
	pass


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index  # 自己受到伤害


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	# TODO: 实现具体效果
	var source_idx = event.source
	if source_idx < 0:
		return
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.tianzuo.name": "天佐", "skill.tianzuo.effect": "tianzuo"}
	))
