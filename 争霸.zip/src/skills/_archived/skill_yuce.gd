# ============================================================
# skill_yuce.gd
# 武将技能：御策（触发技）
#
# 描述：受到伤害后可展示1张手牌，若伤害来源无法弃置与此牌同类型的牌，你回复1点体力。
#
# Gemini:change.12: 批量生成——满宠御策
# ============================================================

class_name SkillYuce
extends Skill


func register_events() -> void:
	EventBus.subscribe(GameEvent.Type.DAMAGE_AFTER, _on_event_received, 0, self)


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index  # 自己受到伤害


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	# TODO: 实现具体效果
	var source_idx = event.source
	if source_idx < 0:
		return
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.yuce.name": "御策", "skill.yuce.effect": "yuce"}
	))
