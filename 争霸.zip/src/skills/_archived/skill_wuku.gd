# ============================================================
# skill_wuku.gd
# 武将技能：武库（被动技）
#
# 描述：觉醒技，准备阶段单回合发动三陈至少3次时，减少1点体力上限，获得破竹技能。
#
# Gemini:change.12: 批量生成——杜预武库
# ============================================================

class_name SkillWuku
extends Skill


func register_events() -> void:
	pass


func can_trigger(_event: GameEvent) -> bool:
	return false


func execute(_event: GameEvent) -> void:
	pass
