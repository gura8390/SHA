# ============================================================
# skill_kuizhu.gd
# 武将技能：溃诛（触发技）
#
# 描述：其他角色死亡时，你可获得其所有手牌。
#
# Gemini:change.12: 批量生成——孙亮溃诛
# ============================================================

class_name SkillKuizhu
extends Skill


func register_events() -> void:
	pass


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index  # 自己受到伤害


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	# TODO: 实现具体效果
	var source_idx = event.source
	if source_idx < 0:
		return
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.kuizhu.name": "溃诛", "skill.kuizhu.effect": "kuizhu"}
	))
