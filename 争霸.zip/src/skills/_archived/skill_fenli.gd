# ============================================================
# skill_fenli.gd
# 武将技能：奋励（触发技）
#
# 描述：出牌阶段限一次，弃1张牌对一名角色造成1点伤害。
#
# Gemini:change.12: 批量生成——朱桓奋励
# ============================================================

class_name SkillFenli
extends Skill


func register_events() -> void:
	EventBus.subscribe(GameEvent.Type.PHASE_START, _on_event_received, 0, self)


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index  # 自己受到伤害


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	# TODO: 实现具体效果
	var source_idx = event.source
	if source_idx < 0:
		return
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.fenli.name": "奋励", "skill.fenli.effect": "fenli"}
	))
