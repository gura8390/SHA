# ============================================================
# skill_miji.gd
# 武将技能：秘计（触发技）
#
# 描述：受到伤害后可进行判定，若为红色你摸X张牌（X为已损失体力值）。
#
# Gemini:change.12: 批量生成——王异秘计
# ============================================================

class_name SkillMiji
extends Skill


func register_events() -> void:
	EventBus.subscribe(GameEvent.Type.DAMAGE_AFTER, _on_event_received, 0, self)


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	DrawCardEffect.create(owner_index, owner_index, 1).resolve(battle_context)
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.miji.name": "秘计", "skill.miji.effect": "miji"}
	))
