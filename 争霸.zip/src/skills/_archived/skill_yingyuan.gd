# ============================================================
# skill_yingyuan.gd
# 武将技能：应援（触发技）
#
# 描述：每回合限一次，你使用的牌结算后，可将此牌交给一名其他角色。
#
# Gemini:change.12: 批量生成——马良应援
# ============================================================

class_name SkillYingyuan
extends Skill


func register_events() -> void:
	pass


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index  # 自己受到伤害


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	# TODO: 实现具体效果
	var source_idx = event.source
	if source_idx < 0:
		return
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.yingyuan.name": "应援", "skill.yingyuan.effect": "yingyuan"}
	))
