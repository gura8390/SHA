# ============================================================
# skill_yuwei.gd
# 武将技能：余威（锁定技）
#
# 描述：主公技，锁定技，其他群势力角色回合内，诗怨改为每回合每项限两次。
#
# Gemini:change.12: 批量生成——刘辩余威
# ============================================================

class_name SkillYuwei
extends Skill


func register_events() -> void:
	pass


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index  # 自己受到伤害


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	# TODO: 实现具体效果
	var source_idx = event.source
	if source_idx < 0:
		return
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.yuwei.name": "余威", "skill.yuwei.effect": "yuwei"}
	))
