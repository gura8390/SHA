# ============================================================
# skill_dinghan.gd
# 武将技能：定汉（触发技）
#
# 描述：成为未记录的锦囊牌目标时，记录牌名并取消之；回合开始时可增减记录的锦囊牌名。
#
# Gemini:change.12: 批量生成——荀彧定汉
# ============================================================

class_name SkillDinghan
extends Skill


func register_events() -> void:
	pass


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index  # 自己受到伤害


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	# TODO: 实现具体效果
	var source_idx = event.source
	if source_idx < 0:
		return
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.dinghan.name": "定汉", "skill.dinghan.effect": "dinghan"}
	))
