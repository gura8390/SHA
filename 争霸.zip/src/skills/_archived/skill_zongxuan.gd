# ============================================================
# skill_zongxuan.gd
# 武将技能：纵玄（触发技）
#
# 描述：摸牌阶段可改为观看牌堆顶3张牌，获得其中1张，其余按任意顺序置于牌堆顶。
#
# Gemini:change.12: 批量生成——虞翻纵玄
# ============================================================

class_name SkillZongxuan
extends Skill


func register_events() -> void:
	EventBus.subscribe(GameEvent.Type.PHASE_START, _on_event_received, 0, self)


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index  # 自己受到伤害


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	# TODO: 实现具体效果
	var source_idx = event.source
	if source_idx < 0:
		return
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.zongxuan.name": "纵玄", "skill.zongxuan.effect": "zongxuan"}
	))
