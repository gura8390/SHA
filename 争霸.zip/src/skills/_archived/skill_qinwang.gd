# ============================================================
# skill_qinwang.gd
# 武将技能：勤王（触发技）
#
# 描述：主公技，你受到伤害时，其他蜀势力角色可替你承受此伤害。
#
# Gemini:change.12: 批量生成——刘谌勤王
# ============================================================

class_name SkillQinwang
extends Skill


func register_events() -> void:
	EventBus.subscribe(GameEvent.Type.DAMAGE_AFTER, _on_event_received, 0, self)


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index  # 自己受到伤害


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	# TODO: 实现具体效果
	var source_idx = event.source
	if source_idx < 0:
		return
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.qinwang.name": "勤王", "skill.qinwang.effect": "qinwang"}
	))
