# ============================================================
# skill_zhiyan.gd
# 武将技能：直言（触发技）
#
# 描述：结束阶段可令一名角色摸1张牌并展示之，若为装备牌其回复1点体力。
#
# Gemini:change.12: 批量生成——虞翻直言
# ============================================================

class_name SkillZhiyan
extends Skill


func register_events() -> void:
	EventBus.subscribe(GameEvent.Type.TURN_END, _on_event_received, 0, self)


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.source == owner_index


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	DrawCardEffect.create(owner_index, owner_index, 1).resolve(battle_context)
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.zhiyan.name": "直言", "skill.zhiyan.effect": "zhiyan"}
	))
