# ============================================================
# skill_liaoyi.gd
# 武将技能：疗疫（触发技）
#
# 描述：其他角色回合开始时，手牌数小于体力值且「仁」足够则令其获得X张「仁」；手牌数大于体力值则令其将X张牌置入「仁」。
#
# Gemini:change.12: 批量生成——张仲景疗疫
# ============================================================

class_name SkillLiaoyi
extends Skill


func register_events() -> void:
	EventBus.subscribe(GameEvent.Type.TURN_START, _on_event_received, 0, self)


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index  # 自己受到伤害


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	# TODO: 实现具体效果
	var source_idx = event.source
	if source_idx < 0:
		return
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.liaoyi.name": "疗疫", "skill.liaoyi.effect": "liaoyi"}
	))
