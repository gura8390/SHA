# ============================================================
# skill_dushi.gd
# 武将技能：毒逝（锁定技）
#
# 描述：锁定技，你进入濒死时，其他角色不能对你使用【桃】；死亡时令一名其他角色获得此技能。
#
# Gemini:change.12: 批量生成——刘辩毒逝
# ============================================================

class_name SkillDushi
extends Skill


func register_events() -> void:
	EventBus.subscribe(GameEvent.Type.PLAYER_DYING, _on_event_received, 0, self)


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index  # 自己受到伤害


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	# TODO: 实现具体效果
	var source_idx = event.source
	if source_idx < 0:
		return
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.dushi.name": "毒逝", "skill.dushi.effect": "dushi"}
	))
