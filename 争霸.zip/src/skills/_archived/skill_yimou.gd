# ============================================================
# skill_yimou.gd
# 武将技能：毅谋（触发技）
#
# 描述：一名角色受到伤害后，若与其距离1以内，可令其执行一项：从牌堆获得1张【杀】；交1张手牌给另一名角色然后摸1张牌。
#
# Gemini:change.12: 批量生成——鲍信毅谋
# ============================================================

class_name SkillYimou
extends Skill


func register_events() -> void:
	EventBus.subscribe(GameEvent.Type.DAMAGE_AFTER, _on_event_received, 0, self)


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	DrawCardEffect.create(owner_index, owner_index, 1).resolve(battle_context)
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.yimou.name": "毅谋", "skill.yimou.effect": "yimou"}
	))
