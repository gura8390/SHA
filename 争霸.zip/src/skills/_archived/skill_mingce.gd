# ============================================================
# skill_mingce.gd
# 武将技能：明策（主动技）
#
# 描述：出牌阶段限一次，交给一名其他角色1张牌，其须对你指定的角色使用一张杀或你摸1张牌。
#
# Gemini:change.12: 批量生成——陈宫明策
# ============================================================

class_name SkillMingce
extends Skill


func register_events() -> void:
	pass


func can_activate() -> bool:
	if not is_enabled:
		return false
	if not _check_use_limit():
		return false
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return not owner.hand_cards.is_empty()


func get_active_targets() -> Array:
	return []  # 无需目标


func activate(targets: Array) -> Dictionary:
	var owner = get_owner_player()
	if owner == null:
		return {"resolved": false, "reason": "no_owner"}
	DrawCardEffect.create(owner_index, owner_index, 2).resolve(battle_context)
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, -1,
		{"skill.mingce.name": "明策", "skill.mingce.effect": "mingce"}
	))
	return {"resolved": true}
