# ============================================================
# skill_wanwei.gd
# 武将技能：挽危（触发技）
#
# 描述：每轮限一次，令一名濒死的其他角色回复X+1点体力，你失去X点体力（X为你当前体力值）。
#
# Gemini:change.12: 批量生成——卞夫人挽危
# ============================================================

class_name SkillWanwei
extends Skill


func register_events() -> void:
	EventBus.subscribe(GameEvent.Type.PLAYER_DYING, _on_event_received, 0, self)


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index  # 自己受到伤害


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	# TODO: 实现具体效果
	var source_idx = event.source
	if source_idx < 0:
		return
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.wanwei.name": "挽危", "skill.wanwei.effect": "wanwei"}
	))
