# ============================================================
# skill_yizheng.gd
# 武将技能：翊正（触发技）
#
# 描述：结束阶段选择一名角色，直到你下回合开始，其造成伤害/回复体力时，若体力上限小于你，你减少1点体力上限，该伤害/回复值+1。
#
# Gemini:change.12: 批量生成——曹嵩翊正
# ============================================================

class_name SkillYizheng
extends Skill


func register_events() -> void:
	EventBus.subscribe(GameEvent.Type.TURN_END, _on_event_received, 0, self)


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index  # 自己受到伤害


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	# TODO: 实现具体效果
	var source_idx = event.source
	if source_idx < 0:
		return
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.yizheng.name": "翊正", "skill.yizheng.effect": "yizheng"}
	))
