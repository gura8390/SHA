# ============================================================
# skill_yizheng2.gd
# 武将技能：义争（主动技）
#
# 描述：出牌阶段限一次，与体力值不大于你的角色拼点，赢则其跳过下个摸牌阶段，没赢则你减1点体力上限。
#
# Gemini:change.12: 批量生成——杨彪义争
# ============================================================

class_name SkillYizheng2
extends Skill


func register_events() -> void:
	pass


func can_activate() -> bool:
	if not is_enabled:
		return false
	if not _check_use_limit():
		return false
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return not owner.hand_cards.is_empty()


func get_active_targets() -> Array:
	return []  # 无需目标


func activate(targets: Array) -> Dictionary:
	var owner = get_owner_player()
	if owner == null:
		return {"resolved": false, "reason": "no_owner"}
	DrawCardEffect.create(owner_index, owner_index, 2).resolve(battle_context)
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, -1,
		{"skill.yizheng2.name": "义争", "skill.yizheng2.effect": "yizheng2"}
	))
	return {"resolved": true}
