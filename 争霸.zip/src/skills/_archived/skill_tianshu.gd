# ============================================================
# skill_tianshu.gd
# 武将技能：天书（触发技）
#
# 描述：出牌阶段开始时，若【太平要术】不在场上/牌堆/弃牌堆，可获得之；你使用【太平要术】无距离限制。
#
# Gemini:change.12: 批量生成——南华老仙天书
# ============================================================

class_name SkillTianshu
extends Skill


func register_events() -> void:
	EventBus.subscribe(GameEvent.Type.PHASE_START, _on_event_received, 0, self)


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index  # 自己受到伤害


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	# TODO: 实现具体效果
	var source_idx = event.source
	if source_idx < 0:
		return
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.tianshu.name": "天书", "skill.tianshu.effect": "tianshu"}
	))
