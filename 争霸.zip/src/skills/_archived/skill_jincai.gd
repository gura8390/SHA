# ============================================================
# skill_jincai.gd
# 武将技能：尽瘁（锁定技）
#
# 描述：锁定技，游戏开始时手牌摸至7张；准备阶段将体力调整至X点（X为牌堆中点数7的牌数，至少为1）。
#
# Gemini:change.12: 批量生成——武诸葛亮尽瘁
# ============================================================

class_name SkillJincai
extends Skill


func register_events() -> void:
	pass


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index  # 自己受到伤害


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	# TODO: 实现具体效果
	var source_idx = event.source
	if source_idx < 0:
		return
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.jincai.name": "尽瘁", "skill.jincai.effect": "jincai"}
	))
