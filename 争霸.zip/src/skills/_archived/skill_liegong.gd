# ============================================================
# skill_liegong.gd
# 武将技能：烈弓（锁定技）
#
# 描述：锁定技，攻击范围+2；使用【杀】对距离大于2的目标造成伤害时，伤害+1。
#
# Gemini:change.12: 批量生成——沙摩柯烈弓
# ============================================================

class_name SkillLiegong
extends Skill


func register_events() -> void:
	pass


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index  # 自己受到伤害


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	# TODO: 实现具体效果
	var source_idx = event.source
	if source_idx < 0:
		return
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.liegong.name": "烈弓", "skill.liegong.effect": "liegong"}
	))
