# ============================================================
# skill_lucun.gd
# 武将技能：赂存（主动技）
#
# 描述：每轮限一次，视为使用一张未以此法用过的基本牌/普通锦囊牌，目标中手牌最多的角色将1张手牌置于你武将牌上称为「赂」。
#
# Gemini:change.12: 批量生成——张让赂存
# ============================================================

class_name SkillLucun
extends Skill


func register_events() -> void:
	pass


func can_activate() -> bool:
	if not is_enabled:
		return false
	if not _check_use_limit():
		return false
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return not owner.hand_cards.is_empty()


func get_active_targets() -> Array:
	var result: Array = []
	for p in battle_context.get_alive_players():
		if p.index != owner_index:
			result.append(p.index)
	return result


func activate(targets: Array) -> Dictionary:
	var owner = get_owner_player()
	if owner == null:
		return {"resolved": false, "reason": "no_owner"}
	if targets.is_empty():
		return {"resolved": false, "reason": "no_target"}
	var target_idx = targets[0]
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, -1,
		{"skill.lucun.name": "赂存", "skill.lucun.effect": "lucun"}
	))
	return {"resolved": true}
