# ============================================================
# skill_guanxing.gd
# 武将技能：观星（触发技）
#
# 描述：准备阶段观看牌堆顶X张牌（X为存活角色数，至多5），任意顺序置于牌堆顶或底。
#
# Gemini:change.12: 批量生成——诸葛亮观星
# ============================================================

class_name SkillGuanxing
extends Skill


func register_events() -> void:
	EventBus.subscribe(GameEvent.Type.PHASE_START, _on_event_received, 0, self)


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index  # 自己受到伤害


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	# TODO: 实现具体效果
	var source_idx = event.source
	if source_idx < 0:
		return
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.guanxing.name": "观星", "skill.guanxing.effect": "guanxing"}
	))
