# ============================================================
# skill_duoshou.gd
# 武将技能：夺首（锁定技）
#
# 描述：锁定技，每回合首张红色牌无距离限制，首张基本牌不计入使用次数，首次造成伤害后摸1张牌。
#
# Gemini:change.12: 批量生成——关羽夺首
# ============================================================

class_name SkillDuoshou
extends Skill


func register_events() -> void:
	pass


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.source == owner_index


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	DrawCardEffect.create(owner_index, owner_index, 1).resolve(battle_context)
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.duoshou.name": "夺首", "skill.duoshou.effect": "duoshou"}
	))
