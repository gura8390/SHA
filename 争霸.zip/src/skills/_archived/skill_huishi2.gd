# ============================================================
# skill_huishi2.gd
# 武将技能：辉逝（主动技）
#
# 描述：限定技，出牌阶段令一名角色失去1点体力上限，然后摸3张牌并回复1点体力。
#
# Gemini:change.12: 批量生成——郭嘉辉逝
# ============================================================

class_name SkillHuishi2
extends Skill


func register_events() -> void:
	pass


func can_activate() -> bool:
	if not is_enabled:
		return false
	if not _check_use_limit():
		return false
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return not owner.hand_cards.is_empty()


func get_active_targets() -> Array:
	return []  # 无需目标


func activate(targets: Array) -> Dictionary:
	var owner = get_owner_player()
	if owner == null:
		return {"resolved": false, "reason": "no_owner"}
	DrawCardEffect.create(owner_index, owner_index, 2).resolve(battle_context)
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, -1,
		{"skill.huishi2.name": "辉逝", "skill.huishi2.effect": "huishi2"}
	))
	return {"resolved": true}
