# ============================================================
# skill_pojun.gd
# 武将技能：破军（触发技）
#
# 描述：使用【杀】指定目标后，可将该角色至多X张牌置于其武将牌上（X为目标体力值），回合结束后其取回；使用【杀】对手牌与装备牌数均不大于你的目标造成伤害时，伤害+1。
#
# Gemini:change.12: 批量生成——徐盛破军
# ============================================================

class_name SkillPojun
extends Skill


func register_events() -> void:
	pass


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index  # 自己受到伤害


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	# TODO: 实现具体效果
	var source_idx = event.source
	if source_idx < 0:
		return
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.pojun.name": "破军", "skill.pojun.effect": "pojun"}
	))
