# ============================================================
# skill_dangxian.gd
# 武将技能：当先（锁定技）
#
# 描述：锁定技，回合开始时你执行一个额外的出牌阶段。
#
# Gemini:change.12: 批量生成——廖化当先
# ============================================================

class_name SkillDangxian
extends Skill


func register_events() -> void:
	EventBus.subscribe(GameEvent.Type.TURN_START, _on_event_received, 0, self)


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index  # 自己受到伤害


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	# TODO: 实现具体效果
	var source_idx = event.source
	if source_idx < 0:
		return
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.dangxian.name": "当先", "skill.dangxian.effect": "dangxian"}
	))
