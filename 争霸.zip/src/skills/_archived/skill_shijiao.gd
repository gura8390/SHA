# ============================================================
# skill_shijiao.gd
# 武将技能：恃娇（触发技）
#
# 描述：成为其他角色牌的目标后，可令其选择：弃1张牌或令此牌无效。
#
# Gemini:change.12: 批量生成——孙鲁班恃娇
# ============================================================

class_name SkillShijiao
extends Skill


func register_events() -> void:
	pass


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index  # 自己受到伤害


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	# TODO: 实现具体效果
	var source_idx = event.source
	if source_idx < 0:
		return
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.shijiao.name": "恃娇", "skill.shijiao.effect": "shijiao"}
	))
