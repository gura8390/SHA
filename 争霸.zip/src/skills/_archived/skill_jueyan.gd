# ============================================================
# skill_jueyan.gd
# 武将技能：决堰（主动技）
#
# 描述：出牌阶段限一次，废除一种装备栏并触发对应效果：武器栏多使用3张杀；防具栏摸3张牌；坐骑栏无距离限制。
#
# Gemini:change.12: 批量生成——陆抗决堰
# ============================================================

class_name SkillJueyan
extends Skill


func register_events() -> void:
	pass


func can_activate() -> bool:
	if not is_enabled:
		return false
	if not _check_use_limit():
		return false
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return not owner.hand_cards.is_empty()


func get_active_targets() -> Array:
	return []  # 无需目标


func activate(targets: Array) -> Dictionary:
	var owner = get_owner_player()
	if owner == null:
		return {"resolved": false, "reason": "no_owner"}
	DrawCardEffect.create(owner_index, owner_index, 2).resolve(battle_context)
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, -1,
		{"skill.jueyan.name": "决堰", "skill.jueyan.effect": "jueyan"}
	))
	return {"resolved": true}
