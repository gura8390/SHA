# ============================================================
# skill_feili.gd
# 武将技能：诽离（触发技）
#
# 描述：受到伤害时，若伤害来源有「诬」标记，移除标记防止伤害并摸2张牌。
#
# Gemini:change.12: 批量生成——清河公主诽离
# ============================================================

class_name SkillFeili
extends Skill


func register_events() -> void:
	EventBus.subscribe(GameEvent.Type.DAMAGE_AFTER, _on_event_received, 0, self)


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	DrawCardEffect.create(owner_index, owner_index, 1).resolve(battle_context)
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.feili.name": "诽离", "skill.feili.effect": "feili"}
	))
