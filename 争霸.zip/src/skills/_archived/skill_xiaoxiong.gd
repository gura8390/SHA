# ============================================================
# skill_xiaoxiong.gd
# 武将技能：枭雄（被动技）
#
# 描述：觉醒技，准备阶段体力小于2且本局杀累计造成大于等于3点伤害时，减1点体力上限，获得英姿+英魂。
#
# Gemini:change.12: 批量生成——孙策枭雄
# ============================================================

class_name SkillXiaoxiong
extends Skill


func register_events() -> void:
	pass


func can_trigger(_event: GameEvent) -> bool:
	return false


func execute(_event: GameEvent) -> void:
	pass
