# ============================================================
# skill_jishi.gd
# 武将技能：济世（锁定技）
#
# 描述：锁定技，使用牌结算后未造成伤害且牌在弃牌堆时，将其置于「仁」区；「仁」牌非因溢出离开时你摸1张牌。
#
# Gemini:change.12: 批量生成——张仲景济世
# ============================================================

class_name SkillJishi
extends Skill


func register_events() -> void:
	pass


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.source == owner_index


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	DrawCardEffect.create(owner_index, owner_index, 1).resolve(battle_context)
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.jishi.name": "济世", "skill.jishi.effect": "jishi"}
	))
