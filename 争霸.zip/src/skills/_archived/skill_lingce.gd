# ============================================================
# skill_lingce.gd
# 武将技能：灵策（锁定技）
#
# 描述：锁定技，一名角色使用非虚拟非转化锦囊牌时，若牌名为智囊牌或奇正相生，你摸1张牌。
#
# Gemini:change.12: 批量生成——荀彧灵策
# ============================================================

class_name SkillLingce
extends Skill


func register_events() -> void:
	EventBus.subscribe(GameEvent.Type.CARD_USED, _on_event_received, 0, self)


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index  # 自己受到伤害


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	# TODO: 实现具体效果
	var source_idx = event.source
	if source_idx < 0:
		return
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.lingce.name": "灵策", "skill.lingce.effect": "lingce"}
	))
