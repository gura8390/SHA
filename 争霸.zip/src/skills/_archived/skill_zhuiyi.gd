# ============================================================
# skill_zhuiyi.gd
# 武将技能：追忆（触发技）
#
# 描述：其他角色死亡时，你可回复1点体力并摸3张牌。
#
# Gemini:change.12: 批量生成——步练师追忆
# ============================================================

class_name SkillZhuiyi
extends Skill


func register_events() -> void:
	pass


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index  # 自己受到伤害


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	# TODO: 实现具体效果
	var source_idx = event.source
	if source_idx < 0:
		return
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.zhuiyi.name": "追忆", "skill.zhuiyi.effect": "zhuiyi"}
	))
