# ============================================================
# skill_shengxi.gd
# 武将技能：生息（触发技）
#
# 描述：准备阶段获得1张【调剂盐梅】；结束阶段若本回合使用过牌且未造成伤害，可获得1张智囊或摸1张牌。
#
# Gemini:change.12: 批量生成——费祎生息
# ============================================================

class_name SkillShengxi
extends Skill


func register_events() -> void:
	EventBus.subscribe(GameEvent.Type.PHASE_START, _on_event_received, 0, self)


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.source == owner_index


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	DrawCardEffect.create(owner_index, owner_index, 1).resolve(battle_context)
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.shengxi.name": "生息", "skill.shengxi.effect": "shengxi"}
	))
