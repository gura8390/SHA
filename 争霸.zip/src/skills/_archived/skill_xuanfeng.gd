# ============================================================
# skill_xuanfeng.gd
# 武将技能：旋风（触发技）
#
# 描述：失去装备区里的牌后，可弃置一名其他角色的1张牌或对一名其他角色造成1点伤害。
#
# Gemini:change.12: 批量生成——凌统旋风
# ============================================================

class_name SkillXuanfeng
extends Skill


func register_events() -> void:
	EventBus.subscribe(GameEvent.Type.EQUIP_REMOVED, _on_event_received, 0, self)


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.source == owner_index


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	# 选择一名其他角色，弃其一张牌或造成1点伤害
	var targets: Array = []
	for p in battle_context.get_alive_players():
		if p.index != owner_index:
			targets.append(p.index)
	if targets.is_empty():
		return
	var target_idx = targets[0]  # AI: 选第一个
	DamageEffect.create(owner_index, target_idx, 1, DamageEffect.DamageType.NORMAL, null).resolve(battle_context)
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.xuanfeng.name": "旋风", "skill.xuanfeng.effect": "xuanfeng"}
	))
