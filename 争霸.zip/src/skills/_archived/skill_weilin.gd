# ============================================================
# skill_weilin.gd
# 武将技能：威临（主动技）
#
# 描述：每回合限一次，将一张牌当酒或任意属性【杀】使用，此牌目标角色与该牌同颜色的手牌视为【杀】直到回合结束。
#
# Gemini:change.12: 批量生成——关羽威临
# ============================================================

class_name SkillWeilin
extends Skill


func register_events() -> void:
	pass


func can_activate() -> bool:
	if not is_enabled:
		return false
	if not _check_use_limit():
		return false
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return not owner.hand_cards.is_empty()


func get_active_targets() -> Array:
	var result: Array = []
	for p in battle_context.get_alive_players():
		if p.index != owner_index:
			result.append(p.index)
	return result


func activate(targets: Array) -> Dictionary:
	var owner = get_owner_player()
	if owner == null:
		return {"resolved": false, "reason": "no_owner"}
	if targets.is_empty():
		return {"resolved": false, "reason": "no_target"}
	var target_idx = targets[0]
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, -1,
		{"skill.weilin.name": "威临", "skill.weilin.effect": "weilin"}
	))
	return {"resolved": true}
