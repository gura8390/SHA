# ============================================================
# skill_quanji.gd
# 武将技能：权计（触发技）
#
# 描述：受到伤害后摸1张牌并可将1张牌置于武将牌上称为「权」。
#
# Gemini:change.12: 批量生成——钟会权计
# ============================================================

class_name SkillQuanji
extends Skill


func register_events() -> void:
	EventBus.subscribe(GameEvent.Type.DAMAGE_AFTER, _on_event_received, 0, self)


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	DrawCardEffect.create(owner_index, owner_index, 1).resolve(battle_context)
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.quanji.name": "权计", "skill.quanji.effect": "quanji"}
	))
