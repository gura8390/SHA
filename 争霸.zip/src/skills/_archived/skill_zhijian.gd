# ============================================================
# skill_zhijian.gd
# 武将技能：直谏（主动技）
#
# 描述：出牌阶段可将手牌中的装备牌交给其他角色，然后摸1张牌。
#
# Gemini:change.12: 批量生成——张昭张纮直谏
# ============================================================

class_name SkillZhijian
extends Skill


func register_events() -> void:
	pass


func can_activate() -> bool:
	if not is_enabled:
		return false
	if not _check_use_limit():
		return false
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return not owner.hand_cards.is_empty()


func get_active_targets() -> Array:
	return []  # 无需目标


func activate(targets: Array) -> Dictionary:
	var owner = get_owner_player()
	if owner == null:
		return {"resolved": false, "reason": "no_owner"}
	DrawCardEffect.create(owner_index, owner_index, 2).resolve(battle_context)
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, -1,
		{"skill.zhijian.name": "直谏", "skill.zhijian.effect": "zhijian"}
	))
	return {"resolved": true}
