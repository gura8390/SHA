# ============================================================
# skill_lipin.gd
# 武将技能：立品（锁定技）
#
# 描述：主公技，锁定技，其他吴势力角色的出牌阶段限一次，可交给你1张手牌。
#
# Gemini:change.12: 批量生成——孙亮立品
# ============================================================

class_name SkillLipin
extends Skill


func register_events() -> void:
	pass


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index  # 自己受到伤害


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	# TODO: 实现具体效果
	var source_idx = event.source
	if source_idx < 0:
		return
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.lipin.name": "立品", "skill.lipin.effect": "lipin"}
	))
