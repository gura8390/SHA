# ============================================================
# skill_xingshuai.gd
# 武将技能：兴衰（触发技）
#
# 描述：主公技，你进入濒死时，其他魏势力角色可令你回复1点体力，然后其受到1点伤害。
#
# Gemini:change.12: 批量生成——曹叡兴衰
# ============================================================

class_name SkillXingshuai
extends Skill


func register_events() -> void:
	EventBus.subscribe(GameEvent.Type.PLAYER_DYING, _on_event_received, 0, self)


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index  # 自己受到伤害


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	# TODO: 实现具体效果
	var source_idx = event.source
	if source_idx < 0:
		return
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.xingshuai.name": "兴衰", "skill.xingshuai.effect": "xingshuai"}
	))
