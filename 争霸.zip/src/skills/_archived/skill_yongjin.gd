# ============================================================
# skill_yongjin.gd
# 武将技能：勇进（主动技）
#
# 描述：出牌阶段限一次，弃1张装备牌对一名角色造成1点伤害。
#
# Gemini:change.12: 批量生成——凌统勇进
# ============================================================

class_name SkillYongjin
extends Skill


func register_events() -> void:
	pass


func can_activate() -> bool:
	if not is_enabled:
		return false
	if not _check_use_limit():
		return false
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return owner.hand_cards.size() >= 1


func get_active_targets() -> Array:
	var result: Array = []
	for p in battle_context.get_alive_players():
		if p.index != owner_index:
			result.append(p.index)
	return result


func activate(targets: Array) -> Dictionary:
	var owner = get_owner_player()
	if owner == null:
		return {"resolved": false, "reason": "no_owner"}
	if targets.is_empty():
		return {"resolved": false, "reason": "no_target"}
	var target_idx = targets[0]
	# 红线 1：通过 DiscardCardEffect 弃置手牌，禁止直接 erase
	var discard_card = owner.hand_cards[0]
	DiscardCardEffect.create(owner_index, owner_index, [discard_card], DiscardCardEffect.DiscardReason.SKILL_COST).resolve(battle_context)
	# 造成1点伤害
	await DamageEffect.create(owner_index, target_idx, 1, DamageEffect.DamageType.NORMAL, null).resolve(battle_context)
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, -1,
		{"skill.yongjin.name": "勇进", "skill.yongjin.effect": "yongjin"}
	))
	return {"resolved": true}
