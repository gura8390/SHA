# ============================================================
# skill_baobian.gd
# 武将技能：豹变（锁定技）
#
# 描述：锁定技，若你的体力值为3或更少，你视为拥有挑衅技能。
#
# Gemini:change.12: 批量生成——夏侯霸豹变
# ============================================================

class_name SkillBaobian
extends Skill


func register_events() -> void:
	pass


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index  # 自己受到伤害


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	# TODO: 实现具体效果
	var source_idx = event.source
	if source_idx < 0:
		return
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.baobian.name": "豹变", "skill.baobian.effect": "baobian"}
	))
