# ============================================================
# skill_lilu.gd
# 武将技能：礼赂（主动技）
#
# 描述：摸牌阶段可改为将手牌摸至体力上限，交给一名其他角色至少1张手牌；首次交牌或交牌数大于上次时，增加1点体力上限并回复1点体力。
#
# Gemini:change.12: 批量生成——曹嵩礼赂
# ============================================================

class_name SkillLilu
extends Skill


func register_events() -> void:
	pass


func can_activate() -> bool:
	if not is_enabled:
		return false
	if not _check_use_limit():
		return false
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return not owner.hand_cards.is_empty()


func get_active_targets() -> Array:
	return []  # 无需目标


func activate(targets: Array) -> Dictionary:
	var owner = get_owner_player()
	if owner == null:
		return {"resolved": false, "reason": "no_owner"}
	DrawCardEffect.create(owner_index, owner_index, 2).resolve(battle_context)
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, -1,
		{"skill.lilu.name": "礼赂", "skill.lilu.effect": "lilu"}
	))
	return {"resolved": true}
