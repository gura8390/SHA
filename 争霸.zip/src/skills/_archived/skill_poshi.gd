# ============================================================
# skill_poshi.gd
# 武将技能：破势（被动技）
#
# 描述：觉醒技，准备阶段所有装备栏均废除或体力为1时，扣1点体力上限，手牌补至体力上限，失去决堰并获得怀柔。
#
# Gemini:change.12: 批量生成——陆抗破势
# ============================================================

class_name SkillPoshi
extends Skill


func register_events() -> void:
	pass


func can_trigger(_event: GameEvent) -> bool:
	return false


func execute(_event: GameEvent) -> void:
	pass
