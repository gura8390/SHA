# ============================================================
# skill_liezhan.gd
# 武将技能：烈战（主动技）
#
# 描述：限定技，进入濒死时回复体力至3点，对攻击范围内一名角色造成2点伤害，失去威霸。
#
# Gemini:change.12: 批量生成——孙策烈战
# ============================================================

class_name SkillLiezhan
extends Skill


func register_events() -> void:
	pass


func can_activate() -> bool:
	if not is_enabled:
		return false
	if not _check_use_limit():
		return false
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return not owner.hand_cards.is_empty()


func get_active_targets() -> Array:
	var result: Array = []
	for p in battle_context.get_alive_players():
		if p.index != owner_index:
			result.append(p.index)
	return result


func activate(targets: Array) -> Dictionary:
	var owner = get_owner_player()
	if owner == null:
		return {"resolved": false, "reason": "no_owner"}
	if targets.is_empty():
		return {"resolved": false, "reason": "no_target"}
	var target_idx = targets[0]
	HealEffect.create(owner_index, target_idx, 1, null).resolve(battle_context)
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, -1,
		{"skill.liezhan.name": "烈战", "skill.liezhan.effect": "liezhan"}
	))
	return {"resolved": true}
