# ============================================================
# skill_fencheng.gd
# 武将技能：焚城（主动技）
#
# 描述：限定技，出牌阶段令所有其他角色依次弃置至少X张牌（X为其装备区牌数），否则受到2点火焰伤害。
#
# Gemini:change.12: 批量生成——李儒焚城
# ============================================================

class_name SkillFencheng
extends Skill


func register_events() -> void:
	pass


func can_activate() -> bool:
	if not is_enabled:
		return false
	if not _check_use_limit():
		return false
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return not owner.hand_cards.is_empty()


func get_active_targets() -> Array:
	var result: Array = []
	for p in battle_context.get_alive_players():
		if p.index != owner_index:
			result.append(p.index)
	return result


func activate(targets: Array) -> Dictionary:
	var owner = get_owner_player()
	if owner == null:
		return {"resolved": false, "reason": "no_owner"}
	if targets.is_empty():
		return {"resolved": false, "reason": "no_target"}
	var target_idx = targets[0]
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, -1,
		{"skill.fencheng.name": "焚城", "skill.fencheng.effect": "fencheng"}
	))
	return {"resolved": true}
