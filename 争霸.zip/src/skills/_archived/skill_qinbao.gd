# ============================================================
# skill_qinbao.gd
# 武将技能：侵暴（锁定技）
#
# 描述：锁定技，手牌数大于等于你的其他角色不能响应你使用的【杀】或普通锦囊牌。
#
# Gemini:change.12: 批量生成——管亥侵暴
# ============================================================

class_name SkillQinbao
extends Skill


func register_events() -> void:
	pass


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index  # 自己受到伤害


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	# TODO: 实现具体效果
	var source_idx = event.source
	if source_idx < 0:
		return
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.qinbao.name": "侵暴", "skill.qinbao.effect": "qinbao"}
	))
