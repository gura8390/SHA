# ============================================================
# skill_qianju.gd
# 武将技能：千驹（被动技）
#
# 描述：你计算与其他角色的距离-1。
#
# Gemini:change.12: 批量生成——曹休千驹
# ============================================================

class_name SkillQianju
extends Skill


func register_events() -> void:
	pass


func can_trigger(_event: GameEvent) -> bool:
	return false


func execute(_event: GameEvent) -> void:
	pass
