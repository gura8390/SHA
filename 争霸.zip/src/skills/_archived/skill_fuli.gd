# ============================================================
# skill_fuli.gd
# 武将技能：伏枥（触发技）
#
# 描述：受到伤害后可进行判定，若为红色你回复1点体力。
#
# Gemini:change.12: 批量生成——廖化伏枥
# ============================================================

class_name SkillFuli
extends Skill


func register_events() -> void:
	EventBus.subscribe(GameEvent.Type.DAMAGE_AFTER, _on_event_received, 0, self)


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index  # 自己受到伤害


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	# TODO: 实现具体效果
	var source_idx = event.source
	if source_idx < 0:
		return
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.fuli.name": "伏枥", "skill.fuli.effect": "fuli"}
	))
