# ============================================================
# skill_jili.gd
# 武将技能：蒺藜（触发技）
#
# 描述：一回合内使用/打出第X张牌时，摸X张牌（X为攻击范围）。
#
# Gemini:change.12: 批量生成——沙摩柯蒺藜
# ============================================================

class_name SkillJili
extends Skill


func register_events() -> void:
	pass


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index  # 自己受到伤害


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	# TODO: 实现具体效果
	var source_idx = event.source
	if source_idx < 0:
		return
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.jili.name": "蒺藜", "skill.jili.effect": "jili"}
	))
