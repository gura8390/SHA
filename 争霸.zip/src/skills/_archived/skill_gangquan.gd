# ============================================================
# skill_gangquan.gd
# 武将技能：罡拳（被动技）
#
# 描述：上一张使用的牌为「炁」时，可将装备牌视为对所有相邻角色的火【杀】；否则可将锦囊牌视为【决斗】使用。
#
# Gemini:change.12: 批量生成——吕布罡拳
# ============================================================

class_name SkillGangquan
extends Skill


func register_events() -> void:
	pass


func can_trigger(_event: GameEvent) -> bool:
	return false


func execute(_event: GameEvent) -> void:
	pass
