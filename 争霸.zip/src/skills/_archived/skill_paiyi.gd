# ============================================================
# skill_paiyi.gd
# 武将技能：排异（主动技）
#
# 描述：出牌阶段限一次，移去1张「权」，令一名角色摸2张牌或对其造成1点伤害。
#
# Gemini:change.12: 批量生成——钟会排异
# ============================================================

class_name SkillPaiyi
extends Skill


func register_events() -> void:
	pass


func can_activate() -> bool:
	if not is_enabled:
		return false
	if not _check_use_limit():
		return false
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return not owner.hand_cards.is_empty()


func get_active_targets() -> Array:
	return []  # 无需目标


func activate(targets: Array) -> Dictionary:
	var owner = get_owner_player()
	if owner == null:
		return {"resolved": false, "reason": "no_owner"}
	DrawCardEffect.create(owner_index, owner_index, 2).resolve(battle_context)
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, -1,
		{"skill.paiyi.name": "排异", "skill.paiyi.effect": "paiyi"}
	))
	return {"resolved": true}
