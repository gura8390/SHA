# ============================================================
# skill_duoqi.gd
# 武将技能：夺炁（锁定技）
#
# 描述：锁定技，所有角色初始手牌称为「炁」直至游戏结束；一号位首个额定回合前，你执行一个无额外阶段的出牌回合且不能使用延时锦囊牌；每回合对一名角色首次造成伤害后，随机获得其一张「炁」。
#
# Gemini:change.12: 批量生成——吕布夺炁
# ============================================================

class_name SkillDuoqi
extends Skill


func register_events() -> void:
	pass


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index  # 自己受到伤害


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	# TODO: 实现具体效果
	var source_idx = event.source
	if source_idx < 0:
		return
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.duoqi.name": "夺炁", "skill.duoqi.effect": "duoqi"}
	))
