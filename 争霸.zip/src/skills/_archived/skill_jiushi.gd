# ============================================================
# skill_jiushi.gd
# 武将技能：酒诗（被动技）
#
# 描述：需使用【酒】时，若武将牌正面朝上，可翻面视为使用一张【酒】；背面朝上时，使用落英获得的牌无距离限制且不可被响应。
#
# Gemini:change.12: 批量生成——曹植酒诗
# ============================================================

class_name SkillJiushi
extends Skill


func register_events() -> void:
	pass


func can_trigger(_event: GameEvent) -> bool:
	return false


func execute(_event: GameEvent) -> void:
	pass
