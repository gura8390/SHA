# ============================================================
# skill_lihuo.gd
# 武将技能：疠火（被动技）
#
# 描述：你使用的普通杀可改为火杀。
#
# Gemini:change.12: 批量生成——程普疠火
# ============================================================

class_name SkillLihuo
extends Skill


func register_events() -> void:
	pass


func can_trigger(_event: GameEvent) -> bool:
	return false


func execute(_event: GameEvent) -> void:
	pass
