# ============================================================
# skill_buyi.gd
# 武将技能：补益（触发技）
#
# 描述：其他角色进入濒死时，你可展示其1张手牌，若不为基本牌其回复1点体力。
#
# Gemini:change.12: 批量生成——吴国太补益
# ============================================================

class_name SkillBuyi
extends Skill


func register_events() -> void:
	EventBus.subscribe(GameEvent.Type.PLAYER_DYING, _on_event_received, 0, self)


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index  # 自己受到伤害


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	# TODO: 实现具体效果
	var source_idx = event.source
	if source_idx < 0:
		return
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.buyi.name": "补益", "skill.buyi.effect": "buyi"}
	))
