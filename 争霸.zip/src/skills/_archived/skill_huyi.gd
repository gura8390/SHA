# ============================================================
# skill_huyi.gd
# 武将技能：虎翼（主动技）
#
# 描述：出牌阶段限一次，与一名角色拼点，赢则对其造成1点伤害。
#
# Gemini:change.12: 批量生成——关兴虎翼
# ============================================================

class_name SkillHuyi
extends Skill


func register_events() -> void:
	pass


func can_activate() -> bool:
	if not is_enabled:
		return false
	if not _check_use_limit():
		return false
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return not owner.hand_cards.is_empty()


func get_active_targets() -> Array:
	var result: Array = []
	for p in battle_context.get_alive_players():
		if p.index != owner_index:
			result.append(p.index)
	return result


func activate(targets: Array) -> Dictionary:
	var owner = get_owner_player()
	if owner == null:
		return {"resolved": false, "reason": "no_owner"}
	if targets.is_empty():
		return {"resolved": false, "reason": "no_target"}
	var target_idx = targets[0]
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, -1,
		{"skill.huyi.name": "虎翼", "skill.huyi.effect": "huyi"}
	))
	return {"resolved": true}
