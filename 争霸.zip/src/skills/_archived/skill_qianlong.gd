# ============================================================
# skill_qianlong.gd
# 武将技能：潜龙（被动技）
#
# 描述：游戏开始获得20点道心；受到/造成伤害、获得牌时分别获得10/15/5点道心；道心达标时获得新技能。
#
# Gemini:change.12: 批量生成——曹髦潜龙
# ============================================================

class_name SkillQianlong
extends Skill


func register_events() -> void:
	pass


func can_trigger(_event: GameEvent) -> bool:
	return false


func execute(_event: GameEvent) -> void:
	pass
