# ============================================================
# skill_xianying.gd
# 武将技能：贤膺（触发技）
#
# 描述：准备阶段或受到伤害后，摸2张牌并弃置任意张牌（不能为本轮以此法弃置过的牌数）；若弃置的牌牌名均相同，回合结束时视为使用之。
#
# Gemini:change.12: 批量生成——秦朗贤膺
# ============================================================

class_name SkillXianying
extends Skill


func register_events() -> void:
	EventBus.subscribe(GameEvent.Type.PHASE_START, _on_event_received, 0, self)


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	DrawCardEffect.create(owner_index, owner_index, 1).resolve(battle_context)
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.xianying.name": "贤膺", "skill.xianying.effect": "xianying"}
	))
