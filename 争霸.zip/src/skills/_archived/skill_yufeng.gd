# ============================================================
# skill_yufeng.gd
# 武将技能：御风（主动技）
#
# 描述：出牌阶段限一次进行御风飞行，失败则摸X张牌；成功则标记至多X名角色并摸剩余分数张牌。
#
# Gemini:change.12: 批量生成——南华老仙御风
# ============================================================

class_name SkillYufeng
extends Skill


func register_events() -> void:
	pass


func can_activate() -> bool:
	if not is_enabled:
		return false
	if not _check_use_limit():
		return false
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return not owner.hand_cards.is_empty()


func get_active_targets() -> Array:
	return []  # 无需目标


func activate(targets: Array) -> Dictionary:
	var owner = get_owner_player()
	if owner == null:
		return {"resolved": false, "reason": "no_owner"}
	DrawCardEffect.create(owner_index, owner_index, 2).resolve(battle_context)
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, -1,
		{"skill.yufeng.name": "御风", "skill.yufeng.effect": "yufeng"}
	))
	return {"resolved": true}
