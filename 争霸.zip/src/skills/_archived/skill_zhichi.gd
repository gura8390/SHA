# ============================================================
# skill_zhichi.gd
# 武将技能：智迟（锁定技）
#
# 描述：锁定技，你的回合外，每回合首次受到的伤害无效。
#
# Gemini:change.12: 批量生成——陈宫智迟
# ============================================================

class_name SkillZhichi
extends Skill


func register_events() -> void:
	pass


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index  # 自己受到伤害


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	# TODO: 实现具体效果
	var source_idx = event.source
	if source_idx < 0:
		return
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.zhichi.name": "智迟", "skill.zhichi.effect": "zhichi"}
	))
