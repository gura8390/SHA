# ============================================================
# skill_tongli.gd
# 武将技能：同礼（触发技）
#
# 描述：其他角色使用锦囊牌时，你可弃1张同类型牌令其无效。
#
# Gemini:change.12: 批量生成——张让同礼
# ============================================================

class_name SkillTongli
extends Skill


func register_events() -> void:
	EventBus.subscribe(GameEvent.Type.CARD_USED, _on_event_received, 0, self)


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index  # 自己受到伤害


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	# TODO: 实现具体效果
	var source_idx = event.source
	if source_idx < 0:
		return
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.tongli.name": "同礼", "skill.tongli.effect": "tongli"}
	))
