# ============================================================
# skill_zili.gd
# 武将技能：自立（被动技）
#
# 描述：觉醒技，准备阶段若「权」大于等于3张，减1点体力上限，获得排异技能。
#
# Gemini:change.12: 批量生成——钟会自立
# ============================================================

class_name SkillZili
extends Skill


func register_events() -> void:
	pass


func can_trigger(_event: GameEvent) -> bool:
	return false


func execute(_event: GameEvent) -> void:
	pass
