# ============================================================
# skill_xiongzhi.gd
# 武将技能：雄志（锁定技）
#
# 描述：锁定技，出牌阶段至多使用X张非装备牌（X为体力上限）。
#
# Gemini:change.12: 批量生成——司马懿雄志
# ============================================================

class_name SkillXiongzhi
extends Skill


func register_events() -> void:
	pass


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index  # 自己受到伤害


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	# TODO: 实现具体效果
	var source_idx = event.source
	if source_idx < 0:
		return
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.xiongzhi.name": "雄志", "skill.xiongzhi.effect": "xiongzhi"}
	))
