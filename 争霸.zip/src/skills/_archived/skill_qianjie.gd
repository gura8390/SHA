# ============================================================
# skill_qianjie.gd
# 武将技能：谦节（锁定技）
#
# 描述：锁定技，不能进入连环状态，不能成为延时锦囊牌或拼点目标。
#
# Gemini:change.12: 批量生成——陆抗谦节
# ============================================================

class_name SkillQianjie
extends Skill


func register_events() -> void:
	pass


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index  # 自己受到伤害


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	# TODO: 实现具体效果
	var source_idx = event.source
	if source_idx < 0:
		return
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.qianjie.name": "谦节", "skill.qianjie.effect": "qianjie"}
	))
