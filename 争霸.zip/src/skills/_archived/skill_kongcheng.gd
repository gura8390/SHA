# ============================================================
# skill_kongcheng.gd
# 武将技能：空城（锁定技）
#
# 描述：锁定技，无手牌时不能成为【杀】或【决斗】的目标。
#
# Gemini:change.12: 批量生成——诸葛亮空城
# ============================================================

class_name SkillKongcheng
extends Skill


func register_events() -> void:
	pass


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index  # 自己受到伤害


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	# TODO: 实现具体效果
	var source_idx = event.source
	if source_idx < 0:
		return
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.kongcheng.name": "空城", "skill.kongcheng.effect": "kongcheng"}
	))
