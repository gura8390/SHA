# ============================================================
# skill_qiuyuan.gd
# 武将技能：求援（触发技）
#
# 描述：每回合限一次，成为杀的目标后，可令一名其他角色交给你1张闪或成为此杀的额外目标。
#
# Gemini:change.12: 批量生成——伏皇后求援
# ============================================================

class_name SkillQiuyuan
extends Skill


func register_events() -> void:
	pass


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index  # 自己受到伤害


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	# TODO: 实现具体效果
	var source_idx = event.source
	if source_idx < 0:
		return
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.qiuyuan.name": "求援", "skill.qiuyuan.effect": "qiuyuan"}
	))
