# ============================================================
# skill_huanhuo.gd
# 武将技能：幻惑（触发技）
#
# 描述：每轮开始时摸2张牌，可弃置至多2张牌，令等量其他角色下个出牌阶段获得负面效果：强制随机选中可用手牌使用，每用1张牌额外弃1张牌，使用2张牌后解除状态。
#
# Gemini:change.12: 批量生成——貂蝉幻惑
# ============================================================

class_name SkillHuanhuo
extends Skill


func register_events() -> void:
	EventBus.subscribe(GameEvent.Type.TURN_START, _on_event_received, 0, self)


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index  # 自己受到伤害


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	# TODO: 实现具体效果
	var source_idx = event.source
	if source_idx < 0:
		return
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.huanhuo.name": "幻惑", "skill.huanhuo.effect": "huanhuo"}
	))
