# ============================================================
# skill_zishu.gd
# 武将技能：自书（锁定技）
#
# 描述：锁定技，你的回合外获得牌时，回合结束时将这些牌置入弃牌堆。
#
# Gemini:change.12: 批量生成——马良自书
# ============================================================

class_name SkillZishu
extends Skill


func register_events() -> void:
	pass


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index  # 自己受到伤害


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	# TODO: 实现具体效果
	var source_idx = event.source
	if source_idx < 0:
		return
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.zishu.name": "自书", "skill.zishu.effect": "zishu"}
	))
