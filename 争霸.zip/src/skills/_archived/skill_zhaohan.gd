# ============================================================
# skill_zhaohan.gd
# 武将技能：昭汉（锁定技）
#
# 描述：锁定技，前4个准备阶段增加1点体力上限并回复1点体力；后3个准备阶段减少1点体力上限。
#
# Gemini:change.12: 批量生成——杨彪昭汉
# ============================================================

class_name SkillZhaohan
extends Skill


func register_events() -> void:
	EventBus.subscribe(GameEvent.Type.PHASE_START, _on_event_received, 0, self)


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index  # 自己受到伤害


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	# TODO: 实现具体效果
	var source_idx = event.source
	if source_idx < 0:
		return
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.zhaohan.name": "昭汉", "skill.zhaohan.effect": "zhaohan"}
	))
