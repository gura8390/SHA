# ============================================================
# skill_shenchong.gd
# 武将技能：甚宠（主动技）
#
# 描述：限定技，出牌阶段令一名角色获得飞扬跋扈，你死亡时其失去所有技能并弃置全部手牌。
#
# Gemini:change.12: 批量生成——刘宏甚宠
# ============================================================

class_name SkillShenchong
extends Skill


func register_events() -> void:
	pass


func can_activate() -> bool:
	if not is_enabled:
		return false
	if not _check_use_limit():
		return false
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return not owner.hand_cards.is_empty()


func get_active_targets() -> Array:
	var result: Array = []
	for p in battle_context.get_alive_players():
		if p.index != owner_index:
			result.append(p.index)
	return result


func activate(targets: Array) -> Dictionary:
	var owner = get_owner_player()
	if owner == null:
		return {"resolved": false, "reason": "no_owner"}
	if targets.is_empty():
		return {"resolved": false, "reason": "no_target"}
	var target_idx = targets[0]
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, -1,
		{"skill.shenchong.name": "甚宠", "skill.shenchong.effect": "shenchong"}
	))
	return {"resolved": true}
