# ============================================================
# skill_jianmie.gd
# 武将技能：翦灭（主动技）
#
# 描述：出牌阶段限一次，与一名角色各自选择一种手牌颜色，弃置对应颜色手牌，弃牌数较多的角色失去1点体力。
#
# Gemini:change.12: 批量生成——张春华翦灭
# ============================================================

class_name SkillJianmie
extends Skill


func register_events() -> void:
	pass


func can_activate() -> bool:
	if not is_enabled:
		return false
	if not _check_use_limit():
		return false
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return not owner.hand_cards.is_empty()


func get_active_targets() -> Array:
	var result: Array = []
	for p in battle_context.get_alive_players():
		if p.index != owner_index:
			result.append(p.index)
	return result


func activate(targets: Array) -> Dictionary:
	var owner = get_owner_player()
	if owner == null:
		return {"resolved": false, "reason": "no_owner"}
	if targets.is_empty():
		return {"resolved": false, "reason": "no_target"}
	var target_idx = targets[0]
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, -1,
		{"skill.jianmie.name": "翦灭", "skill.jianmie.effect": "jianmie"}
	))
	return {"resolved": true}
