# ============================================================
# skill_weitong.gd
# 武将技能：卫统（锁定技）
#
# 描述：主公技，开局有其他魏势力角色时，你额外获得10点道心，且其他魏势力角色可替你承担1点伤害。
#
# Gemini:change.12: 批量生成——曹髦卫统
# ============================================================

class_name SkillWeitong
extends Skill


func register_events() -> void:
	pass


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index  # 自己受到伤害


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	# TODO: 实现具体效果
	var source_idx = event.source
	if source_idx < 0:
		return
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.weitong.name": "卫统", "skill.weitong.effect": "weitong"}
	))
