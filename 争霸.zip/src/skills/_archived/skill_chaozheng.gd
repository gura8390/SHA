# ============================================================
# skill_chaozheng.gd
# 武将技能：朝争（触发技）
#
# 描述：准备阶段令所有其他角色议事，红色意见角色回复1点体力，黑色意见角色失去1点体力；所有角色意见相同时，你摸X张牌。
#
# Gemini:change.12: 批量生成——刘宏朝争
# ============================================================

class_name SkillChaozheng
extends Skill


func register_events() -> void:
	EventBus.subscribe(GameEvent.Type.PHASE_START, _on_event_received, 0, self)


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index  # 自己受到伤害


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	# TODO: 实现具体效果
	var source_idx = event.source
	if source_idx < 0:
		return
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.chaozheng.name": "朝争", "skill.chaozheng.effect": "chaozheng"}
	))
