# ============================================================
# skill_qingshi.gd
# 武将技能：情势（触发技）
#
# 描述：每种牌名每回合限一次，出牌阶段使用一张牌时，若手牌有同名牌，选一项：令此牌对1名目标伤害+1；令任意名角色各摸1张牌；摸3张牌。
#
# Gemini:change.12: 批量生成——武诸葛亮情势
# ============================================================

class_name SkillQingshi
extends Skill


func register_events() -> void:
	EventBus.subscribe(GameEvent.Type.CARD_USED, _on_event_received, 0, self)


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index  # 自己受到伤害


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	# TODO: 实现具体效果
	var source_idx = event.source
	if source_idx < 0:
		return
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.qingshi.name": "情势", "skill.qingshi.effect": "qingshi"}
	))
