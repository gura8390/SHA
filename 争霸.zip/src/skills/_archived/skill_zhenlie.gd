# ============================================================
# skill_zhenlie.gd
# 武将技能：贞烈（触发技）
#
# 描述：每回合限一次，成为其他角色牌的目标后，可令其弃1张牌或令此牌对你无效。
#
# Gemini:change.12: 批量生成——王异贞烈
# ============================================================

class_name SkillZhenlie
extends Skill


func register_events() -> void:
	pass


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index  # 自己受到伤害


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	# TODO: 实现具体效果
	var source_idx = event.source
	if source_idx < 0:
		return
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.zhenlie.name": "贞烈", "skill.zhenlie.effect": "zhenlie"}
	))
