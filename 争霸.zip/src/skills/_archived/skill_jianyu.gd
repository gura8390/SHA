# ============================================================
# skill_jianyu.gd
# 武将技能：谏喻（触发技）
#
# 描述：每轮限一次，出牌阶段选择两名角色，直到你下回合开始，其中一人指定另一人为牌的目标时，另一人摸1张牌。
#
# Gemini:change.12: 批量生成——费祎谏喻
# ============================================================

class_name SkillJianyu
extends Skill


func register_events() -> void:
	EventBus.subscribe(GameEvent.Type.TURN_START, _on_event_received, 0, self)


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index  # 自己受到伤害


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	# TODO: 实现具体效果
	var source_idx = event.source
	if source_idx < 0:
		return
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.jianyu.name": "谏喻", "skill.jianyu.effect": "jianyu"}
	))
