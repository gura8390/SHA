# ============================================================
# skill_gongqi.gd
# 武将技能：弓骑（被动技）
#
# 描述：你的杀无距离限制。
#
# Gemini:change.12: 批量生成——韩当弓骑
# ============================================================

class_name SkillGongqi
extends Skill


func register_events() -> void:
	pass


func can_trigger(_event: GameEvent) -> bool:
	return false


func execute(_event: GameEvent) -> void:
	pass
