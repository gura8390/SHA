# ============================================================
# skill_rangjie.gd
# 武将技能：让节（触发技）
#
# 描述：受到1点伤害后，选择一项：移动场上1张牌；从牌堆/弃牌堆获得1张指定类型的牌；然后摸1张牌。
#
# Gemini:change.12: 批量生成——杨彪让节
# ============================================================

class_name SkillRangjie
extends Skill


func register_events() -> void:
	EventBus.subscribe(GameEvent.Type.DAMAGE_AFTER, _on_event_received, 0, self)


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index  # 自己受到伤害


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	# TODO: 实现具体效果
	var source_idx = event.source
	if source_idx < 0:
		return
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.rangjie.name": "让节", "skill.rangjie.effect": "rangjie"}
	))
