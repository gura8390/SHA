# ============================================================
# skill_julian.gd
# 武将技能：聚敛（触发技）
#
# 描述：主公技，其他群势力角色每回合限两次，摸牌阶段外获得牌时你摸1张牌。
#
# Gemini:change.12: 批量生成——刘宏聚敛
# ============================================================

class_name SkillJulian
extends Skill


func register_events() -> void:
	pass


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index  # 自己受到伤害


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	# TODO: 实现具体效果
	var source_idx = event.source
	if source_idx < 0:
		return
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.julian.name": "聚敛", "skill.julian.effect": "julian"}
	))
