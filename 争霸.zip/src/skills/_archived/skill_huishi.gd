# ============================================================
# skill_huishi.gd
# 武将技能：慧识（主动技）
#
# 描述：出牌阶段限一次，体力上限小于10时可进行判定，若判定花色与本阶段此前不同，可重复判定并增加1点体力上限。
#
# Gemini:change.12: 批量生成——郭嘉慧识
# ============================================================

class_name SkillHuishi
extends Skill


func register_events() -> void:
	pass


func can_activate() -> bool:
	if not is_enabled:
		return false
	if not _check_use_limit():
		return false
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return not owner.hand_cards.is_empty()


func get_active_targets() -> Array:
	var result: Array = []
	for p in battle_context.get_alive_players():
		if p.index != owner_index:
			result.append(p.index)
	return result


func activate(targets: Array) -> Dictionary:
	var owner = get_owner_player()
	if owner == null:
		return {"resolved": false, "reason": "no_owner"}
	if targets.is_empty():
		return {"resolved": false, "reason": "no_target"}
	var target_idx = targets[0]
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, -1,
		{"skill.huishi.name": "慧识", "skill.huishi.effect": "huishi"}
	))
	return {"resolved": true}
