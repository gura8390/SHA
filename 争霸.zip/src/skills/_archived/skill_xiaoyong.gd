# ============================================================
# skill_xiaoyong.gd
# 武将技能：虓勇（被动技）
#
# 描述：装备提供直伤、过牌、增伤等不同效果。
#
# Gemini:change.12: 批量生成——吕玲绮虓勇
# ============================================================

class_name SkillXiaoyong
extends Skill


func register_events() -> void:
	pass


func can_trigger(_event: GameEvent) -> bool:
	return false


func execute(_event: GameEvent) -> void:
	pass
