# ============================================================
# skill_sidi.gd
# 武将技能：司敌（触发技）
#
# 描述：其他角色使用杀指定目标后，你可弃1张牌令此杀无效。
#
# Gemini:change.12: 批量生成——曹真司敌
# ============================================================

class_name SkillSidi
extends Skill


func register_events() -> void:
	pass


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index  # 自己受到伤害


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	# TODO: 实现具体效果
	var source_idx = event.source
	if source_idx < 0:
		return
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.sidi.name": "司敌", "skill.sidi.effect": "sidi"}
	))
