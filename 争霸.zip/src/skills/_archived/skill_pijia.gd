# ============================================================
# skill_pijia.gd
# 武将技能：披甲（触发技）
#
# 描述：准备阶段随机获得一件专属装备置于空置装备栏；集齐指定装备后增加体力上限并回复1点体力。
#
# Gemini:change.12: 批量生成——吕玲绮披甲
# ============================================================

class_name SkillPijia
extends Skill


func register_events() -> void:
	EventBus.subscribe(GameEvent.Type.PHASE_START, _on_event_received, 0, self)


func can_trigger(event: GameEvent) -> bool:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	return event.target == owner_index  # 自己受到伤害


func execute(event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	# TODO: 实现具体效果
	var source_idx = event.source
	if source_idx < 0:
		return
	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.pijia.name": "披甲", "skill.pijia.effect": "pijia"}
	))
