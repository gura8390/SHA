# ============================================================
# skill_jizhi.gd
# 黄月英技能：集智（触发技）
# 描述：当你使用一张非延时锦囊牌时，你可以摸一张牌。
# 触发时机：CARD_USED（使用牌时）
# 同步执行。
# ============================================================

class_name SkillJiZhi
extends Skill


func register_events() -> void:
	EventBus.subscribe(GameEvent.Type.CARD_USED, _on_event_received, 0, self)


func can_trigger(event: GameEvent) -> bool:
	# 必须是自己使用牌
	if event.source != owner_index:
		return false
	var card: CardData = event.data.get("card", null)
	if card == null:
		return false
	# 必须是锦囊牌且非延时锦囊
	if card.card_type != CardData.CardType.TRICK:
		return false
	return card.trick_type != CardData.TrickType.DELAYED


func execute(_event: GameEvent) -> void:
	var eff = DrawCardEffect.create(owner_index, owner_index, 1)
	eff.resolve(battle_context)
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.jizhi.name": "集智", "drawn": 1}
	))
