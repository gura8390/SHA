# ============================================================
# skill_yingzi.gd
# 周瑜技能：英姿（锁定技 / 持续被动）
# 描述：锁定技，你的摸牌阶段摸牌数 +1；你的手牌上限始终为体力上限。
# 实现：被动属性修正——
#   "draw_count" +1（摸牌阶段摸牌数）
#   "hand_limit" 取体力上限（基础手牌上限是当前体力，这里抬到上限）
# ============================================================

class_name SkillYingZi
extends Skill


func register_events() -> void:
	if skill_data != null:
		skill_data.modifies_attributes = true
	# 摸牌阶段摸牌数修正经 DRAW_CARD before 事件
	EventBus.subscribe(GameEvent.Type.DRAW_CARD, _on_draw, 0, self)


func _on_draw(event: GameEvent) -> void:
	if not is_enabled:
		return
	# 仅对自己、摸牌前阶段生效
	if event.target != owner_index:
		return
	if event.data.get("phase", "") != "before":
		return
	# 仅摸牌阶段 +1（无中生有等额外摸牌不受影响）
	if battle_context == null or battle_context.current_phase != BattleContext.Phase.PHASE_DRAW:
		return
	var amount: int = event.data.get("amount", 0)
	event.data["amount"] = amount + 1


# 手牌上限抬到体力上限（英姿：手牌上限为体力上限）
func modify_attribute(attr_name: String, base_value, _ctx_data: Dictionary = {}):
	if attr_name == "hand_limit":
		var p = get_owner_player()
		if p != null:
			return max(base_value, p.max_hp)
	return base_value
