# ============================================================
# skill_wushuang.gd
# 武将技能：无双（锁定技）
#
# 描述：锁定技，你使用的【杀】需两张【闪】才能抵消；
#       与你【决斗】的角色每次需打出两张【杀】。
#
# 实现方式：
#   无双不通过事件系统触发，而是在 card_effect_sha 和 card_effect_duel
#   中通过 is 类型检查 SkillWuShuang 来修改响应流程。
#   本类为标记类 + 提供静态查询方法。
#
# Gemini:change.12: 新建——吕布无双
# ============================================================

class_name SkillWuShuang
extends Skill


func register_events() -> void:
	# 无双的逻辑在杀/决斗结算中通过类型检查触发
	pass


func can_trigger(_event: GameEvent) -> bool:
	return false


func execute(_event: GameEvent) -> void:
	pass


## 检查某玩家是否拥有无双技能
static func has_wushuang(battle_context, player_index: int) -> bool:
	var player = battle_context.get_player(player_index)
	if player == null:
		return false
	for sk in player.skills:
		if sk is SkillWuShuang:
			return true
	return false
