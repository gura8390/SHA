# ============================================================
# skill_biyue.gd
# 武将技能：闭月（触发技）
#
# 描述：结束阶段，你可以摸一张牌。
#
# Gemini:change.12: 新建——貂蝉闭月
# ============================================================

class_name SkillBiYue
extends Skill


func register_events() -> void:
	EventBus.subscribe(GameEvent.Type.TURN_END, _on_event_received, 0, self)


func can_trigger(event: GameEvent) -> bool:
	# 只在自己回合结束时触发
	return event.source == owner_index


func execute(_event: GameEvent) -> void:
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return
	# 摸一张牌
	DrawCardEffect.create(owner_index, owner_index, 1).resolve(battle_context)
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, owner_index,
		{"skill.biyue.name": "闭月", "skill.biyue.effect": "draw_1"}
	))
