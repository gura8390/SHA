# ============================================================
# skill_qingnang.gd
# 武将技能：青囊（主动技）
#
# 描述：出牌阶段，你可以弃置一张手牌，令一名角色回复1点体力。每阶段限一次。
#
# Gemini:change.12: 新建——华佗青囊
# ============================================================

class_name SkillQingNang
extends Skill


func register_events() -> void:
	# 主动技，不订阅事件
	pass


func can_activate() -> bool:
	if not is_enabled:
		return false
	if not _check_use_limit():
		return false
	var owner = get_owner_player()
	if owner == null or not owner.is_alive:
		return false
	# 需要有手牌可弃
	if owner.hand_cards.is_empty():
		return false
	# 场上需要有受伤的角色
	for player in battle_context.get_alive_players():
		if player.current_hp < player.max_hp:
			return true
	return false


func get_active_targets() -> Array:
	# 返回所有受伤角色（含自己）
	var targets: Array = []
	for player in battle_context.get_alive_players():
		if player.current_hp < player.max_hp:
			targets.append(player.index)
	return targets


func activate(targets: Array) -> Dictionary:
	if targets.is_empty():
		return {"resolved": false, "reason": "no_target"}
	var owner = get_owner_player()
	if owner == null:
		return {"resolved": false, "reason": "no_owner"}

	var target_idx: int = targets[0]
	var target_player = battle_context.get_player(target_idx)
	if target_player == null or not target_player.is_alive:
		return {"resolved": false, "reason": "invalid_target"}

	# 选一张手牌弃置（AI 选最低价值，人类通过控制器选）
	var discard_card: CardData = null
	if owner.is_human:
		var controller = battle_context.get_controller(owner_index)
		if controller != null and controller.has_method("decide_card_pick"):
			discard_card = await controller.decide_card_pick(owner_index, owner_index, owner.hand_cards.duplicate(), "qingnang_cost")
		if discard_card == null and not owner.hand_cards.is_empty():
			discard_card = owner.hand_cards[0]
	else:
		# AI：弃最低价值牌
		var min_val: int = 99999
		for c in owner.hand_cards:
			var val = 0
			if battle_context.card_resolver != null:
				val = _simple_card_value(c)
			if val < min_val:
				min_val = val
				discard_card = c

	if discard_card == null:
		return {"resolved": false, "reason": "no_card"}

	# 红线 1：通过 DiscardCardEffect 弃置手牌，禁止先 erase 再 Effect（双重操作）
	DiscardCardEffect.create(
		owner_index, owner_index, [discard_card], DiscardCardEffect.DiscardReason.SKILL_COST
	).resolve(battle_context)

	# 目标回复1点体力
	HealEffect.create(owner_index, target_idx, 1, null).resolve(battle_context)

	record_use()
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, owner_index, target_idx,
		{"skill.qingnang.name": "青囊", "skill.qingnang.effect": "heal_1"}
	))
	return {"resolved": true}


static func _simple_card_value(card: CardData) -> int:
	if card == null:
		return 0
	match card.card_name:
		"桃": return 100
		"无懈可击": return 80
		"闪": return 60
		"酒": return 40
		"火杀", "雷杀": return 38
		"杀": return 35
		_: return 15
