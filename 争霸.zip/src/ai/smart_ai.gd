# ============================================================
# smart_ai.gd
# 智能 AI 控制器：实现 IPlayerController 接口（替代临时 SimpleAI）
#
# 设计目标：在已建成的卡牌/装备/技能/身份系统之上做"局面评估"决策，
# 而非固定优先级 if-else 链。核心思路：
#   1. 威胁评估：综合 HP/手牌/身份关系算目标威胁度，集火敌对残血。
#   2. 手牌价值：给每张牌打价值分，进攻时消耗低价值牌、保留救命牌。
#   3. 桃的取舍：非濒死不乱吃桃，留作救命/濒死自救。
#   4. 杀的目标：攻击范围内挑最优敌对目标，并考虑对方出闪概率。
#   5. 装备策略：优先补空栏（武器提升范围、防具护残血）。
#   6. 响应/技能：濒死必出桃；按收益决定是否出闪、是否发动技能。
#
# IPlayerController 接口约定（duck typing）：
#   setup(context, resolver)
#   decide_play_action(player_index) -> PlayIntent
#   decide_response(request: ResponseRequest) -> ResponseResult
#   decide_discard(player_index, count) -> Array[CardData]
#   decide_skill_activation(skill, event) -> bool
#   cleanup()
# ============================================================

class_name SmartAI
extends RefCounted

## 战场上下文引用
var _context: BattleContext = null

## 卡牌结算中枢引用（目标校验/合法性判断）
var _card_resolver: CardResolver = null


func setup(context: BattleContext, resolver: CardResolver = null) -> void:
	_context = context
	_card_resolver = resolver


func cleanup() -> void:
	pass


## AI 思考延迟（根据 SettingsManager 的设置）
func _ai_delay() -> void:
	var sm = Engine.get_main_loop().root.get_node_or_null("SettingsManager")
	if sm != null and sm.ai_play_delay > 0.01:
		await Engine.get_main_loop().create_timer(sm.ai_play_delay).timeout


# ============================================================
# 卡牌价值评估
# ============================================================

## 卡牌基础价值（越高越珍贵，越不该随意丢弃）
## 救命/防御类高，进攻类中等，纯功能锦囊偏低
func _card_value(card: CardData) -> int:
	if card == null:
		return 0
	match card.card_name:
		"桃": return 100        # 救命，最珍贵
		"无懈可击": return 80    # 反制关键锦囊
		"闪": return 60         # 防御命脉
		"酒": return 40
		"火杀", "雷杀": return 38 # 特殊杀，略高于普通杀
		"杀": return 35
		"无中生有": return 30
		"决斗": return 28
		"过河拆桥", "顺手牵羊": return 26
		"万箭齐发", "南蛮入侵": return 24
		"乐不思蜀", "兵粮寸断", "闪电": return 22
		"借刀杀人": return 20
		"五谷丰登", "桃园结义": return 18
		_:
			# 装备牌价值中等（武器 > 马 > 防具）
			if card.card_type == CardData.CardType.EQUIPMENT:
				return 32
			return 15


# ============================================================
# 身份/威胁评估
# ============================================================

## 敌我关系：>0 敌对（想打），<0 友方（不该打），0 中性/未知
func _hostility(attacker_index: int, target_index: int) -> int:
	var me = _context.get_player(attacker_index)
	var tgt = _context.get_player(target_index)
	if me == null or tgt == null:
		return 0
	# 目标身份未公开 → 中性（仅在已知身份时倾向）
	var t_id: int = tgt.identity if tgt.identity_revealed else -1
	var my_id: int = me.identity
	match my_id:
		Identity.Type.LORD, Identity.Type.LOYALIST:
			match t_id:
				Identity.Type.REBEL: return 12
				Identity.Type.TRAITOR: return 5
				Identity.Type.LORD, Identity.Type.LOYALIST: return -10
				_: return 1
		Identity.Type.REBEL:
			match t_id:
				Identity.Type.LORD: return 12
				Identity.Type.LOYALIST: return 7
				Identity.Type.REBEL: return -10
				_: return 2
		Identity.Type.TRAITOR:
			match t_id:
				Identity.Type.REBEL: return 8
				Identity.Type.LOYALIST: return 6
				Identity.Type.LORD: return 2   # 留主公到最后
				_: return 1
		_:
			return 1


## 目标综合得分：敌对度 + 残血加成（集火快死的敌人）+ 手牌少更好打
func _target_score(attacker_index: int, target_index: int) -> int:
	var host := _hostility(attacker_index, target_index)
	if host <= 0:
		return host * 100   # 友方/中性时直接压低，避免误伤队友
	var tgt = _context.get_player(target_index)
	if tgt == null:
		return host
	var score := host * 10
	# 残血加成：HP 越低越优先（可能一击毙命）
	score += (8 - min(tgt.current_hp, 8)) * 3
	# 手牌少 → 出闪概率低，进攻更划算
	score += (6 - min(tgt.hand_cards.size(), 6))
	return score


# ============================================================
# 出牌阶段决策
# ============================================================

func decide_play_action(player_index: int) -> PlayIntent:
	await _ai_delay()
	var player = _context.get_player(player_index)
	if player == null or not player.is_alive:
		return PlayIntent.end_play()

	# --- 0) 主动技检查（优先于出牌）---
	for sk in player.skills:
		if sk == null or sk.skill_data == null:
			continue
		if sk.skill_data.skill_type != SkillData.SkillType.ACTIVE:
			continue
		if sk.can_activate():
			# AI 简单策略：能发动就发动
			var targets: Array = []
			if sk.has_method("get_active_targets"):
				targets = sk.get_active_targets()
			return PlayIntent.activate_skill(player_index, sk, targets)

	# --- 1) 危急回血：HP<=1 且有桃，立刻吃 ---
	if player.current_hp <= 1 and player.current_hp < player.max_hp:
		var tao = _find_card(player, "桃")
		if tao != null and _can_use(player_index, tao):
			return PlayIntent.no_target(player_index, tao)

	# --- 2) 装备空栏：优先补武器，再补马，最后补防具 ---
	var equip_card = _pick_equip(player)
	if equip_card != null:
		return PlayIntent.no_target(player_index, equip_card)

	# --- 3) 摸牌型增益锦囊：无中生有总是划算 ---
	var wuzhong = _find_card(player, "无中生有")
	if wuzhong != null and _can_use(player_index, wuzhong):
		return PlayIntent.no_target(player_index, wuzhong)

	# --- 4) 进攻：杀（含火杀/雷杀），挑威胁最高的敌对目标 ---
	var effective_kill_limit = player._apply_skill_modifiers("kill_limit", player.kill_limit)
	if player.kill_count_this_turn < effective_kill_limit:
		var sha_intent = _try_attack_with_sha(player_index, player)
		if sha_intent != null:
			return sha_intent

	# --- 5) 单体进攻锦囊：决斗/拆牌类，仅对敌对目标 ---
	for nm in ["决斗", "过河拆桥", "顺手牵羊"]:
		var c = _find_card(player, nm)
		if c != null and _can_use(player_index, c):
			var tgt = _best_hostile_target(player_index, c)
			if tgt != -1:
				return PlayIntent.single_target(player_index, c, tgt)

	# --- 6) 延时锦囊：乐不思蜀/兵粮寸断，控制敌对目标 ---
	for nm in ["乐不思蜀", "兵粮寸断"]:
		var c = _find_card(player, nm)
		if c != null and _can_use(player_index, c):
			var tgt = _best_hostile_target(player_index, c)
			if tgt != -1:
				return PlayIntent.single_target(player_index, c, tgt)

	# --- 7) 借刀杀人：有可借的武器目标才用 ---
	var jiedao = _find_card(player, "借刀杀人")
	if jiedao != null and _can_use(player_index, jiedao):
		var tgt = _best_hostile_target(player_index, jiedao)
		if tgt != -1:
			return PlayIntent.single_target(player_index, jiedao, tgt)

	# --- 8) AOE 伤害锦囊：敌方多于友方时才划算 ---
	if _aoe_is_favorable(player_index):
		for nm in ["万箭齐发", "南蛮入侵"]:
			var c = _find_card(player, nm)
			if c != null and _can_use(player_index, c):
				return PlayIntent.no_target(player_index, c)

	# --- 9) 群体增益：桃园/五谷，自己或队友受伤时用 ---
	if _should_use_group_buff(player_index):
		for nm in ["桃园结义", "五谷丰登"]:
			var c = _find_card(player, nm)
			if c != null and _can_use(player_index, c):
				return PlayIntent.no_target(player_index, c)

	# --- 10) 非危急回血：受伤较重(差>=2)且手牌富余时补血 ---
	if (player.max_hp - player.current_hp) >= 2 and player.hand_cards.size() > 2:
		var tao2 = _find_card(player, "桃")
		if tao2 != null and _can_use(player_index, tao2):
			return PlayIntent.no_target(player_index, tao2)

	return PlayIntent.end_play()


## 用杀进攻：在合法目标里挑得分最高的敌对目标
func _try_attack_with_sha(player_index: int, player) -> PlayIntent:
	# 多张杀时优先用特殊杀（火/雷），普通杀留作灵活；同名取第一张
	for sha_name in ["火杀", "雷杀", "杀"]:
		var sha = _find_card(player, sha_name)
		if sha == null:
			continue
		var tgt = _best_hostile_target(player_index, sha)
		if tgt != -1:
			return PlayIntent.single_target(player_index, sha, tgt)

	# Gemini:change.12: 检查转化技能（武圣：红色手牌当杀；龙胆：闪当杀）
	var conversions = _context.get_convertible_cards(player_index, "杀", _context.current_phase)
	for conv in conversions:
		var sk = conv.get("skill", null)
		var cards = conv.get("cards", [])
		if sk == null or cards.is_empty():
			continue
		# 选价值最低的可转化牌
		var best_conv: CardData = null
		var best_val: int = 99999
		for c in cards:
			var v = _card_value(c)
			if v < best_val:
				best_val = v
				best_conv = c
		if best_conv != null:
			var virtual_sha = sk.create_virtual_card("杀")
			if virtual_sha != null:
				var tgt = _best_hostile_target(player_index, virtual_sha)
				if tgt != -1:
					return PlayIntent.converted_single(player_index, virtual_sha, best_conv, [tgt])

	# Gemini:change.12: 丈八蛇矛——两张手牌当杀
	var has_zhangba := false
	for sk in player.skills:
		if sk is SkillZhangbaSpear:
			has_zhangba = true
			break
	if has_zhangba and player.hand_cards.size() >= 2:
		# 选两张最低价值手牌
		var sorted_cards = player.hand_cards.duplicate()
		sorted_cards.sort_custom(func(a, b): return _card_value(a) < _card_value(b))
		var two_cards: Array = [sorted_cards[0], sorted_cards[1]]
		var virtual_sha = SkillZhangbaSpear.create_sha_from_two_cards(player_index, two_cards, 0)
		var tgt = _best_hostile_target(player_index, virtual_sha.card)
		if tgt != -1:
			var intent = SkillZhangbaSpear.create_sha_from_two_cards(player_index, two_cards, tgt)
			return intent

	return null


# ============================================================
# 响应决策（被杀求闪 / 濒死求桃 / 决斗出杀 等）
# ============================================================

func decide_response(request: ResponseRequest) -> ResponseResult:
	await _ai_delay()
	var player = _context.get_player(request.target_index)
	if player == null or not player.is_alive:
		return ResponseResult.not_played()

	var required = request.required_card_name
	if required.is_empty():
		return ResponseResult.not_played()

	var found = _find_card(player, required)
	if found == null:
		# Gemini:change.12: 检查转化技能（龙胆：杀当闪；急救：红牌当桃等）
		var conversions = request.context.get("convertible_skills", [])
		for conv in conversions:
			var sk = conv.get("skill", null)
			var cards = conv.get("cards", [])
			if sk != null and not cards.is_empty():
				# 选价值最低的可转化牌
				var best_conv: CardData = null
				var best_val: int = 99999
				for c in cards:
					var v = _card_value(c)
					if v < best_val:
						best_val = v
						best_conv = c
				if best_conv != null:
					# 创建虚拟牌并返回
					var virtual_card = sk.create_virtual_card(required)
					if virtual_card != null:
						return ResponseResult.played_converted(virtual_card, best_conv)
		return ResponseResult.not_played()

	# 濒死求桃/酒：有桃必出，濒死者自己也可出酒
	if required == "桃" or required == "酒":
		return ResponseResult.played_card(found)

	# 求闪：默认出闪自保；但若手中仅剩这一张闪且自身 HP 充裕(>=3)，
	# 可考虑硬吃 1 点伤害保留闪——除非这张杀可能致命。
	if required == "闪":
		# 估算伤害（考虑酒加成）
		var damage_est: int = 1
		var src_card = request.context.get("card", null)
		if src_card != null:
			var src_player = _context.get_player(request.source_index)
			if src_player != null and src_player.wine_used:
				damage_est = 2
		var sha_lethal: bool = player.current_hp <= damage_est
		var flash_count: int = _count_card(player, "闪")
		if sha_lethal or flash_count > 1 or player.current_hp < 3:
			return ResponseResult.played_card(found)
		# HP 充裕且仅一张闪：保留，硬吃这点伤害
		return ResponseResult.not_played()

	# Gemini:change.10: 无懈可击——按身份判断是否抵消当前锦囊
	## 策略：若锦囊"对己方有害"则出无懈保护，否则不浪费。
	## 请求 context 含 card(被抵消的锦囊)、primary_target(目标，-1=全体)。
	if required == "无懈可击":
		var trick_card: CardData = request.context.get("card", null)
		var primary_tgt: int = request.context.get("primary_target", -1)
		var trick_source: int = request.source_index
		if trick_card == null:
			return ResponseResult.not_played()
		if _should_wuxie(player.index, trick_source, trick_card, primary_tgt):
			return ResponseResult.played_card(found)
		return ResponseResult.not_played()

	# 决斗等需要出杀响应：有杀就出（拼点不能输）
	return ResponseResult.played_card(found)


# ============================================================
# 选牌决策（过河拆桥/顺手牵羊/五谷丰登等）
# ============================================================

func decide_card_pick(player_index: int, target_index: int, available_cards: Array, pick_context: String = "") -> CardData:
	await _ai_delay()
	if available_cards.is_empty():
		return null

	# 顺手牵羊/五谷丰登：选价值最高的牌给自己
	if pick_context == "steal" or pick_context == "wugu":
		var best: CardData = null
		var best_val: int = -1
		for card in available_cards:
			var val = _card_value(card)
			if val > best_val:
				best_val = val
				best = card
		return best

	# 过河拆桥：优先拆对方最有价值的装备，其次手牌
	if pick_context == "dismantle":
		# 优先拆武器（对敌方最有威胁），其次马，再次防具
		var equip_order := [
			CardData.EquipType.WEAPON,
			CardData.EquipType.HORSE_ATK,
			CardData.EquipType.HORSE_DEF,
			CardData.EquipType.ARMOR,
			CardData.EquipType.TREASURE,
		]
		for want in equip_order:
			for card in available_cards:
				if card.card_type == CardData.CardType.EQUIPMENT and card.equip_type == want:
					return card
		# 无装备则选手牌中价值最高的
		var best: CardData = null
		var best_val: int = -1
		for card in available_cards:
			var val = _card_value(card)
			if val > best_val:
				best_val = val
				best = card
		return best

	# 默认：选第一张
	return available_cards[0]


# ============================================================
# 弃牌决策：弃价值最低的牌
# ============================================================

func decide_discard(player_index: int, count: int) -> Array:
	await _ai_delay()
	var player = _context.get_player(player_index)
	if player == null:
		return []
	# 按价值升序排序手牌索引，弃最低价值的 count 张
	var cards: Array = player.hand_cards.duplicate()
	cards.sort_custom(func(a, b): return _card_value(a) < _card_value(b))
	var to_discard: Array = []
	for i in range(min(count, cards.size())):
		to_discard.append(cards[i])
	return to_discard


# ============================================================
# 技能发动决策：按收益判断
# ============================================================

func decide_skill_activation(skill: Skill, _event: GameEvent) -> bool:
	if skill == null:
		return false
	# 锁定技不经此询问（强制）；可选触发技默认发动——
	# 现有技能（奸雄/反馈）均为"获益型"，发动总是划算。
	# 后续若有负收益技能，可按 skill.skill_data.skill_id 细分。
	return true


# ============================================================
# 辅助方法
# ============================================================

func _can_use(player_index: int, card: CardData) -> bool:
	return _card_resolver != null and _card_resolver.can_use_in_play_phase(_context, player_index, card)


func _find_card(player, card_name: String) -> CardData:
	for card in player.hand_cards:
		if card.card_name == card_name:
			return card
	return null


func _count_card(player, card_name: String) -> int:
	var n := 0
	for card in player.hand_cards:
		if card.card_name == card_name:
			n += 1
	return n


## 挑选一张该补的装备：武器 > 进攻马 > 防御马 > 防具 > 宝物，仅补空栏
func _pick_equip(player) -> CardData:
	var order := [
		CardData.EquipType.WEAPON,
		CardData.EquipType.HORSE_ATK,
		CardData.EquipType.HORSE_DEF,
		CardData.EquipType.ARMOR,
		CardData.EquipType.TREASURE,
	]
	for want in order:
		for card in player.hand_cards:
			if card.card_type != CardData.CardType.EQUIPMENT:
				continue
			if card.equip_type != want:
				continue
			if not _slot_occupied(player, want):
				return card
	return null


func _slot_occupied(player, equip_type: int) -> bool:
	match equip_type:
		CardData.EquipType.WEAPON: return player.equip_weapon != null
		CardData.EquipType.ARMOR: return player.equip_armor != null
		CardData.EquipType.HORSE_DEF: return player.equip_horse_def != null
		CardData.EquipType.HORSE_ATK: return player.equip_horse_atk != null
		CardData.EquipType.TREASURE: return player.equip_treasure != null
	return true


## 在合法目标中挑敌对得分最高者；无敌对目标返回 -1
func _best_hostile_target(attacker_index: int, card: CardData) -> int:
	if _card_resolver == null:
		return -1
	var valid = _card_resolver.get_valid_targets(_context, attacker_index, card)
	if valid.is_empty():
		return -1
	var best: Array = []
	var best_score: int = -999999
	for tgt in valid:
		var s := _target_score(attacker_index, tgt)
		if s > best_score:
			best_score = s
			best = [tgt]
		elif s == best_score:
			best.append(tgt)
	# 若最高分仍为负（只剩友方/中性可选）——进攻锦囊宁可不打友方
	if best_score <= 0:
		return -1
	return best[randi() % best.size()]


## AOE 是否划算：已公开的敌人数 >= 友方数（身份不明时偏保守，按存活数粗判）
func _aoe_is_favorable(player_index: int) -> bool:
	var me = _context.get_player(player_index)
	if me == null:
		return false
	var enemies := 0
	var allies := 0
	for p in _context.get_alive_players():
		if p.index == player_index:
			continue
		var h := _hostility(player_index, p.index)
		if h > 0:
			enemies += 1
		elif h < 0:
			allies += 1
	# 敌人不少于友方，且至少有一个敌人时才放 AOE
	return enemies >= 1 and enemies >= allies


## 群体增益是否该用：自己受伤，或场上有友方受伤
func _should_use_group_buff(player_index: int) -> bool:
	var me = _context.get_player(player_index)
	if me == null:
		return false
	if me.current_hp < me.max_hp:
		return true
	for p in _context.get_alive_players():
		if p.index == player_index:
			continue
		if _hostility(player_index, p.index) < 0 and p.current_hp < p.max_hp:
			return true
	return false


## Gemini:change.10: 是否应该打出无懈可击来抵消一张锦囊
## 策略：单目标锦囊看目标与自己的敌友关系；AOE 看净敌损。
## @param my_idx: 自己（准备打无懈的人）
## @param trick_source_idx: 锦囊使用者
## @param trick_card: 被抵消的锦囊
## @param primary_target: 单目标锦囊的目标，AOE 传 -1
func _should_wuxie(my_idx: int, trick_source_idx: int, trick_card: CardData, primary_target: int) -> bool:
	if trick_card == null:
		return false

	# 无懈可击本身的价值较高（80），不轻易浪费。
	# 只在"锦囊对己方明显有害"时才出。

	var trick_user_hostility := _hostility(my_idx, trick_source_idx)

	# ---- 单目标锦囊（决斗/过河拆桥/顺手牵羊/借刀杀人/延时锦囊）----
	if primary_target >= 0:
		var target_hostility := _hostility(my_idx, primary_target)
		# 锦囊对友方使用（施法者敌对 + 目标友方）→ 有害，应抵消
		if trick_user_hostility > 0 and target_hostility < 0:
			return true
		# 锦囊对自己使用 → 有害，应抵消
		if primary_target == my_idx and trick_user_hostility > 0:
			return true
		# 其余情况（对敌方用、身份不明）→ 不浪费无懈
		return false

	# ---- AOE 锦囊（南蛮/万箭/桃园/五谷）----
	# AOE 伤害型（南蛮/万箭）：如果使用者是敌对，抵消（保护己方全体）
	if trick_card.card_name == "南蛮入侵" or trick_card.card_name == "万箭齐发":
		return trick_user_hostility > 0
	# AOE 增益型（桃园/五谷）：如果使用者是敌对，抵消（不让敌方获益）
	if trick_card.card_name == "桃园结义" or trick_card.card_name == "五谷丰登":
		return trick_user_hostility > 0
	# 其余锦囊：保守不出
	return false
