# ============================================================
# human_controller.gd
# 人类玩家控制器：实现 IPlayerController 接口（与 SimpleAI 对等）
#
# 设计：控制器是"决策来源"，UI 是"输入设备"。两者通过信号解耦：
#   - 控制器需要决策时 emit 请求信号（UI 监听后弹出操作提示/高亮）
#   - UI 收集到玩家操作后调用 submit_* 把结果交回控制器
#   - 决策方法内部 await 自身的"已提交"信号，从而把异步 UI 输入
#     无缝接入 game_manager / ResponseRequest 的 await 链
#
# 这样 game_manager 和 ResponseRequest 完全不需要区分 AI / 人类：
#   var intent = await controller.decide_play_action(idx)   # AI 立即返回，人类等 UI
#
# Gemini:change.4: 新建——人类玩家输入链路（补全 HumanController 桩）
# ============================================================

class_name HumanController
extends RefCounted

## 战场上下文
var _context: BattleContext = null

## 卡牌结算中枢（目标/合法性校验，与 AI 共用）
var _card_resolver: CardResolver = null

# ----- 决策请求信号（UI 监听）-----
## 轮到此人出牌：UI 应展示手牌+可选项，等待玩家选择
## valid_play 为可用牌的提示数据（由 UI 自行计算高亮，这里只通知）
signal play_requested(player_index: int)
## 需要此人响应（出闪/出杀/出桃）：required 为牌名，extra 含提示
signal response_requested(player_index: int, required: String, extra: Dictionary)
## 需要此人弃牌：count 为需弃数量
signal discard_requested(player_index: int, count: int)
## Gemini:change.9: 需要从此区域选择一张牌（过河拆桥/顺手牵羊/五谷丰登）
signal card_pick_requested(player_index: int, target_index: int, available_cards: Array, pick_context: String)
## Gemini:change.10: 和衷技能选择"大于"或"小于"
signal hezhong_direction_requested(player_index: int, rank: int)

# ----- 内部 await 用信号（submit_* 触发）-----
signal _play_submitted(intent: PlayIntent)
signal _response_submitted(result: ResponseResult)
signal _discard_submitted(cards: Array)
signal _card_pick_submitted(picked_card: CardData)
signal _hezhong_direction_submitted(direction: String)


# Gemini:change.4: 初始化（与 SimpleAI.setup 同签名，便于 game_manager 统一注册）
func setup(context: BattleContext, resolver: CardResolver = null) -> void:
	_context = context
	_card_resolver = resolver


# ============================================================
# IPlayerController 接口实现（全部 async，await UI 回填）
# ============================================================

# Gemini:change.4: 出牌决策——发请求信号，await UI 提交 PlayIntent
## call_deferred 发信号：先让本协程挂在 await 上，再于下一空闲帧发请求，
## 否则同步 emit 会在 await 就位前触发 submit，导致信号丢失、死锁。
func decide_play_action(player_index: int):
	var player = _context.get_player(player_index)
	if player == null or not player.is_alive:
		return PlayIntent.end_play()
	(func(): play_requested.emit(player_index)).call_deferred()
	var intent: PlayIntent = await _play_submitted
	return intent


# Gemini:change.4: 响应决策——发请求信号，await UI 提交 ResponseResult
func decide_response(request: ResponseRequest):
	var player = _context.get_player(request.target_index)
	if player == null or not player.is_alive:
		return ResponseResult.not_played()
	var ti := request.target_index
	var rq := request.required_card_name
	var ex := request.context
	(func(): response_requested.emit(ti, rq, ex)).call_deferred()
	var result: ResponseResult = await _response_submitted
	return result


# Gemini:change.4: 弃牌决策——发请求信号，await UI 提交要弃的牌
func decide_discard(player_index: int, count: int) -> Array:
	var player = _context.get_player(player_index)
	if player == null:
		return []
	(func(): discard_requested.emit(player_index, count)).call_deferred()
	var cards: Array = await _discard_submitted
	return cards


# Gemini:change.10: 和衷方向选择——发请求信号，await UI 提交选择
func decide_hezhong_direction(player_index: int, rank: int) -> String:
	(func(): hezhong_direction_requested.emit(player_index, rank)).call_deferred()
	var direction: String = await _hezhong_direction_submitted
	return direction


# Gemini:change.9: 选牌决策——发请求信号，await UI 提交选择的牌
## 用于过河拆桥/顺手牵羊/五谷丰登等需要从列表中选一张牌的场景
func decide_card_pick(player_index: int, target_index: int, available_cards: Array, pick_context: String = "") -> CardData:
	if available_cards.is_empty():
		return null
	(func(): card_pick_requested.emit(player_index, target_index, available_cards, pick_context)).call_deferred()
	var picked: CardData = await _card_pick_submitted
	return picked


# Gemini:change.4: 技能发动决策（保持同步——与 AI 一致，触发技默认发动）
## 触发技自动发动对玩家通常有利（奸雄/反馈），且 SkillTriggerPipeline
## 走同步 EventBus 链；本轮人类技能发动同样默认 yes，避免阻塞同步链。
func decide_skill_activation(skill: Skill, _event: GameEvent) -> bool:
	return skill != null


# ============================================================
# UI 回填入口（由 battle_table 在玩家完成操作后调用）
# ============================================================

# Gemini:change.4: 提交出牌意图（card=null 表示结束出牌阶段）
func submit_play(intent: PlayIntent) -> void:
	_play_submitted.emit(intent)


# Gemini:change.4: 提交"结束出牌阶段"
func submit_end_play() -> void:
	_play_submitted.emit(PlayIntent.end_play())


# Gemini:change.4: 提交响应结果
func submit_response(result: ResponseResult) -> void:
	_response_submitted.emit(result)


# Gemini:change.4: 提交弃牌列表
func submit_discard(cards: Array) -> void:
	_discard_submitted.emit(cards)


# Gemini:change.9: 提交选牌结果
func submit_card_pick(card: CardData) -> void:
	_card_pick_submitted.emit(card)


# Gemini:change.10: 提交和衷方向选择
func submit_hezhong_direction(direction: String) -> void:
	_hezhong_direction_submitted.emit(direction)


# ============================================================
# 供 UI 复用的辅助查询（合法目标 / 出牌阶段可用性）
# ============================================================

# Gemini:change.4: 某张牌在出牌阶段是否可用
func can_use_in_play_phase(player_index: int, card: CardData) -> bool:
	if _card_resolver == null:
		return false
	return _card_resolver.can_use_in_play_phase(_context, player_index, card)


# Gemini:change.4: 某张牌的合法目标列表
func get_valid_targets(player_index: int, card: CardData) -> Array:
	if _card_resolver == null:
		return []
	return _card_resolver.get_valid_targets(_context, player_index, card)


# IPlayerController 接口：清理（对局结束时调用）
func cleanup() -> void:
	pass
