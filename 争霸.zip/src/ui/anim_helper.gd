# ============================================================
# anim_helper.gd
# 动画工具类：提供统一的 UI 动画效果
# 所有方法为静态，接受节点引用，返回 Tween
#
# ============================================================

class_name AnimHelper
extends RefCounted

const EASE_OUT := Tween.EASE_OUT
const EASE_IN := Tween.EASE_IN
const TRANS_QUAD := Tween.TRANS_QUAD
const TRANS_BACK := Tween.TRANS_BACK
const TRANS_SINE := Tween.TRANS_SINE
const TRANS_ELASTIC := Tween.TRANS_ELASTIC


# ============================================================
# 基础动画
# ============================================================

## 面板淡入
static func fade_in(node: Control, duration: float = 0.3) -> Tween:
	node.modulate.a = 0.0
	var tw = node.create_tween()
	tw.tween_property(node, "modulate:a", 1.0, duration).set_ease(EASE_OUT).set_trans(TRANS_QUAD)
	return tw


## 面板淡出
static func fade_out(node: Control, duration: float = 0.25) -> Tween:
	var tw = node.create_tween()
	tw.tween_property(node, "modulate:a", 0.0, duration).set_ease(EASE_IN).set_trans(TRANS_QUAD)
	return tw


## 从下方滑入 + 淡入
static func slide_up(node: Control, distance: float = 30.0, duration: float = 0.4) -> Tween:
	var target_pos = node.position
	node.position.y += distance
	node.modulate.a = 0.0
	var tw = node.create_tween()
	tw.set_parallel(true)
	tw.tween_property(node, "position", target_pos, duration).set_ease(EASE_OUT).set_trans(TRANS_BACK)
	tw.tween_property(node, "modulate:a", 1.0, duration * 0.7).set_ease(EASE_OUT).set_trans(TRANS_QUAD)
	return tw


## 从上方滑入 + 淡入
static func slide_down(node: Control, distance: float = 30.0, duration: float = 0.4) -> Tween:
	var target_pos = node.position
	node.position.y -= distance
	node.modulate.a = 0.0
	var tw = node.create_tween()
	tw.set_parallel(true)
	tw.tween_property(node, "position", target_pos, duration).set_ease(EASE_OUT).set_trans(TRANS_BACK)
	tw.tween_property(node, "modulate:a", 1.0, duration * 0.7).set_ease(EASE_OUT).set_trans(TRANS_QUAD)
	return tw


## 从左侧滑入
static func slide_left(node: Control, distance: float = 50.0, duration: float = 0.35) -> Tween:
	var target_pos = node.position
	node.position.x -= distance
	node.modulate.a = 0.0
	var tw = node.create_tween()
	tw.set_parallel(true)
	tw.tween_property(node, "position", target_pos, duration).set_ease(EASE_OUT).set_trans(TRANS_BACK)
	tw.tween_property(node, "modulate:a", 1.0, duration * 0.6).set_ease(EASE_OUT).set_trans(TRANS_QUAD)
	return tw


## 从右侧滑入
static func slide_right(node: Control, distance: float = 50.0, duration: float = 0.35) -> Tween:
	var target_pos = node.position
	node.position.x += distance
	node.modulate.a = 0.0
	var tw = node.create_tween()
	tw.set_parallel(true)
	tw.tween_property(node, "position", target_pos, duration).set_ease(EASE_OUT).set_trans(TRANS_BACK)
	tw.tween_property(node, "modulate:a", 1.0, duration * 0.6).set_ease(EASE_OUT).set_trans(TRANS_QUAD)
	return tw


## 弹性缩放出现
static func pop_in(node: Control, duration: float = 0.35) -> Tween:
	node.scale = Vector2(0.3, 0.3)
	node.modulate.a = 0.0
	var tw = node.create_tween()
	tw.set_parallel(true)
	tw.tween_property(node, "scale", Vector2(1.0, 1.0), duration).set_ease(EASE_OUT).set_trans(TRANS_BACK)
	tw.tween_property(node, "modulate:a", 1.0, duration * 0.6).set_ease(EASE_OUT).set_trans(TRANS_QUAD)
	return tw


## 缩放消失
static func pop_out(node: Control, duration: float = 0.2) -> Tween:
	var tw = node.create_tween()
	tw.set_parallel(true)
	tw.tween_property(node, "scale", Vector2(0.3, 0.3), duration).set_ease(EASE_IN).set_trans(TRANS_QUAD)
	tw.tween_property(node, "modulate:a", 0.0, duration).set_ease(EASE_IN).set_trans(TRANS_QUAD)
	return tw


## 延迟后执行回调
static func delayed_call(node: Node, delay: float, callback: Callable) -> Tween:
	var tw = node.create_tween()
	tw.tween_interval(delay)
	tw.tween_callback(callback)
	return tw


# ============================================================
# 按钮动画
# ============================================================

## 按钮悬停进入
static func btn_hover_enter(btn: Control, duration: float = 0.15) -> Tween:
	var tw = btn.create_tween()
	tw.tween_property(btn, "scale", Vector2(1.05, 1.05), duration).set_ease(EASE_OUT).set_trans(TRANS_BACK)
	return tw


## 按钮悬停退出
static func btn_hover_exit(btn: Control, duration: float = 0.15) -> Tween:
	var tw = btn.create_tween()
	tw.tween_property(btn, "scale", Vector2(1.0, 1.0), duration).set_ease(EASE_OUT).set_trans(TRANS_QUAD)
	return tw


## 按钮点击涟漪（从中心扩散的圆形）
static func btn_click_ripple(btn: Control) -> void:
	var ripple := ColorRect.new()
	ripple.color = Color(0.72, 0.22, 0.18, 0.15)  # 朱红半透明
	ripple.size = Vector2(4, 4)
	ripple.position = btn.size / 2.0 - Vector2(2, 2)
	ripple.z_index = 10
	btn.add_child(ripple)

	var tw = ripple.create_tween()
	tw.set_parallel(true)
	tw.tween_property(ripple, "size", btn.size * 2.0, 0.4).set_ease(EASE_OUT).set_trans(TRANS_QUAD)
	tw.tween_property(ripple, "position", btn.size / 2.0 - btn.size, 0.4).set_ease(EASE_OUT).set_trans(TRANS_QUAD)
	tw.tween_property(ripple, "modulate:a", 0.0, 0.4).set_ease(EASE_IN).set_trans(TRANS_QUAD)
	tw.chain().tween_callback(ripple.queue_free)


# ============================================================
# 文字动画
# ============================================================

## 打字机效果
static func typewriter(label: Label, text: String, speed: float = 0.03) -> Tween:
	label.text = ""
	var tw = label.create_tween()
	for i in range(text.length()):
		tw.tween_callback(label.set_text.bind(text.substr(0, i + 1)))
		tw.tween_interval(speed)
	return tw


## 墨迹逐字展开（标题用）
static func ink_reveal(label: Label, duration: float = 1.0) -> Tween:
	var full_text: String = label.text
	label.visible_characters = 0
	var tw = label.create_tween()
	tw.tween_property(label, "visible_characters", full_text.length(), duration).set_ease(EASE_OUT).set_trans(TRANS_SINE)
	return tw


## 数字滚动（血量变化用）
static func number_roll(label: Label, from_val: int, to_val: int, duration: float = 0.3) -> Tween:
	var tw = label.create_tween()
	var step_count := absi(to_val - from_val)
	if step_count == 0:
		return tw
	var step_time := duration / float(step_count)
	for i in range(step_count):
		var val := from_val + (1 if to_val > from_val else -1) * (i + 1)
		tw.tween_callback(label.set_text.bind(str(val)))
		tw.tween_interval(step_time)
	return tw


# ============================================================
# 卡牌动画
# ============================================================

## 卡牌飞出（从当前位置飞向目标位置）
static func card_fly(card: Control, target_pos: Vector2, duration: float = 0.3) -> Tween:
	var tw = card.create_tween()
	tw.set_parallel(true)
	tw.tween_property(card, "position", target_pos, duration).set_ease(EASE_OUT).set_trans(TRANS_QUAD)
	tw.tween_property(card, "scale", Vector2(0.5, 0.5), duration).set_ease(EASE_IN).set_trans(TRANS_QUAD)
	tw.tween_property(card, "modulate:a", 0.0, duration * 0.8).set_ease(EASE_IN).set_trans(TRANS_QUAD)
	tw.chain().tween_callback(card.queue_free)
	return tw


## 卡牌消散（缩小 + 透明 + 旋转）
static func card_dissolve(card: Control, duration: float = 0.3) -> Tween:
	var tw = card.create_tween()
	tw.set_parallel(true)
	tw.tween_property(card, "scale", Vector2(0.1, 0.1), duration).set_ease(EASE_IN).set_trans(TRANS_QUAD)
	tw.tween_property(card, "modulate:a", 0.0, duration).set_ease(EASE_IN).set_trans(TRANS_QUAD)
	tw.tween_property(card, "rotation", 0.3, duration).set_ease(EASE_IN).set_trans(TRANS_QUAD)
	tw.chain().tween_callback(card.queue_free)
	return tw


## 卡牌翻转（模拟正面/背面切换）
static func card_flip(card: Control, callback: Callable = Callable(), duration: float = 0.3) -> Tween:
	var half := duration / 2.0
	var tw = card.create_tween()
	tw.tween_property(card, "scale:x", 0.0, half).set_ease(EASE_IN).set_trans(TRANS_QUAD)
	tw.tween_callback(callback)
	tw.tween_property(card, "scale:x", 1.0, half).set_ease(EASE_OUT).set_trans(TRANS_BACK)
	return tw


# ============================================================
# 对局动画
# ============================================================

## 伤害数字弹出（红色，从目标位置上浮淡出）
static func damage_popup(parent: Control, amount: int, pos: Vector2) -> void:
	var lbl := Label.new()
	lbl.text = "-%d" % amount
	lbl.add_theme_font_size_override("font_size", 40)
	lbl.add_theme_color_override("font_color", UITheme.DANGER)
	lbl.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.3))
	lbl.add_theme_constant_override("shadow_offset_x", 2)
	lbl.add_theme_constant_override("shadow_offset_y", 2)
	lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	lbl.position = pos - Vector2(30, 20)
	lbl.z_index = 200
	parent.add_child(lbl)

	# 弹出 + 上浮 + 淡出
	lbl.scale = Vector2(0.5, 0.5)
	var tw = lbl.create_tween()
	tw.tween_property(lbl, "scale", Vector2(1.2, 1.2), 0.15).set_ease(EASE_OUT).set_trans(TRANS_BACK)
	tw.tween_property(lbl, "scale", Vector2(1.0, 1.0), 0.1).set_ease(EASE_OUT).set_trans(TRANS_QUAD)
	tw.tween_interval(0.4)
	tw.set_parallel(true)
	tw.tween_property(lbl, "position:y", pos.y - 80, 0.5).set_ease(EASE_OUT).set_trans(TRANS_QUAD)
	tw.tween_property(lbl, "modulate:a", 0.0, 0.5).set_ease(EASE_IN).set_trans(TRANS_QUAD)
	tw.chain().tween_callback(lbl.queue_free)


## 回复数字弹出（绿色）
static func heal_popup(parent: Control, amount: int, pos: Vector2) -> void:
	var lbl := Label.new()
	lbl.text = "+%d" % amount
	lbl.add_theme_font_size_override("font_size", 40)
	lbl.add_theme_color_override("font_color", UITheme.OK)
	lbl.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.3))
	lbl.add_theme_constant_override("shadow_offset_x", 2)
	lbl.add_theme_constant_override("shadow_offset_y", 2)
	lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	lbl.position = pos - Vector2(30, 20)
	lbl.z_index = 200
	parent.add_child(lbl)

	lbl.scale = Vector2(0.5, 0.5)
	var tw = lbl.create_tween()
	tw.tween_property(lbl, "scale", Vector2(1.2, 1.2), 0.15).set_ease(EASE_OUT).set_trans(TRANS_BACK)
	tw.tween_property(lbl, "scale", Vector2(1.0, 1.0), 0.1).set_ease(EASE_OUT).set_trans(TRANS_QUAD)
	tw.tween_interval(0.4)
	tw.set_parallel(true)
	tw.tween_property(lbl, "position:y", pos.y - 80, 0.5).set_ease(EASE_OUT).set_trans(TRANS_QUAD)
	tw.tween_property(lbl, "modulate:a", 0.0, 0.5).set_ease(EASE_IN).set_trans(TRANS_QUAD)
	tw.chain().tween_callback(lbl.queue_free)


## 技能名弹出（金色，从左侧滑入）
static func skill_popup(parent: Control, skill_name: String, pos: Vector2) -> void:
	var lbl := Label.new()
	lbl.text = "✦ %s" % skill_name
	lbl.add_theme_font_size_override("font_size", 30)
	lbl.add_theme_color_override("font_color", UITheme.ACCENT)
	lbl.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.2))
	lbl.add_theme_constant_override("shadow_offset_x", 1)
	lbl.add_theme_constant_override("shadow_offset_y", 1)
	lbl.position = Vector2(pos.x - 60, pos.y)
	lbl.modulate.a = 0.0
	lbl.z_index = 200
	parent.add_child(lbl)

	var tw = lbl.create_tween()
	tw.tween_property(lbl, "position:x", pos.x, 0.3).set_ease(EASE_OUT).set_trans(TRANS_BACK)
	tw.parallel().tween_property(lbl, "modulate:a", 1.0, 0.2)
	tw.tween_interval(1.0)
	tw.tween_property(lbl, "modulate:a", 0.0, 0.3)
	tw.tween_callback(lbl.queue_free)


## 屏幕中央大字弹出
static func center_announce(parent: Control, text: String, hold_time: float = 1.5) -> void:
	var lbl := Label.new()
	lbl.text = text
	lbl.add_theme_font_size_override("font_size", 60)
	lbl.add_theme_color_override("font_color", UITheme.ACCENT)
	lbl.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.3))
	lbl.add_theme_constant_override("shadow_offset_x", 3)
	lbl.add_theme_constant_override("shadow_offset_y", 3)
	lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	lbl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	lbl.set_anchors_preset(Control.PRESET_CENTER)
	lbl.z_index = 300
	parent.add_child(lbl)

	lbl.scale = Vector2(0.2, 0.2)
	lbl.modulate.a = 0.0
	var tw = lbl.create_tween()
	tw.tween_property(lbl, "scale", Vector2(1.0, 1.0), 0.4).set_ease(EASE_OUT).set_trans(TRANS_BACK)
	tw.parallel().tween_property(lbl, "modulate:a", 1.0, 0.3)
	tw.tween_interval(maxf(hold_time - 0.7, 0.0))
	tw.tween_property(lbl, "modulate:a", 0.0, 0.3)
	tw.tween_callback(lbl.queue_free)


## 濒死震动（屏幕抖动）
static func screen_shake(node: Control, intensity: float = 5.0, duration: float = 0.3) -> void:
	var original_pos = node.position
	var tw = node.create_tween()
	for i in range(6):
		var offset := Vector2(
			randf_range(-intensity, intensity),
			randf_range(-intensity, intensity)
		)
		tw.tween_property(node, "position", original_pos + offset, duration / 6.0)
	tw.tween_property(node, "position", original_pos, 0.05)


## 座位边框脉冲（回合指示器）
static func seat_pulse_border(panel: Panel, color: Color = UITheme.ACCENT, cycles: int = 2) -> Tween:
	var tw = panel.create_tween().set_loops(cycles)
	tw.tween_callback(func():
		var sb := UITheme.panel_style(UITheme.BG_PANEL, color, 10)
		sb.border_width_all = 2
		panel.add_theme_stylebox_override("panel", sb)
	)
	tw.tween_interval(0.4)
	tw.tween_callback(func():
		panel.add_theme_stylebox_override("panel", UITheme.panel_style(UITheme.BG_PANEL))
	)
	tw.tween_interval(0.4)
	return tw


## 装备安装闪光
static func equip_flash(panel: Panel) -> void:
	var flash := ColorRect.new()
	flash.color = Color(1.0, 1.0, 1.0, 0.4)
	flash.set_anchors_preset(Control.PRESET_FULL_RECT)
	flash.mouse_filter = Control.MOUSE_FILTER_IGNORE
	panel.add_child(flash)

	var tw = flash.create_tween()
	tw.tween_property(flash, "modulate:a", 0.0, 0.5).set_ease(EASE_IN).set_trans(TRANS_QUAD)
	tw.tween_callback(flash.queue_free)


## AOE 全屏波纹
static func aoe_ripple(parent: Control) -> void:
	var ripple := ColorRect.new()
	ripple.color = Color(0.72, 0.22, 0.18, 0.08)
	ripple.set_anchors_preset(Control.PRESET_FULL_RECT)
	ripple.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ripple.z_index = 250
	parent.add_child(ripple)

	var tw = ripple.create_tween()
	tw.tween_property(ripple, "color:a", 0.0, 0.6).set_ease(EASE_IN).set_trans(TRANS_QUAD)
	tw.tween_callback(ripple.queue_free)


## 场景切换水墨过渡
static func scene_transition(parent: Control, callback: Callable, duration: float = 0.5) -> void:
	var overlay := ColorRect.new()
	overlay.color = Color(0.18, 0.18, 0.20, 0.0)  # 深灰黑
	overlay.set_anchors_preset(Control.PRESET_FULL_RECT)
	overlay.z_index = 500
	parent.add_child(overlay)

	var tw = overlay.create_tween()
	tw.tween_property(overlay, "color:a", 1.0, duration * 0.6).set_ease(EASE_IN).set_trans(TRANS_QUAD)
	tw.tween_callback(callback)
	tw.tween_property(overlay, "color:a", 0.0, duration * 0.4).set_ease(EASE_OUT).set_trans(TRANS_QUAD)
	tw.tween_callback(overlay.queue_free)


## 血量条平滑过渡
static func hp_bar_smooth(bar: Control, from_ratio: float, to_ratio: float, duration: float = 0.4) -> Tween:
	var tw = bar.create_tween()
	if from_ratio <= 0.0:
		bar.size.x = 0
		return tw
	var ratio := clampf(to_ratio / maxf(from_ratio, 0.01), 0.0, 3.0)
	tw.tween_property(bar, "size:x", bar.size.x * ratio, duration).set_ease(EASE_OUT).set_trans(TRANS_QUAD)
	return tw
