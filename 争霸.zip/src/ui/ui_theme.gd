# ============================================================
# ui_theme.gd
# 统一 UI 主题：墨色漆器 · 描金 · 朱砂 · 宣纸
#
# 设计令牌层：所有界面只能引用这里的值，不允许就地写死颜色或尺寸。
# 色彩铁律：深底 80% + 描金 15% + 朱砂 5%
#
# 最近更新：2026-06-18（v2.0 墨色漆器主题）
# ============================================================

class_name UITheme
extends RefCounted

# ── 背景层次：靠明度差建立纵深，三档明显拉开 ──
const BG_DEEP     = Color(0.08, 0.075, 0.085)   # 墨色牌桌（根背景）
const BG_PANEL    = Color(0.135, 0.13, 0.145)   # 深石板面板
const BG_PANEL_HI = Color(0.19, 0.18, 0.20)     # 高亮面板/按钮默认态

# ── 边框与金 ──
const BORDER      = Color(0.52, 0.43, 0.27)     # 古铜描金边（常规）
const GOLD        = Color(0.83, 0.68, 0.40)     # 高亮描金（标题/重点/选中）

# ── 强调 ──
const ACCENT      = Color(0.78, 0.22, 0.18)     # 朱砂（主按钮/指向/危机）
const ACCENT_DIM  = Color(0.58, 0.19, 0.16)     # 暗朱砂（按下态）

# ── 文字：暖白，不用纯白 ──
const TEXT        = Color(0.92, 0.89, 0.83)     # 主文字（米白）
const TEXT_DIM    = Color(0.60, 0.58, 0.55)     # 次文字/禁用提示

# ── 状态色：提亮以适配深底 ──
const DANGER      = Color(0.86, 0.28, 0.24)
const OK          = Color(0.42, 0.72, 0.46)
const WARN        = Color(0.85, 0.70, 0.30)     # 受损中间态（黄）

# ── 卡牌：染色旧纸，明度统一压在 ~0.8 ──
const CARD_BASIC  = Color(0.90, 0.86, 0.77)     # 暖宣纸（基本牌）
const CARD_TRICK  = Color(0.83, 0.79, 0.85)     # 黛紫旧纸（锦囊）
const CARD_EQUIP  = Color(0.79, 0.83, 0.79)     # 旧青纸（装备）

# ── 罩层 ──
const SCRIM       = Color(0.0, 0.0, 0.0, 0.70)  # 覆盖面板半透黑罩

# ── 字体族（需在项目中放置字体文件）──
# 如果字体文件不存在，回退到默认字体
static var FONT_SERIF = null
static var FONT_SANS = null
static var _fonts_loaded: bool = false

static func _ensure_fonts() -> void:
	if _fonts_loaded:
		return
	_fonts_loaded = true
	if ResourceLoader.exists("res://assets/fonts/NotoSerifCJKsc-Bold.otf"):
		FONT_SERIF = load("res://assets/fonts/NotoSerifCJKsc-Bold.otf")
	if ResourceLoader.exists("res://assets/fonts/NotoSansCJKsc-Regular.otf"):
		FONT_SANS = load("res://assets/fonts/NotoSansCJKsc-Regular.otf")

# ── 字号 ──
const FS_TITLE = 64    # 主标题（书法体）
const FS_HEAD  = 32    # 大标题（书法体）
const FS_SUB   = 22    # 副标题/武将名（书法体）
const FS_BODY  = 18    # 正文（黑体）
const FS_SMALL = 14    # 辅助（黑体）

# ── 间距（8px 基准网格）──
const SP_XS  = 4
const SP_S   = 8
const SP_M   = 16      # 面板内边距默认
const SP_L   = 24      # 分区间距
const SP_XL  = 32
const SP_XXL = 48

# ── 圆角（中式偏方正）──
const RADIUS      = 6
const RADIUS_CARD = 6

# ── 投影 ──
const SHADOW_COLOR  = Color(0, 0, 0, 0.35)
const SHADOW_OFFSET = Vector2(0, 4)
const SHADOW_SIZE   = 6

# ── 座位号圆字 ──
const SEAT_GLYPHS = ["①","②","③","④","⑤","⑥","⑦","⑧","⑨","⑩","⑪","⑫"]


# ============================================================
# 核心样式工厂
# ============================================================

## 标准面板：填充 + 描金边 + 向下投影
static func panel_style(
	bg: Color = BG_PANEL,
	border: Color = BORDER,
	radius: int = RADIUS,
	with_shadow: bool = true
) -> StyleBoxFlat:
	_ensure_fonts()
	var sb := StyleBoxFlat.new()
	sb.bg_color = bg
	sb.set_corner_radius_all(radius)
	sb.set_border_width_all(1)
	sb.border_color = border
	sb.content_margin_left = SP_M
	sb.content_margin_right = SP_M
	sb.content_margin_top = SP_M
	sb.content_margin_bottom = SP_M
	if with_shadow:
		sb.shadow_color = SHADOW_COLOR
		sb.shadow_size = SHADOW_SIZE
		sb.shadow_offset = SHADOW_OFFSET
	return sb


## 重点面板：金边，用于结算/标题/设置
static func panel_style_gold() -> StyleBoxFlat:
	return panel_style(BG_PANEL_HI, GOLD, RADIUS, true)


## 按钮四态（accent=true → 朱砂主按钮；false → 描边次按钮）
static func style_button(btn: Button, accent: bool = false) -> void:
	_ensure_fonts()
	var normal := panel_style(BG_PANEL_HI, BORDER, RADIUS, false)
	var hover  := panel_style(BG_PANEL_HI, GOLD, RADIUS, false)
	var pressed := panel_style(ACCENT_DIM, GOLD, RADIUS, false)
	var disabled := panel_style(BG_PANEL, BORDER, RADIUS, false)

	if accent:
		normal  = panel_style(ACCENT, GOLD, RADIUS, false)
		hover   = panel_style(ACCENT.lightened(0.08), GOLD, RADIUS, false)
		pressed = panel_style(ACCENT_DIM, GOLD, RADIUS, false)

	btn.add_theme_stylebox_override("normal", normal)
	btn.add_theme_stylebox_override("hover", hover)
	btn.add_theme_stylebox_override("pressed", pressed)
	btn.add_theme_stylebox_override("disabled", disabled)
	btn.add_theme_color_override("font_color", TEXT)
	btn.add_theme_color_override("font_hover_color", GOLD if not accent else TEXT)
	btn.add_theme_color_override("font_disabled_color", TEXT_DIM)
	if FONT_SANS:
		btn.add_theme_font_override("font", FONT_SANS)
	btn.add_theme_font_size_override("font_size", FS_BODY)


## 创建标签（size >= FS_SUB 用书法体，否则黑体）
static func make_label(text: String, size: int = FS_BODY, color: Color = TEXT) -> Label:
	_ensure_fonts()
	var lb := Label.new()
	lb.text = text
	var font = FONT_SERIF if (size >= FS_SUB and FONT_SERIF != null) else FONT_SANS
	if font:
		lb.add_theme_font_override("font", font)
	lb.add_theme_font_size_override("font_size", size)
	lb.add_theme_color_override("font_color", color)
	return lb


## 创建按钮
static func make_button(text: String, accent: bool = false) -> Button:
	var btn := Button.new()
	btn.text = text
	style_button(btn, accent)
	return btn


## 创建全屏背景
static func make_bg(color: Color = BG_DEEP) -> ColorRect:
	var cr := ColorRect.new()
	cr.color = color
	cr.set_anchors_preset(Control.PRESET_FULL_RECT)
	cr.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return cr


## 创建半透明黑罩（覆盖面板用）
static func make_scrim() -> ColorRect:
	var cr := ColorRect.new()
	cr.color = SCRIM
	cr.set_anchors_preset(Control.PRESET_FULL_RECT)
	cr.mouse_filter = Control.MOUSE_FILTER_STOP
	return cr


## 创建覆盖面板骨架：SCRIM 罩 + 居中金边面板
## 返回 [scrim_control, panel_vbox]，调用方往 panel_vbox 里加内容
static func make_overlay_panel(gold: bool = true) -> Array:
	var scrim := make_scrim()
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	scrim.add_child(center)

	var panel := Panel.new()
	panel.add_theme_stylebox_override("panel", panel_style_gold() if gold else panel_style())
	panel.custom_minimum_size = Vector2(560, 0)
	center.add_child(panel)

	var margin := MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	margin.add_theme_constant_override("margin_left", SP_L)
	margin.add_theme_constant_override("margin_right", SP_L)
	margin.add_theme_constant_override("margin_top", SP_L)
	margin.add_theme_constant_override("margin_bottom", SP_L)
	panel.add_child(margin)

	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", SP_M)
	margin.add_child(vb)

	return [scrim, vb]


## 创建滑块行（设置面板用）
static func make_slider_row(label_text: String, min_val: float, max_val: float, step: float = 1.0) -> Array:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", SP_M)

	var lbl := make_label(label_text, FS_BODY, TEXT)
	lbl.custom_minimum_size = Vector2(120, 0)
	row.add_child(lbl)

	var slider := HSlider.new()
	slider.min_value = min_val
	slider.max_value = max_val
	slider.step = step
	slider.custom_minimum_size = Vector2(300, 0)
	slider.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	# 滑块样式：轨道描金，grabber 朱砂
	var slider_bg := StyleBoxFlat.new()
	slider_bg.bg_color = BORDER
	slider_bg.set_corner_radius_all(3)
	slider_bg.content_margin_top = 4
	slider_bg.content_margin_bottom = 4
	slider.add_theme_stylebox_override("slider", slider_bg)
	var grabber := StyleBoxFlat.new()
	grabber.bg_color = ACCENT
	grabber.set_corner_radius_all(6)
	grabber.set_content_margin_all(6)
	slider.add_theme_stylebox_override("grabber_area", grabber)
	row.add_child(slider)

	var val_label := make_label("0", FS_BODY, TEXT_DIM)
	val_label.custom_minimum_size = Vector2(40, 0)
	row.add_child(val_label)

	slider.value_changed.connect(func(v): val_label.text = "%d" % int(v))

	return [row, slider, val_label]


## 创建分隔符（8px 间距用）
static func make_spacer(h: int = SP_M) -> Control:
	var c := Control.new()
	c.custom_minimum_size = Vector2(0, h)
	return c
