# ============================================================
# battle_table.gd
# 对局界面：动态人数(4~12)牌桌 + 人类玩家交互（点牌/选目标/响应/弃牌）
#
# 设计：UI 全部用代码动态构建，场景只需 BattleTable 根 + GameManager 子节点。
#   - 容器化分层：顶部信息条 / 中央牌桌区 / 底部操作区（角色卡+手牌+按钮）
#   - 人类座位独立于 AI 环形布局之外，固定在底部中央
#   - 监听 GameManager 信号（初始化/回合/阶段/结束）刷新牌桌
#   - 监听 EventBus 关键事件（伤害/回血/摸弃牌/生死）刷新座位与手牌
#   - 监听 HumanController 的请求信号，驱动人类交互，操作完成后回填控制器
#
# Gemini:change.4: 新建——完整可玩对局界面
# Gemini:change.5: 改造——动态人数 + 动态人类座位 + 环形布局
# Gemini:change.11: 重构——容器化布局 + 人类座位独立 + 座位美化 + game_over 面板
# ============================================================

extends Control

# ----- 交互模式 -----
enum Mode {
	IDLE,                 ## 非人类操作时段
	PLAY_SELECT_CARD,     ## 出牌阶段：等待选手牌
	PLAY_SELECT_TARGET,   ## 已选牌，等待选目标
	DISCARD_SELECT,       ## 弃牌阶段：等待选要弃的牌
	RESPONSE,             ## 响应请求：等待打出/放弃
	CARD_PICK,            ## 选牌：从目标区域选一张（过河拆桥/顺手牵羊）
}

const CardViewScene := preload("res://scenes/cards/card_view.tscn")

# ----- 核心引用 -----
var game_manager: Node = null
var _ctx = null
var human_controller = null

# 人类座位（运行时从 game_manager.human_player_index 读取）
var _human_index: int = 0

# ----- 交互状态 -----
var _mode: int = Mode.IDLE
var _pending_card = null
var _selected_discards: Array = []
var _discard_needed: int = 0
var _response_required: String = ""

# Gemini:change.12: 多目标选择状态（方天画戟：杀可指定至多3个目标）
var _selected_targets: Array = []  # Array[int] 已选中的目标座位索引
var _max_targets: int = 1          # 当前卡牌最多可选目标数

# ----- 容器节点 -----
var _top_bar: HBoxContainer = null
var _table_area: Control = null
var _bottom_area: VBoxContainer = null

# ----- UI 节点（代码构建）-----
var _phase_label: Label = null
var _deck_label: Label = null
var _prompt_label: Label = null
var _hand_box: HBoxContainer = null
var _end_btn: Button = null
var _confirm_btn: Button = null
var _response_panel: Panel = null
var _response_prompt: Label = null
var _play_btn: Button = null
var _pass_btn: Button = null
var _seat_panels: Array = []    # AI 座位面板（不含人类）
var _human_seat_ui: Dictionary = {}   # 人类座位面板引用
var _settings_btn: Button = null
var _pause_panel: Panel = null
var _game_over_panel: Panel = null

# ----- 日志 UI -----
var _log_btn: Button = null
var _log_panel: Panel = null
var _log_rtl: RichTextLabel = null

# ----- 技能列 UI -----
var _skill_box: VBoxContainer = null
var _skill_tooltip: Panel = null
var _skill_tooltip_label: RichTextLabel = null

# ----- 选牌 UI（过河拆桥/顺手牵羊/五谷丰登）-----
var _pick_panel: Panel = null
var _pick_container: VBoxContainer = null
var _pick_available: Array = []  # 当前可选牌列表
var _pick_target_index: int = -1  # 选牌目标（用于判断暗牌）
var _pick_context: String = ""  # Gemini:change.12: 选牌上下文（用于区分转化响应等）
var _pick_convertible_map: Array = []  # Gemini:change.12: 转化技能映射

# ----- 和衷方向选择 UI -----
var _hezhong_panel: Panel = null


# ============================================================
# 生命周期
# ============================================================

func _ready() -> void:
	game_manager = $GameManager
	_build_ui()
	_connect_event_bus()

	game_manager.game_initialized.connect(_on_game_initialized)
	game_manager.round_started.connect(_on_round_started)
	game_manager.phase_changed.connect(_on_phase_changed)
	game_manager.game_over.connect(_on_game_over)

	await get_tree().process_frame

	# 从 GameSetup 读取开局配置（人数 + 人类武将 + 明身份）
	var count: int = 4
	var hero_id: String = ""
	var reveal: bool = false
	var gs = get_node_or_null("/root/GameSetup")
	if gs != null:
		count = gs.player_count
		hero_id = gs.human_hero_id
		reveal = gs.reveal_identity
	game_manager.configure_match(count, hero_id, true, reveal)

	# 修死锁：先 setup（建好控制器与玩家），连接人类请求信号，再 begin。
	game_manager.setup_game()

	# 防御性检查：setup_game 可能因数据加载失败而导致 context 为空
	if game_manager.context == null:
		push_error("[BattleTable] setup_game 失败：context 为 null，无法开始游戏")
		_set_prompt("游戏初始化失败，请检查数据文件并重启")
		return

	_ctx = game_manager.context
	_human_index = game_manager.human_player_index
	human_controller = game_manager.human_controller

	# 先创建人类座位（不依赖布局尺寸），再创建 AI 座位（需要 _table_area 尺寸）
	_build_human_seat()
	_build_seats(_ctx.players.size())

	if human_controller != null:
		human_controller.play_requested.connect(_on_play_requested)
		human_controller.response_requested.connect(_on_response_requested)
		human_controller.discard_requested.connect(_on_discard_requested)
		human_controller.card_pick_requested.connect(_on_card_pick_requested)
		human_controller.hezhong_direction_requested.connect(_on_hezhong_direction_requested)

	# Gemini:change.9: 连接日志回调
	if game_manager.logger != null:
		game_manager.logger.on_log_added = _on_log_entry_added

	_refresh_all()

	# 开始战斗动画
	AnimHelper.center_announce(self, "开 始 战 斗 ！", 1.5)

	# 延迟后开始游戏
	AnimHelper.delayed_call(self, 1.2, func(): game_manager.begin_game())


# ============================================================
# UI 构建（容器化分层布局）
# ============================================================

func _build_ui() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(UITheme.make_bg(UITheme.BG_DEEP))

	# --- 根容器：MarginContainer（全屏，内边距 12）---
	var root_margin := MarginContainer.new()
	root_margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	root_margin.add_theme_constant_override("margin_left", 12)
	root_margin.add_theme_constant_override("margin_right", 12)
	root_margin.add_theme_constant_override("margin_top", 8)
	root_margin.add_theme_constant_override("margin_bottom", 8)
	add_child(root_margin)

	var root_vbox := VBoxContainer.new()
	root_vbox.set_anchors_preset(Control.PRESET_FULL_RECT)
	root_vbox.add_theme_constant_override("separation", 6)
	root_margin.add_child(root_vbox)

	# --- 顶部信息条（深石板面板 + 描金边）---
	_top_bar = HBoxContainer.new()
	_top_bar.custom_minimum_size.y = 48
	_top_bar.add_theme_constant_override("separation", UITheme.SP_M)
	_top_bar.add_theme_stylebox_override("panel", UITheme.panel_style(UITheme.BG_PANEL, UITheme.BORDER, UITheme.RADIUS, false))
	root_vbox.add_child(_top_bar)

	_phase_label = UITheme.make_label("准备中...", UITheme.FS_BODY, UITheme.GOLD)
	_phase_label.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	_top_bar.add_child(_phase_label)

	# 占位 spacer（把右侧元素推到右边）
	var spacer := Control.new()
	spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_top_bar.add_child(spacer)

	_log_btn = UITheme.make_button("📋 日志")
	_log_btn.custom_minimum_size = Vector2(80, 0)
	_log_btn.pressed.connect(_on_log_toggle)
	_top_bar.add_child(_log_btn)

	_deck_label = UITheme.make_label("牌堆: -", UITheme.FS_BODY, UITheme.TEXT)
	_deck_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_top_bar.add_child(_deck_label)

	_settings_btn = UITheme.make_button("⚙ 设置")
	_settings_btn.custom_minimum_size = Vector2(100, 0)
	_settings_btn.pressed.connect(_on_open_pause)
	_top_bar.add_child(_settings_btn)

	# --- 中央牌桌区（expand 填充中间空间）---
	_table_area = Control.new()
	_table_area.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_table_area.clip_contents = true
	root_vbox.add_child(_table_area)

	# 提示药丸（锚定在牌桌区顶部居中，半透深底 + 描金边）
	_prompt_label = UITheme.make_label("", UITheme.FS_BODY, UITheme.GOLD)
	_prompt_label.anchor_left = 0.5
	_prompt_label.anchor_right = 0.5
	_prompt_label.anchor_top = 0.0
	_prompt_label.offset_left = -300.0
	_prompt_label.offset_right = 300.0
	_prompt_label.offset_top = 4.0
	_prompt_label.offset_bottom = 30.0
	_prompt_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	var pill_sb := UITheme.panel_style(Color(0.08, 0.075, 0.085, 0.85), UITheme.BORDER, 15, false)
	_prompt_label.add_theme_stylebox_override("normal", pill_sb)
	_table_area.add_child(_prompt_label)

	# --- 底部操作区 ---
	_bottom_area = VBoxContainer.new()
	_bottom_area.custom_minimum_size.y = 240
	_bottom_area.add_theme_constant_override("separation", 4)
	root_vbox.add_child(_bottom_area)

	# 手牌 + 按钮行（横向排列：手牌区 expand | 按钮固定宽）
	var hand_row := HBoxContainer.new()
	hand_row.size_flags_vertical = Control.SIZE_EXPAND_FILL
	hand_row.add_theme_constant_override("separation", 8)
	_bottom_area.add_child(hand_row)

	# 技能列（手牌区左侧，固定宽，竖排按钮）
	_skill_box = VBoxContainer.new()
	_skill_box.custom_minimum_size = Vector2(110, 0)
	_skill_box.add_theme_constant_override("separation", 6)
	_skill_box.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_skill_box.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	hand_row.add_child(_skill_box)

	# 手牌滚动区（expand 占满中间）
	var hand_scroll := ScrollContainer.new()
	hand_scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hand_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	hand_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	hand_row.add_child(hand_scroll)

	_hand_box = HBoxContainer.new()
	_hand_box.add_theme_constant_override("separation", 8)
	hand_scroll.add_child(_hand_box)

	# 操作按钮区（固定宽，竖排）
	var action_vbox := VBoxContainer.new()
	action_vbox.custom_minimum_size = Vector2(130, 0)
	action_vbox.add_theme_constant_override("separation", 8)
	action_vbox.alignment = BoxContainer.ALIGNMENT_CENTER
	hand_row.add_child(action_vbox)

	_end_btn = UITheme.make_button("结束出牌", true)
	_end_btn.custom_minimum_size.y = 40
	_end_btn.visible = false
	_end_btn.pressed.connect(_on_end_pressed)
	action_vbox.add_child(_end_btn)

	_confirm_btn = UITheme.make_button("确认", true)
	_confirm_btn.custom_minimum_size.y = 40
	_confirm_btn.visible = false
	_confirm_btn.pressed.connect(_on_confirm_pressed)
	action_vbox.add_child(_confirm_btn)

	_build_response_panel()
	_build_pause_panel()
	_build_game_over_panel()
	_build_log_panel()
	_build_pick_panel()
	_build_hezhong_panel()
	_build_skill_tooltip()


# --- 响应面板（出闪/出杀/出桃 时弹出）---
func _build_response_panel() -> void:
	_response_panel = Panel.new()
	_response_panel.add_theme_stylebox_override("panel", UITheme.panel_style(UITheme.BG_PANEL_HI))
	_response_panel.anchor_left = 0.5
	_response_panel.anchor_right = 0.5
	_response_panel.anchor_top = 0.5
	_response_panel.anchor_bottom = 0.5
	_response_panel.offset_left = -220.0
	_response_panel.offset_right = 220.0
	_response_panel.offset_top = -100.0
	_response_panel.offset_bottom = 80.0
	_response_panel.visible = false
	add_child(_response_panel)

	var rp_margin := MarginContainer.new()
	rp_margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	rp_margin.add_theme_constant_override("margin_left", 16)
	rp_margin.add_theme_constant_override("margin_right", 16)
	rp_margin.add_theme_constant_override("margin_top", 12)
	rp_margin.add_theme_constant_override("margin_bottom", 12)
	_response_panel.add_child(rp_margin)

	var rp_vb := VBoxContainer.new()
	rp_vb.set_anchors_preset(Control.PRESET_FULL_RECT)
	rp_vb.add_theme_constant_override("separation", 12)
	rp_vb.alignment = BoxContainer.ALIGNMENT_CENTER
	rp_margin.add_child(rp_vb)

	_response_prompt = UITheme.make_label("", UITheme.FS_SUB, UITheme.TEXT)
	_response_prompt.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_response_prompt.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_response_prompt.custom_minimum_size.y = 50
	rp_vb.add_child(_response_prompt)

	var btn_row := HBoxContainer.new()
	btn_row.add_theme_constant_override("separation", 12)
	btn_row.alignment = BoxContainer.ALIGNMENT_CENTER
	rp_vb.add_child(btn_row)

	_play_btn = UITheme.make_button("打出", true)
	_play_btn.custom_minimum_size = Vector2(100, 40)
	_play_btn.pressed.connect(_on_response_play_pressed)
	btn_row.add_child(_play_btn)

	_pass_btn = UITheme.make_button("跳过")
	_pass_btn.custom_minimum_size = Vector2(100, 40)
	_pass_btn.pressed.connect(_on_response_pass_pressed)
	btn_row.add_child(_pass_btn)

	# 无懈可击专用：对所有人不使用无懈可击
	var skip_all_btn := UITheme.make_button("全部跳过")
	skip_all_btn.custom_minimum_size = Vector2(120, 40)
	skip_all_btn.name = "SkipAllBtn"
	skip_all_btn.pressed.connect(_on_response_skip_all_pressed)
	btn_row.add_child(skip_all_btn)


# --- 暂停面板 ---
func _build_pause_panel() -> void:
	_pause_panel = Panel.new()
	_pause_panel.add_theme_stylebox_override("panel", UITheme.panel_style(UITheme.BG_PANEL_HI))
	_pause_panel.anchor_left = 0.5
	_pause_panel.anchor_right = 0.5
	_pause_panel.anchor_top = 0.5
	_pause_panel.anchor_bottom = 0.5
	_pause_panel.offset_left = -200.0
	_pause_panel.offset_right = 200.0
	_pause_panel.offset_top = -160.0
	_pause_panel.offset_bottom = 160.0
	_pause_panel.visible = false
	add_child(_pause_panel)

	var vb := VBoxContainer.new()
	vb.set_anchors_preset(Control.PRESET_FULL_RECT)
	vb.alignment = BoxContainer.ALIGNMENT_CENTER
	vb.add_theme_constant_override("separation", 18)
	vb.offset_left = 24
	vb.offset_right = -24
	_pause_panel.add_child(vb)

	var title := UITheme.make_label("暂停", UITheme.FS_HEAD, UITheme.ACCENT)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(title)

	_pause_slider(vb, "主音量", "master")
	_pause_slider(vb, "音乐", "bgm")
	_pause_slider(vb, "音效", "sfx")
	_pause_slider(vb, "AI速度", "ai_speed")

	var btn_resume := UITheme.make_button("继续游戏", true)
	btn_resume.custom_minimum_size = Vector2(0, 48)
	btn_resume.pressed.connect(_on_close_pause)
	vb.add_child(btn_resume)

	var btn_menu := UITheme.make_button("返回主菜单")
	btn_menu.custom_minimum_size = Vector2(0, 44)
	btn_menu.pressed.connect(func(): get_tree().change_scene_to_file("res://scenes/ui/main_menu.tscn"))
	vb.add_child(btn_menu)


func _pause_slider(parent: VBoxContainer, label_text: String, kind: String) -> HSlider:
	var sm = get_node_or_null("/root/SettingsManager")
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	parent.add_child(row)
	var lbl := UITheme.make_label(label_text, UITheme.FS_BODY, UITheme.TEXT)
	lbl.custom_minimum_size = Vector2(80, 0)
	row.add_child(lbl)
	var slider := HSlider.new()
	slider.min_value = 0
	slider.max_value = 100
	slider.custom_minimum_size = Vector2(240, 0)
	slider.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	if sm != null:
		if kind == "master":
			slider.value = sm.master_volume * 100.0
		elif kind == "bgm":
			slider.value = sm.bgm_volume * 100.0
		elif kind == "sfx":
			slider.value = sm.sfx_volume * 100.0
		elif kind == "ai_speed":
			slider.value = sm.ai_play_delay / 3.0 * 100.0
	slider.value_changed.connect(_on_volume_changed.bind(kind))
	row.add_child(slider)
	return slider


func _on_volume_changed(v: float, kind: String) -> void:
	var sm = get_node_or_null("/root/SettingsManager")
	if sm == null:
		return
	if kind == "master":
		sm.set_master_volume(v / 100.0)
	elif kind == "bgm":
		sm.set_bgm_volume(v / 100.0)
	elif kind == "sfx":
		sm.set_sfx_volume(v / 100.0)
	elif kind == "ai_speed":
		sm.set_ai_play_delay(v / 100.0 * 3.0)


func _on_open_pause() -> void:
	_pause_panel.visible = true


func _on_close_pause() -> void:
	_pause_panel.visible = false
	var sm = get_node_or_null("/root/SettingsManager")
	if sm != null:
		sm.save_settings()


# --- Game Over 面板 ---
func _build_game_over_panel() -> void:
	_game_over_panel = Panel.new()
	_game_over_panel.add_theme_stylebox_override("panel", UITheme.panel_style(UITheme.BG_PANEL_HI))
	_game_over_panel.anchor_left = 0.5
	_game_over_panel.anchor_right = 0.5
	_game_over_panel.anchor_top = 0.5
	_game_over_panel.anchor_bottom = 0.5
	_game_over_panel.offset_left = -240.0
	_game_over_panel.offset_right = 240.0
	_game_over_panel.offset_top = -120.0
	_game_over_panel.offset_bottom = 120.0
	_game_over_panel.visible = false
	add_child(_game_over_panel)

	var vb := VBoxContainer.new()
	vb.set_anchors_preset(Control.PRESET_FULL_RECT)
	vb.alignment = BoxContainer.ALIGNMENT_CENTER
	vb.add_theme_constant_override("separation", 16)
	vb.offset_left = 24
	vb.offset_right = -24
	_game_over_panel.add_child(vb)

	var go_title := UITheme.make_label("游戏结束", UITheme.FS_HEAD, UITheme.ACCENT)
	go_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	go_title.name = "TitleLabel"
	vb.add_child(go_title)

	var go_detail := UITheme.make_label("", UITheme.FS_SUB, UITheme.TEXT)
	go_detail.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	go_detail.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	go_detail.custom_minimum_size = Vector2(300, 0)
	go_detail.name = "DetailLabel"
	vb.add_child(go_detail)

	var btn_restart := UITheme.make_button("再来一局", true)
	btn_restart.custom_minimum_size = Vector2(200, 48)
	btn_restart.pressed.connect(func(): get_tree().change_scene_to_file("res://scenes/game/battle_table.tscn"))
	vb.add_child(btn_restart)

	var btn_menu := UITheme.make_button("返回主菜单")
	btn_menu.custom_minimum_size = Vector2(200, 44)
	btn_menu.pressed.connect(func(): get_tree().change_scene_to_file("res://scenes/ui/main_menu.tscn"))
	vb.add_child(btn_menu)


# --- 日志面板 ---
func _build_log_panel() -> void:
	_log_panel = Panel.new()
	_log_panel.add_theme_stylebox_override("panel", UITheme.panel_style(UITheme.BG_PANEL_HI))
	_log_panel.anchor_left = 0.0
	_log_panel.anchor_right = 0.45
	_log_panel.anchor_top = 0.0
	_log_panel.anchor_bottom = 0.7
	_log_panel.visible = false
	add_child(_log_panel)

	var log_margin := MarginContainer.new()
	log_margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	log_margin.add_theme_constant_override("margin_left", 8)
	log_margin.add_theme_constant_override("margin_right", 8)
	log_margin.add_theme_constant_override("margin_top", 8)
	log_margin.add_theme_constant_override("margin_bottom", 8)
	_log_panel.add_child(log_margin)

	var vb := VBoxContainer.new()
	vb.set_anchors_preset(Control.PRESET_FULL_RECT)
	vb.add_theme_constant_override("separation", 6)
	log_margin.add_child(vb)

	var header := HBoxContainer.new()
	vb.add_child(header)

	var title := UITheme.make_label("📋 对局日志", UITheme.FS_SUB, UITheme.ACCENT)
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	header.add_child(title)

	var close_btn := UITheme.make_button("✕")
	close_btn.custom_minimum_size = Vector2(36, 28)
	close_btn.pressed.connect(func(): _log_panel.visible = false)
	header.add_child(close_btn)

	_log_rtl = RichTextLabel.new()
	_log_rtl.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_log_rtl.bbcode_enabled = true
	_log_rtl.scroll_following = true
	_log_rtl.selection_enabled = true
	_log_rtl.add_theme_font_size_override("normal_font_size", 14)
	_log_rtl.add_theme_color_override("default_color", UITheme.TEXT)
	vb.add_child(_log_rtl)


func _on_log_toggle() -> void:
	if _log_panel == null:
		return
	_log_panel.visible = not _log_panel.visible


## 日志追加回调（由 BattleLogger 调用）
func _on_log_entry_added(text: String) -> void:
	if _log_rtl == null:
		return
	_log_rtl.append_text(text + "\n")


# --- 选牌面板（过河拆桥/顺手牵羊/五谷丰登）---
func _build_pick_panel() -> void:
	_pick_panel = Panel.new()
	_pick_panel.add_theme_stylebox_override("panel", UITheme.panel_style(UITheme.BG_PANEL_HI))
	_pick_panel.anchor_left = 0.5
	_pick_panel.anchor_right = 0.5
	_pick_panel.anchor_top = 0.5
	_pick_panel.anchor_bottom = 0.5
	_pick_panel.offset_left = -320.0
	_pick_panel.offset_right = 320.0
	_pick_panel.offset_top = -220.0
	_pick_panel.offset_bottom = 220.0
	_pick_panel.visible = false
	add_child(_pick_panel)

	var pick_margin := MarginContainer.new()
	pick_margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	pick_margin.add_theme_constant_override("margin_left", 12)
	pick_margin.add_theme_constant_override("margin_right", 12)
	pick_margin.add_theme_constant_override("margin_top", 10)
	pick_margin.add_theme_constant_override("margin_bottom", 10)
	_pick_panel.add_child(pick_margin)

	var vb := VBoxContainer.new()
	vb.set_anchors_preset(Control.PRESET_FULL_RECT)
	vb.add_theme_constant_override("separation", 8)
	pick_margin.add_child(vb)

	var title := UITheme.make_label("选择一张牌", UITheme.FS_SUB, UITheme.ACCENT)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(title)

	# 可滚动的选牌区域
	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	vb.add_child(scroll)

	_pick_container = VBoxContainer.new()
	_pick_container.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_pick_container.add_theme_constant_override("separation", 4)
	scroll.add_child(_pick_container)


## 显示选牌面板（带分区标签）
func _show_pick_panel(available_cards: Array, _pick_context: String) -> void:
	_pick_available = available_cards

	# 清空旧内容
	for child in _pick_container.get_children():
		child.queue_free()

	# 判断目标是谁（从 pick_context 或当前响应目标推断）
	# 对于过河拆桥/顺手牵羊，牌来自目标（对手）；对于五谷丰登，牌来自公共区域
	var target_player = _ctx.get_player(_pick_target_index) if _pick_target_index >= 0 else null
	var human = _ctx.get_player(_human_index)

	# 按区域分组
	var hand_cards: Array = []      # 目标手牌（对手的=暗牌）
	var my_hand_cards: Array = []   # 自己手牌（五谷丰登等场景）
	var equip_cards: Array = []
	var judge_cards: Array = []

	for card in available_cards:
		# 检查是否在自己的手牌中
		if human != null and card in human.hand_cards:
			my_hand_cards.append(card)
		# 检查是否在目标的装备区
		elif target_player != null and (card == target_player.equip_weapon or card == target_player.equip_armor \
				or card == target_player.equip_horse_def or card == target_player.equip_horse_atk \
				or card == target_player.equip_treasure):
			equip_cards.append(card)
		# 检查是否在目标的判定区
		elif target_player != null and card in target_player.judge_cards:
			judge_cards.append(card)
		else:
			# 对方手牌（暗牌）
			hand_cards.append(card)

	# 添加分区标题和卡牌按钮
	if not hand_cards.is_empty():
		_add_pick_section("手牌（暗牌）", hand_cards, true)  # true = 暗牌
	if not my_hand_cards.is_empty():
		_add_pick_section("手牌", my_hand_cards, false)
	if not equip_cards.is_empty():
		_add_pick_section("装备区", equip_cards, false)
	if not judge_cards.is_empty():
		_add_pick_section("判定区", judge_cards, false)

	_pick_panel.visible = true
	AnimHelper.pop_in(_pick_panel, 0.25)


func _add_pick_section(section_name: String, cards: Array, face_down: bool = false) -> void:
	var label := UITheme.make_label("【%s】" % section_name, UITheme.FS_SMALL, UITheme.TEXT_DIM)
	_pick_container.add_child(label)

	for card in cards:
		var btn := Button.new()
		if face_down:
			# 暗牌：不显示牌名
			btn.text = "？ 暗牌"
			btn.custom_minimum_size = Vector2(0, 36)
			UITheme.style_button(btn)
			btn.add_theme_color_override("font_color", Color(0.6, 0.6, 0.65))
			btn.add_theme_color_override("font_hover_color", UITheme.ACCENT)
		else:
			btn.text = card.get_full_display_name()
			btn.custom_minimum_size = Vector2(0, 36)
			UITheme.style_button(btn)
			if card.is_red():
				btn.add_theme_color_override("font_color", Color(0.95, 0.35, 0.35))
				btn.add_theme_color_override("font_hover_color", Color(1.0, 0.5, 0.5))
			else:
				btn.add_theme_color_override("font_color", Color(0.70, 0.74, 0.82))
				btn.add_theme_color_override("font_hover_color", UITheme.ACCENT)
		btn.pressed.connect(_on_pick_card_selected.bind(card))
		_pick_container.add_child(btn)


func _on_pick_card_selected(card: CardData) -> void:
	_pick_panel.visible = false
	_mode = Mode.IDLE
	_set_prompt("")
	# Gemini:change.12: 转化响应选牌——走 response 通道而非 card_pick 通道
	if _pick_context == "convert_response":
		var virtual_card = null
		for conv in _pick_convertible_map:
			if conv.get("card") == card:
				var sk = conv.get("skill")
				if sk != null:
					virtual_card = sk.create_virtual_card(_response_required)
				break
		if virtual_card != null:
			_submit_response_converted(virtual_card, card)
		else:
			# 兜底：直接提交
			_submit_response(true, card)
		_pick_context = ""
		_pick_convertible_map.clear()
		return
	if human_controller:
		human_controller.submit_card_pick(card)
	_pick_context = ""
	_refresh_hand()
	_refresh_seats()


# --- 和衷方向选择面板 ---
func _build_hezhong_panel() -> void:
	_hezhong_panel = Panel.new()
	_hezhong_panel.add_theme_stylebox_override("panel", UITheme.panel_style(UITheme.BG_PANEL_HI))
	_hezhong_panel.anchor_left = 0.5
	_hezhong_panel.anchor_right = 0.5
	_hezhong_panel.anchor_top = 0.5
	_hezhong_panel.anchor_bottom = 0.5
	_hezhong_panel.offset_left = -220.0
	_hezhong_panel.offset_right = 220.0
	_hezhong_panel.offset_top = -80.0
	_hezhong_panel.offset_bottom = 80.0
	_hezhong_panel.visible = false
	add_child(_hezhong_panel)

	var hz_margin := MarginContainer.new()
	hz_margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	hz_margin.add_theme_constant_override("margin_left", 16)
	hz_margin.add_theme_constant_override("margin_right", 16)
	hz_margin.add_theme_constant_override("margin_top", 12)
	hz_margin.add_theme_constant_override("margin_bottom", 12)
	_hezhong_panel.add_child(hz_margin)

	var vb := VBoxContainer.new()
	vb.set_anchors_preset(Control.PRESET_FULL_RECT)
	vb.add_theme_constant_override("separation", 12)
	vb.alignment = BoxContainer.ALIGNMENT_CENTER
	hz_margin.add_child(vb)

	var title := UITheme.make_label("和衷：选择条件", UITheme.FS_SUB, UITheme.ACCENT)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(title)

	var hint := UITheme.make_label("", UITheme.FS_BODY, UITheme.TEXT)
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hint.name = "HezhongHint"
	vb.add_child(hint)

	var btn_row := HBoxContainer.new()
	btn_row.add_theme_constant_override("separation", 20)
	btn_row.alignment = BoxContainer.ALIGNMENT_CENTER
	vb.add_child(btn_row)

	var btn_greater := UITheme.make_button("大于 ▲", true)
	btn_greater.custom_minimum_size = Vector2(140, 40)
	btn_greater.name = "BtnGreater"
	btn_greater.pressed.connect(_on_hezhong_choice.bind("greater"))
	btn_row.add_child(btn_greater)

	var btn_less := UITheme.make_button("小于 ▼", true)
	btn_less.custom_minimum_size = Vector2(140, 40)
	btn_less.name = "BtnLess"
	btn_less.pressed.connect(_on_hezhong_choice.bind("less"))
	btn_row.add_child(btn_less)


func _on_hezhong_direction_requested(_player_index: int, rank: int) -> void:
	# 更新提示文字
	var hint = _hezhong_panel.find_child("HezhongHint", true, false)
	if hint:
		hint.text = "你展示的牌点数为 %d\n选择下次锦囊的点数条件：" % rank
	_hezhong_panel.visible = true
	AnimHelper.pop_in(_hezhong_panel, 0.25)


func _on_hezhong_choice(direction: String) -> void:
	_hezhong_panel.visible = false
	if human_controller:
		human_controller.submit_hezhong_direction(direction)


# --- 技能列 + Tooltip ---
func _build_skill_tooltip() -> void:
	_skill_tooltip = Panel.new()
	_skill_tooltip.add_theme_stylebox_override("panel", UITheme.panel_style(UITheme.BG_PANEL_HI, UITheme.ACCENT))
	_skill_tooltip.custom_minimum_size = Vector2(260, 0)
	_skill_tooltip.visible = false
	_skill_tooltip.z_index = 100
	add_child(_skill_tooltip)

	var margin := MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	margin.add_theme_constant_override("margin_left", 10)
	margin.add_theme_constant_override("margin_right", 10)
	margin.add_theme_constant_override("margin_top", 8)
	margin.add_theme_constant_override("margin_bottom", 8)
	_skill_tooltip.add_child(margin)

	_skill_tooltip_label = RichTextLabel.new()
	_skill_tooltip_label.bbcode_enabled = true
	_skill_tooltip_label.fit_content = true
	_skill_tooltip_label.scroll_active = false
	_skill_tooltip_label.add_theme_font_size_override("normal_font_size", 14)
	_skill_tooltip_label.add_theme_color_override("default_color", UITheme.TEXT)
	margin.add_child(_skill_tooltip_label)


func _refresh_skills() -> void:
	if _skill_box == null:
		return
	for child in _skill_box.get_children():
		child.queue_free()

	if _ctx == null:
		return
	var player = _ctx.get_player(_human_index)
	if player == null or not player.is_alive:
		return

	# 标题
	var title := UITheme.make_label("技能", UITheme.FS_SMALL, UITheme.ACCENT)
	_skill_box.add_child(title)

	# 显示所有技能
	for sk in player.skills:
		if sk == null or sk.skill_data == null:
			continue

		var sd = sk.skill_data
		var is_active: bool = (sd.skill_type == SkillData.SkillType.ACTIVE)
		var is_compulsory: bool = (sd.skill_type == SkillData.SkillType.COMPULSORY)
		var is_passive: bool = (sd.skill_type == SkillData.SkillType.PASSIVE)
		var is_trigger: bool = (sd.skill_type == SkillData.SkillType.TRIGGER)

		# 类型标签
		var type_tag := ""
		if is_active:
			type_tag = "⟳"
		elif is_compulsory:
			type_tag = "锁定"
		elif is_passive:
			type_tag = "被动"
		elif is_trigger:
			type_tag = "触发"

		var btn := Button.new()
		var btn_text: String = sd.skill_name
		if type_tag != "":
			btn_text = "[%s] %s" % [type_tag, sd.skill_name]

		# 主动技显示剩余次数
		if is_active and sd.use_limit_per_turn > 0:
			var remaining: int = sd.use_limit_per_turn - sk._used_count_this_turn
			btn_text += " (%d)" % remaining

		btn.text = btn_text
		btn.custom_minimum_size = Vector2(100, 34)
		btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL

		# 主动技可点击，其他类型仅展示
		if is_active:
			var can_use: bool = sk.can_activate()
			btn.disabled = not can_use
			if can_use:
				UITheme.style_button(btn, true)
			else:
				UITheme.style_button(btn, false)
				btn.modulate = Color(0.45, 0.45, 0.5, 0.6)
			btn.pressed.connect(_on_skill_button_pressed.bind(sk))
		else:
			# 非主动技：只读展示
			UITheme.style_button(btn, false)
			btn.disabled = true
			btn.modulate = Color(0.6, 0.6, 0.65, 0.8)

		# 悬停显示 Tooltip
		btn.mouse_entered.connect(_show_skill_tooltip.bind(sk, btn))
		btn.mouse_exited.connect(func(): if _skill_tooltip: _skill_tooltip.visible = false)

		_skill_box.add_child(btn)

	# 如果没有技能
	if player.skills.is_empty():
		var lbl := UITheme.make_label("无技能", UITheme.FS_SMALL, UITheme.TEXT_DIM)
		_skill_box.add_child(lbl)


func _show_skill_tooltip(skill, btn: Button) -> void:
	if _skill_tooltip == null or _skill_tooltip_label == null:
		return
	var sd = skill.skill_data
	if sd == null:
		return
	var skill_name: String = sd.skill_name
	var desc: String = sd.description if sd.description != "" else "（无描述）"

	# 类型
	var type_text := ""
	match sd.skill_type:
		SkillData.SkillType.ACTIVE: type_text = "主动技"
		SkillData.SkillType.TRIGGER: type_text = "触发技"
		SkillData.SkillType.COMPULSORY: type_text = "锁定技"
		SkillData.SkillType.PASSIVE: type_text = "被动技"
		SkillData.SkillType.AWAKEN: type_text = "觉醒技"

	var tip_text := "[b]%s[/b] [color=gold]%s[/color]" % [skill_name, type_text]
	tip_text += "\n%s" % desc

	# 显示剩余次数
	if sd.use_limit_per_turn > 0:
		var remaining: int = sd.use_limit_per_turn - skill._used_count_this_turn
		tip_text += "\n[color=gray]剩余次数: %d/%d[/color]" % [remaining, sd.use_limit_per_turn]

	_skill_tooltip_label.text = tip_text
	_skill_tooltip.visible = true

	# 定位到按钮左侧
	var btn_pos = btn.global_position
	_skill_tooltip.global_position = Vector2(btn_pos.x - _skill_tooltip.custom_minimum_size.x - 8, btn_pos.y)


func _on_skill_button_pressed(skill) -> void:
	if skill == null or not skill.can_activate():
		return

	# 检查是否需要选目标
	var targets: Array = []
	if skill.has_method("get_active_targets"):
		targets = skill.get_active_targets()

	if skill.skill_data.active_need_target and targets.is_empty():
		# 需要目标但无合法目标
		_set_prompt("【%s】没有合法目标" % skill.skill_data.skill_name)
		return

	# 提交技能发动意图
	var intent = PlayIntent.activate_skill(_human_index, skill, targets)
	_mode = Mode.IDLE
	_set_prompt("")
	human_controller.submit_play(intent)


# ============================================================
# 座位面板（顺时针环形布局 + 人类独立底部）
# ============================================================

## 创建座位面板（顺时针分布在 _table_area 中，不含人类）
func _build_seats(n: int) -> void:
	for ui in _seat_panels:
		if ui != null and is_instance_valid(ui["panel"]):
			ui["panel"].queue_free()
	_seat_panels.clear()
	_seat_panels.resize(n)

	await get_tree().process_frame
	var area_size := _table_area.size
	if area_size.x < 100:
		area_size = Vector2(1280, 380)

	var pw := 172.0
	var ph := 120.0
	var margin := 16.0

	# 顺时针排列所有非人类座位
	for seat in range(n):
		if seat == _human_index:
			continue
		var pos := _clockwise_seat_position(seat, n, _human_index, area_size, Vector2(pw, ph), margin)
		var ui := _make_seat_panel(pos, Vector2(pw, ph), seat)
		_table_area.add_child(ui["panel"])
		_seat_panels[seat] = ui


## 顺时针座位位置计算
## 从人类座位的下一位开始，沿 顶边(左→右) → 右边(上→下) → 底边(右→左) → 左边(下→上) 排列
func _clockwise_seat_position(seat_idx: int, total: int, human_idx: int, area_size: Vector2, panel_size: Vector2, margin: float) -> Vector2:
	# 计算该座位在顺时针序列中的位置（从人类下一位开始）
	var clockwise_order := _get_clockwise_order(total, human_idx)
	var ring_pos: int = -1
	for i in range(clockwise_order.size()):
		if clockwise_order[i] == seat_idx:
			ring_pos = i
			break
	if ring_pos == -1:
		return Vector2(margin, margin)

	var total_ai: int = total - 1
	if total_ai <= 0:
		return Vector2(area_size.x / 2 - panel_size.x / 2, margin)

	# 四条边的可用区域
	var left := margin
	var right := area_size.x - panel_size.x - margin
	var top := 40.0
	var bottom := area_size.y - panel_size.y - margin

	var rect_w := right - left
	var rect_h := bottom - top
	var perimeter := 2.0 * (rect_w + rect_h)

	# 每条边分配的座位数（按比例）
	# 顶边和底边较长，分配更多座位；左右侧较少
	var top_ratio := rect_w / perimeter
	var right_ratio := rect_h / perimeter
	var bottom_ratio := rect_w / perimeter

	# 为每条边分配座位数
	var top_count := maxi(1, roundi(float(total_ai) * top_ratio))
	var right_count := maxi(1, roundi(float(total_ai) * right_ratio))
	var bottom_count := maxi(1, roundi(float(total_ai) * bottom_ratio))
	var left_count := total_ai - top_count - right_count - bottom_count
	if left_count < 1:
		left_count = 1
		# 从最长的边借
		if top_count >= right_count and top_count >= bottom_count:
			top_count = total_ai - right_count - bottom_count - left_count
		elif right_count >= bottom_count:
			right_count = total_ai - top_count - bottom_count - left_count
		else:
			bottom_count = total_ai - top_count - right_count - left_count

	# 计算座位在环上的 t 值（0~1，从顶边左端开始顺时针）
	var t: float = float(ring_pos) / float(total_ai)

	# 根据 t 值确定在哪条边上
	var top_end := float(top_count) / float(total_ai)
	var right_end := top_end + float(right_count) / float(total_ai)
	var bottom_end := right_end + float(bottom_count) / float(total_ai)

	var x: float
	var y: float

	if t < top_end:
		# 顶边：从左到右
		var k := t / top_end if top_end > 0 else 0.0
		x = lerp(left, right, k)
		y = top
	elif t < right_end:
		# 右边：从上到下
		var k := (t - top_end) / (right_end - top_end) if (right_end - top_end) > 0 else 0.0
		x = right
		y = lerp(top, bottom, k)
	elif t < bottom_end:
		# 底边：从右到左（人类在底部中央，所以底边座位从右往左排，跳过中央）
		var k := (t - right_end) / (bottom_end - right_end) if (bottom_end - right_end) > 0 else 0.0
		x = lerp(right, left, k)
		y = bottom
	else:
		# 左边：从下到上
		var k := (t - bottom_end) / (1.0 - bottom_end) if (1.0 - bottom_end) > 0 else 0.0
		x = left
		y = lerp(bottom, top, k)

	return Vector2(x, y)


## 获取顺时针座位顺序（从人类下一位开始）
func _get_clockwise_order(total: int, human_idx: int) -> Array:
	var order: Array = []
	for i in range(1, total):
		var seat: int = (human_idx + i) % total
		order.append(seat)
	return order


## 创建人类座位面板（底部水平卡片，独立于环形布局）
func _build_human_seat() -> void:
	var p = _ctx.get_player(_human_index)
	if p == null:
		return
	var pw := 360.0
	var ph := 80.0

	# 人类座位挂在 _bottom_area 最上方
	var panel := Panel.new()
	panel.custom_minimum_size = Vector2(0, ph)
	panel.add_theme_stylebox_override("panel", UITheme.panel_style(UITheme.BG_PANEL))
	_bottom_area.add_child(panel)
	_bottom_area.move_child(panel, 0)  # 确保在手牌区上方

	var seat_margin := MarginContainer.new()
	seat_margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	seat_margin.add_theme_constant_override("margin_left", 12)
	seat_margin.add_theme_constant_override("margin_right", 12)
	seat_margin.add_theme_constant_override("margin_top", 6)
	seat_margin.add_theme_constant_override("margin_bottom", 6)
	panel.add_child(seat_margin)

	var hbox := HBoxContainer.new()
	hbox.set_anchors_preset(Control.PRESET_FULL_RECT)
	hbox.add_theme_constant_override("separation", 16)
	seat_margin.add_child(hbox)

	var seat_num_lbl := UITheme.make_label("", UITheme.FS_BODY, UITheme.ACCENT)
	seat_num_lbl.custom_minimum_size = Vector2(50, 0)
	hbox.add_child(seat_num_lbl)

	var name_lbl := UITheme.make_label("", UITheme.FS_BODY, UITheme.ACCENT)
	name_lbl.custom_minimum_size = Vector2(120, 0)
	hbox.add_child(name_lbl)

	var hp_lbl := UITheme.make_label("", UITheme.FS_BODY, UITheme.OK)
	hbox.add_child(hp_lbl)

	var hand_lbl := UITheme.make_label("", UITheme.FS_SMALL, UITheme.TEXT)
	hbox.add_child(hand_lbl)

	var equip_lbl := UITheme.make_label("", UITheme.FS_SMALL, UITheme.GOLD)
	equip_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	equip_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hbox.add_child(equip_lbl)

	var judge_lbl := UITheme.make_label("", UITheme.FS_SMALL, UITheme.WARN)
	hbox.add_child(judge_lbl)

	var status_lbl := UITheme.make_label("", UITheme.FS_SMALL, UITheme.ACCENT)
	hbox.add_child(status_lbl)

	_human_seat_ui = {
		"panel": panel, "seat_num": seat_num_lbl, "name": name_lbl, "hp": hp_lbl,
		"hand": hand_lbl, "equip": equip_lbl, "judge": judge_lbl,
		"status": status_lbl,
	}


## 创建一个座位面板（使用 UITheme 统一风格）
func _make_seat_panel(pos: Vector2, panel_size: Vector2 = Vector2(172, 120), seat_index: int = -1) -> Dictionary:
	var panel := Panel.new()
	panel.position = pos
	panel.size = panel_size
	panel.add_theme_stylebox_override("panel", UITheme.panel_style(UITheme.BG_PANEL))
	panel.gui_input.connect(_on_seat_gui_input.bind(panel))

	var seat_m := MarginContainer.new()
	seat_m.set_anchors_preset(Control.PRESET_FULL_RECT)
	seat_m.add_theme_constant_override("margin_left", 8)
	seat_m.add_theme_constant_override("margin_right", 8)
	seat_m.add_theme_constant_override("margin_top", 4)
	seat_m.add_theme_constant_override("margin_bottom", 4)
	panel.add_child(seat_m)

	var vb := VBoxContainer.new()
	vb.set_anchors_preset(Control.PRESET_FULL_RECT)
	vb.add_theme_constant_override("separation", 2)
	seat_m.add_child(vb)

	# 座位号：描金圆字 ①②③…
	var seat_num_lbl := UITheme.make_label("", UITheme.FS_SMALL, UITheme.GOLD)
	if seat_index >= 0 and seat_index < UITheme.SEAT_GLYPHS.size():
		seat_num_lbl.text = UITheme.SEAT_GLYPHS[seat_index]
	seat_num_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	vb.add_child(seat_num_lbl)

	var name_lbl := UITheme.make_label("", UITheme.FS_SMALL, UITheme.TEXT)
	vb.add_child(name_lbl)

	var hp_lbl := UITheme.make_label("", UITheme.FS_SMALL, UITheme.OK)
	vb.add_child(hp_lbl)

	var hand_lbl := UITheme.make_label("", UITheme.FS_SMALL, UITheme.TEXT_DIM)
	vb.add_child(hand_lbl)

	var equip_lbl := UITheme.make_label("", UITheme.FS_SMALL, Color(0.6, 0.8, 1.0))
	equip_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	vb.add_child(equip_lbl)

	var judge_lbl := UITheme.make_label("", UITheme.FS_SMALL, Color(0.9, 0.7, 1.0))
	vb.add_child(judge_lbl)

	var status_lbl := UITheme.make_label("", UITheme.FS_SMALL, UITheme.ACCENT)
	vb.add_child(status_lbl)

	return {
		"panel": panel, "seat_num": seat_num_lbl, "name": name_lbl, "hp": hp_lbl,
		"hand": hand_lbl, "equip": equip_lbl, "judge": judge_lbl,
		"status": status_lbl,
	}


# ============================================================
# 刷新显示
# ============================================================

func _connect_event_bus() -> void:
	EventBus.subscribe(GameEvent.Type.DAMAGE_AFTER, _on_damage_anim, -190, self)
	EventBus.subscribe(GameEvent.Type.HEAL_AFTER, _on_heal_anim, -190, self)
	EventBus.subscribe(GameEvent.Type.DRAW_CARD, _on_state_changed, -200, self)
	EventBus.subscribe(GameEvent.Type.DISCARD_CARD, _on_state_changed, -200, self)
	EventBus.subscribe(GameEvent.Type.PLAYER_DEAD, _on_state_changed, -200, self)
	EventBus.subscribe(GameEvent.Type.PLAYER_REVIVED, _on_state_changed, -200, self)
	EventBus.subscribe(GameEvent.Type.CARD_RESOLVED, _on_state_changed, -200, self)
	EventBus.subscribe(GameEvent.Type.CARD_TARGETED, _on_card_targeted, -150, self)
	EventBus.subscribe(GameEvent.Type.SKILL_RESOLVED, _on_skill_anim, -180, self)
	EventBus.subscribe(GameEvent.Type.PLAYER_DYING, _on_dying_anim, -185, self)
	EventBus.subscribe(GameEvent.Type.EQUIP_INSTALLED, _on_state_changed, -200, self)


func _on_state_changed(_event) -> void:
	# Gemini:change.12: 音效接入
	match _event.event_type:
		GameEvent.Type.DRAW_CARD:
			AudioManager.play_sfx("card_draw")
		GameEvent.Type.DISCARD_CARD:
			AudioManager.play_sfx("card_discard")
		GameEvent.Type.PLAYER_DEAD:
			AudioManager.play_sfx("death")
		GameEvent.Type.CARD_RESOLVED:
			var card_name = _event.data.get("card_name", "")
			if card_name in ["南蛮入侵", "万箭齐发", "桃园结义", "五谷丰登"]:
				AnimHelper.aoe_ripple(self)
			AudioManager.play_sfx("card_play")
	# Gemini:change.12: 装备闪光动画（equip_flash 需要 Panel 参数，传入触发装备的座位面板）
	if _event.event_type == GameEvent.Type.EQUIP_INSTALLED:
		var equip_target: int = _event.target
		var seat_panel = _get_seat_panel(equip_target)
		if seat_panel != null:
			AnimHelper.equip_flash(seat_panel)
	_refresh_all()


## 伤害数字弹出
func _on_damage_anim(event: GameEvent) -> void:
	AudioManager.play_sfx("damage")
	var amount = event.data.get("amount", 0)
	var tgt_idx: int = event.target
	var pos := _get_seat_center(tgt_idx)
	if pos != Vector2.ZERO and amount > 0:
		AnimHelper.damage_popup(self, amount, pos)
	_refresh_all()


## 回复数字弹出
func _on_heal_anim(event: GameEvent) -> void:
	AudioManager.play_sfx("heal")
	var amount = event.data.get("amount", 0)
	var tgt_idx: int = event.target
	var pos := _get_seat_center(tgt_idx)
	if pos != Vector2.ZERO and amount > 0:
		AnimHelper.heal_popup(self, amount, pos)
	_refresh_all()


## 技能名弹出
func _on_skill_anim(event: GameEvent) -> void:
	AudioManager.play_sfx("skill_activate")
	var skill_name = event.data.get("skill_name", "")
	var src_idx: int = event.source
	var pos := _get_seat_center(src_idx)
	if pos != Vector2.ZERO and skill_name != "":
		AnimHelper.skill_popup(self, skill_name, pos)


## 濒死震动
func _on_dying_anim(event: GameEvent) -> void:
	AudioManager.play_sfx("dying")
	var tgt_idx: int = event.target
	if tgt_idx >= 0:
		AnimHelper.screen_shake(self, 4.0, 0.3)
	_refresh_all()


## 金色指向线：卡牌指向目标时绘制
func _on_card_targeted(event: GameEvent) -> void:
	var src_idx: int = event.source
	var tgt_idx: int = event.target
	if src_idx < 0 or tgt_idx < 0 or src_idx == tgt_idx:
		return
	_draw_target_line(src_idx, tgt_idx)


func _draw_target_line(src_idx: int, tgt_idx: int) -> void:
	AudioManager.play_sfx("target_line")
	var src_pos := _get_seat_center(src_idx)
	var tgt_pos := _get_seat_center(tgt_idx)
	if src_pos == Vector2.ZERO or tgt_pos == Vector2.ZERO:
		return

	# 创建 Line2D
	var line := Line2D.new()
	line.add_point(src_pos)
	line.add_point(tgt_pos)
	line.width = 2.0
	line.default_color = Color(0.92, 0.74, 0.30, 0.9)  # 金色
	line.z_index = 150
	add_child(line)

	# 0.2s 后淡出销毁
	var tw = create_tween()
	tw.tween_interval(0.2)
	tw.tween_property(line, "modulate:a", 0.0, 0.15)
	tw.tween_callback(line.queue_free)


## 获取座位面板的全局中心坐标
func _get_seat_center(player_idx: int) -> Vector2:
	var panel: Control = _get_seat_panel(player_idx)
	if panel == null:
		return Vector2.ZERO
	return panel.global_position + panel.size / 2.0


## 获取座位面板节点
func _get_seat_panel(player_idx: int) -> Panel:
	if player_idx == _human_index:
		if not _human_seat_ui.is_empty():
			return _human_seat_ui.get("panel")
	else:
		if player_idx < _seat_panels.size() and _seat_panels[player_idx] != null:
			return _seat_panels[player_idx].get("panel")
	return null


func _refresh_all() -> void:
	if _ctx == null:
		_ctx = game_manager.context
	if _ctx == null:
		return
	_refresh_seats()
	_refresh_deck()
	_refresh_hand()
	_refresh_skills()


func _refresh_seats() -> void:
	for i in range(_ctx.players.size()):
		var p = _ctx.get_player(i)
		if p == null:
			continue

		var is_human := (i == _human_index)
		var ui: Dictionary

		if is_human:
			if _human_seat_ui.is_empty():
				continue
			ui = _human_seat_ui
		else:
			if i >= _seat_panels.size() or _seat_panels[i] == null:
				continue
			ui = _seat_panels[i]

		var hero_name = p.hero_data.hero_name if p.hero_data else ("玩家%d" % i)
		var tag = "（你）" if is_human else "（AI）"
		var seat_label = UITheme.SEAT_GLYPHS[i] if i < UITheme.SEAT_GLYPHS.size() else "%d号" % (i + 1)

		# 座位号
		if ui.has("seat_num") and ui["seat_num"] != null:
			ui["seat_num"].text = seat_label

		# 身份显示
		var id_visible: bool = is_human or p.identity_revealed or (not p.is_alive)
		var id_text: String = Identity.display_name(p.identity) if id_visible else "？"
		ui["name"].text = "[%s] %s%s" % [id_text, hero_name, tag]
		if id_visible:
			ui["name"].add_theme_color_override("font_color", Identity.display_color(p.identity))
		else:
			ui["name"].add_theme_color_override("font_color", UITheme.TEXT_DIM)

		# 体力（人类用心形排，AI 用数字，按健康度染色 OK→WARN→DANGER）
		if is_human:
			var hearts := ""
			for h in range(p.max_hp):
				hearts += "♥" if h < max(0, p.current_hp) else "♡"
			ui["hp"].text = hearts + " %d/%d" % [max(0, p.current_hp), p.max_hp]
		else:
			ui["hp"].text = "♥ %d/%d" % [max(0, p.current_hp), p.max_hp]
		# 染色：满血=OK，半血=WARN，濒死≤1=DANGER
		var hp_color: Color
		if p.current_hp <= 1:
			hp_color = UITheme.DANGER
		elif p.current_hp <= p.max_hp / 2:
			hp_color = UITheme.WARN
		else:
			hp_color = UITheme.OK
		ui["hp"].add_theme_color_override("font_color", hp_color)

		ui["hand"].text = "🂠 ×%d" % p.hand_cards.size()
		ui["equip"].text = _equip_summary(p)
		ui["judge"].text = _judge_summary(p)

		var status := ""
		if not p.is_alive:
			status = "☠ 阵亡"
			ui["status"].add_theme_color_override("font_color", UITheme.TEXT_DIM)
		elif i == _ctx.current_player_index:
			status = "◆ 回合中"
			ui["status"].add_theme_color_override("font_color", UITheme.ACCENT)
		ui["status"].text = status

		if not is_human:
			_style_seat(ui["panel"], i, p)


func _style_seat(panel: Panel, idx: int, p) -> void:
	var sb := UITheme.panel_style(UITheme.BG_PANEL)
	if not p.is_alive:
		# 阵亡：虚线灰框，半透明
		sb.bg_color = UITheme.BG_DEEP
		sb.border_color = UITheme.TEXT_DIM
		panel.modulate = Color(1, 1, 1, 0.45)
	elif idx == _ctx.current_player_index:
		# 当前行动：金边
		sb.border_color = UITheme.GOLD
		panel.modulate = Color(1, 1, 1, 1)
	elif _mode == Mode.PLAY_SELECT_TARGET and _is_valid_target(idx):
		if idx in _selected_targets:
			sb.bg_color = UITheme.BG_PANEL_HI
			sb.border_color = UITheme.GOLD
		else:
			sb.bg_color = UITheme.BG_PANEL_HI
			sb.border_color = UITheme.OK
		panel.modulate = Color(1, 1, 1, 1)
	else:
		sb.bg_color = UITheme.BG_PANEL
		sb.border_color = UITheme.BORDER
		panel.modulate = Color(1, 1, 1, 1)
	panel.add_theme_stylebox_override("panel", sb)


func _refresh_deck() -> void:
	_deck_label.text = "🂠 %d  |  弃牌堆 %d" % [_ctx.draw_pile.size(), _ctx.discard_pile.size()]


func _refresh_hand() -> void:
	for child in _hand_box.get_children():
		child.queue_free()

	var human = _ctx.get_player(_human_index)
	if human == null:
		return
	for card in human.hand_cards:
		var cv = CardViewScene.instantiate()
		_hand_box.add_child(cv)
		cv.init_card(card)
		cv.card_clicked.connect(_on_hand_card_clicked)
		if _mode == Mode.PLAY_SELECT_CARD:
			cv.modulate = Color(1, 1, 1) if _can_play_card(card) else Color(0.5, 0.5, 0.5)
		elif _mode == Mode.IDLE or _mode == Mode.CARD_PICK:
			cv.modulate = Color(0.7, 0.7, 0.7)
		elif _mode == Mode.DISCARD_SELECT:
			cv.set_selected(card in _selected_discards)
		elif _mode == Mode.RESPONSE:
			var is_match: bool = card.card_name == _response_required
			# 濒死自救时酒也可用
			if _response_required == "桃" and card.card_name == "酒":
				is_match = true
			# Gemini:change.12: 转化牌也可响应（龙胆：杀当闪；急救：红牌当桃）
			if not is_match:
				for sk in human.skills:
					if sk != null and sk.has_method("get_convertible_cards"):
						var conv_cards = sk.get_convertible_cards(human.hand_cards, _response_required, _ctx.current_phase)
						if card in conv_cards:
							is_match = true
							break
			cv.modulate = Color(1, 1, 1) if is_match else Color(0.5, 0.5, 0.5)


# ============================================================
# GameManager 信号回调
# ============================================================

func _on_game_initialized() -> void:
	_refresh_all()


func _on_round_started(player_index: int, round_number: int) -> void:
	AudioManager.play_sfx("turn_start")
	var p = _ctx.get_player(player_index)
	var hero = p.hero_data.hero_name if (p and p.hero_data) else ("玩家%d" % player_index)
	_phase_label.text = "第 %d 回合 · %s" % [round_number, hero]
	_refresh_all()
	# 回合指示器脉冲
	if player_index != _human_index and player_index < _seat_panels.size() and _seat_panels[player_index] != null:
		var panel = _seat_panels[player_index].get("panel")
		if panel:
			AnimHelper.seat_pulse_border(panel, UITheme.ACCENT, 2)


func _on_phase_changed(player_index: int, phase) -> void:
	var p = _ctx.get_player(player_index)
	var hero = p.hero_data.hero_name if (p and p.hero_data) else ("玩家%d" % player_index)
	_phase_label.text = "%s · %s" % [hero, _phase_name(phase)]
	_refresh_all()


func _on_game_over(winner_info: Dictionary) -> void:
	var winner = winner_info.get("winner_name", "无")
	var winners: Array = winner_info.get("winners", [])

	# 构造详细文本
	var detail: String = str(winner) + "\n"
	for wi in winners:
		var wp = _ctx.get_player(wi)
		if wp != null:
			var w_hero = wp.hero_data.hero_name if wp.hero_data else ("玩家%d" % wi)
			detail += "  %s" % w_hero
	detail += " 获胜！"

	_phase_label.text = "游戏结束"
	_set_prompt("")
	_mode = Mode.IDLE
	_end_btn.visible = false
	_confirm_btn.visible = false
	_response_panel.visible = false

	# 弹出结算面板
	if _game_over_panel != null:
		var title_lbl = _game_over_panel.find_child("TitleLabel", true, false)
		if title_lbl:
			title_lbl.text = "🏆 %s" % winner
		var detail_lbl = _game_over_panel.find_child("DetailLabel", true, false)
		if detail_lbl:
			detail_lbl.text = detail
		_game_over_panel.visible = true


func _phase_name(phase) -> String:
	match phase:
		BattleContext.Phase.PHASE_JUDGE: return "判定阶段"
		BattleContext.Phase.PHASE_DRAW: return "摸牌阶段"
		BattleContext.Phase.PHASE_PLAY: return "出牌阶段"
		BattleContext.Phase.PHASE_DISCARD: return "弃牌阶段"
		_: return "回合中"


# ============================================================
# 人类控制器请求回调（驱动交互）
# ============================================================

func _on_play_requested(_player_index: int) -> void:
	_mode = Mode.PLAY_SELECT_CARD
	_pending_card = null
	_end_btn.visible = true
	_confirm_btn.visible = false
	_set_prompt("出牌阶段：点击一张可用的牌或技能，或结束出牌")
	_refresh_hand()
	_refresh_skills()
	_refresh_seats()


func _on_response_requested(_player_index: int, required: String, extra: Dictionary) -> void:
	_mode = Mode.RESPONSE
	_response_required = required
	var prompt = extra.get("prompt", "是否打出【%s】？" % required)
	# Gemini:change.12: 检查转化选项（龙胆/急救等）
	var conversions = extra.get("convertible_skills", [])
	var has_card = _human_has_card(required)
	var has_conversion := false
	if not has_card and not conversions.is_empty():
		for conv in conversions:
			var cards = conv.get("cards", [])
			if not cards.is_empty():
				has_conversion = true
				prompt += "\n（可通过转化技能使用）"
				break
	_play_btn.disabled = not has_card and not has_conversion
	_response_prompt.text = prompt
	_response_panel.visible = true
	AnimHelper.pop_in(_response_panel, 0.25)
	_set_prompt("需要响应：%s" % required)

	# 无懈可击专用：显示/隐藏"全部跳过"按钮
	var is_wuxie := (required == "无懈可击")
	var skip_all_btn = _response_panel.find_child("SkipAllBtn", true, false)
	if skip_all_btn:
		skip_all_btn.visible = is_wuxie

	_refresh_hand()


func _on_discard_requested(_player_index: int, count: int) -> void:
	_mode = Mode.DISCARD_SELECT
	_discard_needed = count
	_selected_discards.clear()
	_confirm_btn.visible = true
	_confirm_btn.disabled = true
	_end_btn.visible = false
	_set_prompt("手牌超出上限，请选择 %d 张弃置" % count)
	_refresh_hand()


func _on_card_pick_requested(_player_index: int, target_index: int, available_cards: Array, pick_context: String) -> void:
	_mode = Mode.CARD_PICK
	_pick_target_index = target_index
	var ctx_text := ""
	match pick_context:
		"steal": ctx_text = "顺手牵羊：选择一张牌获得"
		"dismantle": ctx_text = "过河拆桥：选择一张牌弃置"
		"wugu": ctx_text = "五谷丰登：选择一张牌获得"
		_: ctx_text = "选择一张牌"
	_set_prompt(ctx_text)
	_show_pick_panel(available_cards, pick_context)


# ============================================================
# 手牌点击 / 目标点击 / 按钮
# ============================================================

func _on_hand_card_clicked(card) -> void:
	match _mode:
		Mode.PLAY_SELECT_CARD:
			_handle_play_card_pick(card)
		Mode.DISCARD_SELECT:
			_handle_discard_pick(card)
		Mode.RESPONSE:
			var is_match: bool = card.card_name == _response_required
			if _response_required == "桃" and card.card_name == "酒":
				is_match = true
			if is_match:
				_submit_response(true, card)
			else:
				# Gemini:change.12: 检查转化（龙胆：杀当闪；急救：红牌当桃等）
				var human = _ctx.get_player(_human_index)
				if human != null:
					for sk in human.skills:
						if sk != null and sk.has_method("get_convertible_cards"):
							var conv_cards = sk.get_convertible_cards(human.hand_cards, _response_required, _ctx.current_phase)
							if card in conv_cards:
								var virtual_card = sk.create_virtual_card(_response_required)
								_submit_response_converted(virtual_card, card)
								return


func _handle_play_card_pick(card) -> void:
	if not _can_play_card(card):
		_set_prompt("这张【%s】现在不能使用" % card.card_name)
		return
	if card.need_target:
		var targets = human_controller.get_valid_targets(_human_index, card)
		if targets.is_empty():
			_set_prompt("【%s】没有合法目标" % card.card_name)
			return
		_pending_card = card
		# Gemini:change.12: 查询有效目标数量上限（方天画戟：杀可指定至多3个目标）
		_max_targets = 1
		if _ctx.card_resolver != null:
			_max_targets = _ctx.card_resolver.get_effective_target_count(_ctx, _human_index, card)
		_selected_targets.clear()
		_mode = Mode.PLAY_SELECT_TARGET
		if _max_targets > 1:
			_set_prompt("选择【%s】的目标（至多%d个，点击座位选中/取消，确认后提交）" % [card.card_name, _max_targets])
			_confirm_btn.visible = true
			_confirm_btn.disabled = true
		else:
			_set_prompt("选择【%s】的目标（点击高亮的座位）" % card.card_name)
			_confirm_btn.visible = false
		_refresh_seats()
	else:
		var intent = PlayIntent.no_target(_human_index, card)
		_submit_play(intent)


func _on_seat_clicked(idx: int) -> void:
	if _mode != Mode.PLAY_SELECT_TARGET or _pending_card == null:
		return
	if not _is_valid_target(idx):
		return

	# Gemini:change.12: 多目标选择（方天画戟）
	if _max_targets > 1:
		# 切换选中/取消选中
		if idx in _selected_targets:
			_selected_targets.erase(idx)
		else:
			if _selected_targets.size() < _max_targets:
				_selected_targets.append(idx)
		# 更新确认按钮状态
		_confirm_btn.disabled = _selected_targets.is_empty()
		_set_prompt("已选 %d/%d 个目标" % [_selected_targets.size(), _max_targets])
		_refresh_seats()
	else:
		# 单目标：直接提交
		var intent = PlayIntent.single_target(_human_index, _pending_card, idx)
		_pending_card = null
		_confirm_btn.visible = false
		_submit_play(intent)


func _handle_discard_pick(card) -> void:
	if card in _selected_discards:
		_selected_discards.erase(card)
	elif _selected_discards.size() < _discard_needed:
		_selected_discards.append(card)
	_confirm_btn.disabled = _selected_discards.size() != _discard_needed
	_refresh_hand()


func _on_end_pressed() -> void:
	if _mode == Mode.PLAY_SELECT_CARD or _mode == Mode.PLAY_SELECT_TARGET:
		_end_btn.visible = false
		_confirm_btn.visible = false
		_set_prompt("")
		_mode = Mode.IDLE
		_pending_card = null
		_selected_targets.clear()
		human_controller.submit_end_play()
		_refresh_seats()


func _on_confirm_pressed() -> void:
	# Gemini:change.12: 统一确认按钮处理（弃牌 / 多目标选择）
	match _mode:
		Mode.DISCARD_SELECT:
			if _selected_discards.size() != _discard_needed:
				return
			var cards = _selected_discards.duplicate()
			_selected_discards.clear()
			_confirm_btn.visible = false
			_mode = Mode.IDLE
			_set_prompt("")
			human_controller.submit_discard(cards)
		Mode.PLAY_SELECT_TARGET:
			if _selected_targets.is_empty() or _pending_card == null:
				return
			var intent = PlayIntent.new()
			intent.source_index = _human_index
			intent.card = _pending_card
			intent.target_indices = _selected_targets.duplicate()
			_pending_card = null
			_selected_targets.clear()
			_confirm_btn.visible = false
			_submit_play(intent)


func _on_response_play_pressed() -> void:
	var card = _find_human_card(_response_required)
	# 濒死自救时酒也可用
	if card == null and _response_required == "桃":
		card = _find_human_card("酒")
	if card != null:
		_submit_response(true, card)
		return
	# Gemini:change.12: 没有直接匹配的牌，检查转化技能
	# 让玩家从可转化的手牌中选择一张
	var human = _ctx.get_player(_human_index)
	if human == null:
		return
	var convertible_cards: Array = []
	for sk in human.skills:
		if sk == null:
			continue
		if sk.has_method("get_convertible_cards"):
			var cards = sk.get_convertible_cards(human.hand_cards, _response_required, _ctx.current_phase)
			if not cards.is_empty():
				# 添加到可选列表（带技能标记）
				for c in cards:
					convertible_cards.append({"card": c, "skill": sk})
	if convertible_cards.is_empty():
		return
	# 如果只有一张可转化的牌，直接使用
	if convertible_cards.size() == 1:
		var conv = convertible_cards[0]
		var real_card = conv["card"]
		var sk = conv["skill"]
		var virtual_card = sk.create_virtual_card(_response_required)
		_submit_response_converted(virtual_card, real_card)
	else:
		# 多张可选：显示选牌面板
		_mode = Mode.CARD_PICK
		var cards_only: Array = []
		for conv in convertible_cards:
			cards_only.append(conv["card"])
		_pick_context = "convert_response"
		_pick_convertible_map = convertible_cards
		_show_pick_panel(cards_only, "convert_response")


func _on_response_pass_pressed() -> void:
	_submit_response(false, null)


func _on_response_skip_all_pressed() -> void:
	# 对所有人不使用无懈可击：提交带 skip_all 标记的"未打出"结果
	_response_panel.visible = false
	_mode = Mode.IDLE
	_set_prompt("")
	var result = ResponseResult.not_played()
	result.context_data = {"skip_all_wuxie": true}
	human_controller.submit_response(result)
	_refresh_hand()


func _submit_response(played: bool, card) -> void:
	_response_panel.visible = false
	_mode = Mode.IDLE
	_set_prompt("")
	var result = ResponseResult.played_card(card) if played else ResponseResult.not_played()
	human_controller.submit_response(result)
	_refresh_hand()


# Gemini:change.12: 提交转化牌响应（如龙胆：杀当闪）
func _submit_response_converted(virtual_card, real_card) -> void:
	_response_panel.visible = false
	_mode = Mode.IDLE
	_set_prompt("")
	var result = ResponseResult.played_converted(virtual_card, real_card)
	human_controller.submit_response(result)
	_refresh_hand()


func _submit_play(intent) -> void:
	AudioManager.play_sfx("button_click")
	_mode = Mode.IDLE
	_pending_card = null
	_set_prompt("")
	_refresh_seats()
	human_controller.submit_play(intent)


# ============================================================
# 辅助查询
# ============================================================

func _on_seat_gui_input(event: InputEvent, panel: Panel) -> void:
	if not (event is InputEventMouseButton):
		return
	if event.button_index != MOUSE_BUTTON_LEFT or not event.pressed:
		return
	for i in range(_seat_panels.size()):
		if _seat_panels[i] != null and _seat_panels[i]["panel"] == panel:
			_on_seat_clicked(i)
			return


func _set_prompt(text: String) -> void:
	if _prompt_label:
		_prompt_label.text = text


func _can_play_card(card) -> bool:
	if human_controller == null:
		return false
	if not human_controller.can_use_in_play_phase(_human_index, card):
		return false
	if card.need_target:
		return not human_controller.get_valid_targets(_human_index, card).is_empty()
	return true


func _is_valid_target(idx: int) -> bool:
	if _pending_card == null:
		return false
	return idx in human_controller.get_valid_targets(_human_index, _pending_card)


func _human_has_card(card_name: String) -> bool:
	return _find_human_card(card_name) != null


func _find_human_card(card_name: String):
	var human = _ctx.get_player(_human_index)
	if human == null:
		return null
	for card in human.hand_cards:
		if card.card_name == card_name:
			return card
	return null


func _equip_summary(p) -> String:
	var parts: Array = []
	if p.equip_weapon != null:
		parts.append("武:" + p.equip_weapon.card_name)
	if p.equip_armor != null:
		parts.append("防:" + p.equip_armor.card_name)
	if p.equip_horse_atk != null:
		parts.append("-1")
	if p.equip_horse_def != null:
		parts.append("+1")
	return " ".join(parts) if not parts.is_empty() else ""


func _judge_summary(p) -> String:
	if p.judge_cards.is_empty():
		return ""
	var names: Array = []
	for jc in p.judge_cards:
		names.append(jc.card_name)
	return "判定:" + "·".join(names)
