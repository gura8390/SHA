# ============================================================
# game_setup_screen.gd
# 准备界面：人数滑块(4~12) + 明身份开关 + 武将选择 + 点将
# 主题：墨色漆器 · 金边面板 · 旧纸武将卡
# ============================================================

extends Control

const MAIN_MENU := "res://scenes/ui/main_menu.tscn"
const BATTLE := "res://scenes/game/battle_table.tscn"
const HERO_CHOICES := 4

var _gs = null

var _count_slider: HSlider
var _count_label: Label
var _reveal_check: CheckButton
var _hero_buttons: Array = []
var _selected_hero_id: String = ""
var _start_btn: Button
var _hero_cards: Array = []

var _pick_panel: Control = null
var _pick_grid: GridContainer = null
var _pick_search: LineEdit = null


func _ready() -> void:
	_gs = get_node_or_null("/root/GameSetup")
	_build_ui()
	_deal_heroes()
	AnimHelper.fade_in(self, 0.3)


func _build_ui() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(UITheme.make_bg(UITheme.BG_DEEP))

	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(center)

	var vb := VBoxContainer.new()
	vb.custom_minimum_size = Vector2(720, 0)
	vb.add_theme_constant_override("separation", UITheme.SP_M)
	center.add_child(vb)

	# 标题：书法体描金
	var title := UITheme.make_label("对 局 设 置", UITheme.FS_HEAD, UITheme.GOLD)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(title)

	vb.add_child(UITheme.make_spacer(UITheme.SP_S))

	# ----- 人数滑块 -----
	var slider_data = UITheme.make_slider_row("对局人数", 4, 12)
	vb.add_child(slider_data[0])
	_count_slider = slider_data[1]
	_count_label = slider_data[2]
	_count_slider.value = 8
	_count_slider.value_changed.connect(func(v): _count_label.text = "%d 人" % int(v))

	# ----- 明身份开关 -----
	var reveal_row := HBoxContainer.new()
	reveal_row.add_theme_constant_override("separation", UITheme.SP_M)
	vb.add_child(reveal_row)
	var reveal_lbl := UITheme.make_label("明身份", UITheme.FS_BODY, UITheme.TEXT)
	reveal_lbl.custom_minimum_size = Vector2(120, 0)
	reveal_row.add_child(reveal_lbl)
	_reveal_check = CheckButton.new()
	_reveal_check.button_pressed = false
	reveal_row.add_child(_reveal_check)
	var reveal_hint := UITheme.make_label("（开启后所有身份开局即公开）", UITheme.FS_SMALL, UITheme.TEXT_DIM)
	reveal_row.add_child(reveal_hint)

	vb.add_child(UITheme.make_spacer(UITheme.SP_S))

	# ----- 武将选择 -----
	var hero_title := UITheme.make_label("选择你的武将", UITheme.FS_SUB, UITheme.GOLD)
	vb.add_child(hero_title)

	var hero_row := HBoxContainer.new()
	hero_row.name = "HeroRow"
	hero_row.add_theme_constant_override("separation", UITheme.SP_M)
	hero_row.alignment = BoxContainer.ALIGNMENT_CENTER
	vb.add_child(hero_row)

	# 点将按钮
	var pick_row := HBoxContainer.new()
	pick_row.add_theme_constant_override("separation", UITheme.SP_M)
	pick_row.alignment = BoxContainer.ALIGNMENT_CENTER
	vb.add_child(pick_row)

	var pick_btn := UITheme.make_button("点 将")
	pick_btn.custom_minimum_size = Vector2(160, 42)
	pick_btn.pressed.connect(_on_pick_general_clicked)
	pick_row.add_child(pick_btn)

	var pick_hint := UITheme.make_label("从全部武将中指定选择", UITheme.FS_SMALL, UITheme.TEXT_DIM)
	pick_hint.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	pick_row.add_child(pick_hint)

	var desc := UITheme.make_label("", UITheme.FS_BODY, UITheme.TEXT_DIM)
	desc.name = "HeroDesc"
	desc.custom_minimum_size = Vector2(0, 60)
	desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	vb.add_child(desc)

	vb.add_child(UITheme.make_spacer(UITheme.SP_S))

	# ----- 底部按钮 -----
	var btn_row := HBoxContainer.new()
	btn_row.add_theme_constant_override("separation", UITheme.SP_L)
	btn_row.alignment = BoxContainer.ALIGNMENT_CENTER
	vb.add_child(btn_row)

	var back_btn := UITheme.make_button("返回")
	back_btn.custom_minimum_size = Vector2(180, 52)
	back_btn.pressed.connect(_on_back)
	btn_row.add_child(back_btn)

	_start_btn = UITheme.make_button("开始游戏", true)
	_start_btn.custom_minimum_size = Vector2(220, 52)
	_start_btn.disabled = true
	_start_btn.pressed.connect(_on_start)
	btn_row.add_child(_start_btn)

	_build_pick_panel()


func _deal_heroes() -> void:
	_hero_cards = HeroPool.draw_random(HERO_CHOICES)
	var hero_row := _find_hero_row()
	if hero_row == null:
		return
	for child in hero_row.get_children():
		child.queue_free()
	_hero_buttons.clear()

	for i in range(_hero_cards.size()):
		var hero_def = _hero_cards[i]
		var btn := Button.new()
		btn.custom_minimum_size = Vector2(150, 200)
		btn.toggle_mode = true
		# 武将名（书法体）+ 体力 + 技能名
		var skill_text = hero_def.get("skill_name", "无技能") if hero_def.get("skill_name", "") != "" else "无技能"
		btn.text = "%s\n\n体力 %d\n\n%s" % [
			hero_def.get("name", "?"),
			hero_def.get("hp", 4),
			skill_text,
		]
		UITheme.style_button(btn)
		var hid: String = hero_def.get("id", "")
		btn.pressed.connect(_on_hero_picked.bind(hid))
		hero_row.add_child(btn)
		_hero_buttons.append({"btn": btn, "hero_id": hid})
		# 淡入动画
		btn.modulate.a = 0.0
		var tw = create_tween()
		tw.tween_interval(0.3 + i * 0.12)
		tw.tween_property(btn, "modulate:a", 1.0, 0.3).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_QUAD)


func _find_hero_row() -> Node:
	for c in get_children():
		if c is CenterContainer:
			for v in c.get_children():
				var hr = v.get_node_or_null("HeroRow")
				if hr != null:
					return hr
	return null


func _find_desc() -> Label:
	for c in get_children():
		if c is CenterContainer:
			for v in c.get_children():
				var d = v.get_node_or_null("HeroDesc")
				if d != null:
					return d
	return null


func _on_hero_picked(hero_id: String) -> void:
	_selected_hero_id = hero_id
	for entry in _hero_buttons:
		entry["btn"].button_pressed = (entry["hero_id"] == hero_id)
	_start_btn.disabled = false
	var desc := _find_desc()
	if desc != null:
		var hd := HeroPool.get_by_id(hero_id)
		desc.text = hd.get("desc", "")


func _on_back() -> void:
	AnimHelper.scene_transition(self, func(): get_tree().change_scene_to_file(MAIN_MENU))


func _on_start() -> void:
	if _selected_hero_id == "":
		return
	if _gs != null:
		_gs.player_count = int(_count_slider.value)
		_gs.human_hero_id = _selected_hero_id
		_gs.reveal_identity = _reveal_check.button_pressed
	AnimHelper.scene_transition(self, func(): get_tree().change_scene_to_file(BATTLE))


# ============================================================
# 点将功能
# ============================================================

func _build_pick_panel() -> void:
	# 使用 UITheme.make_overlay_panel 创建 SCRIM + 金边面板
	var overlay = UITheme.make_overlay_panel(true)
	_pick_panel = overlay[0]
	var vb = overlay[1]
	_pick_panel.visible = false
	add_child(_pick_panel)

	# 标题栏
	var header := HBoxContainer.new()
	header.add_theme_constant_override("separation", UITheme.SP_M)
	vb.add_child(header)

	var pick_title := UITheme.make_label("选择武将", UITheme.FS_HEAD, UITheme.GOLD)
	pick_title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	header.add_child(pick_title)

	var close_btn := UITheme.make_button("关闭")
	close_btn.custom_minimum_size = Vector2(100, 36)
	close_btn.pressed.connect(func(): _pick_panel.visible = false)
	header.add_child(close_btn)

	var hint := UITheme.make_label("点击任意武将卡片即可选中", UITheme.FS_SMALL, UITheme.TEXT_DIM)
	vb.add_child(hint)

	# 搜索栏
	var search_row := HBoxContainer.new()
	search_row.add_theme_constant_override("separation", UITheme.SP_S)
	vb.add_child(search_row)

	var search_label := UITheme.make_label("搜索:", UITheme.FS_BODY, UITheme.TEXT)
	search_row.add_child(search_label)

	_pick_search = LineEdit.new()
	_pick_search.placeholder_text = "输入武将名称筛选..."
	_pick_search.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_pick_search.custom_minimum_size = Vector2(300, 36)
	_pick_search.add_theme_font_size_override("font_size", UITheme.FS_BODY)
	_pick_search.text_changed.connect(_on_pick_search_changed)
	search_row.add_child(_pick_search)

	# 可滚动的网格区域
	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	vb.add_child(scroll)

	_pick_grid = GridContainer.new()
	_pick_grid.columns = 4
	_pick_grid.add_theme_constant_override("h_separation", UITheme.SP_S)
	_pick_grid.add_theme_constant_override("v_separation", UITheme.SP_S)
	_pick_grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(_pick_grid)

	_populate_pick_grid()


func _populate_pick_grid(search_text: String = "") -> void:
	for child in _pick_grid.get_children():
		child.queue_free()

	var all_heroes = HeroPool.all()
	var filter := search_text.strip_edges().to_lower()
	for hero_def in all_heroes:
		var hero_name: String = hero_def.get("name", "")
		if filter != "" and not hero_name.to_lower().contains(filter):
			continue
		var card := _make_hero_card(hero_def)
		_pick_grid.add_child(card)


func _on_pick_search_changed(text: String) -> void:
	_populate_pick_grid(text)


func _make_hero_card(hero_def: Dictionary) -> Button:
	var hero_name: String = hero_def.get("name", "?")
	var hp: int = hero_def.get("hp", 4)
	var camp = hero_def.get("camp", HeroData.Camp.QUN)
	var camp_str := ""
	match camp:
		HeroData.Camp.WEI: camp_str = "魏"
		HeroData.Camp.SHU: camp_str = "蜀"
		HeroData.Camp.WU: camp_str = "吴"
		HeroData.Camp.QUN: camp_str = "群"

	var skill_text := "无技能"
	var skills = hero_def.get("skills", [])
	if not skills.is_empty():
		var names: Array = []
		for sk in skills:
			names.append(sk.get("skill_name", sk.get("name", "")))
		skill_text = "、".join(names)
	elif hero_def.get("skill_name", "") != "":
		skill_text = hero_def.get("skill_name", "")

	var btn := Button.new()
	btn.custom_minimum_size = Vector2(200, 120)
	btn.text = "【%s】%s\n体力 %d\n%s" % [camp_str, hero_name, hp, skill_text]
	UITheme.style_button(btn)

	btn.mouse_entered.connect(func(): AnimHelper.btn_hover_enter(btn))
	btn.mouse_exited.connect(func(): AnimHelper.btn_hover_exit(btn))

	# 阵营颜色
	var camp_color := UITheme.TEXT
	match camp:
		HeroData.Camp.WEI: camp_color = Color(0.5, 0.7, 1.0)
		HeroData.Camp.SHU: camp_color = Color(1.0, 0.45, 0.40)
		HeroData.Camp.WU: camp_color = Color(0.4, 0.85, 0.5)
		HeroData.Camp.QUN: camp_color = UITheme.GOLD
	btn.add_theme_color_override("font_color", camp_color)
	btn.add_theme_color_override("font_hover_color", camp_color.lightened(0.2))

	var hid: String = hero_def.get("id", "")
	btn.pressed.connect(_on_pick_general_card_clicked.bind(hid))
	return btn


func _on_pick_general_clicked() -> void:
	if _pick_search != null:
		_pick_search.text = ""
	_populate_pick_grid()
	_pick_panel.visible = true
	AnimHelper.pop_in(_pick_panel, 0.3)
	if _pick_search != null:
		_pick_search.grab_focus()


func _on_pick_general_card_clicked(hero_id: String) -> void:
	_pick_panel.visible = false
	_on_hero_picked(hero_id)
