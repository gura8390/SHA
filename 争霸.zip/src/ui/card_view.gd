# ============================================================
# card_view.gd
# 卡牌视图：120×170，旧纸三色 + 描金边
# 主题：墨色漆器 · 染色旧纸
# ============================================================

class_name CardView
extends Panel

const CARD_SIZE := Vector2(120, 170)

signal card_clicked(card_data: CardData)
signal card_hovered(card_data: CardData)
signal card_unhovered(card_data: CardData)

var _card_data: CardData = null
var _name_label: Label
var _suit_label: Label
var _rank_label: Label
var _type_label: Label
var _is_selected: bool = false
var _original_y: float = 0.0


func _ready() -> void:
	custom_minimum_size = CARD_SIZE
	size = CARD_SIZE
	_original_y = position.y
	_build_ui()
	mouse_entered.connect(_on_mouse_entered)
	mouse_exited.connect(_on_mouse_exited)
	gui_input.connect(_on_gui_input)


func _build_ui() -> void:
	# 面板样式：旧纸底 + 描金边
	_update_background(UITheme.CARD_BASIC, UITheme.BORDER)

	var margin := MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	margin.add_theme_constant_override("margin_left", 6)
	margin.add_theme_constant_override("margin_right", 6)
	margin.add_theme_constant_override("margin_top", 4)
	margin.add_theme_constant_override("margin_bottom", 4)
	add_child(margin)

	var vb := VBoxContainer.new()
	vb.set_anchors_preset(Control.PRESET_FULL_RECT)
	vb.add_theme_constant_override("separation", 2)
	margin.add_child(vb)

	# 花色 + 点数（左上角）
	var top_row := HBoxContainer.new()
	top_row.add_theme_constant_override("separation", 4)
	vb.add_child(top_row)

	_suit_label = UITheme.make_label("", UITheme.FS_BODY, UITheme.ACCENT)
	top_row.add_child(_suit_label)

	_rank_label = UITheme.make_label("", UITheme.FS_BODY, UITheme.ACCENT)
	top_row.add_child(_rank_label)

	# 卡名（居中书法体）
	_name_label = UITheme.make_label("", UITheme.FS_SUB, UITheme.TEXT)
	_name_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_name_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	vb.add_child(_name_label)

	# 类型标签
	_type_label = UITheme.make_label("", UITheme.FS_SMALL, UITheme.GOLD)
	_type_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(_type_label)


## 初始化卡牌显示
func init_card(data: CardData) -> void:
	_card_data = data
	if data == null:
		return

	_name_label.text = data.card_name
	_suit_label.text = data.get_suit_display()
	_rank_label.text = data.get_rank_display()
	_type_label.text = _get_type_display(data)

	# 花色颜色：红心/方块=朱砂，黑桃/梅花=近墨
	if data.is_red():
		_suit_label.add_theme_color_override("font_color", UITheme.ACCENT)
		_rank_label.add_theme_color_override("font_color", UITheme.ACCENT)
	else:
		_suit_label.add_theme_color_override("font_color", Color(0.15, 0.15, 0.17))
		_rank_label.add_theme_color_override("font_color", Color(0.15, 0.15, 0.17))

	# 底色按类型
	var bg_color := _get_type_bg(data)
	_update_background(bg_color, UITheme.BORDER)


func _get_type_display(data: CardData) -> String:
	match data.card_type:
		CardData.CardType.BASIC: return "基本"
		CardData.CardType.TRICK: return "锦囊"
		CardData.CardType.EQUIPMENT: return "装备"
		_: return ""


func _get_type_bg(data: CardData) -> Color:
	if data == null:
		return UITheme.CARD_BASIC
	match data.card_type:
		CardData.CardType.TRICK: return UITheme.CARD_TRICK
		CardData.CardType.EQUIPMENT: return UITheme.CARD_EQUIP
		_: return UITheme.CARD_BASIC


## 选中/取消选中动画
func set_selected(selected: bool) -> void:
	_is_selected = selected
	if selected:
		_original_y = position.y
		var tw = create_tween().set_parallel(true)
		tw.tween_property(self, "position:y", _original_y - 20, 0.15).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
		tw.tween_property(self, "scale", Vector2(1.05, 1.05), 0.15).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
		# 描金外发光
		_update_background(UITheme.BG_PANEL_HI, UITheme.GOLD)
	else:
		var tw = create_tween().set_parallel(true)
		tw.tween_property(self, "position:y", _original_y, 0.15).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_QUAD)
		tw.tween_property(self, "scale", Vector2(1.0, 1.0), 0.15).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_QUAD)
		if _card_data:
			_update_background(_get_type_bg(_card_data), UITheme.BORDER)


## 不可出状态：灰掉去饱和
func set_unplayable() -> void:
	modulate = Color(0.5, 0.5, 0.5, 0.6)


## 恢复可出状态
func set_playable() -> void:
	modulate = Color(1, 1, 1, 1)


func get_card_data() -> CardData:
	return _card_data


## 更新背景样式
func _update_background(bg_color: Color, border_color: Color) -> void:
	add_theme_stylebox_override("panel", UITheme.panel_style(
		bg_color, border_color, UITheme.RADIUS_CARD, false
	))


func _on_mouse_entered() -> void:
	if not _is_selected:
		pivot_offset = size / 2.0
		var tw = create_tween()
		tw.tween_property(self, "scale", Vector2(1.08, 1.08), 0.1).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
	if _card_data:
		card_hovered.emit(_card_data)


func _on_mouse_exited() -> void:
	if not _is_selected:
		var tw = create_tween()
		tw.tween_property(self, "scale", Vector2(1.0, 1.0), 0.1).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_QUAD)
	if _card_data:
		card_unhovered.emit(_card_data)


func _on_gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		if _card_data:
			card_clicked.emit(_card_data)
