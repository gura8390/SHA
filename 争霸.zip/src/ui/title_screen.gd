# ============================================================
# title_screen.gd
# 开始界面：墨底 + 描金标题 + 按任意键进入主菜单
# 主题：墨色漆器
# ============================================================

extends Control

const MAIN_MENU := "res://scenes/ui/main_menu.tscn"

var _entered: bool = false
var _hint: Label = null


func _ready() -> void:
	_build()
	_animate_entrance()


func _build() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	# 墨底
	add_child(UITheme.make_bg(UITheme.BG_DEEP))

	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(center)

	var vb := VBoxContainer.new()
	vb.alignment = BoxContainer.ALIGNMENT_CENTER
	vb.add_theme_constant_override("separation", UITheme.SP_XL)
	center.add_child(vb)

	# 标题：书法体描金
	var title := UITheme.make_label("三  國  爭  霸", UITheme.FS_TITLE, UITheme.GOLD)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.name = "Title"
	vb.add_child(title)

	# 副标题
	var sub := UITheme.make_label("单 机 卡 牌 策 略", UITheme.FS_SUB, UITheme.TEXT_DIM)
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	sub.name = "Subtitle"
	vb.add_child(sub)

	vb.add_child(UITheme.make_spacer(UITheme.SP_XXL))

	# 提示文字
	_hint = UITheme.make_label("按 任 意 键 开 始", UITheme.FS_SUB, UITheme.TEXT)
	_hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_hint.name = "Hint"
	vb.add_child(_hint)


func _animate_entrance() -> void:
	# 标题：墨迹逐字展开
	var title = find_child("Title", true, false)
	if title:
		AnimHelper.ink_reveal(title, 1.2)

	# 副标题：延迟淡入
	var sub = find_child("Subtitle", true, false)
	if sub:
		sub.modulate.a = 0.0
		var tw2 = create_tween()
		tw2.tween_interval(0.6)
		tw2.tween_property(sub, "modulate:a", 1.0, 0.5)

	# 提示文字：延迟淡入后启动呼吸动画
	if _hint:
		_hint.modulate.a = 0.0
		var tw3 = create_tween()
		tw3.tween_interval(1.0)
		tw3.tween_property(_hint, "modulate:a", 1.0, 0.5)
		tw3.tween_callback(func():
			var breath = _hint.create_tween().set_loops()
			breath.tween_property(_hint, "modulate:a", 0.2, 0.8)
			breath.tween_property(_hint, "modulate:a", 1.0, 0.8)
		)


func _unhandled_input(event: InputEvent) -> void:
	if _entered:
		return
	if (event is InputEventKey and event.pressed) or (event is InputEventMouseButton and event.pressed):
		_entered = true
		AudioManager.play_sfx("button_click")
		var tw = create_tween()
		tw.tween_property(self, "modulate:a", 0.0, 0.3)
		tw.tween_callback(func(): get_tree().change_scene_to_file(MAIN_MENU))
