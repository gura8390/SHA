# ============================================================
# main_menu.gd
# 主菜单：开始对局 / 设置 / 退出
# 主题：墨色漆器 · 描金 · 朱砂印章
# ============================================================

extends Control

const GAME_SETUP := "res://scenes/ui/game_setup.tscn"
const SETTINGS := "res://scenes/ui/settings.tscn"


func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	# 墨底
	add_child(UITheme.make_bg(UITheme.BG_DEEP))

	# 居中容器
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(center)

	var vb := VBoxContainer.new()
	vb.alignment = BoxContainer.ALIGNMENT_CENTER
	vb.add_theme_constant_override("separation", UITheme.SP_M)
	center.add_child(vb)

	# 标题：书法体描金
	var title := UITheme.make_label("三  國  爭  霸", UITheme.FS_TITLE, UITheme.GOLD)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.name = "Title"
	vb.add_child(title)

	# 分隔
	vb.add_child(UITheme.make_spacer(UITheme.SP_L))

	# 按钮组：竖排居中，宽 280，非 accent（描边次按钮）
	var btn_play := UITheme.make_button("开 始 对 局")
	btn_play.custom_minimum_size = Vector2(280, 52)
	btn_play.pressed.connect(func(): AudioManager.play_sfx("button_click"); _switch_scene.call_deferred(GAME_SETUP))
	btn_play.name = "BtnPlay"
	vb.add_child(btn_play)

	var btn_set := UITheme.make_button("设  置")
	btn_set.custom_minimum_size = Vector2(280, 52)
	btn_set.pressed.connect(func(): AudioManager.play_sfx("button_click"); _switch_scene.call_deferred(SETTINGS))
	btn_set.name = "BtnSettings"
	vb.add_child(btn_set)

	var btn_quit := UITheme.make_button("退  出")
	btn_quit.custom_minimum_size = Vector2(280, 52)
	btn_quit.pressed.connect(func(): AudioManager.play_sfx("button_click"); get_tree().quit.call_deferred())
	btn_quit.name = "BtnQuit"
	vb.add_child(btn_quit)

	btn_play.grab_focus()

	# 版本号：左下角
	var version := UITheme.make_label("v0.3.1", UITheme.FS_SMALL, UITheme.TEXT_DIM)
	version.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
	version.position = Vector2(UITheme.SP_M, -UITheme.SP_L)
	add_child(version)

	# 入场动画
	_animate_entrance()

	# 按钮悬停动画
	for btn in [btn_play, btn_set, btn_quit]:
		btn.mouse_entered.connect(_btn_hover_enter.bind(btn))
		btn.mouse_exited.connect(_btn_hover_exit.bind(btn))

	# 音效
	AudioManager.play_sfx("game_start")


func _animate_entrance() -> void:
	# 标题：ink_reveal 从左到右晕染
	var title = find_child("Title", true, false)
	if title:
		AnimHelper.ink_reveal(title, 1.2)

	# 按钮：依次淡入
	var buttons = ["BtnPlay", "BtnSettings", "BtnQuit"]
	for i in range(buttons.size()):
		var btn = find_child(buttons[i], true, false)
		if btn:
			btn.modulate.a = 0.0
			var tw = create_tween()
			tw.tween_interval(0.4 + i * 0.12)
			tw.tween_property(btn, "modulate:a", 1.0, 0.3).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_QUAD)


func _btn_hover_enter(btn: Button) -> void:
	btn.pivot_offset = btn.size / 2.0
	AnimHelper.btn_hover_enter(btn)


func _btn_hover_exit(btn: Button) -> void:
	AnimHelper.btn_hover_exit(btn)


func _switch_scene(path: String) -> void:
	AnimHelper.scene_transition(self, func(): get_tree().change_scene_to_file(path))
