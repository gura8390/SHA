# ============================================================
# settings_screen.gd
# 设置页：音量（主/BGM/SFX）+ AI 速度，双向绑定 SettingsManager
# 主题：墨色漆器 · SCRIM 罩 + 金边面板
# ============================================================

extends Control

const MAIN_MENU := "res://scenes/ui/main_menu.tscn"

var _sm = null  # SettingsManager autoload

var _master_slider: HSlider
var _bgm_slider: HSlider
var _sfx_slider: HSlider
var _ai_slider: HSlider


func _ready() -> void:
	_sm = get_node_or_null("/root/SettingsManager")
	_build_ui()
	_load_into_ui()
	# 入场动画
	AnimHelper.fade_in(self, 0.3)


func _build_ui() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(UITheme.make_bg(UITheme.BG_DEEP))

	# SCRIM 罩 + 居中金边面板
	var overlay := UITheme.make_overlay_panel(true)
	var scrim = overlay[0]
	var vb = overlay[1]
	add_child(scrim)

	# 标题
	var title := UITheme.make_label("设  置", UITheme.FS_HEAD, UITheme.GOLD)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(title)

	vb.add_child(UITheme.make_spacer(UITheme.SP_M))

	# 音量滑块
	var slider_data: Array

	slider_data = UITheme.make_slider_row("主音量", 0, 100)
	vb.add_child(slider_data[0])
	_master_slider = slider_data[1]

	slider_data = UITheme.make_slider_row("音乐音量", 0, 100)
	vb.add_child(slider_data[0])
	_bgm_slider = slider_data[1]

	slider_data = UITheme.make_slider_row("音效音量", 0, 100)
	vb.add_child(slider_data[0])
	_sfx_slider = slider_data[1]

	vb.add_child(UITheme.make_spacer(UITheme.SP_S))

	slider_data = UITheme.make_slider_row("AI 速度", 0, 100)
	vb.add_child(slider_data[0])
	_ai_slider = slider_data[1]

	vb.add_child(UITheme.make_spacer(UITheme.SP_L))

	# 按钮行
	var btn_row := HBoxContainer.new()
	btn_row.add_theme_constant_override("separation", UITheme.SP_M)
	btn_row.alignment = BoxContainer.ALIGNMENT_CENTER
	vb.add_child(btn_row)

	var back_btn := UITheme.make_button("保存并返回", true)
	back_btn.custom_minimum_size = Vector2(200, 48)
	back_btn.pressed.connect(_on_back)
	btn_row.add_child(back_btn)

	# 连接交互
	_master_slider.value_changed.connect(func(v): if _sm: _sm.set_master_volume(v / 100.0))
	_bgm_slider.value_changed.connect(func(v): if _sm: _sm.set_bgm_volume(v / 100.0))
	_sfx_slider.value_changed.connect(func(v): if _sm: _sm.set_sfx_volume(v / 100.0))
	if _ai_slider:
		_ai_slider.value_changed.connect(func(v): if _sm: _sm.ai_play_delay = (100 - v) / 100.0 * 3.0)


func _load_into_ui() -> void:
	if _sm == null:
		return
	_master_slider.value = _sm.master_volume * 100.0
	_bgm_slider.value = _sm.bgm_volume * 100.0
	_sfx_slider.value = _sm.sfx_volume * 100.0
	if _ai_slider:
		_ai_slider.value = (1.0 - _sm.ai_play_delay / 3.0) * 100.0


func _on_back() -> void:
	if _sm:
		_sm.save_settings()
	AnimHelper.scene_transition(self, func(): get_tree().change_scene_to_file(MAIN_MENU))
