# ============================================================
# identity.gd
# 身份系统数据：身份枚举 + 标准配置表 + 分配器
#
# 三国杀身份局规则：
#   - 主公(LORD)：座位固定 0 号，体力上限 +1
#   - 忠臣(LOYALIST)：与主公同阵营，保护主公
#   - 反贼(REBEL)：击杀主公获胜
#   - 内奸(TRAITOR)：最后与主公单挑获胜
#
# 胜负条件：
#   - 主公/忠臣阵营胜：消灭所有反贼 + 内奸
#   - 反贼阵营胜：主公死亡（且场上仍有反贼，或不论）
#   - 内奸胜：场上仅剩主公与内奸，且内奸存活时主公死亡（这里简化为
#     "全场仅剩内奸一人存活"即内奸胜）
#
# Gemini:change.6: 新建——身份系统
# ============================================================

class_name Identity
extends RefCounted

# Gemini:change.6: 身份枚举
enum Type {
	LORD,        ## 主公
	LOYALIST,    ## 忠臣
	REBEL,       ## 反贼
	TRAITOR,     ## 内奸
}


# Gemini:change.6: 标准身份配置表（人数 → 各身份数量）
## 参考标准三国杀身份局配置，扩展到 12 人。
## 每项：[忠臣数, 反贼数, 内奸数]（主公恒为 1，不列入）
const CONFIG: Dictionary = {
	4:  {"loyalist": 1, "rebel": 2, "traitor": 0},
	5:  {"loyalist": 1, "rebel": 2, "traitor": 1},
	6:  {"loyalist": 1, "rebel": 3, "traitor": 1},
	7:  {"loyalist": 2, "rebel": 3, "traitor": 1},
	8:  {"loyalist": 2, "rebel": 4, "traitor": 1},
	9:  {"loyalist": 3, "rebel": 4, "traitor": 1},
	10: {"loyalist": 3, "rebel": 5, "traitor": 1},
	11: {"loyalist": 3, "rebel": 6, "traitor": 1},
	12: {"loyalist": 4, "rebel": 6, "traitor": 1},
}


# Gemini:change.6: 身份显示名
static func display_name(t: int) -> String:
	match t:
		Type.LORD: return "主公"
		Type.LOYALIST: return "忠臣"
		Type.REBEL: return "反贼"
		Type.TRAITOR: return "内奸"
		_: return "未知"


# Gemini:change.6: 身份显示颜色（供 UI）
static func display_color(t: int) -> Color:
	match t:
		Type.LORD: return Color(1.0, 0.84, 0.2)      # 金
		Type.LOYALIST: return Color(0.4, 0.7, 1.0)   # 蓝
		Type.REBEL: return Color(1.0, 0.4, 0.35)     # 红
		Type.TRAITOR: return Color(0.7, 0.5, 0.9)    # 紫
		_: return Color.WHITE


# Gemini:change.6: 按人数生成身份列表并分配座位
## 规则：座位 0 固定主公；其余身份随机打乱后依次分配到座位 1..n-1。
## @param rng: 可选确定性随机源（架构铁律 9）；为 null 时回退内置 shuffle。
## @return: Array[int]，下标=座位，值=Identity.Type
static func assign(player_count: int, rng: RngService = null) -> Array:
	var count: int = clampi(player_count, 4, 12)
	var cfg: Dictionary = CONFIG.get(count, CONFIG[4])

	# 主公固定座位 0
	var result: Array = []
	result.resize(count)
	result[0] = Type.LORD

	# 其余身份装入池后打乱
	var pool: Array = []
	for i in range(cfg.get("loyalist", 0)):
		pool.append(Type.LOYALIST)
	for i in range(cfg.get("rebel", 0)):
		pool.append(Type.REBEL)
	for i in range(cfg.get("traitor", 0)):
		pool.append(Type.TRAITOR)
	if rng != null:
		rng.shuffle(pool)
	else:
		pool.shuffle()

	# 依次分配到座位 1..n-1
	for seat in range(1, count):
		result[seat] = pool[seat - 1] if (seat - 1) < pool.size() else Type.REBEL

	return result


# Gemini:change.6: 该身份的初始体力加成（主公 +1）
static func hp_bonus(t: int) -> int:
	return 1 if t == Type.LORD else 0


# Gemini:change.12: 判断两个身份是否同阵营
## 主公+忠臣 = 同阵营；反贼 = 反贼阵营；内奸 = 独立阵营
static func is_ally(id_a: int, id_b: int) -> bool:
	if id_a == id_b:
		return true
	# 主公和忠臣互为友方
	if (id_a == Type.LORD and id_b == Type.LOYALIST) or (id_a == Type.LOYALIST and id_b == Type.LORD):
		return true
	return false
