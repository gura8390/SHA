# ============================================================
# hero_pool.gd
# 武将池：本作可选武将的静态目录（数据驱动玩家组装）
#
# 旧实现把 4 名武将硬编码在 game_manager 里。现在抽出为武将池，
# 供"武将选择界面"列举、供 game_manager 按 id 组装玩家。
#
# 数据来源：从 JsonDataLoader 动态加载 data/heroes/*.json
#
# Gemini:change.5: 新建——武将池，取代 game_manager 硬编码
# Gemini:change.9: 数据驱动——从 JsonDataLoader 加载
# ============================================================

class_name HeroPool
extends RefCounted

## 缓存的武将列表（从 JSON 加载后缓存）
static var _cached_heroes: Array[Dictionary] = []
static var _loaded: bool = false


## 从 JsonDataLoader 加载武将数据
static func _ensure_loaded() -> void:
	if _loaded:
		return
	_loaded = true
	_cached_heroes.clear()

	var jdl = Engine.get_main_loop().root.get_node_or_null("JsonDataLoader")
	if jdl == null:
		push_warning("[HeroPool] JsonDataLoader 未找到，使用内置默认武将")
		_load_fallback()
		return

	var defs: Array = jdl.get_all_hero_defs()
	for def in defs:
		var hero_entry := _json_def_to_hero_entry(def)
		if not hero_entry.is_empty():
			_cached_heroes.append(hero_entry)

	if _cached_heroes.is_empty():
		push_warning("[HeroPool] JSON 无武将数据，使用内置默认武将")
		_load_fallback()


## 将 JSON 武将定义转换为 HeroPool 内部格式
static func _json_def_to_hero_entry(def: Dictionary) -> Dictionary:
	var hero_id: String = def.get("id", "")
	var hero_name: String = def.get("name", "")
	if hero_id == "" or hero_name == "":
		return {}

	# 解析阵营
	var camp_str: String = def.get("camp", "群")
	var camp: int = HeroData.Camp.QUN
	match camp_str:
		"魏": camp = HeroData.Camp.WEI
		"蜀": camp = HeroData.Camp.SHU
		"吴": camp = HeroData.Camp.WU
		"群": camp = HeroData.Camp.QUN

	var hp: int = def.get("hp", 4)

	# 解析技能列表
	var skills_def: Array = def.get("skills", [])
	var skill_defs: Array = []
	for sk in skills_def:
		skill_defs.append({
			"skill_id": sk.get("id", ""),
			"skill_name": sk.get("name", ""),
			"skill_type": _parse_skill_type(sk.get("type", "trigger")),
			"skill_timing": _parse_trigger_timing(sk.get("timing", "none")),
			"skill_script": sk.get("script", ""),
			"limit": sk.get("limit", -1),
		})

	# 构造兼容 HeroPool 格式的字典
	var prefix: String = def.get("prefix", "")
	var display_name: String = def.get("display_name", hero_name)
	var entry: Dictionary = {
		"id": hero_id,
		"name": hero_name,
		"prefix": prefix,
		"display_name": display_name,
		"camp": camp,
		"hp": hp,
		"gender": def.get("gender", "male"),
		"skills": skill_defs,
	}

	# 兼容旧单技能格式（供 _build_player_from_def 回退用）
	if skill_defs.size() == 1:
		entry["skill_id"] = skill_defs[0]["skill_id"]
		entry["skill_name"] = skill_defs[0]["skill_name"]
		entry["skill_type"] = skill_defs[0]["skill_type"]
		entry["skill_timing"] = skill_defs[0]["skill_timing"]
		entry["skill_script"] = skill_defs[0]["skill_script"]
		entry["desc"] = skills_def[0].get("desc", "")
	elif skill_defs.size() > 1:
		entry["skill_id"] = skill_defs[0]["skill_id"]
		entry["skill_name"] = skill_defs[0]["skill_name"]
		entry["skill_type"] = skill_defs[0]["skill_type"]
		entry["skill_timing"] = skill_defs[0]["skill_timing"]
		entry["skill_script"] = skill_defs[0]["skill_script"]
		entry["desc"] = skills_def[0].get("desc", "")

	return entry


## 解析技能类型字符串
static func _parse_skill_type(type_str: String) -> int:
	match type_str:
		"active": return SkillData.SkillType.ACTIVE
		"trigger": return SkillData.SkillType.TRIGGER
		"compulsory": return SkillData.SkillType.COMPULSORY
		"passive": return SkillData.SkillType.PASSIVE
		"awaken": return SkillData.SkillType.AWAKEN
		_: return SkillData.SkillType.TRIGGER


## 解析触发时机字符串
static func _parse_trigger_timing(timing_str: String) -> int:
	match timing_str:
		"on_take_damage": return SkillData.TriggerTiming.ON_TAKE_DAMAGE
		"on_deal_damage": return SkillData.TriggerTiming.ON_DEAL_DAMAGE
		"on_card_used": return SkillData.TriggerTiming.ON_CARD_USED
		"on_phase_play": return SkillData.TriggerTiming.ON_PHASE_PLAY
		"on_phase_draw": return SkillData.TriggerTiming.ON_PHASE_DRAW
		"on_phase_judge": return SkillData.TriggerTiming.ON_JUDGE
		"on_turn_end": return SkillData.TriggerTiming.ON_TURN_END
		"on_equip_removed": return SkillData.TriggerTiming.ON_EQUIP_CHANGE
		"none": return SkillData.TriggerTiming.NONE
		_: return SkillData.TriggerTiming.NONE


## 内置默认武将（JSON 加载失败时的兜底）
static func _load_fallback() -> void:
	_cached_heroes = [
		{
			"id": "caocao", "name": "曹操", "camp": HeroData.Camp.WEI, "hp": 4,
			"skill_id": "jianxiong", "skill_name": "奸雄",
			"skill_type": SkillData.SkillType.TRIGGER,
			"skill_timing": SkillData.TriggerTiming.ON_TAKE_DAMAGE,
			"skill_script": "res://src/skills/skill_jianxiong.gd",
			"desc": "奸雄：当你受到伤害后，你可以获得造成伤害的牌。",
		},
		{
			"id": "guojia", "name": "郭嘉", "camp": HeroData.Camp.WEI, "hp": 3,
			"skill_id": "fankui", "skill_name": "反馈",
			"skill_type": SkillData.SkillType.TRIGGER,
			"skill_timing": SkillData.TriggerTiming.ON_TAKE_DAMAGE,
			"skill_script": "res://src/skills/skill_fankui.gd",
			"desc": "反馈：当你受到伤害后，你可以获得伤害来源的一张手牌。",
		},
		{
			"id": "zhangfei", "name": "张飞", "camp": HeroData.Camp.SHU, "hp": 4,
			"skill_id": "paoxiao", "skill_name": "咆哮",
			"skill_type": SkillData.SkillType.COMPULSORY,
			"skill_timing": SkillData.TriggerTiming.ON_PHASE_PLAY,
			"skill_script": "res://src/skills/skill_paoxiao.gd",
			"desc": "咆哮（锁定技）：出牌阶段，你使用【杀】无次数限制。",
		},
		{
			"id": "wumingshi", "name": "无名氏", "camp": HeroData.Camp.QUN, "hp": 4,
			"skill_id": "", "skill_name": "",
			"skill_type": SkillData.SkillType.PASSIVE,
			"skill_timing": SkillData.TriggerTiming.NONE,
			"skill_script": "",
			"desc": "无技能。",
		},
	]


# ============================================================
# 公共接口（保持与旧 API 兼容）
# ============================================================

## 全部武将
static func all() -> Array[Dictionary]:
	_ensure_loaded()
	return _cached_heroes


## 按 id 取武将（找不到返回空字典）
static func get_by_id(hero_id: String) -> Dictionary:
	_ensure_loaded()
	for h in _cached_heroes:
		if h.get("id", "") == hero_id:
			return h
	return {}


## 取武将的技能定义列表（架构改进——支持一武将多技能）
static func get_skill_defs(hero_def: Dictionary) -> Array:
	if hero_def.has("skills") and hero_def["skills"] is Array:
		return hero_def["skills"]
	# 回退：单技能字段
	if hero_def.get("skill_script", "") != "":
		return [{
			"skill_id": hero_def.get("skill_id", ""),
			"skill_name": hero_def.get("skill_name", ""),
			"skill_type": hero_def.get("skill_type", SkillData.SkillType.TRIGGER),
			"skill_timing": hero_def.get("skill_timing", SkillData.TriggerTiming.NONE),
			"skill_script": hero_def.get("skill_script", ""),
		}]
	return []


## 随机抽取 n 个不重复武将（供选择界面发牌）
static func draw_random(n: int) -> Array[Dictionary]:
	_ensure_loaded()
	var pool := _cached_heroes.duplicate()
	pool.shuffle()
	var result: Array[Dictionary] = []
	for i in range(min(n, pool.size())):
		result.append(pool[i])
	return result


## 数量
static func size() -> int:
	_ensure_loaded()
	return _cached_heroes.size()
