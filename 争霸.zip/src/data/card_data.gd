# ============================================================
# card_data.gd
# 卡牌静态数据（Resource）：定义一张卡牌的所有固定属性
# 运行时实际使用的卡牌实例只是对此 Resource 的引用
# 策划通过编辑器创建 .tres 文件配置每张卡牌
# Gemini:change.1: 初始创建——定义卡牌 Resource 数据结构
# ============================================================

class_name CardData
extends Resource

# Gemini:change.1: 卡牌花色枚举
enum Suit {
	SPADE,       ## 黑桃 ♠
	HEART,       ## 红心 ♥
	CLUB,        ## 梅花 ♣
	DIAMOND,     ## 方块 ♦
}

# Gemini:change.2: 修复命名冲突——重命名为 CardColor 避免与 Godot 内置 Color 类型冲突
enum CardColor {
	BLACK,       ## 黑色（黑桃、梅花）
	RED,         ## 红色（红心、方块）
}

# Gemini:change.1: 卡牌大类
enum CardType {
	BASIC,       ## 基本牌（杀、闪、桃）
	TRICK,       ## 锦囊牌
	EQUIPMENT,   ## 装备牌
}

# Gemini:change.1: 锦囊子类型
enum TrickType {
	NONE,        ## 非锦囊
	INSTANT,     ## 即时锦囊（过河拆桥、无中生有等）
	DELAYED,     ## 延时锦囊（乐不思蜀、兵粮寸断、闪电）
	AOE,         ## AOE锦囊（万箭齐发、南蛮入侵、桃园结义）
}

# Gemini:change.1: 装备子类型
enum EquipType {
	NONE,        ## 非装备
	WEAPON,      ## 武器
	ARMOR,       ## 防具
	HORSE_DEF,   ## 防御马（+1马）
	HORSE_ATK,   ## 进攻马（-1马）
	TREASURE,    ## 宝物
}

@export_group("标识")
## 卡牌唯一ID（如 "sha_spade_7" 表示黑桃7的杀）
@export var card_id: String = ""
## 卡牌显示名称（如 "杀"、"闪"、"南蛮入侵"）
@export var card_name: String = ""

@export_group("类型")
## 卡牌大类
@export var card_type: CardType = CardType.BASIC
## 锦囊子类型（仅锦囊牌有效）
@export var trick_type: TrickType = TrickType.NONE
## 装备子类型（仅装备牌有效）
@export var equip_type: EquipType = EquipType.NONE

@export_group("花色与点数")
## 花色
@export var suit: Suit = Suit.SPADE
## 点数（1=A, 2-10, 11=J, 12=Q, 13=K）
@export var rank: int = 1

@export_group("装备属性")
## 武器攻击范围（仅武器有效）
@export var weapon_range: int = 1
## 装备特殊效果脚本路径
@export var equip_effect_script: String = ""

@export_group("使用规则")
## 是否需要指定目标
@export var need_target: bool = true
## 可选目标数量（-1 = 全体，0 = 不需要，1+ = 指定数量）
@export var target_count: int = 1
## 是否可对自己使用
@export var can_target_self: bool = false
## 使用时的距离限制（-1 = 无限制）
@export var range_limit: int = -1

@export_group("表现")
## 卡牌描述文本
@export_multiline var description: String = ""
## 卡面贴图
@export var texture: Texture2D = null

@export_group("效果逻辑")
## 卡牌效果脚本路径（指向处理该卡牌结算逻辑的脚本）
@export var effect_script_path: String = ""


# Gemini:change.2: 获取卡牌颜色（返回类型修正为 CardColor）
func get_color() -> CardColor:
	if suit == Suit.HEART or suit == Suit.DIAMOND:
		return CardColor.RED
	return CardColor.BLACK


# Gemini:change.2: 判断是否为红色牌
func is_red() -> bool:
	return get_color() == CardColor.RED


# Gemini:change.2: 判断是否为黑色牌
func is_black() -> bool:
	return get_color() == CardColor.BLACK


# Gemini:change.1: 获取点数的显示字符串
func get_rank_display() -> String:
	match rank:
		1: return "A"
		11: return "J"
		12: return "Q"
		13: return "K"
		_: return str(rank)


# Gemini:change.1: 获取花色的显示字符串
func get_suit_display() -> String:
	match suit:
		Suit.SPADE: return "♠"
		Suit.HEART: return "♥"
		Suit.CLUB: return "♣"
		Suit.DIAMOND: return "♦"
		_: return "?"


# Gemini:change.1: 完整显示名称（如 "♠7 杀"）
func get_full_display_name() -> String:
	return "%s%s %s" % [get_suit_display(), get_rank_display(), card_name]
