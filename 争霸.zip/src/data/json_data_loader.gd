# ============================================================
# json_data_loader.gd
# JSON 数据加载器（Autoload 单例）
#
# 职责：
#   - 从 data/cards/*.json 加载所有卡牌定义
#   - 从 data/heroes/*.json 加载所有武将定义
#   - 提供按 id / name 的查询接口
#
# 设计：启动时一次性扫描加载，运行时只读。
# ============================================================

extends Node

## 卡牌定义字典（key = card id, value = JSON 字典）
var _cards: Dictionary = {}

## 武将定义字典（key = hero id, value = JSON 字典）
var _heroes: Dictionary = {}


func _ready() -> void:
	_load_all_cards()
	_load_all_heroes()
	print("[JsonDataLoader] 加载完成：卡牌 %d 张，武将 %d 名" % [_cards.size(), _heroes.size()])
	if _cards.is_empty():
		push_warning("[JsonDataLoader] 警告：卡牌数据为空！将使用内置默认数据。")
	if _heroes.is_empty():
		push_warning("[JsonDataLoader] 警告：武将数据为空！将使用内置默认数据。")


# ============================================================
# 加载逻辑（增强错误处理）
# ============================================================

func _load_all_cards() -> void:
	var dir_path := "res://data/cards/"
	# 尝试打开目录
	var dir := DirAccess.open(dir_path)
	if dir == null:
		push_warning("[JsonDataLoader] 无法打开卡牌目录: %s (错误码: %d)" % [dir_path, DirAccess.get_open_error()])
		# 备用方案：逐个尝试已知文件名
		_load_cards_fallback()
		return

	dir.list_dir_begin()
	var file_name := dir.get_next()
	var loaded_count := 0
	while file_name != "":
		if file_name.ends_with(".json"):
			var full_path := dir_path + file_name
			var card_def := _load_json_file(full_path)
			if not card_def.is_empty():
				var card_id: String = card_def.get("id", "")
				if card_id != "":
					_cards[card_id] = card_def
					loaded_count += 1
				else:
					push_warning("[JsonDataLoader] 卡牌文件缺少 id: %s" % full_path)
		file_name = dir.get_next()
	dir.list_dir_end()
	print("[JsonDataLoader] 从目录加载了 %d 张卡牌" % loaded_count)


func _load_all_heroes() -> void:
	var dir_path := "res://data/heroes/"
	var loaded_count := _scan_hero_dir(dir_path)
	print("[JsonDataLoader] 从目录加载了 %d 名武将" % loaded_count)
	if _heroes.is_empty():
		push_warning("[JsonDataLoader] 警告：武将数据为空！将使用内置默认数据。")
		_load_heroes_fallback()


## 递归扫描武将目录（支持子文件夹）
func _scan_hero_dir(dir_path: String) -> int:
	var dir := DirAccess.open(dir_path)
	if dir == null:
		push_warning("[JsonDataLoader] 无法打开武将目录: %s" % dir_path)
		return 0

	var loaded_count := 0
	dir.list_dir_begin()
	var file_name := dir.get_next()
	while file_name != "":
		if file_name.begins_with("."):
			file_name = dir.get_next()
			continue
		var full_path := dir_path + file_name
		if dir.current_is_dir():
			# 递归扫描子文件夹
			loaded_count += _scan_hero_dir(full_path + "/")
		elif file_name.ends_with(".json"):
			var hero_def := _load_json_file(full_path)
			if not hero_def.is_empty():
				var hero_id: String = hero_def.get("id", "")
				if hero_id != "":
					# 如果没有 prefix 字段，从文件夹路径推断
					if not hero_def.has("prefix"):
						hero_def["prefix"] = ""
					# 自动生成 display_name
					var prefix: String = hero_def.get("prefix", "")
					var hero_name: String = hero_def.get("name", "")
					if prefix != "":
						hero_def["display_name"] = prefix + hero_name
					else:
						hero_def["display_name"] = hero_name
					_heroes[hero_id] = hero_def
					loaded_count += 1
				else:
					push_warning("[JsonDataLoader] 武将文件缺少 id: %s" % full_path)
		file_name = dir.get_next()
	dir.list_dir_end()
	return loaded_count


## 备用加载：逐个尝试已知卡牌文件名
func _load_cards_fallback() -> void:
	var known_cards = [
		"sha", "huosha", "leisha", "shan", "tao", "jiu",
		"juedou", "guoheqiao", "shunshouqian", "wuzhongshengyou",
		"nanmanruqin", "wanjiangifa", "taoyuanjieyi", "wugufengdeng",
		"jiedaosharen", "wuxiekeji", "lebusishu", "bingliangduan", "shandian",
		"zhugeliannu", "cixiongshuangguanjian", "qinggangjian", "qinglongyanyuedao",
		"zhangbashequ", "guanshifu", "fangtianhuaji", "qilingong",
		"baguazhen", "renwangdun", "tengjia", "baiyinshizi",
		"dilu", "jueying", "chitu", "zhuahuang",
	]
	var loaded := 0
	for card_id in known_cards:
		var path := "res://data/cards/%s.json" % card_id
		if FileAccess.file_exists(path):
			var def := _load_json_file(path)
			if not def.is_empty() and def.has("id"):
				_cards[def["id"]] = def
				loaded += 1
		else:
			push_warning("[JsonDataLoader] 文件不存在: %s" % path)
	print("[JsonDataLoader] 备用方案加载了 %d 张卡牌" % loaded)


## 备用加载：逐个尝试已知武将文件名
func _load_heroes_fallback() -> void:
	var known_heroes = [
		"caocao", "guojia", "zhangfei", "liubei", "guanyu", "zhaoyun",
		"huangyueying", "sunquan", "zhouyu", "sunshangxiang", "zhangliao",
		"zhenji", "machao", "zhugeliang", "lvbu", "diaochan", "huatuo",
		"yuanshao", "wumingshi", "feiyi",
	]
	var loaded := 0
	for hero_id in known_heroes:
		var path := "res://data/heroes/%s.json" % hero_id
		if FileAccess.file_exists(path):
			var def := _load_json_file(path)
			if not def.is_empty() and def.has("id"):
				_heroes[def["id"]] = def
				loaded += 1
		else:
			push_warning("[JsonDataLoader] 文件不存在: %s" % path)
	print("[JsonDataLoader] 备用方案加载了 %d 名武将" % loaded)


func _load_json_file(path: String) -> Dictionary:
	if not FileAccess.file_exists(path):
		push_warning("[JsonDataLoader] 文件不存在: %s" % path)
		return {}
	var file := FileAccess.open(path, FileAccess.READ)
	if file == null:
		push_warning("[JsonDataLoader] 无法读取: %s (错误码: %d)" % [path, FileAccess.get_open_error()])
		return {}
	var text := file.get_as_text()
	file.close()
	if text.is_empty():
		push_warning("[JsonDataLoader] 文件为空: %s" % path)
		return {}
	var json := JSON.new()
	var error := json.parse(text)
	if error != OK:
		push_warning("[JsonDataLoader] JSON 解析失败: %s (行 %d: %s)" % [path, json.get_error_line(), json.get_error_message()])
		return {}
	var result = json.data
	if result is Dictionary:
		return result
	push_warning("[JsonDataLoader] JSON 顶层不是字典: %s" % path)
	return {}


# ============================================================
# 公共查询接口
# ============================================================

func get_card_def(card_id: String) -> Dictionary:
	return _cards.get(card_id, {})


func get_all_card_defs() -> Array:
	var result: Array = []
	for key in _cards:
		result.append(_cards[key])
	return result


func get_all_card_ids() -> Array:
	return _cards.keys()


func get_hero_def(hero_id: String) -> Dictionary:
	return _heroes.get(hero_id, {})


func get_all_hero_defs() -> Array:
	var result: Array = []
	for key in _heroes:
		result.append(_heroes[key])
	return result


func get_all_hero_ids() -> Array:
	return _heroes.keys()


func get_card_defs_by_name(card_name: String) -> Array:
	var result: Array = []
	for key in _cards:
		if _cards[key].get("name", "") == card_name:
			result.append(_cards[key])
	return result


func get_first_card_def_by_name(card_name: String) -> Dictionary:
	for key in _cards:
		if _cards[key].get("name", "") == card_name:
			return _cards[key]
	return {}
