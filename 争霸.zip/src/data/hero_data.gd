# ============================================================
# hero_data.gd
# 武将静态数据（Resource）：定义一名武将的所有固定属性
# 策划通过编辑器创建 .tres 文件配置每个武将
# 注意：skills 字段使用 Array[SkillData]，非 Array[String]
# Gemini:change.1: 初始创建——定义武将 Resource 数据结构
# ============================================================

class_name HeroData
extends Resource

# Gemini:change.1: 势力/阵营枚举
enum Camp {
	WEI,     ## 魏
	SHU,     ## 蜀
	WU,      ## 吴
	QUN,     ## 群
}

# Gemini:change.1: 性别枚举
enum Gender {
	MALE,    ## 男
	FEMALE,  ## 女
}

@export_group("基础信息")
## 武将唯一ID（如 "guan_yu"、"zhao_yun"）
@export var hero_id: String = ""
## 武将显示名称（如 "关羽"、"赵云"）
@export var hero_name: String = ""
## 势力/阵营
@export var camp: Camp = Camp.WEI
## 性别
@export var gender: Gender = Gender.MALE

@export_group("属性")
## 体力上限
@export var max_hp: int = 4
## 初始体力（通常等于 max_hp，主公可能+1）
@export var start_hp: int = 4

@export_group("技能")
## 武将技能配置列表（直接引用 SkillData Resource）
## 使用 Array[SkillData] 而非 Array[String]
## 确保数据完整性，编辑器中可直接拖拽配置
@export var skills: Array[SkillData] = []

@export_group("表现")
## 武将立绘
@export var portrait: Texture2D = null
## 武将描述/传记
@export_multiline var description: String = ""
## 武将称号（如 "美髯公"、"常胜将军"）
@export var title: String = ""


# Gemini:change.1: 获取势力显示名称
func get_camp_display() -> String:
	match camp:
		Camp.WEI: return "魏"
		Camp.SHU: return "蜀"
		Camp.WU: return "吴"
		Camp.QUN: return "群"
		_: return "?"


# Gemini:change.1: 获取性别显示名称
func get_gender_display() -> String:
	match gender:
		Gender.MALE: return "男"
		Gender.FEMALE: return "女"
		_: return "?"


# Gemini:change.1: 获取技能数量
func get_skill_count() -> int:
	return skills.size()
