# ============================================================
# skill_data.gd
# 技能配置数据（Resource）：存储技能的静态配置信息
# 策划在编辑器中通过 Inspector 配置技能参数
# 运行时由 Skill 类读取此数据驱动逻辑
# Gemini:change.1: 初始创建——定义技能 Resource 配置结构
# ============================================================

class_name SkillData
extends Resource

# Gemini:change.1: 技能类型枚举
enum SkillType {
	ACTIVE,          ## 主动技：出牌阶段主动选择发动
	TRIGGER,         ## 触发技：满足条件时可选择是否发动
	COMPULSORY,      ## 锁定技：满足条件时强制发动，不可选择
	PASSIVE,         ## 状态技：持续生效的被动能力（如马术，修正属性）
	AWAKEN,          ## 觉醒技：满足条件时一次性永久觉醒（如界曹操"雄才"前置）
}

# Gemini:change.1: 技能触发时机枚举
enum TriggerTiming {
	NONE,                ## 无（主动技使用）
	ON_TURN_START,       ## 回合开始时
	ON_TURN_END,         ## 回合结束时
	ON_PHASE_DRAW,       ## 摸牌阶段
	ON_PHASE_PLAY,       ## 出牌阶段
	ON_PHASE_DISCARD,    ## 弃牌阶段
	ON_DEAL_DAMAGE,      ## 造成伤害时
	ON_TAKE_DAMAGE,      ## 受到伤害时
	ON_CARD_USED,        ## 使用牌时
	ON_BECOME_TARGET,    ## 成为目标时
	ON_DYING,            ## 濒死时
	ON_DEATH,            ## 角色死亡时
	ON_DRAW_CARD,        ## 摸牌时
	ON_DISCARD_CARD,     ## 弃牌时
	ON_LOSE_HP,          ## 失去体力时
	ON_RECOVER_HP,       ## 回复体力时
	ON_JUDGE,            ## 判定时
	ON_EQUIP_CHANGE,     ## 装备变化时
	ON_RESPOND,          ## 需要响应时（如被杀需出闪）
	CUSTOM,              ## 自定义时机（由技能脚本自行处理）
}

@export_group("基础信息")
## 技能唯一标识
@export var id: String = ""
## 技能显示名称
@export var skill_name: String = ""
## 技能类型
@export var skill_type: SkillType = SkillType.TRIGGER
## 技能描述（给玩家看的）
@export_multiline var description: String = ""

@export_group("触发配置")
## 触发时机
@export var trigger_timing: TriggerTiming = TriggerTiming.NONE
## 每回合可发动次数限制（-1 = 无限）
@export var use_limit_per_turn: int = -1
## 每局可发动次数限制（-1 = 无限）
@export var use_limit_per_game: int = -1

@export_group("逻辑脚本")
## 技能运行时逻辑脚本路径（继承 Skill 的 .gd 文件）
@export var skill_script_path: String = ""

@export_group("主动技配置")
## Gemini:change.7: 主动技是否需要指定目标
@export var active_need_target: bool = false
## 主动技目标数量（-1=任意/全体，0=无，1+=指定）
@export var active_target_count: int = 1

@export_group("被动/属性修正配置")
## Gemini:change.7: 该技能是否会修正属性（被动技地基）
## 为 true 时，属性查询（攻击范围/手牌上限/距离等）会调用本技能的 modify_attribute
@export var modifies_attributes: bool = false

@export_group("觉醒技配置")
## Gemini:change.7: 觉醒后是否转为锁定技持续生效
@export var awaken_becomes_compulsory: bool = true

@export_group("表现")
## 技能图标（可选）
@export var icon: Texture2D = null
## 技能语音路径（可选）
@export var voice_path: String = ""
