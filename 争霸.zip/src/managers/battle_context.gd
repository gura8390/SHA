# ============================================================
# battle_context.gd
# 战场上下文：整局战斗的数据中心
# 所有系统通过此对象访问和修改战局数据
# 禁止各系统直接依赖 GameManager 获取数据
# 设计原则：BattleContext 只是数据容器+简单查询接口，不含业务逻辑
# Gemini:change.1: 初始创建——定义战场数据容器
# ============================================================

class_name BattleContext
extends RefCounted

# Gemini:change.1: 游戏阶段枚举
enum Phase {
	NONE,            ## 未开始
	ROUND_START,     ## 回合开始
	PHASE_JUDGE,     ## 判定阶段
	PHASE_DRAW,      ## 摸牌阶段
	PHASE_PLAY,      ## 出牌阶段
	PHASE_DISCARD,   ## 弃牌阶段
	ROUND_END,       ## 回合结束
}

# Gemini:change.1: 玩家运行时数据结构（内嵌类）
# 存储每个玩家的完整动态状态
class PlayerState:
	extends RefCounted

	## 玩家索引（座位号，0-based）
	var index: int = -1
	## 关联的武将静态数据
	var hero_data: HeroData = null
	## 是否为人类玩家
	var is_human: bool = false
	## 当前体力
	var current_hp: int = 4
	## 体力上限
	var max_hp: int = 4
	## 是否存活
	var is_alive: bool = true
	## 手牌列表
	var hand_cards: Array = []  # Array[CardData]
	## 装备区
	var equip_weapon: CardData = null
	var equip_armor: CardData = null
	var equip_horse_def: CardData = null   # +1马
	var equip_horse_atk: CardData = null   # -1马
	var equip_treasure: CardData = null
	## 判定区（延时锦囊）
	var judge_cards: Array = []  # Array[CardData]
	## 技能实例列表（运行时 Skill 对象）
	var skills: Array = []  # Array[Skill]
	## 本回合已出杀次数
	var kill_count_this_turn: int = 0
	## 本回合出杀上限
	var kill_limit: int = 1
	## 是否使用过酒
	var wine_used: bool = false
	## 是否翻面
	var is_flipped: bool = false
	## 是否横置（连环）
	var is_chained: bool = false
	## Gemini:change.6: 身份（Identity.Type），-1 表示未分配
	var identity: int = -1
	## Gemini:change.6: 身份是否已对所有人公开（明身份局或已死亡翻开）
	var identity_revealed: bool = false
	## Gemini:change.9: 本回合跳过出牌阶段（乐不思蜀）
	var skip_play_phase: bool = false
	## Gemini:change.9: 本回合跳过摸牌阶段（兵粮寸断）
	var skip_draw_phase: bool = false

	## 获取手牌上限
	## Gemini:change.7: 经被动技修正（如某些技能改手牌上限）
	func get_hand_limit() -> int:
		return _apply_skill_modifiers("hand_limit", current_hp)

	## 获取攻击距离
	## Gemini:change.7: 武器范围 + 被动技修正（如马术/武器特性）
	func get_attack_range() -> int:
		var base := 1
		if equip_weapon:
			base = equip_weapon.weapon_range
		return _apply_skill_modifiers("attack_range", base)

	## Gemini:change.7: 被动技属性修正通道
	## 遍历持有者技能中标记 modifies_attributes 的，依次调用 modify_attribute。
	## @param attr_name: 属性名
	## @param base_value: 基础值
	## @param ctx_data: 附加上下文
	func _apply_skill_modifiers(attr_name: String, base_value, ctx_data: Dictionary = {}):
		var value = base_value
		for skill in skills:
			if skill == null:
				continue
			if skill.skill_data != null and skill.skill_data.modifies_attributes:
				value = skill.modify_attribute(attr_name, value, ctx_data)
		return value

	## 重置回合状态
	func reset_turn_state() -> void:
		kill_count_this_turn = 0
		kill_limit = 1
		wine_used = false
		skip_play_phase = false
		skip_draw_phase = false
		# 重置每个技能的回合计数
		for skill in skills:
			skill.reset_turn_count()


# ===== 战局数据 =====

# Gemini:change.1: 所有玩家状态列表（含已死亡）
var players: Array = []  # Array[PlayerState]

# Gemini:change.1: 抽牌堆
var draw_pile: Array = []  # Array[CardData]

# Gemini:change.1: 弃牌堆
var discard_pile: Array = []  # Array[CardData]

# Gemini:change.1: 当前回合玩家索引
var current_player_index: int = 0

# Gemini:change.1: 当前阶段
var current_phase: Phase = Phase.NONE

# Gemini:change.1: 当前回合数（从1开始）
var turn_index: int = 0

# Gemini:change.1: 动作队列引用
var action_queue: ActionQueue = null

# Gemini:change.2: 系统引用（由 GameManager 注入）
var death_resolver = null
var card_resolver = null
var judge_system = null  # Gemini:change.9: 判定系统
var deck_manager = null  # Gemini:change.13: 牌堆管理器（用于回收洗牌回调）

# 内核重写：确定性随机源（架构铁律 9）。由 GameManager 注入。
var rng: RngService = null
# 内核重写：牌位真值登记表（单一真值原则）。由 GameManager 注入。
var registry: CardLocationRegistry = null

# Gemini:change.2: 玩家控制器注册表（key=player_index, value=IPlayerController 实现对象）
# AI 与人类控制器都注册在此，ResponseRequest/SkillTriggerPipeline 通过此表查询
var controllers: Dictionary = {}


# ===== 查询接口 =====

# Gemini:change.1: 获取指定索引的玩家状态
func get_player(index: int) -> PlayerState:
	if index >= 0 and index < players.size():
		return players[index]
	return null


# Gemini:change.1: 获取当前回合玩家
func get_current_player() -> PlayerState:
	return get_player(current_player_index)


# Gemini:change.1: 获取所有存活玩家列表
func get_alive_players() -> Array:
	var alive: Array = []
	for player in players:
		if player.is_alive:
			alive.append(player)
	return alive


# Gemini:change.6: 获取主公（找不到返回 null）
func get_lord():
	for player in players:
		if player.identity == Identity.Type.LORD:
			return player
	return null


# Gemini:change.6: 按身份取存活玩家列表
func get_alive_by_identity(identity_type: int) -> Array:
	var result: Array = []
	for player in players:
		if player.is_alive and player.identity == identity_type:
			result.append(player)
	return result


# Gemini:change.2: 注册玩家控制器（AI/人类）
## GameManager 在初始化玩家时为每个玩家注册其控制器
func register_controller(player_index: int, controller) -> void:
	controllers[player_index] = controller


# Gemini:change.2: 获取指定玩家的控制器（无则返回 null）
func get_controller(player_index: int):
	return controllers.get(player_index, null)


# Gemini:change.1: 获取存活玩家数量
func get_alive_count() -> int:
	var count: int = 0
	for player in players:
		if player.is_alive:
			count += 1
	return count


# Gemini:change.2: 从牌堆顶摸一张牌（自动处理牌堆耗尽回收）
## 严格的所有权转移：一张牌在任一时刻只属于一个区域
## （手牌 / 抽牌堆 / 弃牌堆 / 装备区 / 判定区 / 结算中）
func draw_from_pile() -> CardData:
	if draw_pile.is_empty():
		_recycle_discard_pile()
	if draw_pile.is_empty():
		return null  # 极端情况：牌堆彻底为空（抽+弃都空）
	# pop_back 本身就是所有权转移：从 draw_pile 移除，返回给调用方
	return draw_pile.pop_back()


# Gemini:change.1: 将牌放入弃牌堆
## 调用方必须保证此牌已从原区域移除（所有权转交）
func add_to_discard_pile(card: CardData) -> void:
	discard_pile.append(card)


# Gemini:change.2: 弃牌堆回收洗入抽牌堆（所有权整体转移，非拷贝）
## 旧实现用 duplicate()+clear() 容易引起引用歧义；改为直接搬运数组对象
## Gemini:change.13: 回收洗牌后通知 DeckManager 记录牌序
func _recycle_discard_pile() -> void:
	# 把弃牌堆整个数组对象交给抽牌堆，弃牌堆换一个空数组
	# 这样不存在两个数组同时持有同一批元素引用的中间态
	draw_pile = discard_pile
	discard_pile = []
	_shuffle(draw_pile)
	# Gemini:change.13: 通知 DeckManager 记录本次回收洗牌
	if deck_manager != null:
		deck_manager.on_recycle_shuffle(draw_pile)


## 洗牌：优先用确定性 RngService（架构铁律 9），回退到内置 shuffle。
func _shuffle(arr: Array) -> void:
	if rng != null:
		rng.shuffle(arr)
	else:
		arr.shuffle()


# Gemini:change.1: 计算两个玩家之间的座位距离
## 考虑存活玩家的环形座位排列
func get_distance(from_index: int, to_index: int) -> int:
	if from_index == to_index:
		return 0
	var alive = get_alive_players()
	var alive_indices: Array = []
	for p in alive:
		alive_indices.append(p.index)

	var from_pos = alive_indices.find(from_index)
	var to_pos = alive_indices.find(to_index)
	if from_pos == -1 or to_pos == -1:
		return 999  # 无效目标

	var total = alive_indices.size()
	var clockwise = (to_pos - from_pos + total) % total
	var counter_clockwise = (from_pos - to_pos + total) % total
	var base_distance = mini(clockwise, counter_clockwise)

	# Gemini:change.1: 考虑马匹修正
	var from_player = get_player(from_index)
	var to_player = get_player(to_index)
	var modifier: int = 0
	# 进攻方的-1马减少距离
	if from_player and from_player.equip_horse_atk:
		modifier -= 1
	# 防御方的+1马增加距离
	if to_player and to_player.equip_horse_def:
		modifier += 1

	var dist := maxi(1, base_distance + modifier)

	# Gemini:change.7: 被动技对距离的修正（如马术：计算与他人距离-1）
	if from_player:
		dist = from_player._apply_skill_modifiers("distance_from", dist, {"to": to_index})
	if to_player:
		dist = to_player._apply_skill_modifiers("distance_to", dist, {"from": from_index})
	return maxi(1, dist)


# Gemini:change.1: 获取指定玩家的下家（存活）
func get_next_alive_player(from_index: int) -> PlayerState:
	var alive = get_alive_players()
	if alive.is_empty():
		return null
	var current_pos = -1
	for i in range(alive.size()):
		if alive[i].index == from_index:
			current_pos = i
			break
	if current_pos == -1:
		return alive[0]
	var next_pos = (current_pos + 1) % alive.size()
	return alive[next_pos]


# Gemini:change.1: 初始化牌堆（传入完整卡牌列表后洗牌）
func init_draw_pile(cards: Array) -> void:
	draw_pile = cards.duplicate()
	_shuffle(draw_pile)


# Gemini:change.12: 查询玩家是否有技能可将某张牌转化为目标牌
## 遍历玩家技能，查找含 can_convert(card, target_name, phase) 静态方法的技能
## 返回第一个匹配的转化结果 {skill, virtual_card}，或 null
func get_card_conversion(player_index: int, target_card_name: String, phase: int = -1):
	var player = get_player(player_index)
	if player == null or not player.is_alive:
		return null
	for sk in player.skills:
		if sk == null:
			continue
		if sk.has_method("can_convert"):
			var result = sk.can_convert(target_card_name, phase)
			if result != null:
				return {"skill": sk, "virtual_card": result}
	return null


# Gemini:change.12: 获取玩家手牌中可用于转化的牌列表
## 对于每个转化技能，返回 {skill, cards} 其中 cards 是可转化为 target_name 的手牌列表
## 按优先级排序：PASSIVE（被动转化）> COMPULSORY > TRIGGER > ACTIVE
func get_convertible_cards(player_index: int, target_card_name: String, phase: int = -1) -> Array:
	var player = get_player(player_index)
	if player == null or not player.is_alive:
		return []
	var results: Array = []
	for sk in player.skills:
		if sk == null:
			continue
		if sk.has_method("get_convertible_cards"):
			# 传递 owner_index 和 current_player_index 供技能判断回合内外
			var cards = sk.get_convertible_cards(player.hand_cards, target_card_name, phase, player_index, current_player_index)
			if not cards.is_empty():
				results.append({"skill": sk, "cards": cards})
	# 按技能类型优先级排序：PASSIVE > COMPULSORY > TRIGGER > ACTIVE
	var type_priority := {
		SkillData.SkillType.PASSIVE: 0,
		SkillData.SkillType.COMPULSORY: 1,
		SkillData.SkillType.TRIGGER: 2,
		SkillData.SkillType.ACTIVE: 3,
		SkillData.SkillType.AWAKEN: 4,
	}
	results.sort_custom(func(a, b):
		var pa = type_priority.get(a["skill"].skill_data.skill_type, 99) if a["skill"].skill_data else 99
		var pb = type_priority.get(b["skill"].skill_data.skill_type, 99) if b["skill"].skill_data else 99
		return pa < pb
	)
	return results
