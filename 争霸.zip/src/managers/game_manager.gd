# ============================================================
# game_manager.gd
# 游戏主控制器（Autoload 单例）：协调各子系统、驱动回合流转
#
# Gemini:change.3: 重构——整合全部子系统
#   - DeathResolver 接管濒死求桃（修 Bug-3）
#   - SkillTriggerPipeline 接管触发技询问（修 Bug-12）
#   - CardResolver 接入距离校验（修 Bug-9）
#   - PlayCardEffect 统一使用牌流程（修 Bug-4/5）
#   - SimpleAI 实现 IPlayerController 接口
#   - ResponseRequest 异步响应管道
# ============================================================

extends Node

# ===== 信号（供 UI 监听）=====
signal game_initialized()
signal round_started(player_index: int, round_number: int)
signal round_ended(player_index: int)
signal phase_changed(player_index: int, phase: BattleContext.Phase)
signal game_over(winner_info: Dictionary)

# ===== 核心引用 =====
var context: BattleContext = null
var action_queue: ActionQueue = null
var deck_manager: DeckManager = null
var ai: SmartAI = null
var logger: BattleLogger = null
var death_resolver: DeathResolver = null
var skill_pipeline: SkillTriggerPipeline = null
var card_resolver: CardResolver = null
var judge_system: JudgeSystem = null  # Gemini:change.9

# Gemini:change.4: 人类玩家配置
## 指定哪个座位是人类（-1 = 全 AI）。由 UI 在 start 前设置。
var human_player_index: int = -1
## 人类控制器引用（供 UI 监听其请求信号 / 回填操作）
var human_controller: HumanController = null

# Gemini:change.5: 本局组装参数（由 setup_match 设置，_init_test_players 读取）
var _match_player_count: int = 4
var _match_human_hero_id: String = ""
## 是否有人类参战（true=组装 HumanController 并随机人类座位）
var _match_has_human: bool = true
## Gemini:change.6: 是否明身份局（所有人身份开局即公开）
var _match_reveal_identity: bool = false
## 内核重写：本局随机种子（-1=随机生成）。用于确定性/回放（架构铁律 9）。
var _match_seed: int = -1

# ===== 游戏状态 =====
var _is_game_running: bool = false
const MAX_ROUNDS: int = 200


# ============================================================
# 初始化
# ============================================================

# Gemini:change.5: 配置本局参数（UI 在 setup_game 前调用）
## @param player_count: 总人数（4~12，含 1 名人类）
## @param human_hero_id: 人类选定武将 id（""=随机）
## @param has_human: 是否有人类参战（false = 全 AI 观战）
## @param reveal_identity: 是否明身份局（Gemini:change.6）
func configure_match(player_count: int, human_hero_id: String = "", has_human: bool = true, reveal_identity: bool = false) -> void:
	_match_player_count = clampi(player_count, 4, 12)
	_match_human_hero_id = human_hero_id
	_match_has_human = has_human
	_match_reveal_identity = reveal_identity


# Gemini:change.4: 启动一局游戏（便捷：含/不含人类）
## @param human_idx: 兼容旧签名。>=0 表示有人类（座位随机，不再用此值）；
##                   -1 表示全 AI。新代码请改用 configure_match + setup_game + begin_game。
##
## 注意（修死锁）：本方法 = setup_game() + begin_game()。
## 若调用方需要在"游戏开始前"连接 human_controller 的请求信号
## （UI 场景就是这种情况），必须改为：
##     gm.configure_match(count, hero_id)
##     gm.setup_game()
##     gm.human_controller.play_requested.connect(...)   # 先连信号
##     gm.begin_game()                                   # 再开第一回合
## 否则第一回合的 play_requested 会在信号连接前发出，导致人类永远收不到、卡死。
func start_test_game(human_idx: int = -1) -> void:
	configure_match(_match_player_count, _match_human_hero_id, human_idx >= 0)
	setup_game()
	begin_game()


# Gemini:change.4: 建立一局所需的全部子系统、玩家、初始手牌（不开始回合）
func setup_game() -> void:
	# Gemini:change.10: 清理旧订阅（再来一局时防止重复触发）
	if skill_pipeline != null:
		skill_pipeline.cleanup()
	if logger != null:
		logger.cleanup()
	WuxieInquiry.clear_skip_all()

	human_player_index = -1  # 由 _init_test_players 决定（随机人类座位）

	# 创建战场上下文
	context = BattleContext.new()

	# 内核重写：确定性随机源（架构铁律 9）+ 牌位真值登记表（单一真值）
	context.rng = RngService.new()
	context.rng.setup(_match_seed)
	context.registry = CardLocationRegistry.new()
	context.registry.setup(context)

	# 创建动作队列
	action_queue = ActionQueue.new()
	action_queue.setup(context)
	context.action_queue = action_queue

	# 创建牌堆管理器并构建测试牌组
	deck_manager = DeckManager.new()
	deck_manager.setup(context)
	context.deck_manager = deck_manager  # Gemini:change.13: 注入引用供回收洗牌回调
	deck_manager.build_test_deck()

	# 创建子系统
	card_resolver = CardResolver.new()
	death_resolver = DeathResolver.new()
	death_resolver.setup(context)
	context.death_resolver = death_resolver
	context.card_resolver = card_resolver

	# Gemini:change.9: 判定系统
	judge_system = JudgeSystem.new()
	judge_system.setup(context)
	context.judge_system = judge_system

	skill_pipeline = SkillTriggerPipeline.new()
	skill_pipeline.setup(context)

	ai = SmartAI.new()
	ai.setup(context, card_resolver)

	# Gemini:change.5: 有人类参战时创建人类控制器（座位在 _init_test_players 随机）
	if _match_has_human:
		human_controller = HumanController.new()
		human_controller.setup(context, card_resolver)
	else:
		human_controller = null

	# 创建日志
	logger = BattleLogger.new()
	logger.setup(context)

	# 按武将池 + 配置组装玩家并注册控制器
	_init_test_players()

	# 发放初始手牌
	_deal_initial_hands()

	# 内核重写：装配完成后，从既有区域数组对齐牌位真值表（单一真值原则）
	context.registry.sync_from_context()


# Gemini:change.4: 开始游戏（发 game_initialized 并启动第一回合）
func begin_game() -> void:
	_is_game_running = true
	game_initialized.emit()

	# 打印初始状态
	logger.print_status_summary()

	# 开始第一个回合
	_start_next_round()


# Gemini:change.5: 从武将池 + 开局配置组装玩家（动态人数 + 随机座位）
## Gemini:change.6: 增加身份分配 + 武将去重
func _init_test_players() -> void:
	var count: int = clampi(_match_player_count, 4, 12)
	# 随机人类座位（无人类则保持 -1）
	if _match_has_human:
		human_player_index = context.rng.randi_below(count)
	else:
		human_player_index = -1

	# Gemini:change.6: 分配身份（座位 0 固定主公，其余随机）
	var identities: Array = Identity.assign(count, context.rng)

	# Gemini:change.6: 为每个座位分配不重复的武将
	var hero_assignment: Array = _assign_heroes(count)

	for seat in range(count):
		_build_player_from_def(seat, hero_assignment[seat], identities[seat])


# Gemini:change.6: 为每个座位分配武将，保证不重复（池不足时才允许循环补充）
## 人类座位用其选定武将；其余座位从"剩余池"按序不重复抽取。
## Gemini:change.10: 防御性检查——池为空时使用内置兜底武将
func _assign_heroes(count: int) -> Array:
	var result: Array = []
	result.resize(count)

	# 剩余池（打乱），并记录已用 id
	var all_heroes: Array = HeroPool.all()
	if all_heroes.is_empty():
		push_warning("[GameManager] HeroPool 为空，使用内置兜底武将")
		all_heroes = _get_fallback_heroes()
	var remaining: Array = all_heroes.duplicate()
	context.rng.shuffle(remaining)
	var used_ids: Dictionary = {}

	# 先确定人类武将（从池中剔除）
	if human_player_index >= 0:
		var human_def: Dictionary = HeroPool.get_by_id(_match_human_hero_id)
		if human_def.is_empty():
				if remaining.is_empty():
					remaining = all_heroes.duplicate()
					context.rng.shuffle(remaining)
				human_def = remaining[0]
		result[human_player_index] = human_def
		used_ids[human_def.get("id", "")] = true
		_remove_hero_from_pool(remaining, human_def.get("id", ""))

	# 其余座位按序从剩余池抽取
	for seat in range(count):
		if seat == human_player_index:
			continue
		if remaining.is_empty():
			remaining = all_heroes.duplicate()
			context.rng.shuffle(remaining)
		if remaining.is_empty():
			# 极端情况：连兜底都为空，创建一个默认武将
			result[seat] = {"id": "default", "name": "玩家%d" % seat, "camp": HeroData.Camp.QUN, "hp": 4}
		else:
			var def: Dictionary = remaining.pop_back()
			result[seat] = def
			used_ids[def.get("id", "")] = true

	return result


## 内置兜底武将（HeroPool 和 JSON 都失败时用）
func _get_fallback_heroes() -> Array:
	return [
		{"id": "caocao", "name": "曹操", "camp": HeroData.Camp.WEI, "hp": 4,
			"skill_id": "jianxiong", "skill_name": "奸雄",
			"skill_type": SkillData.SkillType.TRIGGER,
			"skill_timing": SkillData.TriggerTiming.ON_TAKE_DAMAGE,
			"skill_script": "res://src/skills/skill_jianxiong.gd", "desc": "奸雄"},
		{"id": "guojia", "name": "郭嘉", "camp": HeroData.Camp.WEI, "hp": 3,
			"skill_id": "fankui", "skill_name": "反馈",
			"skill_type": SkillData.SkillType.TRIGGER,
			"skill_timing": SkillData.TriggerTiming.ON_TAKE_DAMAGE,
			"skill_script": "res://src/skills/skill_fankui.gd", "desc": "反馈"},
		{"id": "zhangfei", "name": "张飞", "camp": HeroData.Camp.SHU, "hp": 4,
			"skill_id": "paoxiao", "skill_name": "咆哮",
			"skill_type": SkillData.SkillType.COMPULSORY,
			"skill_timing": SkillData.TriggerTiming.ON_PHASE_PLAY,
			"skill_script": "res://src/skills/skill_paoxiao.gd", "desc": "咆哮"},
		{"id": "wumingshi", "name": "无名氏", "camp": HeroData.Camp.QUN, "hp": 4,
			"skill_id": "", "skill_name": "", "skill_script": "", "desc": "无技能"},
	]


# Gemini:change.6: 从池数组移除指定 id 的武将
func _remove_hero_from_pool(pool: Array, hero_id: String) -> void:
	for i in range(pool.size() - 1, -1, -1):
		if pool[i].get("id", "") == hero_id:
			pool.remove_at(i)


# Gemini:change.5: 根据武将定义构建一个 PlayerState 并注册控制器
## Gemini:change.6: 增加身份参数 + 主公体力加成
func _build_player_from_def(seat: int, hero_def: Dictionary, identity_type: int) -> void:
	var p = BattleContext.PlayerState.new()
	p.index = seat
	var base_hp: int = hero_def.get("hp", 4)
	# Gemini:change.6: 主公体力上限 +1
	var bonus: int = Identity.hp_bonus(identity_type)
	p.max_hp = base_hp + bonus
	p.current_hp = p.max_hp
	p.identity = identity_type
	# Gemini:change.6: 明身份局或主公始终可见
	p.identity_revealed = _match_reveal_identity or identity_type == Identity.Type.LORD
	p.hero_data = _create_hero(hero_def.get("name", "玩家%d" % seat), hero_def.get("camp", HeroData.Camp.QUN), p.max_hp, hero_def.get("gender", "male"))

	# Gemini:change.6: 安装该武将全部技能（支持一武将多技能）
	for sk in HeroPool.get_skill_defs(hero_def):
		var script_path: String = sk.get("skill_script", "")
		if script_path == "":
			continue
		var script_class = load(script_path)
		if script_class != null:
			_init_skill_for_player(
				p,
				sk.get("skill_id", ""),
				sk.get("skill_name", ""),
				sk.get("skill_type", SkillData.SkillType.TRIGGER),
				sk.get("skill_timing", SkillData.TriggerTiming.NONE),
				script_class,
				sk.get("limit", -1)
			)

	context.players.append(p)
	_register_controller_for(p)


# Gemini:change.4: 按座位注册控制器——人类座位用 HumanController，其余用共享 AI
func _register_controller_for(player: BattleContext.PlayerState) -> void:
	if player.index == human_player_index and human_controller != null:
		player.is_human = true
		context.register_controller(player.index, human_controller)
	else:
		player.is_human = false
		context.register_controller(player.index, ai)


# Gemini:change.3: 通用技能初始化辅助
# Gemini:change.10: 增加 use_limit_per_turn 参数
func _init_skill_for_player(player, skill_id: String, skill_name: String, skill_type: SkillData.SkillType, trigger_timing: SkillData.TriggerTiming, script_class, use_limit_per_turn: int = -1) -> void:
	var skill_data = SkillData.new()
	skill_data.id = skill_id
	skill_data.skill_name = skill_name
	skill_data.skill_type = skill_type
	skill_data.trigger_timing = trigger_timing
	skill_data.use_limit_per_turn = use_limit_per_turn
	var skill_instance = script_class.new()
	skill_instance.setup(skill_data, player.index, context)
	player.skills.append(skill_instance)


# Gemini:change.2: 快速创建武将数据（测试用）
# Gemini:change.10: 增加 gender 参数
func _create_hero(hero_name: String, camp: HeroData.Camp, hp: int, gender_str: String = "male") -> HeroData:
	var hero = HeroData.new()
	hero.hero_id = hero_name.to_lower()
	hero.hero_name = hero_name
	hero.camp = camp
	hero.max_hp = hp
	hero.start_hp = hp
	match gender_str:
		"female": hero.gender = HeroData.Gender.FEMALE
		_: hero.gender = HeroData.Gender.MALE
	return hero


# Gemini:change.2: 发放初始手牌（每人4张，初始化阶段不发事件）
func _deal_initial_hands() -> void:
	for player in context.players:
		for j in range(4):
			var card = context.draw_from_pile()
			if card:
				player.hand_cards.append(card)


# ============================================================
# 回合流转状态机
# ============================================================

# Gemini:change.2: 开始下一个回合
func _start_next_round() -> void:
	if not _is_game_running:
		return

	if context.turn_index >= MAX_ROUNDS:
		print("[GameManager] 达到最大回合数 %d，游戏强制结束" % MAX_ROUNDS)
		_is_game_running = false
		game_over.emit({"reason": "max_rounds"})
		return

	var player = context.get_current_player()
	if player == null or not player.is_alive:
		_advance_to_next_player()
		player = context.get_current_player()
		if player == null:
			return

	context.turn_index += 1
	player.reset_turn_state()

	var turn_event = GameEvent.create(
		GameEvent.Type.TURN_START,
		player.index, player.index,
		{"turn_index": context.turn_index}
	)
	EventBus.publish(turn_event)
	round_started.emit(player.index, context.turn_index)

	# 检查翻面
	if player.is_flipped:
		player.is_flipped = false
	else:
		await _execute_phase(player, BattleContext.Phase.PHASE_JUDGE)
		if not _is_game_running:
			return
		await _execute_phase(player, BattleContext.Phase.PHASE_DRAW)
		if not _is_game_running:
			return
		await _execute_phase(player, BattleContext.Phase.PHASE_PLAY)
		if not _is_game_running:
			return
		await _execute_phase(player, BattleContext.Phase.PHASE_DISCARD)
		if not _is_game_running:
			return

	var end_event = GameEvent.create(
		GameEvent.Type.TURN_END,
		player.index, player.index,
		{"turn_index": context.turn_index}
	)
	EventBus.publish(end_event)
	round_ended.emit(player.index)

	if _check_game_over():
		return

	_advance_to_next_player()
	await get_tree().process_frame
	_start_next_round()


# Gemini:change.2: 执行指定阶段
func _execute_phase(player: BattleContext.PlayerState, phase: BattleContext.Phase) -> void:
	if not _is_game_running or not player.is_alive:
		return

	context.current_phase = phase
	phase_changed.emit(player.index, phase)

	var phase_start_event = GameEvent.create(
		GameEvent.Type.PHASE_START, player.index, -1, {"phase": phase}
	)
	EventBus.publish(phase_start_event)

	match phase:
		BattleContext.Phase.PHASE_JUDGE:
			await _do_judge_phase(player)
		BattleContext.Phase.PHASE_DRAW:
			await _do_draw_phase(player)
		BattleContext.Phase.PHASE_PLAY:
			await _do_play_phase(player)
		BattleContext.Phase.PHASE_DISCARD:
			await _do_discard_phase(player)

	var phase_end_event = GameEvent.create(
		GameEvent.Type.PHASE_END, player.index, -1, {"phase": phase}
	)
	EventBus.publish(phase_end_event)


# ============================================================
# 各阶段逻辑
# ============================================================

# Gemini:change.9: 判定阶段——逆序处理判定区延时锦囊
func _do_judge_phase(player: BattleContext.PlayerState) -> void:
	if player.judge_cards.is_empty():
		return
	# 后置入的先判定（逆序）
	var queue: Array = player.judge_cards.duplicate()
	queue.reverse()
	for delay_card in queue:
		if not player.is_alive:
			break
		player.judge_cards.erase(delay_card)
		await _resolve_delayed_trick(player, delay_card)


# Gemini:change.9: 结算一张延时锦囊
func _resolve_delayed_trick(player: BattleContext.PlayerState, card: CardData) -> void:
	var name := card.card_name
	var judge := judge_system.perform_judge(player.index, name)
	var suit: int = judge.get("suit", -1)

	match name:
		"乐不思蜀":
			# 判定结果非红桃 → 跳过出牌阶段
			if suit != CardData.Suit.HEART:
				player.skip_play_phase = true
			# 延时锦囊判定后入弃牌堆（judge 已处理判定牌；延时锦囊牌本体此处弃置）
			_discard_delayed(card)
		"兵粮寸断":
			# 判定结果非梅花 → 跳过摸牌阶段
			if suit != CardData.Suit.CLUB:
				player.skip_draw_phase = true
			_discard_delayed(card)
		"闪电":
			# 判定为黑桃 2~9 → 受 3 点雷电伤害；否则移交下家
			var rank: int = judge.get("rank", 0)
			if suit == CardData.Suit.SPADE and rank >= 2 and rank <= 9:
				_discard_delayed(card)
				await DamageEffect.create(-1, player.index, 3, DamageEffect.DamageType.THUNDER, card).resolve(context)
			else:
					# 移交下家判定区（跳过已有闪电的玩家）
				var next_p = context.get_next_alive_player(player.index)
				var start_idx := player.index
				while next_p != null and next_p.index != start_idx:
					var has_lightning := false
					for jc in next_p.judge_cards:
						if jc.card_name == "闪电":
							has_lightning = true
							break
					if not has_lightning:
						next_p.judge_cards.append(card)
						break
					next_p = context.get_next_alive_player(next_p.index)
		_:
			_discard_delayed(card)


# Gemini:change.9: 延时锦囊本体入弃牌堆
func _discard_delayed(card: CardData) -> void:
	if not context.discard_pile.has(card):
		context.add_to_discard_pile(card)


# Gemini:change.2: 摸牌阶段——通过 Effect 系统
func _do_draw_phase(player: BattleContext.PlayerState) -> void:
	# Gemini:change.9: 兵粮寸断——跳过摸牌阶段
	if player.skip_draw_phase:
		return
	var draw_effect = DrawCardEffect.create(player.index, player.index, 2)
	draw_effect.resolve(context)


# Gemini:change.3: 出牌阶段——通过 PlayCardEffect + IPlayerController
## 控制器返回 PlayIntent → PlayCardEffect 统一执行（手牌移除/事件/结算/弃牌堆）
## Gemini:change.4: AI 与人类统一 await controller.decide_play_action
##   （AI 同步返回，人类 await UI），不再对 is_human 分支 break。
func _do_play_phase(player: BattleContext.PlayerState) -> void:
	# Gemini:change.9: 乐不思蜀——跳过出牌阶段
	if player.skip_play_phase:
		return
	var play_count: int = 0
	const MAX_PLAYS_PER_TURN: int = 50

	while player.is_alive and _is_game_running and play_count < MAX_PLAYS_PER_TURN:
		var controller = context.get_controller(player.index)
		if controller == null:
			break
		var intent: PlayIntent = await controller.decide_play_action(player.index)

		if intent == null or intent.is_end_play():
			break

		# Gemini:change.7: 主动技发动意图——直接 await 技能 activate
		if intent.is_skill_activation():
			if intent.skill != null and intent.skill.can_activate():
				intent.skill.record_use()
				await intent.skill.activate(intent.target_indices)
			play_count += 1
			await get_tree().process_frame
			continue

		# 通过 PlayCardEffect 统一执行使用牌流程
		var play_action = PlayCardEffect.create_from_intent(intent, card_resolver)
		action_queue.push_action(play_action)
		await action_queue.execute_all()
		play_count += 1

		await get_tree().process_frame


# Gemini:change.3: 弃牌阶段——通过 Effect 系统
## Gemini:change.4: AI 与人类统一 await controller.decide_discard
func _do_discard_phase(player: BattleContext.PlayerState) -> void:
	var hand_limit = player.get_hand_limit()
	var excess = player.hand_cards.size() - hand_limit
	if excess <= 0:
		return

	var cards_to_discard: Array = []
	var controller = context.get_controller(player.index)
	if controller != null:
		cards_to_discard = await controller.decide_discard(player.index, excess)

	if not cards_to_discard.is_empty():
		var discard_effect = DiscardCardEffect.create(
			player.index, player.index, cards_to_discard,
			DiscardCardEffect.DiscardReason.PHASE_DISCARD
		)
		discard_effect.resolve(context)


# ============================================================
# 辅助方法
# ============================================================

# Gemini:change.2: 推进到下一位存活玩家
func _advance_to_next_player() -> void:
	var total = context.players.size()
	var current = context.current_player_index
	for i in range(1, total + 1):
		var next_idx = (current + i) % total
		var next_player = context.get_player(next_idx)
		if next_player and next_player.is_alive:
			context.current_player_index = next_idx
			return


# Gemini:change.6: 检查游戏是否结束——按身份阵营判定胜负
## 胜负规则：
##   - 主公死亡：若场上还有反贼存活 → 反贼阵营胜；
##              若仅剩内奸（且无反贼）→ 内奸胜。
##   - 反贼与内奸全部出局 → 主公阵营（主公+忠臣）胜。
##   - 兜底：仅剩 1 人存活，按其身份归属判定。
func _check_game_over() -> bool:
	var lord = context.get_lord()
	var lord_dead: bool = (lord == null) or (not lord.is_alive)
	var rebels = context.get_alive_by_identity(Identity.Type.REBEL)
	var traitors = context.get_alive_by_identity(Identity.Type.TRAITOR)

	var winner_camp: String = ""

	if lord_dead:
		# 主公已死
		if rebels.size() > 0:
			winner_camp = "rebel"
		elif traitors.size() > 0 and rebels.is_empty():
			# 仅剩内奸（典型：内奸单挑收掉主公）
			winner_camp = "traitor"
		else:
			# 主公死且无反贼无内奸（极端情况）→ 无胜者
			winner_camp = ""
	else:
		# 主公存活：若反贼+内奸清空 → 主公阵营胜
		if rebels.is_empty() and traitors.is_empty():
			winner_camp = "lord"

	if winner_camp == "":
		return false  # 游戏继续

	_is_game_running = false

	# Gemini:change.13: 对局结束清理洗牌记录
	if deck_manager != null:
		deck_manager.cleanup()

	var winner_info := _build_winner_info(winner_camp)
	print("")
	print("★★★ 游戏结束！%s ★★★" % winner_info.get("winner_name", ""))
	logger.print_status_summary()
	game_over.emit(winner_info)
	return true


# Gemini:change.6: 构造胜利方信息（含获胜阵营成员）
func _build_winner_info(camp: String) -> Dictionary:
	var camp_name := ""
	var winners: Array = []
	match camp:
		"lord":
			camp_name = "主公阵营胜利"
			for p in context.players:
				if p.identity == Identity.Type.LORD or p.identity == Identity.Type.LOYALIST:
					winners.append(p.index)
		"rebel":
			camp_name = "反贼阵营胜利"
			for p in context.players:
				if p.identity == Identity.Type.REBEL:
					winners.append(p.index)
		"traitor":
			camp_name = "内奸胜利"
			for p in context.players:
				if p.identity == Identity.Type.TRAITOR:
					winners.append(p.index)
	# 标记所有人身份公开（结算展示）
	for p in context.players:
		p.identity_revealed = true
	return {
		"winner_camp": camp,
		"winner_name": camp_name,
		"winners": winners,
	}
