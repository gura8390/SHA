# ============================================================
# deck_manager.gd
# 牌堆管理器：负责构建、洗牌、摸牌、弃牌、重洗
# 与 BattleContext 协同工作，BattleContext 持有数据，
# DeckManager 提供操作逻辑
#
# Gemini:change.1: 初始创建——实现牌堆完整生命周期管理
# Gemini:change.9: 数据驱动——从 JsonDataLoader 读取卡牌定义
# Gemini:change.13: 洗牌记录——记录每次洗牌的牌序，对局结束清理
# ============================================================

class_name DeckManager
extends RefCounted

# Gemini:change.1: 战场上下文引用
var _context: BattleContext = null

# Gemini:change.13: 洗牌记录日志
## 每次洗牌（开局/弃牌堆回收）记录当时的牌序
## 格式：Array[Dictionary]，每项 {"cards": Array[String], "reason": String}
var shuffle_log: Array = []


# Gemini:change.1: 初始化绑定上下文
func setup(context: BattleContext) -> void:
	_context = context


# Gemini:change.13: 对局结束清理——清除洗牌记录
func cleanup() -> void:
	shuffle_log.clear()


# Gemini:change.9: 构建标准版完整牌堆并洗入抽牌堆（数据驱动）
## 从 JsonDataLoader 读取卡牌定义，按牌名+数量构建
func build_test_deck() -> void:
	var cards: Array = []

	# 牌名 → 数量的配比表
	var card_counts: Dictionary = {
		# ---- 基本牌 ----
		"杀": 20,
		"火杀": 4,
		"雷杀": 4,
		"闪": 15,
		"桃": 8,
		"酒": 5,
		# ---- 即时锦囊 ----
		"决斗": 3,
		"过河拆桥": 6,
		"顺手牵羊": 5,
		"无中生有": 4,
		"南蛮入侵": 3,
		"万箭齐发": 1,
		"桃园结义": 1,
		"五谷丰登": 2,
		"借刀杀人": 2,
		"火攻": 3,
		"无懈可击": 3,
		# ---- 延时锦囊 ----
		"乐不思蜀": 3,
		"兵粮寸断": 2,
		"闪电": 2,
	}

	# 装备牌（每种1张）
	var equip_names: Array = [
		"诸葛连弩", "雌雄双股剑", "青釭剑", "青龙偃月刀",
		"丈八蛇矛", "贯石斧", "方天画戟", "麒麟弓",
		"八卦阵", "仁王盾", "藤甲", "白银狮子",
		"的卢", "绝影", "赤兔", "爪黄飞电",
	]

	# 构建基本牌和锦囊牌
	for card_name in card_counts:
		var count: int = card_counts[card_name]
		cards.append_array(_make_many(card_name, count))

	# 构建装备牌（每张不同花色点数）
	var equip_idx := 0
	for card_name in equip_names:
		cards.append(_make_card(card_name, equip_idx))
		equip_idx += 1

	# 初始化抽牌堆并洗牌（init_draw_pile 内部会 shuffle）
	_context.init_draw_pile(cards)

	# Gemini:change.13: 记录开局洗牌顺序
	_record_shuffle(_context.draw_pile, "game_start")


# Gemini:change.13: 记录一次洗牌的牌序
## @param pile: 洗牌后的牌堆数组
## @param reason: 洗牌原因（"game_start" / "recycle"）
func _record_shuffle(pile: Array, reason: String) -> void:
	var card_ids: Array = []
	for card in pile:
		card_ids.append(card.card_id if card != null else "?")
	shuffle_log.append({
		"cards": card_ids,
		"reason": reason,
	})


# Gemini:change.13: 供 BattleContext 回调——弃牌堆回收时记录洗牌
func on_recycle_shuffle(new_draw_pile: Array) -> void:
	_record_shuffle(new_draw_pile, "recycle")


# Gemini:change.9: 批量创建同名牌
func _make_many(card_name: String, count: int) -> Array:
	var result: Array = []
	for i in range(count):
		result.append(_make_card(card_name, i))
	return result


# Gemini:change.9: 按牌名创建一张配置好的卡牌（从 JsonDataLoader 读取定义）
func _make_card(card_name: String, idx: int = 0) -> CardData:
	var suits = [CardData.Suit.SPADE, CardData.Suit.HEART, CardData.Suit.CLUB, CardData.Suit.DIAMOND]
	var card = CardData.new()
	card.card_id = "%s_%03d" % [card_name, idx]
	card.card_name = card_name
	card.suit = suits[idx % 4]
	card.rank = (idx % 13) + 1

	# 从 JsonDataLoader 获取卡牌定义
	var jdl = Engine.get_main_loop().root.get_node_or_null("JsonDataLoader")
	var def: Dictionary = {}
	if jdl != null:
		# 尝试按牌名查找（优先精确匹配第一个）
		var defs = jdl.get_card_defs_by_name(card_name)
		if not defs.is_empty():
			def = defs[0]

	# 根据 JSON 定义配置卡牌属性
	var card_type_str: String = def.get("type", "basic")
	var target_rule: String = def.get("target_rule", "none")
	var equip_type_str: String = def.get("equip_type", "")

	# 设置卡牌类型
	match card_type_str:
		"basic":
			card.card_type = CardData.CardType.BASIC
		"trick":
			card.card_type = CardData.CardType.TRICK
			var trick_str: String = def.get("trick_type", "instant")
			match trick_str:
				"instant": card.trick_type = CardData.TrickType.INSTANT
				"delayed": card.trick_type = CardData.TrickType.DELAYED
				"aoe": card.trick_type = CardData.TrickType.AOE
		"equipment":
			card.card_type = CardData.CardType.EQUIPMENT
			match equip_type_str:
				"weapon": card.equip_type = CardData.EquipType.WEAPON
				"armor": card.equip_type = CardData.EquipType.ARMOR
				"horse_def": card.equip_type = CardData.EquipType.HORSE_DEF
				"horse_atk": card.equip_type = CardData.EquipType.HORSE_ATK
				"treasure": card.equip_type = CardData.EquipType.TREASURE

	# 设置使用规则
	match target_rule:
		"single_enemy", "single_enemy_range1":
			card.need_target = true
			card.target_count = 1
		"double_target":
			card.need_target = true
			card.target_count = 2
		"self":
			card.need_target = false
			card.can_target_self = true
		"all", "all_enemy":
			card.need_target = false
		"none":
			card.need_target = false
			card.target_count = 0

	# 武器射程
	if card.equip_type == CardData.EquipType.WEAPON:
		card.weapon_range = def.get("weapon_range", 1)

	# 马的距离修正
	if card.equip_type == CardData.EquipType.HORSE_DEF or card.equip_type == CardData.EquipType.HORSE_ATK:
		pass  # horse_value 在效果层处理

	# 存储效果标识（供 card_resolver 使用）
	if not def.is_empty():
		card.effect_script_path = def.get("effect", "")
		card.description = def.get("description", "")

	# 顺手牵羊的距离限制
	if card_name == "顺手牵羊" or card_name == "兵粮寸断":
		card.range_limit = 1

	return card


# Gemini:change.1: 摸牌接口（通过 DrawCardEffect 执行）
## 这是推荐的摸牌方式，确保经过 Effect 系统
func draw_cards_for_player(player_index: int, count: int) -> Dictionary:
	var effect = DrawCardEffect.create(player_index, player_index, count)
	return effect.resolve(_context)


# Gemini:change.1: 获取抽牌堆剩余数量
func get_draw_pile_count() -> int:
	return _context.draw_pile.size()


# Gemini:change.1: 获取弃牌堆数量
func get_discard_pile_count() -> int:
	return _context.discard_pile.size()
