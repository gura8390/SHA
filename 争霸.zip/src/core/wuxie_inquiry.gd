# ============================================================
# wuxie_inquiry.gd
# 无懈可击协调器：对一张正在结算的锦囊发起"无懈可击"询问
#
# 标准规则：
#   - 当一张锦囊牌（含 AOE）生效时，按座次从使用者下家起依次询问每位
#     存活玩家是否打出【无懈可击】。
#   - 打出无懈可击后，该无懈本身也可被后续玩家再次无懈抵消（"连环无懈"）。
#   - 最终若原锦囊被至少一张未被抵消的无懈命中，则原锦囊无效。
#
# 设计：本协调器是 ResponseRequest 之上的一层封装——它循环调用
# ResponseRequest.ask 单目标询问，遇"打出"则递归对本张无懈再开一轮询问，
# 天然支持连环；由于牌堆中无懈可击数量有限（标准版 3 张），递归自然终止。
#
# 调用方在锦囊 effect 的合适时机（CARD_USED 后 / CARD_TARGETED 后）调用：
#     if await WuxieInquiry.inquire(ctx, source_index, card, primary_target):
#         event.is_cancelled = true   # 复用各 effect 已有的回滚/短路
#
# Gemini:change.10: 新建——无懈可击结算（P0 补全）
# ============================================================

class_name WuxieInquiry
extends RefCounted

# 标准版无懈可击最多 3 张，理论连环深度有限；保险上限
const MAX_CHAIN_DEPTH: int = 8

# Gemini:change.10: 全局跳过标记——当玩家点击"全部跳过"时设置
# key: card 的 instance_id（int），value: true
static var _skip_all_cards: Dictionary = {}


## 清除所有跳过标记（新游戏开始时调用）
static func clear_skip_all() -> void:
	_skip_all_cards.clear()


## 检查玩家是否有指定名称的牌
static func _player_has_card(player, card_name: String) -> bool:
	if player == null:
		return false
	for c in player.hand_cards:
		if c.card_name == card_name:
			return true
	return false


# 对一张正在结算的锦囊发起无懈可击询问。
## @param battle_context: 战场上下文
## @param source_idx: 锦囊使用者的座位
## @param card: 被抵消的锦囊牌（CardData）
## @param primary_target: 主要目标索引（单目标锦囊），AOE/全体锦囊传 -1
## @return: true = 该锦囊被无懈可击抵消（调用方应置 is_cancelled）；false = 未被抵消
static func inquire(
	battle_context,
	source_idx: int,
	card: CardData,
	primary_target: int = -1
) -> bool:
	# 非锦囊牌不适用无懈可击
	if card == null or card.card_type != CardData.CardType.TRICK:
		return false

	# 检查是否已被标记为"全部跳过"
	var card_key := card.get_instance_id()
	if _skip_all_cards.has(card_key):
		_skip_all_cards.erase(card_key)  # 用过即清除
		return false

	return await _inquire_round(battle_context, source_idx, card, primary_target, source_idx, 0)


# 一轮询问：从 start_after 的下家起，环形遍历询问是否打出无懈。
## @param chain_source: 本轮要抵消的"锦囊/无懈"的使用者（用于 prompt 与座次起点）
## @param depth: 连环深度，防保险
## @return: 本轮是否产生"有效的无懈抵消"
static func _inquire_round(
	battle_context,
	chain_source: int,
	target_card: CardData,
	primary_target: int,
	start_after: int,
	depth: int
) -> bool:
	if depth > MAX_CHAIN_DEPTH:
		return false

	# 按座次从 start_after 的下家开始，收集本轮询问顺序（存活玩家）
	var alive = battle_context.get_alive_players()
	if alive.is_empty():
		return false

	# 找到 start_after 在存活列表中的位置，从其下家开始
	var start_pos := 0
	for i in range(alive.size()):
		if alive[i].index == start_after:
			start_pos = i
			break

	# 逐个询问
	for offset in range(1, alive.size() + 1):
		var p = alive[(start_pos + offset) % alive.size()]
		if p == null or not p.is_alive:
			continue

		# 跳过没有无懈可击的玩家
		if not _player_has_card(p, "无懈可击"):
			continue

		# 向该玩家请求无懈可击
		var prompt_text := _build_prompt(battle_context, chain_source, target_card, primary_target)
		var result = await ResponseRequest.ask(
			battle_context,
			p.index,
			"无懈可击",
			chain_source,
			{
				"card": target_card,
				"context": "wuxie",
				"primary_target": primary_target,
				"prompt": prompt_text,
			}
		)

		# Gemini:change.10: 检查"全部跳过"标记
		if result.context_data.get("skip_all_wuxie", false):
			_skip_all_cards[target_card.get_instance_id()] = true
			return false  # 本张锦囊不被抵消，且后续不再询问

		if result.played and result.card_used != null:
			# 该玩家打出无懈可击：从手牌移除、入弃牌堆
			var wuxie_card = result.card_used
			p.hand_cards.erase(wuxie_card)
			var discard_eff = DiscardCardEffect.create(
				p.index, p.index, [wuxie_card], DiscardCardEffect.DiscardReason.USAGE
			)
			discard_eff.resolve(battle_context)

			# 通知：一张无懈已打出（供日志/UI）
			EventBus.publish(GameEvent.create(
				GameEvent.Type.SKILL_RESOLVED, p.index, chain_source,
				{"skill_name": "无懈可击", "target_card": target_card}
			))

			# 连环：对本张无懈再开一轮询问（从打出者下家起），
			# 询问是否有人再出无懈来抵消这张无懈。
			#   - 若这轮无懈又被抵消 → 本张无懈失效 → 原锦囊"未被有效抵消"，返回 false
			#   - 若这轮无懈未被抵消 → 本张无懈生效 → 原锦囊被取消，返回 true
			var countered: bool = await _inquire_round(
				battle_context, p.index, wuxie_card, primary_target, p.index, depth + 1
			)
			return not countered

	# 本轮无人打出无懈 → 未抵消
	return false


# 构造询问提示文本
static func _build_prompt(ctx, chain_source: int, card: CardData, primary_target: int) -> String:
	var name := card.card_name if card != null else "锦囊"
	var src_name := _pname(chain_source, ctx)
	if primary_target >= 0:
		var tgt_name := _pname(primary_target, ctx)
		return "%s 对 %s 使用【%s】，是否打出【无懈可击】？" % [src_name, tgt_name, name]
	return "%s 使用【%s】，是否打出【无懈可击】？" % [src_name, name]


static func _pname(idx: int, ctx) -> String:
	if ctx == null:
		return "%d号" % (idx + 1)
	var p = ctx.get_player(idx)
	if p == null:
		return "%d号" % (idx + 1)
	if p.hero_data != null and p.hero_data.hero_name != "":
		return p.hero_data.hero_name
	return "%d号" % (idx + 1)
