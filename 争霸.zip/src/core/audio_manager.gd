# ============================================================
# audio_manager.gd
# 音效管理器（Autoload 单例）
#
# 职责：
#   - 管理音效播放（SFX）
#   - 提供统一的 play_sfx(name) 接口
#   - 无音频文件时静默失败（不报错）
#
# 使用方式：
#   AudioManager.play_sfx("card_play")
#   AudioManager.play_sfx("damage")
#
# 音频文件放置位置：res://assets/audio/sfx/<name>.ogg
# （当前无音频文件，所有 play_sfx 调用静默忽略）
# ============================================================

extends Node

## 音效播放器池（避免同时播放过多时创建新节点）
var _sfx_pool: Array[AudioStreamPlayer] = []
const POOL_SIZE: int = 8

## 音效名称 → 文件路径映射
const SFX_MAP: Dictionary = {
	"card_play": "res://assets/audio/sfx/card_play.wav",
	"card_draw": "res://assets/audio/sfx/card_draw.wav",
	"card_discard": "res://assets/audio/sfx/card_discard.wav",
	"damage": "res://assets/audio/sfx/damage.wav",
	"heal": "res://assets/audio/sfx/heal.wav",
	"skill_activate": "res://assets/audio/sfx/skill_activate.wav",
	"equip": "res://assets/audio/sfx/equip.wav",
	"dying": "res://assets/audio/sfx/dying.wav",
	"death": "res://assets/audio/sfx/death.wav",
	"game_start": "res://assets/audio/sfx/game_start.wav",
	"turn_start": "res://assets/audio/sfx/turn_start.wav",
	"button_click": "res://assets/audio/sfx/button_click.wav",
	"target_line": "res://assets/audio/sfx/target_line.wav",
}


func _ready() -> void:
	# 初始化播放器池
	for i in range(POOL_SIZE):
		var player := AudioStreamPlayer.new()
		player.bus = "SFX"
		add_child(player)
		_sfx_pool.append(player)


## 播放音效
## @param sfx_name: 音效名称（见 SFX_MAP）
## @param volume_db: 音量偏移（默认 0）
func play_sfx(sfx_name: String, volume_db: float = 0.0) -> void:
	var path: String = SFX_MAP.get(sfx_name, "")
	if path == "":
		return

	# 检查文件是否存在
	if not ResourceLoader.exists(path):
		return  # 静默失败

	# 从池中获取空闲播放器
	var player := _get_idle_player()
	if player == null:
		return  # 所有播放器都在用，跳过

	var stream = load(path)
	if stream == null:
		return
	player.stream = stream
	player.volume_db = volume_db
	player.play()


## 获取一个空闲的播放器
func _get_idle_player() -> AudioStreamPlayer:
	for player in _sfx_pool:
		if not player.playing:
			return player
	# 所有都在用，返回第一个（会打断正在播放的）
	return _sfx_pool[0] if not _sfx_pool.is_empty() else null


## 停止所有音效
func stop_all() -> void:
	for player in _sfx_pool:
		player.stop()
