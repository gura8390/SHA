# ============================================================
# judge_system.gd
# 判定系统：翻开牌堆顶作为判定牌，发布判定事件，判定牌入弃牌堆
#
# 用途：
#   - 延时锦囊（乐不思蜀/兵粮寸断/闪电）在判定阶段判定
#   - 装备技（八卦阵）/武将技的判定型效果
#
# 流程：
#   1. JUDGE_START（通知）
#   2. 翻开牌堆顶 → JUDGE_RESULT（改判技能可在此替换判定牌）
#   3. JUDGE_FINISH
#   4. 判定牌入弃牌堆
#
# Gemini:change.9: 新建——判定系统
# ============================================================

class_name JudgeSystem
extends RefCounted

var _context = null


func setup(context) -> void:
	_context = context


# Gemini:change.9: 执行一次判定，返回判定结果字典
## @param who: 判定的归属玩家索引
## @param reason: 判定原因（"乐不思蜀"/"闪电"/"八卦阵"等，供改判技能识别）
## @return: {"card": CardData, "suit": int, "rank": int, "is_red": bool, "reason": String}
func perform_judge(who: int, reason: String = "") -> Dictionary:
	# JUDGE_START
	EventBus.publish(GameEvent.create(
		GameEvent.Type.JUDGE_START, who, who, {"reason": reason}
	))

	# 翻开牌堆顶
	var card: CardData = _context.draw_from_pile()
	if card == null:
		return {"card": null, "reason": reason}

	var result := {
		"card": card,
		"suit": card.suit,
		"rank": card.rank,
		"is_red": card.is_red(),
		"reason": reason,
		"who": who,
	}

	# JUDGE_RESULT（改判技能可修改 result.card / 重写花色点数）
	var result_event = GameEvent.create(
		GameEvent.Type.JUDGE_RESULT, who, who, {"judge": result, "reason": reason}
	)
	EventBus.publish(result_event)
	# 改判后可能替换了判定牌，回读
	var final_judge: Dictionary = result_event.data.get("judge", result)
	var final_card: CardData = final_judge.get("card", card)

	# JUDGE_FINISH
	EventBus.publish(GameEvent.create(
		GameEvent.Type.JUDGE_FINISH, who, who, {"judge": final_judge, "reason": reason}
	))

	# 判定牌入弃牌堆（若改判换牌，原判定牌也已在流程中处理；这里把最终判定牌弃置）
	if final_card != null and not _context.discard_pile.has(final_card):
		_context.add_to_discard_pile(final_card)

	return final_judge
