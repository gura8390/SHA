# ============================================================
# game_setup.gd
# 开局配置载体（Autoload 单例）
#
# 职责：在"开局设置界面 → 对局场景"之间传递本局参数。
# 场景切换会销毁节点，普通变量无法跨场景，故用 autoload 暂存。
#
# 字段：
#   player_count   本局总人数（4~12，含 1 名人类）
#   human_hero_id  人类选择的武将 id（""=随机）
#
# Gemini:change.5: 新建——跨场景开局配置
# ============================================================

extends Node

## 本局总人数（含人类），范围 4~12
var player_count: int = 4

## 人类选择的武将 id（空字符串表示随机）
var human_hero_id: String = ""

## Gemini:change.6: 是否明身份局（开局公开所有人身份）
var reveal_identity: bool = false


# Gemini:change.5: 重置为默认（回主菜单时调用）
func reset() -> void:
	player_count = 4
	human_hero_id = ""
	reveal_identity = false
