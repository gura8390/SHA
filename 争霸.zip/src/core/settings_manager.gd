# ============================================================
# settings_manager.gd
# 全局设置管理器（Autoload 单例）
#
# 职责：
#   - 音量：Master / BGM / SFX 三条音频总线的音量（0~1 线性）
#     注：本轮不接入实际音效，但音频总线与设置接口已就绪，
#     以后 AudioManager 播放时挂到对应总线即可生效。
#   - 显示：窗口分辨率、全屏 / 窗口模式
#   - 持久化：写入 user://settings.cfg，启动时自动加载并应用
#
# 设计：所有 setter 即时生效并发 settings_changed 信号，UI 双向绑定。
#
# Gemini:change.5: 新建——完整设置系统（音量接口 + 分辨率 + 全屏）
# ============================================================

extends Node

signal settings_changed()

const CONFIG_PATH := "user://settings.cfg"

# ----- 音频总线名 -----
const BUS_MASTER := "Master"
const BUS_BGM := "BGM"
const BUS_SFX := "SFX"

# ----- 可选分辨率（16:9）-----
const RESOLUTIONS: Array[Vector2i] = [
	Vector2i(1280, 720),
	Vector2i(1600, 900),
	Vector2i(1920, 1080),
	Vector2i(2560, 1440),
]

# ----- 当前设置值 -----
var master_volume: float = 1.0   ## 0~1 线性
var bgm_volume: float = 0.8
var sfx_volume: float = 0.8
var resolution_index: int = 0     ## 指向 RESOLUTIONS
var fullscreen: bool = false
var ai_play_delay: float = 1.0    ## AI 出牌延迟（秒），范围 0.0~3.0


func _ready() -> void:
	_ensure_audio_buses()
	load_settings()
	apply_all()
# SM_APPEND_MARKER


# ============================================================
# 音频总线
# ============================================================

# Gemini:change.5: 确保 BGM / SFX 总线存在（项目默认只有 Master）
## 这样以后接入音效时直接 AudioStreamPlayer.bus = "BGM"/"SFX" 即可
func _ensure_audio_buses() -> void:
	if AudioServer.get_bus_index(BUS_BGM) == -1:
		AudioServer.add_bus()
		var idx = AudioServer.bus_count - 1
		AudioServer.set_bus_name(idx, BUS_BGM)
		AudioServer.set_bus_send(idx, BUS_MASTER)
	if AudioServer.get_bus_index(BUS_SFX) == -1:
		AudioServer.add_bus()
		var idx = AudioServer.bus_count - 1
		AudioServer.set_bus_name(idx, BUS_SFX)
		AudioServer.set_bus_send(idx, BUS_MASTER)


# Gemini:change.5: 把 0~1 线性音量应用到指定总线（转 dB）
func _apply_bus_volume(bus_name: String, linear: float) -> void:
	var idx = AudioServer.get_bus_index(bus_name)
	if idx == -1:
		return
	# 线性 0 视为静音
	var db = linear_to_db(clampf(linear, 0.0, 1.0)) if linear > 0.0001 else -80.0
	AudioServer.set_bus_volume_db(idx, db)


# ============================================================
# Setter（即时生效 + 发信号）
# ============================================================

func set_master_volume(v: float) -> void:
	master_volume = clampf(v, 0.0, 1.0)
	_apply_bus_volume(BUS_MASTER, master_volume)
	settings_changed.emit()


func set_bgm_volume(v: float) -> void:
	bgm_volume = clampf(v, 0.0, 1.0)
	_apply_bus_volume(BUS_BGM, bgm_volume)
	settings_changed.emit()


func set_sfx_volume(v: float) -> void:
	sfx_volume = clampf(v, 0.0, 1.0)
	_apply_bus_volume(BUS_SFX, sfx_volume)
	settings_changed.emit()


func set_resolution_index(idx: int) -> void:
	resolution_index = clampi(idx, 0, RESOLUTIONS.size() - 1)
	_apply_window()
	settings_changed.emit()


func set_fullscreen(on: bool) -> void:
	fullscreen = on
	_apply_window()
	settings_changed.emit()


func set_ai_play_delay(v: float) -> void:
	ai_play_delay = clampf(v, 0.0, 3.0)
	settings_changed.emit()


func get_resolution() -> Vector2i:
	return RESOLUTIONS[clampi(resolution_index, 0, RESOLUTIONS.size() - 1)]


func get_resolution_labels() -> PackedStringArray:
	var labels := PackedStringArray()
	for r in RESOLUTIONS:
		labels.append("%d × %d" % [r.x, r.y])
	return labels
# SM_APPEND_MARKER2


# ============================================================
# 应用 / 持久化
# ============================================================

# Gemini:change.5: 应用窗口模式与分辨率
func _apply_window() -> void:
	if fullscreen:
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN)
	else:
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED)
		var res = get_resolution()
		DisplayServer.window_set_size(res)
		# 居中
		var screen = DisplayServer.screen_get_size()
		var pos = (screen - res) / Vector2i(2, 2)
		DisplayServer.window_set_position(pos)


# Gemini:change.5: 应用全部设置（启动时调用）
func apply_all() -> void:
	_apply_bus_volume(BUS_MASTER, master_volume)
	_apply_bus_volume(BUS_BGM, bgm_volume)
	_apply_bus_volume(BUS_SFX, sfx_volume)
	# headless 下不动窗口
	if DisplayServer.get_name() != "headless":
		_apply_window()


# Gemini:change.5: 保存到 user://settings.cfg
func save_settings() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("audio", "master", master_volume)
	cfg.set_value("audio", "bgm", bgm_volume)
	cfg.set_value("audio", "sfx", sfx_volume)
	cfg.set_value("display", "resolution_index", resolution_index)
	cfg.set_value("display", "fullscreen", fullscreen)
	cfg.set_value("gameplay", "ai_play_delay", ai_play_delay)
	cfg.save(CONFIG_PATH)


# Gemini:change.5: 从 user://settings.cfg 加载（无文件则用默认值）
func load_settings() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(CONFIG_PATH) != OK:
		return  # 首次运行，保持默认
	master_volume = cfg.get_value("audio", "master", master_volume)
	bgm_volume = cfg.get_value("audio", "bgm", bgm_volume)
	sfx_volume = cfg.get_value("audio", "sfx", sfx_volume)
	resolution_index = cfg.get_value("display", "resolution_index", resolution_index)
	fullscreen = cfg.get_value("display", "fullscreen", fullscreen)
	ai_play_delay = cfg.get_value("gameplay", "ai_play_delay", ai_play_delay)
