# ============================================================
# battle_logger.gd
# 战斗日志系统：订阅所有关键事件并统一格式输出
# 用于开发阶段调试和验证架构正确性
#
# Gemini:change.1: 初始创建——实现战斗日志输出
# Gemini:change.9: 增强——内存存储 + 信号通知 UI
# ============================================================

class_name BattleLogger
extends RefCounted

# Gemini:change.1: 战场上下文引用（用于获取玩家名称）
var _context: BattleContext = null

# Gemini:change.1: 是否启用日志
var enabled: bool = true

# Gemini:change.9: 日志条目存储（供 UI 读取）
var _log_entries: Array[String] = []
const MAX_LOG_ENTRIES: int = 500

# Gemini:change.9: 新日志信号（UI 监听以实时刷新）
## 由于 BattleLogger 是 RefCounted 不是 Node，不能直接发信号。
## 改用回调函数引用——由 battle_table 注册。
var on_log_added: Callable = Callable()


# Gemini:change.1: 初始化并订阅所有关键事件
func setup(context: BattleContext) -> void:
	_context = context
	_subscribe_events()


# Gemini:change.9: 添加一条日志（存入内存 + 通知 UI）
func _add_log(text: String) -> void:
	_log_entries.append(text)
	# 超出上限时裁剪前面的
	if _log_entries.size() > MAX_LOG_ENTRIES:
		_log_entries = _log_entries.slice(_log_entries.size() - MAX_LOG_ENTRIES)
	if on_log_added.is_valid():
		on_log_added.call(text)


# Gemini:change.9: 获取所有日志文本
func get_all_logs() -> PackedStringArray:
	var result := PackedStringArray()
	for entry in _log_entries:
		result.append(entry)
	return result


# Gemini:change.9: 清空日志
func clear_logs() -> void:
	_log_entries.clear()


# Gemini:change.1: 批量订阅事件
func _subscribe_events() -> void:
	EventBus.subscribe(GameEvent.Type.TURN_START, _on_turn_start, -100, self)
	EventBus.subscribe(GameEvent.Type.TURN_END, _on_turn_end, -100, self)
	EventBus.subscribe(GameEvent.Type.PHASE_START, _on_phase_start, -100, self)
	EventBus.subscribe(GameEvent.Type.CARD_USED, _on_card_used, -100, self)
	EventBus.subscribe(GameEvent.Type.DAMAGE_AFTER, _on_damage_after, -100, self)
	EventBus.subscribe(GameEvent.Type.HEAL_AFTER, _on_heal_after, -100, self)
	EventBus.subscribe(GameEvent.Type.DRAW_CARD, _on_draw_card, -100, self)
	EventBus.subscribe(GameEvent.Type.DISCARD_CARD, _on_discard_card, -100, self)
	EventBus.subscribe(GameEvent.Type.PLAYER_DYING, _on_player_dying, -100, self)
	EventBus.subscribe(GameEvent.Type.PLAYER_DEAD, _on_player_dead, -100, self)
	EventBus.subscribe(GameEvent.Type.SKILL_RESOLVED, _on_skill_resolved, -100, self)
	EventBus.subscribe(GameEvent.Type.RESPONSE_RECEIVED, _on_response, -100, self)


# Gemini:change.1: 获取玩家显示名称
func _get_name(index: int) -> String:
	if _context == null:
		return "Player_%d" % index
	var player = _context.get_player(index)
	if player == null:
		return "Player_%d" % index
	if player.hero_data != null:
		return player.hero_data.hero_name
	return "Player_%d" % index


# Gemini:change.1: 获取阶段名称
func _get_phase_name(phase) -> String:
	match phase:
		BattleContext.Phase.ROUND_START: return "回合开始"
		BattleContext.Phase.PHASE_JUDGE: return "判定阶段"
		BattleContext.Phase.PHASE_DRAW: return "摸牌阶段"
		BattleContext.Phase.PHASE_PLAY: return "出牌阶段"
		BattleContext.Phase.PHASE_DISCARD: return "弃牌阶段"
		BattleContext.Phase.ROUND_END: return "回合结束"
		_: return "未知阶段"


# ===== 事件回调 =====

# Gemini:change.1: 回合开始
func _on_turn_start(event: GameEvent) -> void:
	if not enabled:
		return
	AudioManager.play_sfx("turn_start")
	var turn_idx = event.data.get("turn_index", 0)
	var text := "[回合%d] %s 的回合开始" % [turn_idx, _get_name(event.source)]
	print("")
	print("═══════════════════════════════════════════")
	print(text)
	print("═══════════════════════════════════════════")
	_add_log("═══ %s ═══" % text)

	# Gemini:change.9: 记录当前回合玩家的血量信息
	var player = _context.get_player(event.source)
	if player != null:
		_add_log("  %s HP:%d/%d 手牌:%d" % [
			_get_name(event.source),
			max(0, player.current_hp), player.max_hp,
			player.hand_cards.size()
		])


# Gemini:change.1: 回合结束
func _on_turn_end(event: GameEvent) -> void:
	if not enabled:
		return
	var text := "[回合] %s 的回合结束" % _get_name(event.source)
	print(text)
	_add_log(text)


# Gemini:change.1: 阶段开始
func _on_phase_start(event: GameEvent) -> void:
	if not enabled:
		return
	var phase = event.data.get("phase", -1)
	var text := "  [%s] %s" % [_get_phase_name(phase), _get_name(event.source)]
	print(text)
	_add_log(text)


# Gemini:change.1: 卡牌使用
func _on_card_used(event: GameEvent) -> void:
	if not enabled:
		return
	AudioManager.play_sfx("card_play")
	var card_name = event.data.get("card_name", "未知")
	var target_str = ""
	if event.target >= 0:
		target_str = " → %s" % _get_name(event.target)
	var text := "  [出牌] %s 使用【%s】%s" % [_get_name(event.source), card_name, target_str]
	print(text)
	_add_log(text)


# Gemini:change.1: 伤害结算完成
func _on_damage_after(event: GameEvent) -> void:
	if not enabled:
		return
	var amount = event.data.get("amount", 0)
	var current_hp = event.data.get("current_hp", 0)
	var dmg_type = event.data.get("damage_type", 0)
	var type_str := ""
	match dmg_type:
		DamageEffect.DamageType.FIRE: type_str = "(火)"
		DamageEffect.DamageType.THUNDER: type_str = "(雷)"
	var text := "  [伤害] %s 受到 %d 点%s伤害 (剩余HP:%d)" % [_get_name(event.target), amount, type_str, current_hp]
	print(text)
	_add_log(text)


# Gemini:change.1: 回复体力
func _on_heal_after(event: GameEvent) -> void:
	if not enabled:
		return
	AudioManager.play_sfx("heal")
	var amount = event.data.get("amount", 0)
	var current_hp = event.data.get("current_hp", 0)
	var text := "  [回复] %s 回复 %d 点体力 (当前HP:%d)" % [_get_name(event.target), amount, current_hp]
	print(text)
	_add_log(text)


# Gemini:change.1: 摸牌
func _on_draw_card(event: GameEvent) -> void:
	if not enabled:
		return
	var phase = event.data.get("phase", "")
	if phase != "after":
		return  # 只记录摸牌完成的事件
	AudioManager.play_sfx("card_draw")
	var amount = event.data.get("amount", 0)
	var text := "  [摸牌] %s 摸了 %d 张牌" % [_get_name(event.target), amount]
	print(text)
	_add_log(text)


# Gemini:change.1: 弃牌
func _on_discard_card(event: GameEvent) -> void:
	if not enabled:
		return
	var phase = event.data.get("phase", "")
	if phase != "after":
		return
	AudioManager.play_sfx("card_discard")
	var cards = event.data.get("cards", [])
	var card_names: Array = []
	for c in cards:
		card_names.append(c.card_name)
	var text := "  [弃牌] %s 弃置了 %s" % [_get_name(event.target), str(card_names)]
	print(text)
	_add_log(text)


# Gemini:change.1: 濒死
func _on_player_dying(event: GameEvent) -> void:
	if not enabled:
		return
	var text := "  [⚠ 濒死] %s 进入濒死状态！" % _get_name(event.target)
	print(text)
	_add_log(text)


# Gemini:change.1: 死亡
func _on_player_dead(event: GameEvent) -> void:
	if not enabled:
		return
	AudioManager.play_sfx("death")
	var text := "  [☠ 阵亡] %s 阵亡！" % _get_name(event.target)
	print(text)
	_add_log(text)


# Gemini:change.1: 技能触发
func _on_skill_resolved(event: GameEvent) -> void:
	if not enabled:
		return
	AudioManager.play_sfx("skill_activate")
	var skill_name = event.data.get("skill_name", "未知")
	var text := "  [技能] %s 发动了【%s】" % [_get_name(event.source), skill_name]
	print(text)
	_add_log(text)


# Gemini:change.10: 响应结果（订阅 RESPONSE_RECEIVED）
## event.source = 响应者（被询问的玩家），event.target = 请求发起方（可能为 -1）
func _on_response(event: GameEvent) -> void:
	if not enabled:
		return
	# Gemini:change.13: 修复——用 event.source（响应者）而非 event.target（请求者）
	# 濒死求桃时请求者为 -1（系统），用 event.target 会显示 Player_-1
	var responder_name := _get_name(event.source)
	var played = event.data.get("played", false)
	var text := ""
	if played:
		var card_used = event.data.get("card_used", null)
		var card_name = card_used.card_name if card_used != null else "?"
		text = "  [响应] %s 打出了【%s】" % [responder_name, card_name]
	else:
		text = "  [响应] %s 未打出响应牌" % responder_name
	if text != "":
		print(text)
		_add_log(text)


# Gemini:change.1: 打印当前战局状态摘要
func print_status_summary() -> void:
	if _context == null:
		return
	print("")
	print("───── 战局状态 ─────")
	_add_log("───── 战局状态 ─────")
	for player in _context.players:
		var status = "✓" if player.is_alive else "✗"
		var name = "Player_%d" % player.index
		if player.hero_data:
			name = player.hero_data.hero_name
		var role = "人类" if player.is_human else "AI"
		var line := "  [%s] %s (%s) HP:%d/%d 手牌:%d" % [
			status, name, role,
			player.current_hp, player.max_hp,
			player.hand_cards.size()
		]
		print(line)
		_add_log(line)
	var deck_line := "  牌堆: 抽牌堆 %d | 弃牌堆 %d" % [
		_context.draw_pile.size(),
		_context.discard_pile.size()
	]
	print(deck_line)
	_add_log(deck_line)
	print("────────────────────")
	_add_log("────────────────────")


# Gemini:change.1: 清理
func cleanup() -> void:
	EventBus.unsubscribe_all(self)
