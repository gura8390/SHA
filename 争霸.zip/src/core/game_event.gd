# ============================================================
# game_event.gd
# 通用游戏事件对象：所有系统间通信的标准数据载体
# 事件本身只携带数据，不包含任何业务逻辑
#
# 因果链（架构铁律 2）：每个事件携带全局唯一 event_id；由其他事件派生的
# 子事件记录 parent_event_id，形成可追溯链路（日志/回放/调试）。
# ============================================================

class_name GameEvent
extends RefCounted

# 统一事件类型枚举
# 所有游戏中可能发生的事件都必须在此注册
# 技能通过监听这些事件类型来决定是否触发
enum Type {
	# ----- 回合相关 -----
	TURN_START,          ## 回合开始（当前玩家回合正式开始）
	TURN_END,            ## 回合结束（当前玩家回合正式结束）

	# ----- 阶段相关 -----
	PHASE_START,         ## 阶段开始（准备/判定/摸牌/出牌/弃牌/结束）
	PHASE_END,           ## 阶段结束

	# ----- 卡牌使用相关 -----
	CARD_USED,           ## 卡牌被使用（已声明使用，尚未结算）
	CARD_TARGETED,       ## 成为卡牌目标（目标被指定）
	CARD_RESOLVED,       ## 卡牌结算完成
	CARD_CANCELLED,      ## 卡牌被取消（如被无懈可击抵消）

	# ----- 伤害与回复 -----
	DAMAGE_BEFORE,       ## 即将造成伤害（可被技能修改/拦截）
	DAMAGE_AFTER,        ## 伤害已造成（事后通知，如遗计触发）
	HEAL_BEFORE,         ## 即将回复体力
	HEAL_AFTER,          ## 体力已回复

	# ----- 手牌变化 -----
	DRAW_CARD,           ## 摸牌事件（阶段级：摸牌阶段批量，保留兼容）
	DISCARD_CARD,        ## 弃牌事件（阶段级：弃牌阶段批量，保留兼容）
	CARD_LOST,           ## 牌被其他方式失去（已废弃，用 CARD_STOLEN/CARD_DISCARDED）
	CARD_OBTAINED,       ## 获得牌（已废弃，用 CARD_STOLEN/CARD_GIVEN）
	CARD_DRAWN,          ## 单次摸牌入手（由 CardLocationRegistry.move_card 发出）
	CARD_STOLEN,         ## 卡牌被夺取（如反馈、突袭、顺手牵羊）
	CARD_GIVEN,          ## 卡牌被给予（如仁德）
	CARD_DISCARDED,      ## 卡牌被弃置（如过河拆桥、刚烈）
	CARD_CONSUMED,       ## 卡牌被技能消耗（非入弃牌堆）
	JUDGE_CARD_ADDED,    ## 延时锦囊进入判定区

	# ----- 装备相关 -----
	EQUIP_INSTALLED,     ## 装备被装上
	EQUIP_REMOVED,       ## 装备被移除

	# ----- 翻面/连环 -----
	FLIP_BEFORE,         ## 即将翻面（可取消）
	FLIP_AFTER,          ## 翻面完成
	CHAIN_TOGGLED,       ## 连环状态切换（横置/解除）

	# ----- 体力流失 -----
	LOSE_HP_BEFORE,      ## 即将失去体力（不可被伤害防护技能阻止）
	LOSE_HP_AFTER,       ## 体力已失去

	# ----- 生死相关 -----
	PLAYER_DYING,        ## 玩家濒死（可被桃救回）
	PLAYER_DEAD,         ## 玩家死亡（确认无法救回）
	PLAYER_REVIVED,      ## 玩家被救回

	# ----- 判定相关 -----
	JUDGE_START,         ## 判定开始
	JUDGE_RESULT,        ## 判定结果确定（可被改判技能修改）
	JUDGE_FINISH,        ## 判定最终完成

	# ----- 响应相关 -----
	RESPONSE_REQUESTED,  ## 请求响应（如询问是否出闪）
	RESPONSE_RECEIVED,   ## 收到响应结果

	# ----- 技能相关 -----
	SKILL_TRIGGERED,     ## 技能被触发
	SKILL_RESOLVED,      ## 技能结算完成
}

# 事件生命周期阶段（架构铁律 3）
# BEFORE 可被取消；AFTER/RESOLVED 仅通知，不可取消
enum Stage {
	BEFORE,    ## 即将发生，可拦截/改值
	EXECUTE,   ## 正在写状态（内部）
	AFTER,     ## 已发生，仅触发后续
	RESOLVED,  ## 整条结算链结束
}

# ----- 因果链 ID（架构铁律 2）-----
## 全局自增计数器（由 EventBus 在分发时分配，未分配为 -1）
static var _id_counter: int = 0

## 事件全局唯一 ID（-1 表示尚未分配）
var event_id: int = -1

## 父事件 ID（-1 表示根事件）。子事件由其他事件派生时记录父 ID。
var parent_event_id: int = -1

# 事件核心属性
## 事件类型
var event_type: Type = Type.TURN_START

## 事件来源（通常为发起操作的玩家索引，-1 表示系统发起）
var source: int = -1

## 事件目标（受影响的玩家索引，-1 表示无特定目标）
var target: int = -1

## 事件附加数据（灵活字典，不同事件携带不同数据）
## 例如 DAMAGE_BEFORE: {"amount": 1, "card": CardData, "damage_type": "normal"}
## 例如 CARD_USED: {"card": CardData, "targets": [0, 2]}
var data: Dictionary = {}

## 事件所处生命周期阶段
var stage: Stage = Stage.AFTER

## 事件是否已被取消（仅 BEFORE 阶段可置 true）
var is_cancelled: bool = false

## 事件优先级修饰（用于确定多个技能同时响应时的处理顺序）
var priority_modifier: int = 0


## 分配下一个全局唯一事件 ID（由 EventBus 调用）
static func next_id() -> int:
	_id_counter += 1
	return _id_counter


# 便捷构造函数
## 创建一个新的游戏事件实例。
## @param parent: 父事件（非空时自动串接 parent_event_id，形成因果链）
static func create(type: Type, src: int = -1, tgt: int = -1, extra_data: Dictionary = {}, parent: GameEvent = null) -> GameEvent:
	var event = GameEvent.new()
	event.event_type = type
	event.source = src
	event.target = tgt
	event.data = extra_data
	if parent != null:
		event.parent_event_id = parent.event_id
	return event


# 便捷方法——取消事件
## 将事件标记为已取消，后续监听者可检查此标志决定是否跳过
func cancel() -> void:
	is_cancelled = true


# 调试用字符串表示
func _to_string() -> String:
	return "GameEvent#%d(parent=%d)[%s] src=%d tgt=%d cancelled=%s data=%s" % [
		event_id,
		parent_event_id,
		Type.keys()[event_type],
		source,
		target,
		str(is_cancelled),
		str(data)
	]
