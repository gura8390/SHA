# ============================================================
# event_bus.gd
# 全局事件中心（Autoload 单例）
# 职责：管理事件订阅、发布、优先级排序
# 所有系统间通信必须通过 EventBus，禁止直接耦合
# Gemini:change.1: 初始创建——实现 subscribe/unsubscribe/publish
# ============================================================

extends Node

# Gemini:change.1: 订阅者数据结构
# key: GameEvent.Type
# value: Array[Dictionary]，每个 Dictionary 包含:
#   - "callback": Callable  (接收 GameEvent 参数)
#   - "priority": int       (越大越先执行，默认 0)
#   - "owner": Object       (订阅者引用，用于自动清理)
var _subscribers: Dictionary = {}


# Gemini:change.1: 订阅事件
## 注册一个回调函数监听指定类型的事件
## @param event_type: 要监听的事件类型
## @param callback: 回调函数，签名为 func(event: GameEvent) -> void
## @param priority: 优先级，越大越先被调用（默认 0）
## @param owner: 订阅者对象引用（用于批量取消订阅）
func subscribe(event_type: GameEvent.Type, callback: Callable, priority: int = 0, p_owner: Object = null) -> void:
	if not _subscribers.has(event_type):
		_subscribers[event_type] = []

	var entry: Dictionary = {
		"callback": callback,
		"priority": priority,
		"owner": p_owner,
	}

	_subscribers[event_type].append(entry)
	# Gemini:change.1: 按优先级降序排列，高优先级先执行
	_subscribers[event_type].sort_custom(_sort_by_priority)


# Gemini:change.1: 取消订阅（按回调）
## 移除指定事件类型下的指定回调
func unsubscribe(event_type: GameEvent.Type, callback: Callable) -> void:
	if not _subscribers.has(event_type):
		return
	var list: Array = _subscribers[event_type]
	for i in range(list.size() - 1, -1, -1):
		if list[i]["callback"] == callback:
			list.remove_at(i)
			break


# Gemini:change.1: 批量取消订阅（按拥有者）
## 移除某个对象注册的所有事件监听（对象销毁时调用）
func unsubscribe_all(p_owner: Object) -> void:
	for event_type in _subscribers.keys():
		var list: Array = _subscribers[event_type]
		for i in range(list.size() - 1, -1, -1):
			if list[i]["owner"] == p_owner:
				list.remove_at(i)


# Gemini:change.1: 发布事件（同步，纯通知语义）
## 将事件分发给所有该类型的订阅者，订阅者按优先级从高到低依次调用。
## 如果事件被标记为 is_cancelled，后续低优先级订阅者仍会收到事件
## （由订阅者自行检查 is_cancelled 决定是否处理）。
#
# 注意：EventBus 只负责"事件通知"（同步、广播）。
# "定向等待某个玩家返回决策"（如杀→等闪、濒死→等桃）的职责
# 由 ResponseRequest 管道承担，不要在这里用同步填充做请求-响应。
func publish(event: GameEvent) -> GameEvent:
	# 分配全局唯一事件 ID（架构铁律 2：因果链）
	if event.event_id < 0:
		event.event_id = GameEvent.next_id()

	if not _subscribers.has(event.event_type):
		return event

	var list: Array = _subscribers[event.event_type]
	# Gemini:change.1: 复制列表后遍历，防止回调中修改订阅列表导致迭代异常
	var snapshot: Array = list.duplicate()
	for entry in snapshot:
		var callback: Callable = entry["callback"]
		if callback.is_valid():
			callback.call(event)
		else:
			# Gemini:change.1: 自动清理失效的回调（对象已销毁）
			list.erase(entry)

	return event


# Gemini:change.1: 优先级排序比较函数（降序：高优先级在前）
func _sort_by_priority(a: Dictionary, b: Dictionary) -> bool:
	return a["priority"] > b["priority"]


# Gemini:change.1: 清空所有订阅（用于战斗结束重置）
func clear_all() -> void:
	_subscribers.clear()


# Gemini:change.1: 调试用——打印当前订阅状态
func debug_print_subscribers() -> void:
	print("===== EventBus Subscribers =====")
	for event_type in _subscribers.keys():
		var type_name = GameEvent.Type.keys()[event_type]
		var count = _subscribers[event_type].size()
		print("  %s: %d subscriber(s)" % [type_name, count])
	print("================================")
