# ============================================================
# rng_service.gd
# 确定性随机源（架构铁律 9）
#
# 全局唯一的随机来源。所有规则层的随机（洗牌、判定、AI 抖动）必须
# 经此服务，禁止直接 randi()/Array.shuffle()。相同 seed + 相同调用序列
# → 相同结果，为存档/回放/未来联机提供确定性基础。
# ============================================================

class_name RngService
extends RefCounted

## 底层随机数生成器
var _rng: RandomNumberGenerator = RandomNumberGenerator.new()

## 本局种子（记录入存档，用于回放）
var seed_value: int = 0


## 初始化随机源。
## @param p_seed: 指定种子；<0 时随机生成一个并记录。
func setup(p_seed: int = -1) -> void:
	if p_seed < 0:
		_rng.randomize()
		seed_value = _rng.seed
	else:
		seed_value = p_seed
		_rng.seed = p_seed


## 返回 [0, n) 的随机整数。
func randi_below(n: int) -> int:
	if n <= 0:
		return 0
	return _rng.randi() % n


## 返回 [from, to] 闭区间随机整数。
func randi_range(from: int, to: int) -> int:
	return _rng.randi_range(from, to)


## 返回 [0.0, 1.0) 随机浮点。
func randf() -> float:
	return _rng.randf()


## 就地洗牌一个数组（Fisher-Yates，使用本服务的确定性随机）。
func shuffle(arr: Array) -> void:
	var n := arr.size()
	for i in range(n - 1, 0, -1):
		var j := _rng.randi() % (i + 1)
		var tmp = arr[i]
		arr[i] = arr[j]
		arr[j] = tmp


## 从数组随机取一个元素（空数组返回 null）。
func pick(arr: Array):
	if arr.is_empty():
		return null
	return arr[randi_below(arr.size())]


## 导出状态（供存档：种子 + 当前 RNG 内部状态）。
func serialize() -> Dictionary:
	return {"seed": seed_value, "state": _rng.state}


## 恢复状态（供读档）。
func deserialize(d: Dictionary) -> void:
	seed_value = d.get("seed", 0)
	_rng.seed = seed_value
	if d.has("state"):
		_rng.state = d["state"]
