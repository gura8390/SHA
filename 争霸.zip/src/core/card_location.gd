# ============================================================
# card_location.gd
# 牌位真值登记表（架构铁律：单一真值原则）
#
# 每张 CardData 的当前位置（区域 + 拥有者）是唯一、可查询、可校验的真值。
# 旧内核没有此真值，靠"遍历全场猜一张牌被谁认领"判断归属，是卡牌泄漏/
# 复制/凭空消失系列 bug 的根因。
#
# 唯一移动入口：move_card()。它从源区移除、登记到目标区，并发出精确的
# 语义事件（CARD_DRAWN / CARD_DISCARDED / CARD_STOLEN / ...，架构铁律 7）。
#
# 迁移说明：M0 阶段本登记表与 BattleContext 的数组（hand_cards/discard_pile…）
# 并存，move_card 同步维护两者；M2/M5 逐步把直接数组操作替换为 move_card。
# ============================================================

class_name CardLocationRegistry
extends RefCounted

## 牌区枚举
enum Zone {
	DRAW_PILE,      ## 抽牌堆
	DISCARD_PILE,   ## 弃牌堆
	HAND,           ## 手牌
	EQUIP,          ## 装备区
	JUDGE,          ## 判定区（延时锦囊）
	PROCESSING,     ## 结算中间态（已离开原区、尚未入目标区）
	LIMBO,          ## 未登记/游离（默认）
}

## 战场上下文引用（持有各区域数组）
var _context = null

## 牌位真值表：card(CardData) -> { "zone": Zone, "owner": int }
## owner 对牌堆/弃堆/结算中为 -1
var _locations: Dictionary = {}


func setup(context) -> void:
	_context = context


# ============================================================
# 查询
# ============================================================

## 查询一张牌的位置真值。未登记返回 LIMBO。
func locate(card) -> Dictionary:
	if card != null and _locations.has(card):
		return _locations[card]
	return {"zone": Zone.LIMBO, "owner": -1}


## 一张牌是否在指定区域（可选限定 owner）。
func is_in(card, zone: int, owner: int = -1) -> bool:
	var loc := locate(card)
	if loc["zone"] != zone:
		return false
	if owner >= 0 and loc["owner"] != owner:
		return false
	return true


## 列举某区域（可选某 owner）的全部牌。
func cards_in(zone: int, owner: int = -1) -> Array:
	var result: Array = []
	for card in _locations:
		var loc = _locations[card]
		if loc["zone"] != zone:
			continue
		if owner >= 0 and loc["owner"] != owner:
			continue
		result.append(card)
	return result


# ============================================================
# 唯一移动入口
# ============================================================

## 把一张牌移动到目标区域，并发出对应语义事件。
## @param card: 要移动的牌
## @param to_zone: 目标区域（Zone）
## @param to_owner: 目标拥有者索引（牌堆/弃堆/结算中传 -1）
## @param reason: 迁移原因（"draw"/"usage"/"discard"/"snatch"/"give"/"skill"/"equip"...）
## @param parent_event_id: 因果链父事件 ID（架构铁律 2）
func move_card(card, to_zone: int, to_owner: int = -1, reason: String = "", parent_event_id: int = -1) -> void:
	if card == null:
		return
	var from := locate(card)
	# 1) 从源区数组移除（同步维护 BattleContext 数组）
	_detach_from_zone(card, from["zone"], from["owner"])
	# 2) 登记到目标区
	_locations[card] = {"zone": to_zone, "owner": to_owner}
	# 3) 挂入目标区数组
	_attach_to_zone(card, to_zone, to_owner)
	# 4) 发出语义事件
	_emit_move_event(card, from, {"zone": to_zone, "owner": to_owner}, reason, parent_event_id)


## 仅登记位置，不触碰数组、不发事件（用于初始化时与既有数组对齐）。
func register(card, zone: int, owner: int = -1) -> void:
	if card == null:
		return
	_locations[card] = {"zone": zone, "owner": owner}


## 注销一张牌（极少用：彻底移出对局）。
func unregister(card) -> void:
	_locations.erase(card)


## 从 BattleContext 既有区域数组重建整张真值表。
## M0 阶段用于在装配完成后（发完初始手牌）一次性对齐；
## 后续里程碑把直接数组操作替换为 move_card 后，此方法仅作开局初始化用。
func sync_from_context() -> void:
	if _context == null:
		return
	_locations.clear()
	for card in _context.draw_pile:
		_locations[card] = {"zone": Zone.DRAW_PILE, "owner": -1}
	for card in _context.discard_pile:
		_locations[card] = {"zone": Zone.DISCARD_PILE, "owner": -1}
	for p in _context.players:
		for card in p.hand_cards:
			_locations[card] = {"zone": Zone.HAND, "owner": p.index}
		for card in p.judge_cards:
			_locations[card] = {"zone": Zone.JUDGE, "owner": p.index}
		for card in [p.equip_weapon, p.equip_armor, p.equip_horse_def, p.equip_horse_atk, p.equip_treasure]:
			if card != null:
				_locations[card] = {"zone": Zone.EQUIP, "owner": p.index}


# ============================================================
# 数组同步（与 BattleContext 既有区域数组保持一致）
# ============================================================

func _detach_from_zone(card, zone: int, owner: int) -> void:
	if _context == null:
		return
	match zone:
		Zone.DRAW_PILE:
			_context.draw_pile.erase(card)
		Zone.DISCARD_PILE:
			_context.discard_pile.erase(card)
		Zone.HAND:
			var p = _context.get_player(owner)
			if p != null:
				p.hand_cards.erase(card)
		Zone.JUDGE:
			var p2 = _context.get_player(owner)
			if p2 != null:
				p2.judge_cards.erase(card)
		Zone.EQUIP:
			var p3 = _context.get_player(owner)
			if p3 != null:
				_detach_equip(p3, card)
		_:
			pass  # PROCESSING / LIMBO 无数组


func _attach_to_zone(card, zone: int, owner: int) -> void:
	if _context == null:
		return
	match zone:
		Zone.DRAW_PILE:
			if not _context.draw_pile.has(card):
				_context.draw_pile.append(card)
		Zone.DISCARD_PILE:
			if not _context.discard_pile.has(card):
				_context.discard_pile.append(card)
		Zone.HAND:
			var p = _context.get_player(owner)
			if p != null and not p.hand_cards.has(card):
				p.hand_cards.append(card)
		Zone.JUDGE:
			var p2 = _context.get_player(owner)
			if p2 != null and not p2.judge_cards.has(card):
				p2.judge_cards.append(card)
		Zone.EQUIP:
			pass  # 装备槽位由 EquipEffect 决定，此处不自动塞
		_:
			pass  # PROCESSING / LIMBO 无数组


func _detach_equip(player, card) -> void:
	if player.equip_weapon == card:
		player.equip_weapon = null
	elif player.equip_armor == card:
		player.equip_armor = null
	elif player.equip_horse_def == card:
		player.equip_horse_def = null
	elif player.equip_horse_atk == card:
		player.equip_horse_atk = null
	elif player.equip_treasure == card:
		player.equip_treasure = null


# ============================================================
# 语义事件（架构铁律 7：精确语义）
# ============================================================

func _emit_move_event(card, from: Dictionary, to: Dictionary, reason: String, parent_event_id: int) -> void:
	var ev: GameEvent = null
	match to["zone"]:
		Zone.HAND:
			match from["zone"]:
				Zone.DRAW_PILE:
					ev = GameEvent.create(GameEvent.Type.CARD_DRAWN, to["owner"], to["owner"], {"card": card, "reason": reason})
				Zone.HAND:
					ev = GameEvent.create(GameEvent.Type.CARD_STOLEN, from["owner"], to["owner"], {"card": card, "reason": reason, "source": from["owner"], "target": to["owner"]})
				_:
					ev = GameEvent.create(GameEvent.Type.CARD_GIVEN, from["owner"], to["owner"], {"card": card, "reason": reason, "source": from["owner"], "target": to["owner"]})
		Zone.DISCARD_PILE:
			ev = GameEvent.create(GameEvent.Type.CARD_DISCARDED, from["owner"], -1, {"card": card, "reason": reason, "source": from["owner"]})
		Zone.JUDGE:
			ev = GameEvent.create(GameEvent.Type.JUDGE_CARD_ADDED, to["owner"], to["owner"], {"card": card, "reason": reason})
		_:
			pass  # 进入 PROCESSING/DRAW_PILE 等不在此发事件（由调用方按需发）
	if ev != null:
		ev.parent_event_id = parent_event_id
		EventBus.publish(ev)


# ============================================================
# 不变量校验（架构第七章）
# ============================================================

## 牌守恒：登记表中的牌总数应等于牌库总数。
func validate_conservation(expected_total: int) -> bool:
	var counted := _locations.size()
	if counted != expected_total:
		push_warning("[CardLocation] 牌守恒被破坏：登记 %d ≠ 预期 %d" % [counted, expected_total])
		return false
	return true


## 单所有权：每张牌只登记一次（Dictionary 天然保证 key 唯一，此处校验区域合法）。
func validate_single_ownership() -> bool:
	for card in _locations:
		var loc = _locations[card]
		if loc["zone"] == Zone.HAND or loc["zone"] == Zone.JUDGE or loc["zone"] == Zone.EQUIP:
			if loc["owner"] < 0:
				push_warning("[CardLocation] 牌 %s 在玩家区却无 owner" % card)
				return false
	return true
