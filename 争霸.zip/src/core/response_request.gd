# ============================================================
# response_request.gd
# 请求-响应管道核心：封装一次"询问某玩家是否打出某牌"的异步请求
#
# 设计动机：
#   旧实现用 "EventBus.publish(RESPONSE_REQUESTED) + 同步填充 event.data"
#   只能服务 AI（同步函数里无法等人类点按钮）。本类把"等响应"从
#   EventBus 解耦出来：EventBus 只做事件通知（同步广播），
#   而"定向等待某个玩家返回决策"的职责交给 ResponseRequest（可 await）。
#
# 调用方式：
#   var result: ResponseResult = await ResponseRequest.ask(
#       battle_context, target_index, "闪", source_index, context_dict)
#   if result.played: ...
#
# Gemini:change.1: 新建——请求-响应管道，取代同步 publish+读 data 模式
# ============================================================

class_name ResponseRequest
extends RefCounted

## 全局自增请求ID（调试用）
static var _next_id: int = 1

## 本请求ID
var request_id: int = 0

## 被询问的玩家索引
var target_index: int = -1

## 要求打出的牌名（如 "闪"/"杀"/"桃"）
var required_card_name: String = ""

## 请求发起方（伤害来源/决斗对手等），-1 表示系统
var source_index: int = -1

## 附加上下文（提示文案、来源牌等）
var context: Dictionary = {}

## 响应结果（await 完成后填入）
var result: ResponseResult = null


# Gemini:change.1: 静态入口——发起一次响应请求并 await 结果
## 这是外部使用的唯一入口
## @param battle_context: 战场上下文（用于查 controller）
## @param target_idx: 被询问玩家
## @param required: 要求的牌名（"闪"/"杀"/"桃"）
## @param src_idx: 请求发起方
## @param extra: 附加上下文
## @return: ResponseResult
static func ask(
	battle_context,
	target_idx: int,
	required: String,
	src_idx: int = -1,
	extra: Dictionary = {}
) -> ResponseResult:
	var req = ResponseRequest.new()
	req.request_id = _next_id
	_next_id += 1
	req.target_index = target_idx
	req.required_card_name = required
	req.source_index = src_idx
	req.context = extra
	return await req._resolve(battle_context)


# Gemini:change.1: 内部——根据目标玩家类型分派响应
## AI 玩家：调用其 controller.decide_response()，同步返回
## 人类玩家：发布 UI 请求事件并 await 回填（本轮 controller 未实现，预留接口）
func _resolve(battle_context) -> ResponseResult:
	var target_player = battle_context.get_player(target_index)
	if target_player == null or not target_player.is_alive:
		# 已死亡或无效目标：视为放弃响应
		result = ResponseResult.not_played()
		return result

	# 先发一个 RESPONSE_REQUESTED 通知事件（供日志/UI 监听，纯通知，不带返回值语义）
	var notify_event = GameEvent.create(
		GameEvent.Type.RESPONSE_REQUESTED,
		source_index,
		target_index,
		{
			"required_response": required_card_name,
			"source_index": source_index,
			"request_id": request_id,
			"context": context,
		}
	)
	EventBus.publish(notify_event)

	# Gemini:change.10: 跳过没有对应牌的玩家（避免无意义的询问）
	# 注：酒可以代替桃濒死时使用，所以濒死求桃时不跳过
	# Gemini:change.12: 同时检查转化技能（武圣/龙胆/急救等）
	var has_convertible := false
	if battle_context.has_method("get_convertible_cards"):
		var conversions = battle_context.get_convertible_cards(target_index, required_card_name, battle_context.current_phase)
		has_convertible = not conversions.is_empty()
		if has_convertible:
			# 将转化信息附加上下文，供控制器决策
			context["convertible_skills"] = conversions

	if required_card_name != "" and required_card_name != "桃":
		if not _player_has_card(target_player, required_card_name) and not has_convertible:
			result = ResponseResult.not_played()
			return result

	# ===== 统一通过控制器决策（AI 同步返回，人类 await UI）=====
	var controller = battle_context.get_controller(target_index)
	if controller == null:
		# 无 controller（理论不应发生）：放弃响应
		result = ResponseResult.not_played()
	else:
		result = await controller.decide_response(self)

	# 发一个 RESPONSE_RECEIVED 通知事件
	var received_event = GameEvent.create(
		GameEvent.Type.RESPONSE_RECEIVED,
		target_index,
		source_index,
		{
			"played": result.played,
			"card_used": result.card_used,
			"request_id": request_id,
		}
	)
	EventBus.publish(received_event)

	return result


func _to_string() -> String:
	return "ResponseRequest[id=%d target=%d required=%s]" % [
		request_id, target_index, required_card_name
	]


## 检查玩家是否有指定名称的牌
static func _player_has_card(player, card_name: String) -> bool:
	if player == null:
		return false
	for c in player.hand_cards:
		if c.card_name == card_name:
			return true
	return false
