# ============================================================
# death_resolver.gd
# 濒死-求桃-死亡结算器（修 Bug-3：玩家永不死亡）
#
# 旧实现：DamageEffect 扣血后只 publish(PLAYER_DYING) 就 return，
# 没有任何代码消费这个事件，导致 HP<=0 的角色 is_alive 永远为 true，
# 游戏靠 MAX_ROUNDS=200 强制终止——这是最严重的阻塞 bug。
#
# 本类接管濒死流程：
#   1. 从濒死者开始，按座位顺序逐一 await 询问是否使用"桃"
#   2. 有人出桃 → 濒死者 HP+1，脱险返回（saved=true）
#   3. 无人救 → 触发 PLAYER_DEAD，置 is_alive=false，移出存活列表，奖惩结算
#
# 注意：本类不订阅事件，而是由 DamageEffect 在扣血后主动 await 调用。
# 这样可以保证"扣血→求桃→死亡"是串行的，不会和其他结算交错。
#
# Gemini:change.1: 新建——濒死求桃完整结算
# ============================================================

class_name DeathResolver
extends RefCounted

## 战场上下文
var _context: BattleContext = null


# Gemini:change.1: 初始化
func setup(context: BattleContext) -> void:
	_context = context


# Gemini:change.1: 执行濒死求桃流程（async）
## @param dying_index: 濒死的玩家索引
## @param killer_index: 致死的伤害来源（-1 表示无来源/失去体力）
## @return: true=被救回，false=死亡
func resolve_dying(dying_index: int, killer_index: int) -> bool:
	var dying_player = _context.get_player(dying_index)
	if dying_player == null:
		return false

	# 只要 HP 仍然 <=0 就继续求桃（可能多次求桃）
	while dying_player.current_hp <= 0:
		var saved = await _ask_for_peach(dying_index, killer_index)
		if not saved:
			# 无人救援，角色死亡
			_resolve_death(dying_player, killer_index)
			return false
		# 有人出桃，HP+1，重新判断是否脱险（HP>0 即脱险）

	return true  # 被救回


# Gemini:change.1: 一轮求桃：从濒死者开始按座位顺序逐一询问
## 任何一人出桃即视为本轮救援成功
func _ask_for_peach(dying_index: int, killer_index: int) -> bool:
	var alive = _context.get_alive_players()
	if alive.is_empty():
		return false

	# Gemini:change.3: 修编译错误——本函数作用域需自行取濒死者引用
	var dying_player = _context.get_player(dying_index)
	if dying_player == null:
		return false

	# 定位濒死者在存活列表中的位置
	var start_pos = -1
	for i in range(alive.size()):
		if alive[i].index == dying_index:
			start_pos = i
			break
	if start_pos == -1:
		# 濒死者已不在存活列表（理论不应发生），无法求桃
		return false

	# 从濒死者开始环形遍历所有人
	for i in range(alive.size()):
		var idx = (start_pos + i) % alive.size()
		var helper = alive[idx]
		if not helper.is_alive:
			continue

		# 异步询问此人是否出桃（濒死者自己可用酒代替桃）
		var required_card := "桃"
		var prompt_text := "%s 濒死，是否使用【桃】救援？" % (dying_player.hero_data.hero_name if dying_player.hero_data else "玩家")
		if helper.index == dying_index:
			# 濒死者自救：酒也可用
			if _player_has_card(helper, "酒") and not _player_has_card(helper, "桃"):
				required_card = "酒"
				prompt_text = "你濒死，是否使用【酒】自救？"
			elif _player_has_card(helper, "酒") and _player_has_card(helper, "桃"):
				# 优先用桃（酒留给酒+杀组合），但提示中说明酒也可用
				required_card = "桃"
				prompt_text = "你濒死，是否使用【桃】自救？（也可使用【酒】）"
		var result: ResponseResult = await ResponseRequest.ask(
			_context,
			helper.index,
			required_card,
			-1,
			{
				"context": "dying_save",
				"dying_player": dying_index,
				"killer": killer_index,
				"prompt": prompt_text,
			}
		)

		if result.played and result.card_used != null:
			# 救援成功：濒死者 HP+1，桃经 Effect 入弃牌堆
			var peach_card = result.card_used
			# Gemini:change.12: 转化牌模式——移除实际牌而非虚拟牌（如急救：红牌当桃）
			var actual_card = result.convert_source if result.convert_source != null else peach_card
			helper.hand_cards.erase(actual_card)
			var discard_eff = DiscardCardEffect.create(
				helper.index, helper.index, [actual_card],
				DiscardCardEffect.DiscardReason.USAGE
			)
			discard_eff.resolve(_context)
			# 濒死者回血1点（不经过 HealEffect，因为这是濒死救援的特殊回血，
			# 三国杀规则：桃在濒死时使用直接令 HP 从0变1，不受减伤/禁疗影响）
			dying_player.current_hp += 1
			# 发布被救回事件
			var revive_event = GameEvent.create(
				GameEvent.Type.PLAYER_REVIVED,
				helper.index,
				dying_index,
				{"savior": helper.index, "peach": peach_card}
			)
			EventBus.publish(revive_event)
			return true

	return false  # 所有人都不出桃


# Gemini:change.1: 死亡结算
## 置 is_alive=false，发布 PLAYER_DEAD，奖惩结算
func _resolve_death(dead_player, killer_index: int) -> void:
	dead_player.is_alive = false
	# Gemini:change.6: 死亡即翻开身份
	dead_player.identity_revealed = true
	# 清理翻面/连环状态
	dead_player.is_flipped = false
	dead_player.is_chained = false

	# Gemini:change.10: 死亡弃置所有手牌和装备
	_discard_dead_player_cards(_context, dead_player)

	# 发布死亡事件（技能如反馈死亡弃牌、奖惩在此触发）
	var death_event = GameEvent.create(
		GameEvent.Type.PLAYER_DEAD,
		killer_index,
		dead_player.index,
		{
			"dead_player": dead_player.index,
			"killer": killer_index,
		}
	)
	EventBus.publish(death_event)

	# Gemini:change.10: 击杀奖惩结算
	_apply_kill_reward(_context, killer_index, dead_player)


## 死亡弃置所有手牌和装备
static func _discard_dead_player_cards(ctx, dead_player) -> void:
	var all_cards: Array = []
	all_cards.append_array(dead_player.hand_cards)
	dead_player.hand_cards.clear()
	if dead_player.equip_weapon != null:
		all_cards.append(dead_player.equip_weapon)
		dead_player.equip_weapon = null
	if dead_player.equip_armor != null:
		all_cards.append(dead_player.equip_armor)
		dead_player.equip_armor = null
	if dead_player.equip_horse_def != null:
		all_cards.append(dead_player.equip_horse_def)
		dead_player.equip_horse_def = null
	if dead_player.equip_horse_atk != null:
		all_cards.append(dead_player.equip_horse_atk)
		dead_player.equip_horse_atk = null
	if dead_player.equip_treasure != null:
		all_cards.append(dead_player.equip_treasure)
		dead_player.equip_treasure = null
	if not dead_player.judge_cards.is_empty():
		all_cards.append_array(dead_player.judge_cards)
		dead_player.judge_cards.clear()
	if not all_cards.is_empty():
		for c in all_cards:
			ctx.add_to_discard_pile(c)


## 检查玩家是否有指定名称的牌
static func _player_has_card(player, card_name: String) -> bool:
	if player == null:
		return false
	for c in player.hand_cards:
		if c.card_name == card_name:
			return true
	return false


## 击杀奖惩结算
## 杀反贼 → 摸3张牌
## 杀忠臣 → 弃置所有手牌和装备（主公杀忠臣时）
## 杀内奸/队友 → 无奖惩
static func _apply_kill_reward(ctx, killer_index: int, dead_player) -> void:
	if killer_index < 0:
		return  # 无击杀者（如闪电致死）
	var killer = ctx.get_player(killer_index)
	if killer == null or not killer.is_alive:
		return

	var dead_identity = dead_player.identity

	# 杀反贼 → 摸3张牌
	if dead_identity == Identity.Type.REBEL:
		DrawCardEffect.create(killer_index, killer_index, 3).resolve(ctx)
		EventBus.publish(GameEvent.create(
			GameEvent.Type.SKILL_RESOLVED, killer_index, dead_player.index,
			{"skill_name": "击杀奖惩", "effect": "draw_3"}
		))

	# 主公杀忠臣 → 弃置所有手牌和装备
	elif dead_identity == Identity.Type.LOYALIST and killer.identity == Identity.Type.LORD:
		# 弃置手牌
		if not killer.hand_cards.is_empty():
			var hand_cards = killer.hand_cards.duplicate()
			killer.hand_cards.clear()
			DiscardCardEffect.create(
				killer_index, killer_index, hand_cards, DiscardCardEffect.DiscardReason.FORCED
			).resolve(ctx)
		# 弃置装备
		var equip_cards: Array = []
		if killer.equip_weapon != null:
			equip_cards.append(killer.equip_weapon)
			killer.equip_weapon = null
		if killer.equip_armor != null:
			equip_cards.append(killer.equip_armor)
			killer.equip_armor = null
		if killer.equip_horse_def != null:
			equip_cards.append(killer.equip_horse_def)
			killer.equip_horse_def = null
		if killer.equip_horse_atk != null:
			equip_cards.append(killer.equip_horse_atk)
			killer.equip_horse_atk = null
		if killer.equip_treasure != null:
			equip_cards.append(killer.equip_treasure)
			killer.equip_treasure = null
		if not equip_cards.is_empty():
			DiscardCardEffect.create(
				killer_index, killer_index, equip_cards, DiscardCardEffect.DiscardReason.FORCED
			).resolve(ctx)
		EventBus.publish(GameEvent.create(
			GameEvent.Type.SKILL_RESOLVED, killer_index, dead_player.index,
			{"skill_name": "击杀奖惩", "effect": "discard_all"}
		))
