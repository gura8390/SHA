# ============================================================
# response_result.gd
# 响应结果载体：一次"询问是否打出某牌"的返回值
# 由 ResponseRequest 在 await 完成后产出，由请求方（杀/决斗/南蛮/求桃）消费
# Gemini:change.1: 新建——请求-响应管道的结果对象
# ============================================================

class_name ResponseResult
extends RefCounted

## 是否打出了牌
var played: bool = false

## 打出的牌（played=true 时非空，played=false 时为 null）
var card_used: CardData = null

## Gemini:change.10: 附加上下文（用于特殊标记如 skip_all_wuxie）
var context_data: Dictionary = {}

## Gemini:change.12: 转化牌标记——实际从手牌移除的牌（武圣/龙胆/急救等）
## 当 convert_source 非空时，消费方应移除 convert_source 而非 card_used
var convert_source: CardData = null


# Gemini:change.1: 便捷构造——未打出（放弃响应）
static func not_played() -> ResponseResult:
	var r = ResponseResult.new()
	r.played = false
	r.card_used = null
	return r


# Gemini:change.1: 便捷构造——打出了一张牌
static func played_card(card: CardData) -> ResponseResult:
	var r = ResponseResult.new()
	r.played = true
	r.card_used = card
	return r


# Gemini:change.12: 便捷构造——通过转化打出了一张牌
## virtual_card: 虚拟牌（如虚拟闪），real_card: 手中实际消耗的牌
static func played_converted(virtual_card: CardData, real_card: CardData) -> ResponseResult:
	var r = ResponseResult.new()
	r.played = true
	r.card_used = virtual_card
	r.convert_source = real_card
	return r


func _to_string() -> String:
	if played and card_used:
		if convert_source:
			return "ResponseResult[played=%s(converted from %s)]" % [card_used.card_name, convert_source.card_name]
		return "ResponseResult[played=%s]" % card_used.card_name
	return "ResponseResult[played=false]"
