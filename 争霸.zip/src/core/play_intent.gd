# ============================================================
# play_intent.gd
# 出牌意图：玩家控制器（AI/人类）表达"本回合想用哪张牌、对谁"
# 由 IPlayerController.decide_play_action() 返回，由 PlayCardEffect 消费
#
# 设计动机：
#   旧实现里 SimpleAI 自己 erase 手牌 + 入弃牌堆 + 创建 effect action，
#   绕过了 Effect 系统且职责越界。改为：控制器只"声明意图"，
#   具体的"从手牌移除→发事件→结算→入弃牌堆"由 PlayCardEffect 统一执行。
#
# Gemini:change.1: 新建——出牌意图载体
# ============================================================

class_name PlayIntent
extends RefCounted

## 要使用的卡牌（必须在使用者手牌中）
var card: CardData = null

## 目标玩家索引列表（杀=1个目标，南蛮=空，桃=自己等）
var target_indices: Array = []  # Array[int]

## 使用者索引（便于校验，由 PlayCardEffect 填充/校验）
var source_index: int = -1

## Gemini:change.7: 主动技发动意图（非空表示本意图是"发动主动技"而非"使用牌"）
var skill = null  # Skill 实例

## Gemini:change.10: 牌转化标记（丈八蛇矛：两张手牌当杀）
## 非空时表示这些牌代替 card 进行结算（从手牌移除这些牌而非 card）
var convert_cards: Array = []  # Array[CardData]

## Gemini:change.12: 单张转化牌（武圣/龙胆/急救等：一张手牌当另一张使用）
## 非空时 convert_card 代替 card 从手牌移除并入弃牌堆
var convert_card: CardData = null


# Gemini:change.1: 便捷构造——对单目标使用一张牌
static func single_target(src: int, card_data: CardData, target: int) -> PlayIntent:
	var intent = PlayIntent.new()
	intent.source_index = src
	intent.card = card_data
	intent.target_indices = [target]
	return intent


# Gemini:change.1: 便捷构造——无目标（自己/全体）使用一张牌
static func no_target(src: int, card_data: CardData) -> PlayIntent:
	var intent = PlayIntent.new()
	intent.source_index = src
	intent.card = card_data
	intent.target_indices = []
	return intent


# Gemini:change.7: 便捷构造——发动主动技
static func activate_skill(src: int, skill_obj, targets: Array = []) -> PlayIntent:
	var intent = PlayIntent.new()
	intent.source_index = src
	intent.skill = skill_obj
	intent.target_indices = targets.duplicate()
	return intent


# Gemini:change.12: 便捷构造——单张转化牌（武圣/龙胆/急救/乱击等）
## virtual_card: 虚拟牌（如虚拟杀、虚拟桃），convert_card: 手中实际消耗的牌
static func converted_single(src: int, virtual_card: CardData, real_card: CardData, targets: Array = []) -> PlayIntent:
	var intent = PlayIntent.new()
	intent.source_index = src
	intent.card = virtual_card
	intent.convert_card = real_card
	intent.target_indices = targets.duplicate()
	return intent


# Gemini:change.1: 便捷构造——结束出牌阶段（card=null 是约定的"结束"信号）
static func end_play() -> PlayIntent:
	var intent = PlayIntent.new()
	intent.card = null
	return intent


## 是否表示"结束出牌阶段"
## Gemini:change.7: 发动主动技的意图不算结束（card 为 null 但 skill 非空）
func is_end_play() -> bool:
	return card == null and skill == null


## Gemini:change.7: 是否为主动技发动意图
func is_skill_activation() -> bool:
	return skill != null


func _to_string() -> String:
	if skill != null:
		return "PlayIntent[skill=%s targets=%s]" % [
			skill.skill_data.skill_name if skill.skill_data else "?", str(target_indices)
		]
	if card == null:
		return "PlayIntent[end_play]"
	return "PlayIntent[src=%d card=%s targets=%s]" % [
		source_index, card.card_name, str(target_indices)
	]
