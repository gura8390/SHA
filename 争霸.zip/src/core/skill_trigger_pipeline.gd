# ============================================================
# skill_trigger_pipeline.gd
# 触发技询问管道（修 Bug-12：奸雄/反馈 execute 永不调用）
#
# 旧实现：skill.gd 对 TRIGGER 类型只发 SKILL_TRIGGERED 事件，
# 但没有任何代码订阅该事件，导致 execute() 永远不被调用。
#
# 本类订阅 SKILL_TRIGGERED，对每个触发的非锁定技：
#   1. 查询持有者的 controller.decide_skill_activation() 判断是否发动
#   2. 同意 → 调用 skill.execute(event)
#   3. 拒绝 → 跳过
#
# 本轮实现（全 AI）：同步处理，不需要 await。
# 下轮接入人类后，decide_skill_activation 人类版会需要 await UI，
# 届时需将此管道改为 async 版本。
#
# 兼容性：COMPULSORY（锁定技）不经过此管道，仍走 skill.gd 直接 execute。
#
# Gemini:change.1: 新建——触发技询问管道，修复 execute 断链
# ============================================================

class_name SkillTriggerPipeline
extends RefCounted

## 战场上下文引用
var _context: BattleContext = null


# Gemini:change.1: 初始化并订阅 SKILL_TRIGGERED 事件
func setup(context: BattleContext) -> void:
	_context = context
	EventBus.subscribe(GameEvent.Type.SKILL_TRIGGERED, _on_skill_triggered, 0, self)


# Gemini:change.1: 处理触发的技能
func _on_skill_triggered(event: GameEvent) -> void:
	var skill = event.data.get("skill", null)
	var original_event = event.data.get("original_event", null)
	if skill == null or original_event == null:
		return

	var owner_index = event.source
	if _context.get_player(owner_index) == null:
		return

	# 查询持有者的控制器：是否发动此技能
	var controller = _context.get_controller(owner_index)
	if controller == null:
		return

	var should_activate: bool = controller.decide_skill_activation(skill, original_event)
	if should_activate:
		# 玩家同意发动 → 记录使用 + 执行技能效果
		skill.record_use()
		skill.execute(original_event)


# ============================================================
# Gemini:change.7: 主动技查询辅助（供控制器在出牌阶段使用）
# ============================================================

# 返回某玩家当前可发动的主动技列表
static func get_activatable_skills(context, player_index: int) -> Array:
	var result: Array = []
	var player = context.get_player(player_index)
	if player == null:
		return result
	for skill in player.skills:
		if skill == null or skill.skill_data == null:
			continue
		if skill.skill_data.skill_type != SkillData.SkillType.ACTIVE:
			continue
		if skill.can_activate():
			result.append(skill)
	return result


# Gemini:change.1: 清理
func cleanup() -> void:
	EventBus.unsubscribe_all(self)
