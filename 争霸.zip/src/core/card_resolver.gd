# ============================================================
# card_resolver.gd
# 卡牌结算中枢：卡牌类型分发 + 目标/距离合法性校验
#
# 职责：
#   1. 根据 CardData.card_name 创建对应的卡牌效果 GameAction（取代硬编码 match）
#   2. validate_target：检查目标合法性，含【杀】的距离校验（修 Bug-9）
#   3. get_valid_targets：枚举一张牌所有合法目标
#
# Gemini:change.1: 新建——卡牌结算中枢，接入距离系统
# ============================================================

class_name CardResolver
extends RefCounted


# Gemini:change.1: 根据卡牌数据创建对应的卡牌效果 GameAction
## 返回 null 表示该卡牌暂未实现效果
## 由 PlayCardEffect 调用
func create_effect(card: CardData, source_index: int, target_indices: Array) -> GameAction:
	if card == null:
		return null

	# Gemini:change.8: 装备牌 → 装入装备栏
	if card.card_type == CardData.CardType.EQUIPMENT:
		return CardEffectEquip.create_action(source_index, card)

	match card.card_name:
		"杀", "火杀", "雷杀":
			if target_indices.is_empty():
				return null
			return CardEffectSha.create_action(source_index, target_indices[0], card)
		"桃":
			return CardEffectTao.create_action(source_index, card)
		"酒":
			return CardEffectWine.create_action(source_index, card)
		"决斗":
			if target_indices.is_empty():
				return null
			return CardEffectDuel.create_action(source_index, target_indices[0], card)
		"南蛮入侵":
			return CardEffectNanman.create_action(source_index, card)
		"万箭齐发":
			return CardEffectWanjian.create_action(source_index, card)
		"无中生有":
			return CardEffectWuzhong.create_action(source_index, card)
		"桃园结义":
			return CardEffectTaoyuan.create_action(source_index, card)
		"五谷丰登":
			return CardEffectWugu.create_action(source_index, card)
		"过河拆桥", "顺手牵羊":
			if target_indices.is_empty():
				return null
			return CardEffectDismantle.create_action(source_index, target_indices[0], card)
		"火攻":
			if target_indices.is_empty():
				return null
			return CardEffectHuogong.create_action(source_index, target_indices[0], card)
		"乐不思蜀", "兵粮寸断", "闪电":
			# 延时锦囊放置（闪电放自己，乐/兵放目标）
			var tgt = target_indices[0] if not target_indices.is_empty() else source_index
			return CardEffectDelayed.create_action(source_index, tgt, card)
		"借刀杀人":
			if target_indices.size() < 2:
				return null
			return CardEffectJiedao.create_action(source_index, target_indices[0], target_indices[1], card)
		_:
			return null


# Gemini:change.1: 校验"source 能否对 target 使用这张牌"
## 含距离校验（杀需在攻击范围内）、存活校验、目标数量校验、目标牌区非空校验等
## @return: {"valid": bool, "reason": String, ...附加上下文}
func validate_target(
	battle_context,
	source_index: int,
	card: CardData,
	target_index: int
) -> Dictionary:
	var source = battle_context.get_player(source_index)
	var target = battle_context.get_player(target_index)

	if source == null:
		return {"valid": false, "reason": "invalid_source"}
	if target == null or not target.is_alive:
		return {"valid": false, "reason": "invalid_or_dead_target"}
	if source_index == target_index and not card.can_target_self:
		return {"valid": false, "reason": "cannot_target_self"}

	# 【杀】（含火杀/雷杀）需要距离校验：目标距离 <= 攻击范围
	if card.card_name == "杀" or card.card_name == "火杀" or card.card_name == "雷杀":
		var distance = battle_context.get_distance(source_index, target_index)
		var attack_range = source.get_attack_range()
		if distance > attack_range:
			return {
				"valid": false,
				"reason": "out_of_range",
				"distance": distance,
				"attack_range": attack_range,
			}

	# Gemini:change.9: 顺手牵羊距离限制 1
	if card.card_name == "顺手牵羊":
		if battle_context.get_distance(source_index, target_index) > 1:
			return {"valid": false, "reason": "out_of_range"}

	# Gemini:change.10: 顺手牵羊/过河拆桥——目标必须有牌（手牌/装备/判定区）才有意义
	if card.card_name == "顺手牵羊" or card.card_name == "过河拆桥":
		if not _player_has_any_card(target):
			return {"valid": false, "reason": "target_empty"}

	# 火攻——目标必须有手牌
	if card.card_name == "火攻":
		if target.hand_cards.is_empty():
			return {"valid": false, "reason": "target_no_hand"}

	# Gemini:change.10: 兵粮寸断——必须距离 1（标准规则）
	if card.card_name == "兵粮寸断":
		var dist = battle_context.get_distance(source_index, target_index)
		if dist != 1:
			return {"valid": false, "reason": "out_of_range", "distance": dist, "required": 1}

	# Gemini:change.10: 决斗/乐不思蜀/闪电——存活与不能对自己已在上方校验，无需距离校验

	return {"valid": true}


# Gemini:change.10: 判断一个玩家是否持有任意牌（手牌/装备/判定区）
## 用于过河拆桥/顺手牵羊的目标合法性校验
func _player_has_any_card(player) -> bool:
	if player == null:
		return false
	if not player.hand_cards.is_empty():
		return true
	if player.equip_weapon != null or player.equip_armor != null \
			or player.equip_horse_def != null or player.equip_horse_atk != null \
			or player.equip_treasure != null:
		return true
	if not player.judge_cards.is_empty():
		return true
	return false


# Gemini:change.10: 多目标牌的合法性校验（借刀杀人 targets=[A, B]）
## 借刀杀人规则：
##   - A（被借刀者）必须存活且装备了武器
##   - B（受害者）必须存活
##   - B 必须在 A 的攻击范围内
##   - A ≠ B，A ≠ source（不能借自己的刀去杀自己）
## @return: {"valid": bool, "reason": String, "invalid_index": int}
func validate_targets_multi(
	battle_context,
	source_index: int,
	card: CardData,
	targets: Array
) -> Dictionary:
	if card.card_name != "借刀杀人":
		# 仅借刀杀人为双目标；其余多目标牌暂不在此校验
		return {"valid": true}
	if targets.size() < 2:
		return {"valid": false, "reason": "need_two_targets"}

	var a_idx: int = targets[0]
	var b_idx: int = targets[1]
	var source = battle_context.get_player(source_index)
	var a = battle_context.get_player(a_idx)
	var b = battle_context.get_player(b_idx)

	if source == null:
		return {"valid": false, "reason": "invalid_source"}
	if a == null or not a.is_alive:
		return {"valid": false, "reason": "invalid_or_dead_target", "invalid_index": 0}
	if b == null or not b.is_alive:
		return {"valid": false, "reason": "invalid_or_dead_target", "invalid_index": 1}
	# 被借刀者必须装备武器
	if a.equip_weapon == null:
		return {"valid": false, "reason": "no_weapon", "invalid_index": 0}
	# A、B 不能是同一人；A 不能是 source（借自己的刀无意义）
	if a_idx == b_idx:
		return {"valid": false, "reason": "same_target"}
	if a_idx == source_index:
		return {"valid": false, "reason": "cannot_steal_own_weapon", "invalid_index": 0}
	# B 必须在 A 的攻击范围内
	var dist_ab = battle_context.get_distance(a_idx, b_idx)
	var a_range = a.get_attack_range()
	if dist_ab > a_range:
		return {
			"valid": false, "reason": "out_of_range", "invalid_index": 1,
			"distance": dist_ab, "attack_range": a_range,
		}
	return {"valid": true}


# Gemini:change.10: 枚举某张多目标牌在"第一目标已选定"后的合法第二目标
## 当前仅借刀杀人用到：给定被借刀者 A，返回 A 攻击范围内可被杀的存活者
func get_valid_secondary_targets(
	battle_context,
	source_index: int,
	card: CardData,
	first_target: int
) -> Array:
	var result: Array = []
	if card.card_name != "借刀杀人":
		return result
	var a = battle_context.get_player(first_target)
	if a == null or not a.is_alive or a.equip_weapon == null:
		return result
	var a_range = a.get_attack_range()
	for p in battle_context.get_alive_players():
		if p.index == first_target:
			continue
		if p.index == source_index:
			continue
		if battle_context.get_distance(first_target, p.index) <= a_range:
			result.append(p.index)
	return result


# Gemini:change.1: 枚举一张牌的所有合法目标
## 用于 AI 决策或 UI 高亮可选目标
## 桃/闪等无目标牌返回空数组；杀返回攻击范围内的存活他人
func get_valid_targets(battle_context, source_index: int, card: CardData) -> Array:
	var result: Array = []

	# 无目标牌（桃对自己、南蛮全体等由结算自行处理）
	if not card.need_target:
		return result

	for player in battle_context.get_alive_players():
		if player.index == source_index and not card.can_target_self:
			continue
		var check = validate_target(battle_context, source_index, card, player.index)
		if check.get("valid", false):
			result.append(player.index)

	return result


# Gemini:change.10: 获取一张牌的有效目标数量上限
## 方天画戟：当杀是最后一张手牌时，可指定至多3个目标
func get_effective_target_count(battle_context, source_index: int, card: CardData) -> int:
	var base_count: int = card.target_count
	if base_count <= 1:
		base_count = 1

	# 方天画戟：杀是最后一张手牌时，target_count = 3
	if card.card_name == "杀" or card.card_name == "火杀" or card.card_name == "雷杀":
		var source = battle_context.get_player(source_index)
		if source != null and source.hand_cards.size() == 1:
			for sk in source.skills:
				if sk is SkillFangtianHalberd:
					return 3
	return base_count


# Gemini:change.1: 判断当前阶段是否可以使用这张牌
## 出牌阶段：杀（未超次数限制）、桃（自己未满血且非濒死救援）、锦囊
## 其他阶段只能用桃救援（由 ResponseRequest 触发，不走此方法）
func can_use_in_play_phase(battle_context, source_index: int, card: CardData) -> bool:
	var source = battle_context.get_player(source_index)
	if source == null:
		return false

	# Gemini:change.8: 装备牌出牌阶段可装备
	if card.card_type == CardData.CardType.EQUIPMENT:
		return true

	match card.card_name:
		"杀", "火杀", "雷杀":
			var effective_limit = source._apply_skill_modifiers("kill_limit", source.kill_limit)
			return source.kill_count_this_turn < effective_limit
		"桃":
			# 出牌阶段对自己用桃：必须不满血
			return source.current_hp < source.max_hp
		"酒":
			# 每回合限一次，且尚未处于"已用酒"状态
			return not source.wine_used
		"决斗", "南蛮入侵", "万箭齐发", "无中生有", "过河拆桥", \
		"顺手牵羊", "桃园结义", "五谷丰登", "借刀杀人", "火攻", \
		"乐不思蜀", "兵粮寸断", "闪电":
			return true
		"闪", "无懈可击":
			return false  # 只能作为响应打出，不能主动使用
		_:
			return false
