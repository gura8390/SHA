# ============================================================
# chain_effect.gd
# 连环/横置 Effect：切换目标玩家的连环状态
#
# 三国杀规则：
#   - 横置（连环）状态：受到属性伤害（火/雷）时，伤害传递给所有其他横置玩家
#   - 传递后所有横置玩家解除横置
#   - 铁索连环牌可横置/解除横置一名角色
# ============================================================

class_name ChainEffect
extends Effect

## true=横置，false=解除横置，-1=切换当前状态
var _force_state: int = -1


static func create(src: int, tgt: int, force_state: int = -1) -> ChainEffect:
	var eff = ChainEffect.new()
	eff.source_index = src
	eff.target_index = tgt
	eff.effect_type = EffectType.CUSTOM
	eff._force_state = force_state
	return eff


func resolve(battle_context) -> Dictionary:
	var target = battle_context.get_player(target_index)
	if target == null or not target.is_alive:
		return {"resolved": false, "reason": "invalid_target"}

	var old_state: bool = target.is_chained
	var new_state: bool

	if _force_state >= 0:
		new_state = _force_state == 1
	else:
		new_state = not old_state

	if old_state == new_state:
		return {"resolved": false, "reason": "no_change"}

	# 执行切换
	target.is_chained = new_state

	# 发布 CHAIN_TOGGLED
	EventBus.publish(GameEvent.create(
		GameEvent.Type.CHAIN_TOGGLED, source_index, target_index,
		{"is_chained": new_state}
	))

	return {"resolved": true, "is_chained": new_state}
