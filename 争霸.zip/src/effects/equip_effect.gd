# ============================================================
# equip_effect.gd
# 装备效果：将一张装备牌装入对应装备栏（武器/防具/+1马/-1马/宝物）
#
# 执行流程：
#   1. 确定目标装备栏（按 CardData.equip_type）
#   2. 若该栏已有装备 → 旧装备进弃牌堆，发 EQUIP_REMOVED + 卸下其携带技能
#   3. 新装备装入栏，发 EQUIP_INSTALLED + 安装其携带技能
#
# 装备携带的技能（如诸葛连弩=出杀无限）由"装备数据 → 技能脚本"映射安装到
# 技能地基（阶段1）。映射表见本文件 _equip_skill_for。
#
# Gemini:change.8: 新建——装备系统核心
# ============================================================

class_name EquipEffect
extends Effect

## 要装备的卡牌
var equip_card: CardData = null


func _init() -> void:
	effect_type = EffectType.EQUIP


# Gemini:change.8: 便捷创建
static func create(src: int, tgt: int, card: CardData) -> EquipEffect:
	var effect = EquipEffect.new()
	effect.source_index = src
	effect.target_index = tgt
	effect.equip_card = card
	effect.related_card = card
	return effect


# Gemini:change.8: 执行装备结算
func resolve(battle_context) -> Dictionary:
	var player = battle_context.get_player(target_index)
	if player == null or equip_card == null:
		return {"resolved": false, "reason": "invalid"}

	var slot := _slot_name(equip_card.equip_type)
	if slot == "":
		return {"resolved": false, "reason": "not_equipment"}

	# 卸下旧装备（若有）
	var old_card: CardData = _get_slot(player, slot)
	if old_card != null:
		_remove_equip_skill(player, old_card)
		_set_slot(player, slot, null)
		battle_context.add_to_discard_pile(old_card)
		EventBus.publish(GameEvent.create(
			GameEvent.Type.EQUIP_REMOVED, target_index, target_index,
			{"card": old_card, "slot": slot}
		))

	# 装入新装备
	_set_slot(player, slot, equip_card)
	_install_equip_skill(player, equip_card, battle_context)
	AudioManager.play_sfx("equip")
	EventBus.publish(GameEvent.create(
		GameEvent.Type.EQUIP_INSTALLED, target_index, target_index,
		{"card": equip_card, "slot": slot}
	))

	return {"resolved": true, "slot": slot, "replaced": old_card}


# ----- 装备栏读写 -----

func _slot_name(equip_type: int) -> String:
	match equip_type:
		CardData.EquipType.WEAPON: return "weapon"
		CardData.EquipType.ARMOR: return "armor"
		CardData.EquipType.HORSE_DEF: return "horse_def"
		CardData.EquipType.HORSE_ATK: return "horse_atk"
		CardData.EquipType.TREASURE: return "treasure"
		_: return ""


func _get_slot(player, slot: String) -> CardData:
	match slot:
		"weapon": return player.equip_weapon
		"armor": return player.equip_armor
		"horse_def": return player.equip_horse_def
		"horse_atk": return player.equip_horse_atk
		"treasure": return player.equip_treasure
		_: return null


func _set_slot(player, slot: String, card) -> void:
	match slot:
		"weapon": player.equip_weapon = card
		"armor": player.equip_armor = card
		"horse_def": player.equip_horse_def = card
		"horse_atk": player.equip_horse_atk = card
		"treasure": player.equip_treasure = card


# ----- 装备携带技能（接入阶段1技能地基）-----

# Gemini:change.8: 装备 → 技能脚本路径映射（装备技）
# Gemini:change.10: 补全全部 10 件装备技（含 4 件 TODO 占位）
const EQUIP_SKILLS: Dictionary = {
	# --- 武器 ---
	"诸葛连弩": "res://src/skills/equip/skill_zhuge_crossbow.gd",
	"雌雄双股剑": "res://src/skills/equip/skill_cixiong_sword.gd",
	"青釭剑": "res://src/skills/equip/skill_qinggang_sword.gd",
	"青龙偃月刀": "res://src/skills/equip/skill_qinglong_dao.gd",
	"丈八蛇矛": "res://src/skills/equip/skill_zhangba_spear.gd",
	"贯石斧": "res://src/skills/equip/skill_guanshi_axe.gd",
	"方天画戟": "res://src/skills/equip/skill_fangtian_halberd.gd",
	"麒麟弓": "res://src/skills/equip/skill_qilin_bow.gd",
	# --- 防具 ---
	"八卦阵": "res://src/skills/equip/skill_bagua.gd",
	"仁王盾": "res://src/skills/equip/skill_renwang_shield.gd",
	"藤甲": "res://src/skills/equip/skill_tengjia.gd",
	"白银狮子": "res://src/skills/equip/skill_baiyin_shizi.gd",
}


func _install_equip_skill(player, card: CardData, battle_context) -> void:
	var path: String = EQUIP_SKILLS.get(card.card_name, "")
	if path == "":
		return
	if not ResourceLoader.exists(path):
		return
	var script_class = load(path)
	if script_class == null:
		return
	var sd := SkillData.new()
	sd.id = "equip_" + card.card_name
	sd.skill_name = card.card_name
	sd.skill_type = SkillData.SkillType.COMPULSORY
	var skill = script_class.new()
	skill.setup(sd, player.index, battle_context)
	# 标记来源装备，便于卸下时移除
	skill.set_meta("equip_source", card)
	player.skills.append(skill)


func _remove_equip_skill(player, card: CardData) -> void:
	for i in range(player.skills.size() - 1, -1, -1):
		var sk = player.skills[i]
		if sk != null and sk.has_meta("equip_source") and sk.get_meta("equip_source") == card:
			if sk.has_method("unregister_events"):
				sk.unregister_events()
			player.skills.remove_at(i)
