# ============================================================
# damage_effect.gd
# 伤害效果：对目标造成指定数值的伤害
# 执行流程：
#   1. 发布 DAMAGE_BEFORE 事件（技能可修改伤害值或取消）
#   2. 如果未被取消，扣减目标 HP
#   3. 发布 DAMAGE_AFTER 事件（触发受伤后技能，如遗计）
#   4. 如果目标 HP <= 0，触发濒死流程
# Gemini:change.1: 初始创建——实现伤害结算
# ============================================================

class_name DamageEffect
extends Effect

# Gemini:change.1: 伤害类型枚举
enum DamageType {
	NORMAL,      ## 普通伤害（如杀）
	FIRE,        ## 火焰伤害（火杀、火攻）
	THUNDER,     ## 雷电伤害（雷杀、闪电判定）
	NONE,        ## 无来源伤害（失去体力，非伤害）
}

## 伤害数值
var amount: int = 1

## 伤害类型
var damage_type: DamageType = DamageType.NORMAL


func _init() -> void:
	effect_type = EffectType.DAMAGE


# Gemini:change.1: 便捷创建方法
static func create(src: int, tgt: int, dmg_amount: int, dmg_type: DamageType = DamageType.NORMAL, card: Resource = null) -> DamageEffect:
	var effect = DamageEffect.new()
	effect.source_index = src
	effect.target_index = tgt
	effect.amount = dmg_amount
	effect.damage_type = dmg_type
	effect.related_card = card
	return effect


# Gemini:change.2: 执行伤害结算（async，集成濒死求桃流程）
## 修 Bug-3：旧实现扣血后只 publish(PLAYER_DYING) 就返回，无人消费，
## 导致角色永不死亡。现改为扣血后 await DeathResolver.resolve_dying，
## 保证"扣血→求桃→死亡/救回"是完整串行流程。
func resolve(battle_context) -> Dictionary:
	# 步骤1：发布伤害前事件，允许技能修改伤害值或取消
	var before_event = GameEvent.create(
		GameEvent.Type.DAMAGE_BEFORE,
		source_index,
		target_index,
		{
			"amount": amount,
			"damage_type": damage_type,
			"effect": self,
			"card": related_card,
		}
	)
	EventBus.publish(before_event)

	# 检查是否被取消（如技能"仁王盾"防止黑杀伤害）
	if before_event.is_cancelled or is_cancelled:
		return {"resolved": false, "reason": "cancelled"}

	# Gemini:change.1: 从事件数据中取回可能被技能修改后的伤害值
	amount = before_event.data.get("amount", amount)

	# 步骤2：执行实际扣血
	var target_player = battle_context.get_player(target_index)
	if target_player == null:
		return {"resolved": false, "reason": "target_not_found"}

	target_player.current_hp -= amount

	# 步骤3：发布伤害后事件（技能如奸雄/反馈在此触发）
	var after_event = GameEvent.create(
		GameEvent.Type.DAMAGE_AFTER,
		source_index,
		target_index,
		{
			"amount": amount,
			"damage_type": damage_type,
			"effect": self,
			"card": related_card,
			"current_hp": target_player.current_hp,
		}
	)
	EventBus.publish(after_event)

	# 步骤3b：连环伤害传递
	# 属性伤害（火/雷）命中横置角色时，传递给所有其他横置角色并解除全部横置
	if (damage_type == DamageType.FIRE or damage_type == DamageType.THUNDER) and target_player.is_chained:
		await _propagate_chain_damage(battle_context, target_player)

	# 步骤4：检查濒死
	var is_dying: bool = target_player.current_hp <= 0
	var saved: bool = false

	if is_dying:
		# 发布濒死事件（通知/UI 用）
		var dying_event = GameEvent.create(
			GameEvent.Type.PLAYER_DYING,
			source_index,
			target_index,
			{"damage_source": source_index}
		)
		EventBus.publish(dying_event)

		# Gemini:change.2: await 濒死求桃流程（DeathResolver 接管）
		# 这是修复 Bug-3 的关键：真正执行求桃循环
		if battle_context.death_resolver != null:
			saved = await battle_context.death_resolver.resolve_dying(target_index, source_index)

	return {
		"resolved": true,
		"amount": amount,
		"target_hp": target_player.current_hp,
		"is_dying": is_dying,
		"saved": saved,
		"died": is_dying and not saved,
	}


## 连环伤害传递：属性伤害命中横置角色时，传递给所有其他横置角色
func _propagate_chain_damage(battle_context, hit_player) -> void:
	# 收集所有其他横置存活玩家
	var chained_others: Array = []
	for p in battle_context.get_alive_players():
		if p.index != hit_player.index and p.is_chained:
			chained_others.append(p)

	# 解除所有横置（包括被命中的角色）
	hit_player.is_chained = false
	for p in chained_others:
		p.is_chained = false
		EventBus.publish(GameEvent.create(
			GameEvent.Type.CHAIN_TOGGLED, -1, p.index,
			{"is_chained": false, "reason": "chain_damage"}
		))

	# 对每个横置角色传递相同伤害
	for p in chained_others:
		if not p.is_alive:
			continue
		var chain_damage = DamageEffect.create(source_index, p.index, amount, damage_type, related_card)
		await chain_damage.resolve(battle_context)
