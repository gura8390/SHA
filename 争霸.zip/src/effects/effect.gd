# ============================================================
# effect.gd
# 效果基类：所有游戏状态变化的唯一合法入口
# 任何对 HP、手牌、装备等的修改，都必须通过 Effect 子类执行
# 技能不可直接修改玩家数据，必须创建对应的 Effect 并提交执行
# Gemini:change.1: 初始创建——定义效果基类接口
# ============================================================

class_name Effect
extends RefCounted

# Gemini:change.1: 效果类型枚举（用于日志和UI表现）
enum EffectType {
	DAMAGE,          ## 造成伤害
	HEAL,            ## 回复体力
	DRAW_CARD,       ## 摸牌
	DISCARD_CARD,    ## 弃牌
	LOSE_CARD,       ## 失去牌（被拆/被顺）
	OBTAIN_CARD,     ## 获得牌
	EQUIP,           ## 装备
	JUDGE,           ## 判定
	CUSTOM,          ## 自定义效果（技能专用扩展）
}

## 效果类型标识
var effect_type: EffectType = EffectType.CUSTOM

## 效果来源玩家索引（-1 表示系统/无来源）
var source_index: int = -1

## 效果目标玩家索引
var target_index: int = -1

## 关联的卡牌数据（可选，如"杀"造成的伤害会关联该卡牌）
var related_card: Resource = null

## 效果是否已被取消（技能可在 BEFORE 事件中取消）
var is_cancelled: bool = false

## 效果附加上下文数据
var context: Dictionary = {}


# Gemini:change.1: 核心方法——执行效果
## 子类必须重写此方法，实现具体的状态变化逻辑
## @param battle_context: 战场上下文引用，提供所有战局数据的读写
## @return: 执行结果字典（可选，用于传递结果数据给后续流程）
func resolve(_battle_context) -> Dictionary:
	push_error("Effect.resolve() 必须由子类重写！当前类: %s" % get_script().get_path())
	return {}


# Gemini:change.1: 取消效果
func cancel() -> void:
	is_cancelled = true


# Gemini:change.1: 调试信息
func _to_string() -> String:
	return "Effect[%s] src=%d tgt=%d cancelled=%s" % [
		EffectType.keys()[effect_type],
		source_index,
		target_index,
		str(is_cancelled)
	]
