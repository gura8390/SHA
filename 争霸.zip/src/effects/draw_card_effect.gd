# ============================================================
# draw_card_effect.gd
# 摸牌效果：从牌堆顶部为目标摸取指定数量的牌
# 执行流程：
#   1. 发布 DRAW_CARD 事件（BEFORE 阶段，技能可修改摸牌数）
#   2. 从牌堆摸牌，加入目标手牌
#   3. 发布 DRAW_CARD 事件（AFTER 阶段）
# Gemini:change.1: 初始创建——实现摸牌结算
# ============================================================

class_name DrawCardEffect
extends Effect

## 摸牌数量
var amount: int = 1


func _init() -> void:
	effect_type = EffectType.DRAW_CARD


# Gemini:change.1: 便捷创建方法
static func create(src: int, tgt: int, draw_amount: int) -> DrawCardEffect:
	var effect = DrawCardEffect.new()
	effect.source_index = src
	effect.target_index = tgt
	effect.amount = draw_amount
	return effect


# Gemini:change.1: 执行摸牌结算
func resolve(battle_context) -> Dictionary:
	var target_player = battle_context.get_player(target_index)
	if target_player == null:
		return {"resolved": false, "reason": "target_not_found"}

	# 步骤1：发布摸牌事件（可被技能修改摸牌数量，如遁甲摸3张）
	var draw_event = GameEvent.create(
		GameEvent.Type.DRAW_CARD,
		source_index,
		target_index,
		{
			"amount": amount,
			"effect": self,
			"phase": "before",
		}
	)
	EventBus.publish(draw_event)

	if draw_event.is_cancelled or is_cancelled:
		return {"resolved": false, "reason": "cancelled"}

	# Gemini:change.1: 取回可能被技能修改的摸牌数
	amount = draw_event.data.get("amount", amount)

	# 步骤2：从牌堆摸牌
	var drawn_cards: Array = []
	for i in range(amount):
		var card = battle_context.draw_from_pile()
		if card == null:
			break  # 牌堆耗尽
		drawn_cards.append(card)
		target_player.hand_cards.append(card)

	# 步骤3：发布摸牌完成事件
	var after_event = GameEvent.create(
		GameEvent.Type.DRAW_CARD,
		source_index,
		target_index,
		{
			"amount": drawn_cards.size(),
			"cards": drawn_cards,
			"effect": self,
			"phase": "after",
		}
	)
	EventBus.publish(after_event)

	return {
		"resolved": true,
		"drawn_count": drawn_cards.size(),
		"drawn_cards": drawn_cards,
	}
