# ============================================================
# flip_effect.gd
# 翻面 Effect：将目标玩家翻面，跳过其下一回合
#
# 三国杀规则：
#   - 翻面后跳过整个下一回合（判定/摸牌/出牌/弃牌全部跳过）
#   - 回合开始时自动翻回正面
#   - 翻面状态可被某些技能设置
# ============================================================

class_name FlipEffect
extends Effect

static func create(src: int, tgt: int) -> FlipEffect:
	var eff = FlipEffect.new()
	eff.source_index = src
	eff.target_index = tgt
	eff.effect_type = EffectType.CUSTOM
	return eff


func resolve(battle_context) -> Dictionary:
	var target = battle_context.get_player(target_index)
	if target == null or not target.is_alive:
		return {"resolved": false, "reason": "invalid_target"}

	# 已经翻面则不重复
	if target.is_flipped:
		return {"resolved": false, "reason": "already_flipped"}

	# 发布 FLIP_BEFORE（可取消）
	var before_event = GameEvent.create(GameEvent.Type.FLIP_BEFORE, source_index, target_index, {})
	EventBus.publish(before_event)
	if before_event.is_cancelled:
		return {"resolved": false, "reason": "cancelled"}

	# 执行翻面
	target.is_flipped = true

	# 发布 FLIP_AFTER
	EventBus.publish(GameEvent.create(GameEvent.Type.FLIP_AFTER, source_index, target_index, {}))

	return {"resolved": true}
