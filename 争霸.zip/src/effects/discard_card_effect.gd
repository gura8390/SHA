# ============================================================
# discard_card_effect.gd
# 弃牌效果：将目标的指定手牌移入弃牌堆
# 执行流程：
#   1. 发布 DISCARD_CARD 事件（BEFORE）
#   2. 从目标手牌中移除指定牌，放入弃牌堆
#   3. 发布 DISCARD_CARD 事件（AFTER）
# Gemini:change.1: 初始创建——实现弃牌结算
# ============================================================

class_name DiscardCardEffect
extends Effect

## 要弃置的卡牌列表（CardData 引用）
var cards_to_discard: Array = []

## 弃牌原因（用于区分主动弃牌、被拆等）
enum DiscardReason {
	PHASE_DISCARD,   ## 弃牌阶段主动弃牌
	SKILL_COST,      ## 技能代价弃牌
	FORCED,          ## 被强制弃牌（过河拆桥等）
	USAGE,           ## 使用牌后进入弃牌堆
}

var reason: DiscardReason = DiscardReason.PHASE_DISCARD


func _init() -> void:
	effect_type = EffectType.DISCARD_CARD


# Gemini:change.1: 便捷创建方法
static func create(src: int, tgt: int, cards: Array, discard_reason: DiscardReason = DiscardReason.PHASE_DISCARD) -> DiscardCardEffect:
	var effect = DiscardCardEffect.new()
	effect.source_index = src
	effect.target_index = tgt
	effect.cards_to_discard = cards
	effect.reason = discard_reason
	return effect


# Gemini:change.1: 执行弃牌结算
func resolve(battle_context) -> Dictionary:
	var target_player = battle_context.get_player(target_index)
	if target_player == null:
		return {"resolved": false, "reason": "target_not_found"}

	if cards_to_discard.is_empty():
		return {"resolved": false, "reason": "no_cards_to_discard"}

	# 步骤1：发布弃牌前事件
	var before_event = GameEvent.create(
		GameEvent.Type.DISCARD_CARD,
		source_index,
		target_index,
		{
			"cards": cards_to_discard,
			"reason": reason,
			"effect": self,
			"phase": "before",
		}
	)
	EventBus.publish(before_event)

	if before_event.is_cancelled or is_cancelled:
		return {"resolved": false, "reason": "cancelled"}

	# 步骤2：执行弃牌
	# Gemini:change.3: 修卡牌泄漏——USAGE 原因的牌通常已被使用流程从手牌移到
	# "结算中"(limbo)，此时 hand_cards 已不含该牌，但仍必须入弃牌堆。
	# 旧实现只在"牌还在手牌"时才入弃牌堆，导致所有使用过的牌（杀/闪/桃/锦囊）
	# 凭空消失，牌堆持续缩水。现在：USAGE 牌即使不在手牌也入弃牌堆。
	var actually_discarded: Array = []
	for card in cards_to_discard:
		var was_in_hand: bool = target_player.hand_cards.has(card)
		if was_in_hand:
			target_player.hand_cards.erase(card)
		# 入弃牌堆条件：原本在手牌中，或这是"使用后入堆"(USAGE，牌在 limbo)
		if was_in_hand or reason == DiscardReason.USAGE:
			# 防重复入堆
			if not battle_context.discard_pile.has(card):
				battle_context.add_to_discard_pile(card)
				actually_discarded.append(card)

	# 步骤3：发布弃牌后事件
	var after_event = GameEvent.create(
		GameEvent.Type.DISCARD_CARD,
		source_index,
		target_index,
		{
			"cards": actually_discarded,
			"reason": reason,
			"effect": self,
			"phase": "after",
		}
	)
	EventBus.publish(after_event)

	return {
		"resolved": true,
		"discarded_count": actually_discarded.size(),
		"discarded_cards": actually_discarded,
	}
