# ============================================================
# heal_effect.gd
# 回复效果：为目标回复指定数值的体力
# 执行流程：
#   1. 发布 HEAL_BEFORE 事件（可被修改或取消）
#   2. 回复体力（不超过体力上限）
#   3. 发布 HEAL_AFTER 事件
# Gemini:change.1: 初始创建——实现体力回复结算
# ============================================================

class_name HealEffect
extends Effect

## 回复数值
var amount: int = 1


func _init() -> void:
	effect_type = EffectType.HEAL


# Gemini:change.1: 便捷创建方法
static func create(src: int, tgt: int, heal_amount: int, card: Resource = null) -> HealEffect:
	var effect = HealEffect.new()
	effect.source_index = src
	effect.target_index = tgt
	effect.amount = heal_amount
	effect.related_card = card
	return effect


# Gemini:change.1: 执行回复结算
func resolve(battle_context) -> Dictionary:
	var target_player = battle_context.get_player(target_index)
	if target_player == null:
		return {"resolved": false, "reason": "target_not_found"}

	# 已满血则无法回复
	if target_player.current_hp >= target_player.max_hp:
		return {"resolved": false, "reason": "already_full_hp"}

	# 步骤1：发布回复前事件
	var before_event = GameEvent.create(
		GameEvent.Type.HEAL_BEFORE,
		source_index,
		target_index,
		{
			"amount": amount,
			"effect": self,
			"card": related_card,
		}
	)
	EventBus.publish(before_event)

	if before_event.is_cancelled or is_cancelled:
		return {"resolved": false, "reason": "cancelled"}

	# Gemini:change.1: 取回可能被修改的回复量
	amount = before_event.data.get("amount", amount)

	# 步骤2：执行回复（不超过上限）
	var old_hp = target_player.current_hp
	target_player.current_hp = mini(target_player.current_hp + amount, target_player.max_hp)
	var actual_heal = target_player.current_hp - old_hp

	# 步骤3：发布回复后事件
	var after_event = GameEvent.create(
		GameEvent.Type.HEAL_AFTER,
		source_index,
		target_index,
		{
			"amount": actual_heal,
			"effect": self,
			"current_hp": target_player.current_hp,
		}
	)
	EventBus.publish(after_event)

	return {
		"resolved": true,
		"actual_heal": actual_heal,
		"current_hp": target_player.current_hp,
	}
