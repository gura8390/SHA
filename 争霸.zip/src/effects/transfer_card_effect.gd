# ============================================================
# transfer_card_effect.gd
# 卡牌转移 Effect：统一处理卡牌在不同区域间的转移
#
# 支持的转移模式：
#   HAND_TO_HAND: 从来源手牌 → 目标手牌（如反馈、仁德、突袭）
#   DISCARD_TO_HAND: 从弃牌堆 → 目标手牌（如奸雄、洛神）
#   DRAW_PILE_TO_HAND: 从牌堆顶 → 目标手牌（摸牌，含知天预知）
#   HAND_DISCARD: 从手牌 → 弃牌堆（技能消耗，替代裸 erase+append）
#
# 红线 1：所有卡牌区域变更必须通过此 Effect 完成
# ============================================================

class_name TransferCardEffect
extends GameAction

enum TransferType {
	HAND_TO_HAND,       # 手牌 → 手牌
	DISCARD_TO_HAND,    # 弃牌堆 → 手牌
	DRAW_PILE_TO_HAND,  # 牌堆顶 → 手牌
	HAND_DISCARD,       # 手牌 → 弃牌堆
}

## 转移类型
var transfer_type: int = TransferType.HAND_TO_HAND

## 要转移的卡牌列表
var cards: Array = []  # Array[CardData]

## 转移原因（用于事件 data）
var reason: String = ""


## 便捷构造：手牌 → 手牌（偷牌/给牌）
static func hand_to_hand(src_idx: int, tgt_idx: int, card_list: Array, reason_str: String = "") -> TransferCardEffect:
	var eff = TransferCardEffect.new()
	eff.source_index = src_idx
	eff.target_index = tgt_idx
	eff.transfer_type = TransferType.HAND_TO_HAND
	eff.cards = card_list.duplicate()
	eff.reason = reason_str if reason_str != "" else "transfer"
	eff.description = "%d→%d 转移%d张牌" % [src_idx, tgt_idx, card_list.size()]
	return eff


## 便捷构造：弃牌堆 → 手牌（从弃牌堆获取）
static func discard_to_hand(tgt_idx: int, card_list: Array, reason_str: String = "") -> TransferCardEffect:
	var eff = TransferCardEffect.new()
	eff.source_index = -1
	eff.target_index = tgt_idx
	eff.transfer_type = TransferType.DISCARD_TO_HAND
	eff.cards = card_list.duplicate()
	eff.reason = reason_str if reason_str != "" else "gain_from_discard"
	eff.description = "弃牌堆→%d 获取%d张牌" % [tgt_idx, card_list.size()]
	return eff


## 便捷构造：牌堆顶 → 手牌（指定牌摸牌）
static func pile_to_hand(tgt_idx: int, card_list: Array, reason_str: String = "") -> TransferCardEffect:
	var eff = TransferCardEffect.new()
	eff.source_index = -1
	eff.target_index = tgt_idx
	eff.transfer_type = TransferType.DRAW_PILE_TO_HAND
	eff.cards = card_list.duplicate()
	eff.reason = reason_str if reason_str != "" else "gain_from_pile"
	eff.description = "牌堆→%d 获取%d张牌" % [tgt_idx, card_list.size()]
	return eff


## 便捷构造：手牌 → 弃牌堆（技能消耗，不经过 DiscardCardEffect 的 USAGE 语义）
static func hand_to_discard(src_idx: int, card_list: Array, reason_str: String = "") -> TransferCardEffect:
	var eff = TransferCardEffect.new()
	eff.source_index = src_idx
	eff.target_index = src_idx
	eff.transfer_type = TransferType.HAND_DISCARD
	eff.cards = card_list.duplicate()
	eff.reason = reason_str if reason_str != "" else "skill_cost"
	eff.description = "%d 弃%d张牌" % [src_idx, card_list.size()]
	return eff


func execute(ctx, _action_queue) -> Dictionary:
	match transfer_type:
		TransferType.HAND_TO_HAND:
			return _exec_hand_to_hand(ctx)
		TransferType.DISCARD_TO_HAND:
			return _exec_discard_to_hand(ctx)
		TransferType.DRAW_PILE_TO_HAND:
			return _exec_pile_to_hand(ctx)
		TransferType.HAND_DISCARD:
			return _exec_hand_to_discard(ctx)
	return {"resolved": false, "reason": "unknown_type"}


func _exec_hand_to_hand(ctx) -> Dictionary:
	var src_player = ctx.get_player(source_index)
	var tgt_player = ctx.get_player(target_index)
	if src_player == null or tgt_player == null:
		return {"resolved": false, "reason": "invalid_player"}

	var transferred: Array = []
	for card in cards:
		if src_player.hand_cards.has(card):
			src_player.hand_cards.erase(card)
			tgt_player.hand_cards.append(card)
			transferred.append(card)

	if not transferred.is_empty():
		# 发布 CARD_STOLEN 或 CARD_GIVEN 事件（红线 7）
		for card in transferred:
			var evt_type = GameEvent.Type.CARD_STOLEN if reason in ["steal", "fankui", "tuxi"] else GameEvent.Type.CARD_GIVEN
			EventBus.publish(GameEvent.create(
				evt_type, source_index, target_index,
				{"card": card, "reason": reason}
			))
	return {"resolved": true, "transferred": transferred}


func _exec_discard_to_hand(ctx) -> Dictionary:
	var tgt_player = ctx.get_player(target_index)
	if tgt_player == null:
		return {"resolved": false, "reason": "invalid_player"}

	var transferred: Array = []
	for card in cards:
		if ctx.discard_pile.has(card):
			ctx.discard_pile.erase(card)
			tgt_player.hand_cards.append(card)
			transferred.append(card)

	if not transferred.is_empty():
		for card in transferred:
			EventBus.publish(GameEvent.create(
				GameEvent.Type.CARD_GIVEN, -1, target_index,
				{"card": card, "reason": reason}
			))
	return {"resolved": true, "transferred": transferred}


func _exec_pile_to_hand(ctx) -> Dictionary:
	var tgt_player = ctx.get_player(target_index)
	if tgt_player == null:
		return {"resolved": false, "reason": "invalid_player"}

	var transferred: Array = []
	for card in cards:
		if ctx.draw_pile.has(card):
			ctx.draw_pile.erase(card)
			tgt_player.hand_cards.append(card)
			transferred.append(card)

	return {"resolved": true, "transferred": transferred}


func _exec_hand_to_discard(ctx) -> Dictionary:
	var src_player = ctx.get_player(source_index)
	if src_player == null:
		return {"resolved": false, "reason": "invalid_player"}

	var discarded: Array = []
	for card in cards:
		if src_player.hand_cards.has(card):
			src_player.hand_cards.erase(card)
			ctx.add_to_discard_pile(card)
			discarded.append(card)

	if not discarded.is_empty():
		EventBus.publish(GameEvent.create(
			GameEvent.Type.DISCARD_CARD, source_index, -1,
			{"cards": discarded, "reason": reason}
		))
	return {"resolved": true, "discarded": discarded}
