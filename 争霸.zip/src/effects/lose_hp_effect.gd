# ============================================================
# lose_hp_effect.gd
# 体力流失 Effect：失去体力（非伤害）
#
# 与 DamageEffect 的关键区别：
#   - 不发布 DAMAGE_BEFORE/DAMAGE_AFTER（不可被防具/技能阻止）
#   - 不触发"受到伤害"类技能（如奸雄、反馈）
#   - 触发"失去体力"类技能
#   - 无伤害来源、无伤害类型
#   - 仍可导致濒死（DeathResolver 处理）
#
# 使用场景：
#   - 某些技能的代价（如失去体力上限）
#   - 特殊卡牌效果
# ============================================================

class_name LoseHpEffect
extends Effect

var amount: int = 1


static func create(tgt: int, lose_amount: int) -> LoseHpEffect:
	var eff = LoseHpEffect.new()
	eff.source_index = -1  # 无来源
	eff.target_index = tgt
	eff.amount = lose_amount
	eff.effect_type = EffectType.CUSTOM
	return eff


func resolve(battle_context) -> Dictionary:
	var target = battle_context.get_player(target_index)
	if target == null or not target.is_alive:
		return {"resolved": false, "reason": "invalid_target"}

	if amount <= 0:
		return {"resolved": false, "reason": "invalid_amount"}

	# 发布 LOSE_HP_BEFORE（可取消，但通常不应取消）
	var before_event = GameEvent.create(
		GameEvent.Type.LOSE_HP_BEFORE, -1, target_index,
		{"amount": amount}
	)
	EventBus.publish(before_event)
	if before_event.is_cancelled:
		return {"resolved": false, "reason": "cancelled"}

	# 读取可能被技能修改的 amount
	amount = before_event.data.get("amount", amount)

	# 扣减体力（直接扣，不经过伤害防护）
	target.current_hp -= amount

	# 发布 LOSE_HP_AFTER
	var after_event = GameEvent.create(
		GameEvent.Type.LOSE_HP_AFTER, -1, target_index,
		{"amount": amount, "current_hp": target.current_hp}
	)
	EventBus.publish(after_event)

	# 检查濒死
	if target.current_hp <= 0:
		var death_resolver = battle_context.death_resolver
		if death_resolver != null:
			var saved: bool = await death_resolver.resolve_dying(target_index, -1)
			return {"resolved": true, "amount": amount, "target_hp": target.current_hp, "is_dying": true, "saved": saved, "died": not saved}

	return {"resolved": true, "amount": amount, "target_hp": target.current_hp, "is_dying": false}
