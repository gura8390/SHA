# ============================================================
# card_effect_tao.gd
# 卡牌效果：桃（纯结算逻辑）
#
# 注意（Gemini:change.2 重构）：
#   "从手牌移除桃、发 CARD_USED、桃入弃牌堆、发 CARD_RESOLVED" 已由
#   PlayCardEffect 统一接管，本类只负责回血逻辑。
#
# 结算流程：
#   1. 校验：出牌阶段对自己用桃必须不满血
#   2. 通过 HealEffect 回复1点体力
#
# Gemini:change.2: 重构——剥离生命周期事件
# ============================================================

class_name CardEffectTao
extends GameAction

## 使用的卡牌数据
var card: CardData = null


# Gemini:change.1: 便捷创建
static func create_action(src: int, card_data: CardData) -> CardEffectTao:
	var action = CardEffectTao.new()
	action.source_index = src
	action.target_index = src  # 桃对自己使用
	action.card = card_data
	action.description = "%d 桃" % src
	return action


# Gemini:change.2: 执行"桃"的结算
func execute(battle_context, _action_queue) -> Dictionary:
	description = "%s 使用【桃】" % _pname(source_index, battle_context)
	var source_player = battle_context.get_player(source_index)
	if source_player == null:
		return {"resolved": false, "reason": "invalid_source"}

	# 体力已满不能使用桃（出牌阶段，非濒死救援）
	if source_player.current_hp >= source_player.max_hp:
		return {"resolved": false, "reason": "full_hp"}

	# 通过 HealEffect 回复体力
	var heal_effect = HealEffect.create(source_index, source_index, 1, card)
	var heal_result = heal_effect.resolve(battle_context)

	return {"resolved": true, "heal_result": heal_result}
