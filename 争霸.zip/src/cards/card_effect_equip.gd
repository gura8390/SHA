# ============================================================
# card_effect_equip.gd
# 卡牌效果：装备牌（武器/防具/+1马/-1马/宝物）
# 把装备牌装入使用者对应装备栏（经 EquipEffect）。
# Gemini:change.8: 新建——装备牌使用入口
# ============================================================

class_name CardEffectEquip
extends GameAction

var card: CardData = null


static func create_action(src: int, card_data: CardData) -> CardEffectEquip:
	var action = CardEffectEquip.new()
	action.source_index = src
	action.target_index = src  # 装备给自己
	action.card = card_data
	action.description = "%d 装备%s" % [src, card_data.card_name]
	return action


func execute(battle_context, _action_queue) -> Dictionary:
	description = "%s 装备【%s】" % [_pname(source_index, battle_context), card.card_name]
	var effect = EquipEffect.create(source_index, source_index, card)
	return effect.resolve(battle_context)
