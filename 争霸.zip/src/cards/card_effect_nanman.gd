# ============================================================
# card_effect_nanman.gd
# 卡牌效果：南蛮入侵（AOE，纯结算逻辑）
#
# 注意（Gemini:change.2 重构）：
#   "从手牌移除南蛮、发 CARD_USED、南蛮入弃牌堆、发 CARD_RESOLVED" 已由
#   PlayCardEffect 统一接管，本类只负责 AOE 的逐一结算。
#
# 结算流程：
#   1. AOE 从使用者下家开始逐一询问是否出"杀"（每轮 await ResponseRequest）
#   2. 未出杀者受到1点伤害
#
# 规则修正（Bug-8）：
#   旧实现一次性取目标列表后循环，中途有人死亡座位顺序会错乱。
#   现在：每次结算一个目标后重新 get_alive_players() 重算，
#   且每次都重新定位"下一个目标"，保证座位顺序正确。
#
# Gemini:change.2: 重构——async 化 + 每次重算存活
# ============================================================

class_name CardEffectNanman
extends GameAction

## 使用的卡牌数据
var card: CardData = null


# Gemini:change.1: 便捷创建
static func create_action(src: int, card_data: CardData) -> CardEffectNanman:
	var action = CardEffectNanman.new()
	action.source_index = src
	action.target_index = -1  # AOE无特定目标
	action.card = card_data
	action.description = "%d 南蛮入侵" % src  # execute 中用姓名覆盖
	return action


# Gemini:change.2: 执行"南蛮入侵"的结算（async）
func execute(battle_context, _action_queue) -> Dictionary:
	description = "%s 使用【南蛮入侵】" % _pname(source_index, battle_context)
	var source_player = battle_context.get_player(source_index)
	if source_player == null:
		return {"resolved": false, "reason": "invalid_source"}

	var damage_results: Array = []
	# 已结算过的玩家索引集合（防止结算中座次变化导致重复）
	var processed: Dictionary = {}

	# Gemini:change.2: 动态推进——每次重新计算下家
	# 从 source 的下家开始，按座位顺序逐一结算
	while true:
		var next_target = _find_next_target(battle_context, source_index, processed)
		if next_target == null:
			break  # 所有存活他人已结算完

		var target_idx = next_target.index
		processed[target_idx] = true

		# 再次校验存活（结算过程中可能死亡）
		if not next_target.is_alive:
			continue

		# 发布目标指定事件
		var targeted_event = GameEvent.create(
			GameEvent.Type.CARD_TARGETED,
			source_index,
			target_idx,
			{"card": card, "card_name": "南蛮入侵"}
		)
		EventBus.publish(targeted_event)
		if targeted_event.is_cancelled:
			continue

		# Gemini:change.10: 无懈可击——AOE 逐目标询问（标准规则）
		if await WuxieInquiry.inquire(battle_context, source_index, card, target_idx):
			continue

		# 异步请求目标出杀
		var result: ResponseResult = await ResponseRequest.ask(
			battle_context,
			target_idx,
			"杀",
			source_index,
			{
				"card": card,
				"context": "nanman",
				"prompt": "%s 使用了【南蛮入侵】，是否打出【杀】？" % (source_player.hero_data.hero_name if source_player.hero_data else ""),
			}
		)

		if result.played and result.card_used != null:
			# 打出了杀，免除伤害；杀经 Effect 入弃牌堆（修 Bug-4）
			var sha_card = result.card_used
			# Gemini:change.12: 转化牌模式——移除实际牌而非虚拟牌
			var actual_card = result.convert_source if result.convert_source != null else sha_card
			next_target.hand_cards.erase(actual_card)
			var discard_eff = DiscardCardEffect.create(
				target_idx, target_idx, [actual_card], DiscardCardEffect.DiscardReason.USAGE
			)
			discard_eff.resolve(battle_context)
		else:
			# 未出杀，受到伤害
			var dmg_effect = DamageEffect.create(source_index, target_idx, 1, DamageEffect.DamageType.NORMAL, card)
			# Gemini:change.3: DamageEffect.resolve 现为 async（内含濒死求桃），必须 await
			var r = await dmg_effect.resolve(battle_context)
			damage_results.append(r)

	return {"resolved": true, "damage_count": damage_results.size()}


# Gemini:change.2: 找下一个未结算的存活目标（从 source 下家开始的座位顺序）
func _find_next_target(battle_context, src_index: int, processed: Dictionary):
	var alive = battle_context.get_alive_players()
	if alive.is_empty():
		return null
	# 定位 source 在存活列表中的位置
	var src_pos = -1
	for i in range(alive.size()):
		if alive[i].index == src_index:
			src_pos = i
			break
	if src_pos == -1:
		# source 已死，AOE 中止
		return null
	# 从 src_pos+1 开始环形查找第一个未处理过的存活他人
	for i in range(1, alive.size()):
		var idx = (src_pos + i) % alive.size()
		var candidate = alive[idx]
		if candidate.index == src_index:
			continue
		if processed.has(candidate.index):
			continue
		if not candidate.is_alive:
			continue
		return candidate
	return null
