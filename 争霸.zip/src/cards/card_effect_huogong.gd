# ============================================================
# card_effect_huogong.gd
# 卡牌效果：火攻（即时锦囊）
#
# 流程：
#   1. 目标展示一张手牌（随机选一张）
#   2. 使用者可弃一张与展示牌同花色的手牌
#   3. 若弃牌，对目标造成1点火焰伤害
#
# 知天联动：若使用者有知天技能，可从可见牌中选一张代替弃牌
# ============================================================

class_name CardEffectHuogong
extends GameAction

var card: CardData = null
var target_idx: int = -1


static func create_action(src: int, tgt: int, card_data: CardData) -> CardEffectHuogong:
	var action = CardEffectHuogong.new()
	action.source_index = src
	action.target_index = tgt
	action.target_idx = tgt
	action.card = card_data
	action.description = "%d→%d 火攻" % [src, tgt]
	return action


func execute(battle_context, _action_queue) -> Dictionary:
	description = "%s 对 %s 使用【火攻】" % [_pname(source_index, battle_context), _pname(target_idx, battle_context)]
	var source_player = battle_context.get_player(source_index)
	var target_player = battle_context.get_player(target_idx)

	if target_player == null or not target_player.is_alive:
		return {"resolved": false, "reason": "invalid_target"}

	# 无懈可击检查
	var targeted = GameEvent.create(
		GameEvent.Type.CARD_TARGETED, source_index, target_idx,
		{"card": card, "card_name": "火攻"}
	)
	EventBus.publish(targeted)
	if await WuxieInquiry.inquire(battle_context, source_index, card, target_idx):
		return {"resolved": false, "reason": "cancelled"}

	if target_player == null or not target_player.is_alive:
		return {"resolved": false, "reason": "invalid_target"}
	if source_player == null:
		return {"resolved": false, "reason": "invalid_source"}
	if target_player.hand_cards.is_empty():
		return {"resolved": true, "empty": true}

	# 目标选择展示哪张手牌（标准规则：目标选择）
	var shown_card: CardData = null
	var target_controller = battle_context.get_controller(target_idx)
	if target_controller != null and target_controller.has_method("decide_card_pick"):
		shown_card = await target_controller.decide_card_pick(target_idx, source_index, target_player.hand_cards.duplicate(), "huogong_reveal")
	if shown_card == null:
		shown_card = target_player.hand_cards[0]
	EventBus.publish(GameEvent.create(
		GameEvent.Type.SKILL_RESOLVED, target_idx, source_index,
		{"skill_name": "火攻", "effect": "reveal", "card": shown_card}
	))

	# 检查使用者是否有同花色手牌可弃
	var can_discard := false
	for c in source_player.hand_cards:
		if c != card and c.suit == shown_card.suit:
			can_discard = true
			break

	if not can_discard:
		return {"resolved": true, "no_match": true}

	# 让使用者选择是否弃牌（AI自动判断，人类通过控制器）
	var discard_card: CardData = null
	var controller = battle_context.get_controller(source_index)
	if controller != null and controller.has_method("decide_card_pick"):
		# 收集可弃的同花色牌
		var candidates: Array = []
		for c in source_player.hand_cards:
			if c != card and c.suit == shown_card.suit:
				candidates.append(c)
		if not candidates.is_empty():
			discard_card = await controller.decide_card_pick(source_index, target_idx, candidates, "huogong")
	else:
		# AI：弃最低价值的同花色牌
		var best: CardData = null
		var best_val: int = 999
		for c in source_player.hand_cards:
			if c != card and c.suit == shown_card.suit:
				var val = _simple_card_value(c)
				if val < best_val:
					best_val = val
					best = c
		discard_card = best

	if discard_card == null:
		return {"resolved": true, "declined": true}

	# 弃牌
	source_player.hand_cards.erase(discard_card)
	DiscardCardEffect.create(
		source_index, source_index, [discard_card], DiscardCardEffect.DiscardReason.USAGE
	).resolve(battle_context)

	# 造成1点火焰伤害
	var dmg_result = await DamageEffect.create(
		source_index, target_idx, 1, DamageEffect.DamageType.FIRE, card
	).resolve(battle_context)

	return {"resolved": true, "damage": true, "dmg_result": dmg_result}


func _simple_card_value(card: CardData) -> int:
	if card == null:
		return 0
	match card.card_name:
		"桃": return 100
		"无懈可击": return 80
		"闪": return 60
		"酒": return 40
		_: return 15
