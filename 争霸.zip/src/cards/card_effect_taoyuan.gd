# ============================================================
# card_effect_taoyuan.gd
# 卡牌效果：桃园结义——所有存活角色回复1点体力
#
# Gemini:change.9: 新建——AOE 锦囊"桃园结义"
# Gemini:change.10: 逐目标无懈可击（标准规则）
# ============================================================

class_name CardEffectTaoyuan
extends GameAction

var card: CardData = null


static func create_action(src: int, card_data: CardData) -> CardEffectTaoyuan:
	var action = CardEffectTaoyuan.new()
	action.source_index = src
	action.target_index = -1
	action.card = card_data
	action.description = "%d 桃园结义" % src
	return action


func execute(battle_context, _action_queue) -> Dictionary:
	description = "%s 使用【桃园结义】" % _pname(source_index, battle_context)
	# 从使用者开始按座位顺序回血（仅未满血者）
	var alive = battle_context.get_alive_players()
	var order := _seat_order(battle_context, source_index, alive)
	for p in order:
		if not p.is_alive:
			continue
		if p.current_hp >= p.max_hp:
			continue

		# 发布目标指定事件
		var targeted_event = GameEvent.create(
			GameEvent.Type.CARD_TARGETED, source_index, p.index,
			{"card": card, "card_name": "桃园结义"}
		)
		EventBus.publish(targeted_event)
		if targeted_event.is_cancelled:
			continue

		# 无懈可击——逐目标询问（标准规则）
		if await WuxieInquiry.inquire(battle_context, source_index, card, p.index):
			continue

		HealEffect.create(source_index, p.index, 1, card).resolve(battle_context)
	return {"resolved": true}


func _seat_order(battle_context, src_index: int, alive: Array) -> Array:
	var order: Array = []
	var src_pos = -1
	for i in range(alive.size()):
		if alive[i].index == src_index:
			src_pos = i
			break
	if src_pos == -1:
		return alive
	for i in range(alive.size()):
		order.append(alive[(src_pos + i) % alive.size()])
	return order
