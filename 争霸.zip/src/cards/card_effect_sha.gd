# ============================================================
# card_effect_sha.gd
# 卡牌效果：杀（纯结算逻辑）
#
# 注意（Gemini:change.2 重构）：
#   本类只负责"杀的结算"——即请求目标响应闪、决定是否造成伤害。
#   "从手牌移除杀、发 CARD_USED、杀入弃牌堆、发 CARD_RESOLVED" 已由
#   PlayCardEffect 统一接管，本类不再发这些事件。
#
# 结算流程：
#   1. publish CARD_TARGETED（目标被指定）
#   2. 通过 ResponseRequest 异步请求目标是否打出"闪"
#   3. 若出闪：闪经 DiscardCardEffect.Usage 入弃牌堆
#   4. 武器钩子（贯石斧/青龙偃月刀）——杀被闪后可追加效果
#   5. 若未出闪：通过 DamageEffect 造成伤害（含酒+1）
#
# Gemini:change.2: 重构——async 化 + 剥离生命周期事件 + 走响应管道
# Gemini:change.10: 武器后置钩子（贯石斧/青龙偃月刀）
# ============================================================

class_name CardEffectSha
extends GameAction

## 使用的卡牌数据
var card: CardData = null

## 目标玩家索引
var target_idx: int = -1

## 是否为追加杀（青龙偃月刀触发，避免无限循环）
var is_follow_up: bool = false


# Gemini:change.1: 便捷创建
static func create_action(src: int, tgt: int, card_data: CardData) -> CardEffectSha:
	var action = CardEffectSha.new()
	action.source_index = src
	action.target_index = tgt
	action.target_idx = tgt
	action.card = card_data
	action.description = "%d→%d 杀" % [src, tgt]  # execute 中用姓名覆盖
	return action


# Gemini:change.10: 创建追加杀（青龙偃月刀用）
static func create_follow_up(src: int, tgt: int, card_data: CardData) -> CardEffectSha:
	var action = create_action(src, tgt, card_data)
	action.is_follow_up = true
	return action


# Gemini:change.2: 执行"杀"的结算（async，await 目标响应）
func execute(battle_context, _action_queue) -> Dictionary:
	description = "%s 对 %s 使用【%s】" % [_pname(source_index, battle_context), _pname(target_idx, battle_context), card.card_name]
	var source_player = battle_context.get_player(source_index)
	var target_player = battle_context.get_player(target_idx)

	if target_player == null or not target_player.is_alive:
		return {"resolved": false, "reason": "invalid_target"}
	if source_player == null:
		return {"resolved": false, "reason": "invalid_source"}

	# 步骤1：发布目标被指定事件（技能如反馈/八卦阵在此拦截）
	var targeted_event = GameEvent.create(
		GameEvent.Type.CARD_TARGETED,
		source_index,
		target_idx,
		{"card": card, "card_name": card.card_name}
	)
	EventBus.publish(targeted_event)
	if targeted_event.is_cancelled:
		return {"resolved": false, "reason": "target_cancelled"}

	# Gemini:change.10: 步骤2a：八卦阵判定（在正式询问闪之前）
	var bagua_dodged := false
	for sk in target_player.skills:
		if sk is SkillBagua:
			if sk.try_judge_dodge():
				bagua_dodged = true
				break
	if bagua_dodged:
		return {"resolved": true, "dodged": true, "source": "bagua"}

	# 步骤2b：异步请求目标是否打出"闪"
	var result: ResponseResult = await ResponseRequest.ask(
		battle_context,
		target_idx,
		"闪",
		source_index,
		{
			"card": card,
			"context": "sha",
			"prompt": ("%s 对你使用了【杀】，是否打出【闪】？" % source_player.hero_data.hero_name) if source_player.hero_data else "是否打出【闪】？",
		}
	)

	# Gemini:change.12: 步骤2c：无双判定——若攻击者有无双技能，需要两张闪
	var wushuang_active := false
	if result.played and result.card_used != null:
		if SkillWuShuang.has_wushuang(battle_context, source_index):
			wushuang_active = true

	# 步骤3：处理响应
	if result.played and result.card_used != null:
		# 目标打出了闪
		var dodge_card = result.card_used
		# Gemini:change.12: 转化牌模式——移除实际牌而非虚拟牌
		var actual_card = result.convert_source if result.convert_source != null else dodge_card
		target_player.hand_cards.erase(actual_card)
		var discard_eff = DiscardCardEffect.create(
			target_idx, target_idx, [actual_card], DiscardCardEffect.DiscardReason.USAGE
		)
		discard_eff.resolve(battle_context)

		# Gemini:change.12: 无双——需要第二张闪
		if wushuang_active:
			var result2: ResponseResult = await ResponseRequest.ask(
				battle_context,
				target_idx,
				"闪",
				source_index,
				{
					"card": card,
					"context": "sha_wushuang",
					"prompt": "【无双】！需要第二张【闪】！",
				}
			)
			if not (result2.played and result2.card_used != null):
				# 未出第二张闪，杀命中
				pass  # 继续到步骤4造成伤害
			else:
				# 打出了第二张闪
				var dodge2 = result2.card_used
				var actual2 = result2.convert_source if result2.convert_source != null else dodge2
				target_player.hand_cards.erase(actual2)
				DiscardCardEffect.create(
					target_idx, target_idx, [actual2], DiscardCardEffect.DiscardReason.USAGE
				).resolve(battle_context)
				# 两张闪都出了，杀被抵消
				if not is_follow_up:
					var weapon_result = await _try_weapon_follow_through(battle_context, source_player, target_player)
					if weapon_result.get("force_hit", false):
						pass  # 贯石斧强命中
					elif weapon_result.get("follow_up_sha", false):
						return {"resolved": true, "dodged": true, "weapon": "qinglong_dao"}
					else:
						return {"resolved": true, "dodged": true}
				else:
					return {"resolved": true, "dodged": true}
		else:
			# 普通情况（无无双）：一张闪即抵消
			# Gemini:change.10: 步骤3a：武器后置钩子（杀被闪后）
			if not is_follow_up:
				var weapon_result = await _try_weapon_follow_through(battle_context, source_player, target_player)
				if weapon_result.get("force_hit", false):
					pass  # 贯石斧强命中
				elif weapon_result.get("follow_up_sha", false):
					return {"resolved": true, "dodged": true, "weapon": "qinglong_dao"}
				else:
					return {"resolved": true, "dodged": true}
			else:
				return {"resolved": true, "dodged": true}

	# 步骤4：未出闪，造成伤害（含酒+1）
	var damage = 1
	if source_player.wine_used:
		damage += 1
		source_player.wine_used = false

	var dmg_type := DamageEffect.DamageType.NORMAL
	match card.card_name:
		"火杀": dmg_type = DamageEffect.DamageType.FIRE
		"雷杀": dmg_type = DamageEffect.DamageType.THUNDER
		_: dmg_type = DamageEffect.DamageType.NORMAL

	var dmg_effect = DamageEffect.create(source_index, target_idx, damage, dmg_type, card)
	var dmg_result = await dmg_effect.resolve(battle_context)

	return {"resolved": true, "dodged": false, "damage_result": dmg_result}


# Gemini:change.10: 武器后置钩子——杀被闪后尝试触发武器效果
## 贯石斧：弃2张手牌 → 强制命中
## 青龙偃月刀：再出一张杀 → 对同一目标追击
## @return: {"force_hit": bool, "follow_up_sha": bool}
func _try_weapon_follow_through(battle_context, source_player, target_player) -> Dictionary:
	var source_controller = battle_context.get_controller(source_index)
	if source_controller == null:
		return {}

	# 检查贯石斧
	var has_guanshi := false
	for sk in source_player.skills:
		if sk is SkillGuanshiAxe:
			has_guanshi = true
			break

	if has_guanshi and source_player.hand_cards.size() >= 2:
		# 询问是否弃2张手牌强命中
		var should_force := false
		if source_player.is_human:
			# 人类玩家：通过控制器询问（简化：AI自动判断）
			should_force = await _ask_guanshi(source_controller, source_player)
		else:
			# AI：杀的价值高于2张低价值手牌时才用
			should_force = _ai_should_guanshi(source_player)

		if should_force:
			# 弃2张最低价值手牌
			var sorted_cards = source_player.hand_cards.duplicate()
			sorted_cards.sort_custom(func(a, b): return _card_val(a) < _card_val(b))
			var discard_2: Array = []
			for i in range(min(2, sorted_cards.size())):
				discard_2.append(sorted_cards[i])
			for c in discard_2:
				source_player.hand_cards.erase(c)
			DiscardCardEffect.create(
				source_index, source_index, discard_2, DiscardCardEffect.DiscardReason.USAGE
			).resolve(battle_context)
			EventBus.publish(GameEvent.create(
				GameEvent.Type.SKILL_RESOLVED, source_index, target_idx,
				{"skill_name": "贯石斧", "effect": "force_hit"}
			))
			return {"force_hit": true}

	# 检查青龙偃月刀（非追加杀才触发）
	var has_qinglong := false
	for sk in source_player.skills:
		if sk is SkillQinglongDao:
			has_qinglong = true
			break

	if has_qinglong and not is_follow_up:
		# 检查是否有杀可追加
		var has_sha := false
		for c in source_player.hand_cards:
			if c.card_name == "杀" or c.card_name == "火杀" or c.card_name == "雷杀":
				has_sha = true
				break

		if has_sha:
			# 询问是否追加杀
			var should_follow := false
			if source_player.is_human:
				should_follow = await _ask_qinglong(source_controller, source_player)
			else:
				should_follow = _ai_should_qinglong(source_player)

			if should_follow:
				# 让玩家选择一张杀打出
				var sha_card: CardData = null
				if source_player.is_human:
					# 人类：通过控制器选牌
					var sha_candidates: Array = []
					for c in source_player.hand_cards:
						if c.card_name == "杀" or c.card_name == "火杀" or c.card_name == "雷杀":
							sha_candidates.append(c)
					if sha_candidates.size() > 1:
						var controller = battle_context.get_controller(source_index)
						if controller != null and controller.has_method("decide_card_pick"):
							sha_card = await controller.decide_card_pick(source_index, target_idx, sha_candidates, "qinglong_sha")
					if sha_card == null and not sha_candidates.is_empty():
						sha_card = sha_candidates[0]
				else:
					# AI：取第一张杀
					for c in source_player.hand_cards:
						if c.card_name == "杀" or c.card_name == "火杀" or c.card_name == "雷杀":
							sha_card = c
							break

				if sha_card != null:
					source_player.hand_cards.erase(sha_card)
					DiscardCardEffect.create(
						source_index, source_index, [sha_card], DiscardCardEffect.DiscardReason.USAGE
					).resolve(battle_context)
					EventBus.publish(GameEvent.create(
						GameEvent.Type.SKILL_RESOLVED, source_index, target_idx,
						{"skill_name": "青龙偃月刀", "effect": "follow_up_sha"}
					))
					# 递归执行追加杀
					var follow_sha = CardEffectSha.create_follow_up(source_index, target_idx, sha_card)
					await follow_sha.execute(battle_context, null)
					return {"follow_up_sha": true}

	return {}


func _card_val(card: CardData) -> int:
	if card == null:
		return 0
	match card.card_name:
		"桃": return 100
		"无懈可击": return 80
		"闪": return 60
		"酒": return 40
		"火杀", "雷杀": return 38
		"杀": return 35
		"无中生有": return 30
		_: return 15


## 询问人类是否发动贯石斧
func _ask_guanshi(controller, player) -> bool:
	if player.is_human:
		# 人类玩家：通过控制器询问（简化：手牌>=2就询问）
		return player.hand_cards.size() >= 2
	return _ai_should_guanshi(player)


## AI 判断是否发动贯石斧
func _ai_should_guanshi(player) -> bool:
	# 手牌充足（>=4张）时愿意弃2张强命中
	return player.hand_cards.size() >= 4


## 询问人类是否发动青龙偃月刀
func _ask_qinglong(controller, player) -> bool:
	if player.is_human:
		# 人类玩家：有杀且手牌>=2就询问
		var has_sha := false
		for c in player.hand_cards:
			if c.card_name == "杀" or c.card_name == "火杀" or c.card_name == "雷杀":
				has_sha = true
				break
		return has_sha and player.hand_cards.size() >= 2
	return _ai_should_qinglong(player)


## AI 判断是否发动青龙偃月刀
func _ai_should_qinglong(player) -> bool:
	# 有杀且手牌充足时追击
	return player.hand_cards.size() >= 3
