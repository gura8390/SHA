# ============================================================
# card_effect_jiedao.gd
# 卡牌效果：借刀杀人——令装备武器的目标A对其攻击范围内的角色B使用【杀】，
#            若A不杀（或无法杀），A的武器归使用者。
# 简化实现：要求 target_indices = [A, B]。A 被请求出杀给 B。
# Gemini:change.9: 新建——即时锦囊"借刀杀人"
# ============================================================

class_name CardEffectJiedao
extends GameAction

var card: CardData = null
var coerced_idx: int = -1   # A：被借刀的人
var victim_idx: int = -1    # B：被杀的人


static func create_action(src: int, coerced: int, victim: int, card_data: CardData) -> CardEffectJiedao:
	var action = CardEffectJiedao.new()
	action.source_index = src
	action.target_index = coerced
	action.coerced_idx = coerced
	action.victim_idx = victim
	action.card = card_data
	action.description = "%d→%d→%d 借刀" % [src, coerced, victim]
	return action


func execute(battle_context, _action_queue) -> Dictionary:
	description = "%s 借刀：令 %s 杀 %s" % [_pname(source_index, battle_context), _pname(coerced_idx, battle_context), _pname(victim_idx, battle_context)]
	var coerced = battle_context.get_player(coerced_idx)
	var victim = battle_context.get_player(victim_idx)
	if coerced == null or not coerced.is_alive:
		return {"resolved": false, "reason": "invalid_coerced"}
	# Gemini:change.10: B 也必须存活（A 被借刀时目标 B 已不存在则无效）
	if victim == null or not victim.is_alive:
		return {"resolved": false, "reason": "invalid_victim"}

	# Gemini:change.10: 发布目标指定事件（A 为主要目标）
	var targeted_event = GameEvent.create(
		GameEvent.Type.CARD_TARGETED, source_index, coerced_idx,
		{"card": card, "card_name": "借刀杀人", "victim": victim_idx}
	)
	EventBus.publish(targeted_event)

	# Gemini:change.10: 无懈可击——借刀杀人是单目标锦囊，可被无懈抵消
	if await WuxieInquiry.inquire(battle_context, source_index, card, coerced_idx):
		targeted_event.is_cancelled = true

	if targeted_event.is_cancelled:
		return {"resolved": false, "reason": "cancelled"}

	# 请求 A 打出【杀】给 B
	var result: ResponseResult = await ResponseRequest.ask(
		battle_context, coerced_idx, "杀", source_index,
		{"card": card, "context": "jiedao", "victim": victim_idx,
		 "prompt": "借刀杀人：是否对 %s 使用【杀】？" % _pname(victim_idx, battle_context)}
	)

	if result.played and result.card_used != null and victim != null and victim.is_alive:
		# A 出杀 → 对 B 结算一次杀
		var sha_card = result.card_used
		coerced.hand_cards.erase(sha_card)
		var sha_action = CardEffectSha.create_action(coerced_idx, victim_idx, sha_card)
		await sha_action.execute(battle_context, null)
		# 杀牌入弃牌堆（经 Effect 系统，发 DISCARD_CARD 事件）
		DiscardCardEffect.create(coerced_idx, coerced_idx, [sha_card], DiscardCardEffect.DiscardReason.USAGE).resolve(battle_context)
		return {"resolved": true, "killed": true}
	else:
		# A 不杀 → 武器归使用者
		if coerced.equip_weapon != null:
			var weapon = coerced.equip_weapon
			# 卸载装备技能
			for i in range(coerced.skills.size() - 1, -1, -1):
				var sk = coerced.skills[i]
				if sk != null and sk.has_meta("equip_source") and sk.get_meta("equip_source") == weapon:
					if sk.has_method("unregister_events"):
						sk.unregister_events()
					coerced.skills.remove_at(i)
			coerced.equip_weapon = null
			# 发布装备移除事件
			EventBus.publish(GameEvent.create(
				GameEvent.Type.EQUIP_REMOVED, coerced_idx, coerced_idx,
				{"card": weapon, "slot": "weapon"}
			))
			var me = battle_context.get_player(source_index)
			if me != null:
				me.hand_cards.append(weapon)
		return {"resolved": true, "killed": false}
