# ============================================================
# card_effect_delayed.gd
# 卡牌效果：延时锦囊放置（乐不思蜀/兵粮寸断/闪电）
#   - 乐不思蜀/兵粮寸断：放入指定目标的判定区
#   - 闪电：放入使用者自己的判定区
# 实际判定在目标回合的判定阶段由 game_manager._do_judge_phase 处理。
# Gemini:change.9: 新建——延时锦囊放置
# ============================================================

class_name CardEffectDelayed
extends GameAction

var card: CardData = null
var target_idx: int = -1


static func create_action(src: int, tgt: int, card_data: CardData) -> CardEffectDelayed:
	var action = CardEffectDelayed.new()
	action.source_index = src
	action.target_index = tgt
	action.target_idx = tgt
	action.card = card_data
	action.description = "%d→%d %s" % [src, tgt, card_data.card_name]
	return action


func execute(battle_context, _action_queue) -> Dictionary:
	description = "%s 对 %s 放置【%s】" % [_pname(source_index, battle_context), _pname(target_idx, battle_context), card.card_name]
	# 闪电固定放自己判定区
	var place_to := target_idx
	if card.card_name == "闪电":
		place_to = source_index

	var target = battle_context.get_player(place_to)
	if target == null or not target.is_alive:
		return {"resolved": false, "reason": "invalid_target"}

	# 不可重复放置同名延时锦囊（乐/兵）
	for jc in target.judge_cards:
		if jc.card_name == card.card_name:
			return {"resolved": false, "reason": "duplicate_delayed"}

	target.judge_cards.append(card)
	return {"resolved": true, "placed_to": place_to}
