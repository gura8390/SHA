# ============================================================
# card_effect_duel.gd
# 卡牌效果：决斗（纯结算逻辑）
#
# 注意（Gemini:change.2 重构）：
#   "从手牌移除决斗、发 CARD_USED、决斗入弃牌堆、发 CARD_RESOLVED" 已由
#   PlayCardEffect 统一接管，本类只负责交替出杀的结算。
#
# 结算流程：
#   1. publish CARD_TARGETED
#   2. 目标先出杀，然后来源出杀，交替循环（每轮 await ResponseRequest）
#   3. 先无法出杀的一方受到1点伤害
#
# 规则修正（Bug-7）：
#   决斗的伤害来源始终是"使用决斗的玩家"（source_index）。
#   旧实现里交替后 other_idx 语义混乱，可能把伤害来源搞成目标自己。
#   现在：无论谁先不出杀，伤害来源都是 source_index（使用决斗的人）。
#   ——这与三国杀规则一致：决斗的受害方受到来自决斗使用者的伤害。
#
# Gemini:change.2: 重构——async 化 + 修伤害来源语义
# ============================================================

class_name CardEffectDuel
extends GameAction

## 使用的卡牌数据
var card: CardData = null

## 目标玩家索引
var target_idx: int = -1


# Gemini:change.1: 便捷创建
static func create_action(src: int, tgt: int, card_data: CardData) -> CardEffectDuel:
	var action = CardEffectDuel.new()
	action.source_index = src
	action.target_index = tgt
	action.target_idx = tgt
	action.card = card_data
	action.description = "%d→%d 决斗" % [src, tgt]  # execute 中用姓名覆盖
	return action


# Gemini:change.2: 执行"决斗"的结算（async）
func execute(battle_context, _action_queue) -> Dictionary:
	description = "%s 对 %s 使用【决斗】" % [_pname(source_index, battle_context), _pname(target_idx, battle_context)]
	var source_player = battle_context.get_player(source_index)
	var target_player = battle_context.get_player(target_idx)

	if target_player == null or not target_player.is_alive:
		return {"resolved": false, "reason": "invalid_target"}
	if source_player == null:
		return {"resolved": false, "reason": "invalid_source"}

	# 发布目标指定事件
	var targeted_event = GameEvent.create(
		GameEvent.Type.CARD_TARGETED,
		source_index,
		target_idx,
		{"card": card, "card_name": "决斗"}
	)
	EventBus.publish(targeted_event)

	# Gemini:change.10: 无懈可击——决斗是单目标锦囊，目标"成为目标时"可被无懈抵消
	if await WuxieInquiry.inquire(battle_context, source_index, card, target_idx):
		targeted_event.is_cancelled = true

	if targeted_event.is_cancelled:
		return {"resolved": false, "reason": "target_cancelled"}

	# Gemini:change.2: 决斗交替出杀
	# current_responder：当前轮到谁出杀；初始是目标先出
	# 伤害来源恒为 source_index（使用决斗的人）
	var current_responder_idx = target_idx

	while true:
		var responder = battle_context.get_player(current_responder_idx)
		if responder == null or not responder.is_alive:
			# 响应者已死，另一方无需继续
			break

		# Gemini:change.12: 无双判定——对手需出两张杀
		var other_idx = source_index if current_responder_idx == target_idx else target_idx
		var needs_two_sha := SkillWuShuang.has_wushuang(battle_context, other_idx)

		# 异步请求当前响应者出杀
		var result: ResponseResult = await ResponseRequest.ask(
			battle_context,
			current_responder_idx,
			"杀",
			other_idx,
			{
				"card": card,
				"context": "duel",
				"prompt": "决斗中，是否打出【杀】？",
			}
		)

		if result.played and result.card_used != null:
			# 打出了杀
			var sha_card = result.card_used
			var actual_card = result.convert_source if result.convert_source != null else sha_card
			responder.hand_cards.erase(actual_card)
			DiscardCardEffect.create(
				current_responder_idx, current_responder_idx, [actual_card],
				DiscardCardEffect.DiscardReason.USAGE
			).resolve(battle_context)

			# Gemini:change.12: 无双——需要第二张杀
			if needs_two_sha:
				var result2: ResponseResult = await ResponseRequest.ask(
					battle_context,
					current_responder_idx,
					"杀",
					other_idx,
					{
						"card": card,
						"context": "duel_wushuang",
						"prompt": "【无双】！需要第二张【杀】！",
					}
				)
				if not (result2.played and result2.card_used != null):
					# 未出第二张杀，受到伤害
					var dmg_effect = DamageEffect.create(
						other_idx, current_responder_idx, 1,
						DamageEffect.DamageType.NORMAL, card
					)
					await dmg_effect.resolve(battle_context)
					break
				else:
					# 打出了第二张杀
					var sha2 = result2.card_used
					var actual2 = result2.convert_source if result2.convert_source != null else sha2
					responder.hand_cards.erase(actual2)
					DiscardCardEffect.create(
						current_responder_idx, current_responder_idx, [actual2],
						DiscardCardEffect.DiscardReason.USAGE
					).resolve(battle_context)

			# 交换响应者
			current_responder_idx = other_idx
		else:
			# 无法出杀，受到伤害
			var dmg_effect = DamageEffect.create(
				other_idx, current_responder_idx, 1,
				DamageEffect.DamageType.NORMAL, card
			)
			await dmg_effect.resolve(battle_context)
			break

	return {"resolved": true}
