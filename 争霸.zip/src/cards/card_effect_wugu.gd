# ============================================================
# card_effect_wugu.gd
# 卡牌效果：五谷丰登——亮出等同存活人数的牌，每人按座位顺序选走一张
#
# 标准规则：
#   1. 从牌堆翻出 N 张牌（N = 存活角色数）
#   2. 从使用者开始按座位顺序，每人选择并获得一张
#   3. 剩余牌弃置
#
# Gemini:change.9: 新建——AOE 锦囊"五谷丰登"
# Gemini:change.10: 逐目标无懈可击 + 玩家选择（标准规则）
# ============================================================

class_name CardEffectWugu
extends GameAction

var card: CardData = null


static func create_action(src: int, card_data: CardData) -> CardEffectWugu:
	var action = CardEffectWugu.new()
	action.source_index = src
	action.target_index = -1
	action.card = card_data
	action.description = "%d 五谷丰登" % src
	return action


func execute(battle_context, _action_queue) -> Dictionary:
	description = "%s 使用【五谷丰登】" % _pname(source_index, battle_context)
	var alive = battle_context.get_alive_players()

	# 亮出 N 张牌
	var revealed: Array = []
	for i in range(alive.size()):
		var c = battle_context.draw_from_pile()
		if c != null:
			revealed.append(c)

	if revealed.is_empty():
		return {"resolved": true, "empty": true}

	# 按座位顺序（从使用者起）每人选一张
	var order := _seat_order(battle_context, source_index, alive)
	for p in order:
		if revealed.is_empty():
			break
		if not p.is_alive:
			continue

		# 发布目标指定事件
		var targeted_event = GameEvent.create(
			GameEvent.Type.CARD_TARGETED, source_index, p.index,
			{"card": card, "card_name": "五谷丰登"}
		)
		EventBus.publish(targeted_event)
		if targeted_event.is_cancelled:
			continue

		# 无懈可击——逐目标询问
		if await WuxieInquiry.inquire(battle_context, source_index, card, p.index):
			continue

		# 让玩家选择一张
		var picked: CardData = null
		var controller = battle_context.get_controller(p.index)
		if controller != null and controller.has_method("decide_card_pick"):
			picked = await controller.decide_card_pick(p.index, source_index, revealed.duplicate(), "wugu")
		if picked == null and not revealed.is_empty():
			picked = revealed[0]

		if picked != null and revealed.has(picked):
			revealed.erase(picked)
			# 牌已通过 draw_from_pile 取出，不在 draw_pile 中，直接加入手牌
			p.hand_cards.append(picked)
			EventBus.publish(GameEvent.create(
				GameEvent.Type.CARD_GIVEN, -1, p.index,
				{"card": picked, "reason": "wugu"}
			))

	# 剩余牌入弃牌堆
	for leftover in revealed:
		battle_context.add_to_discard_pile(leftover)
	return {"resolved": true}


func _seat_order(battle_context, src_index: int, alive: Array) -> Array:
	var order: Array = []
	var src_pos = -1
	for i in range(alive.size()):
		if alive[i].index == src_index:
			src_pos = i
			break
	if src_pos == -1:
		return alive
	for i in range(alive.size()):
		order.append(alive[(src_pos + i) % alive.size()])
	return order
