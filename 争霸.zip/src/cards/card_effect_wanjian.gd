# ============================================================
# card_effect_wanjian.gd
# 卡牌效果：万箭齐发——对所有其他角色，每人需打出一张【闪】否则受1点伤害
# 结构与南蛮入侵相同，只是响应牌为"闪"。
# Gemini:change.9: 新建——AOE 锦囊"万箭齐发"
# ============================================================

class_name CardEffectWanjian
extends GameAction

var card: CardData = null


static func create_action(src: int, card_data: CardData) -> CardEffectWanjian:
	var action = CardEffectWanjian.new()
	action.source_index = src
	action.target_index = -1
	action.card = card_data
	action.description = "%d 万箭齐发" % src
	return action


func execute(battle_context, _action_queue) -> Dictionary:
	description = "%s 使用【万箭齐发】" % _pname(source_index, battle_context)
	var source_player = battle_context.get_player(source_index)
	if source_player == null:
		return {"resolved": false, "reason": "invalid_source"}

	var processed: Dictionary = {}
	while true:
		var next_target = _find_next_target(battle_context, source_index, processed)
		if next_target == null:
			break
		var target_idx = next_target.index
		processed[target_idx] = true
		if not next_target.is_alive:
			continue

		var targeted = GameEvent.create(
			GameEvent.Type.CARD_TARGETED, source_index, target_idx,
			{"card": card, "card_name": "万箭齐发"}
		)
		EventBus.publish(targeted)
		if targeted.is_cancelled:
			continue

		# Gemini:change.10: 无懈可击——AOE 逐目标询问（标准规则）
		if await WuxieInquiry.inquire(battle_context, source_index, card, target_idx):
			continue

		var result: ResponseResult = await ResponseRequest.ask(
			battle_context, target_idx, "闪", source_index,
			{"card": card, "context": "wanjian", "prompt": "【万箭齐发】，是否打出【闪】？"}
		)
		if result.played and result.card_used != null:
			var dodge = result.card_used
			# Gemini:change.12: 转化牌模式——移除实际牌而非虚拟牌
			var actual_card = result.convert_source if result.convert_source != null else dodge
			next_target.hand_cards.erase(actual_card)
			DiscardCardEffect.create(target_idx, target_idx, [actual_card], DiscardCardEffect.DiscardReason.USAGE).resolve(battle_context)
		else:
			await DamageEffect.create(source_index, target_idx, 1, DamageEffect.DamageType.NORMAL, card).resolve(battle_context)

	return {"resolved": true}


func _find_next_target(battle_context, src_index: int, processed: Dictionary):
	var alive = battle_context.get_alive_players()
	if alive.is_empty():
		return null
	var src_pos = -1
	for i in range(alive.size()):
		if alive[i].index == src_index:
			src_pos = i
			break
	if src_pos == -1:
		return null
	for i in range(1, alive.size()):
		var idx = (src_pos + i) % alive.size()
		var candidate = alive[idx]
		if candidate.index == src_index or processed.has(candidate.index) or not candidate.is_alive:
			continue
		return candidate
	return null
