# ============================================================
# play_card_effect.gd
# 统一"使用一张牌"的入口流程（GameAction）
#
# 这是消灭 Bug-4/Bug-5 的核心：旧实现里 AI 和卡牌效果各自裸 erase 手牌 +
# 入弃牌堆，绕过了 Effect 系统且不发 DISCARD_CARD 事件。本类把"使用牌"
# 的完整生命周期收口到这里，所有卡牌进出都经过统一通道。
#
# 流程：
#   1. 校验（卡牌在手牌中、目标合法、出牌阶段限制）
#   2. 从手牌移除（所有权转移到"结算中"）
#   3. 出杀次数+1（若是杀）
#   4. publish CARD_USED
#   5. 创建并执行对应卡牌效果 GameAction（await，支持响应链）
#   6. 将使用的牌入弃牌堆——走 DiscardCardEffect.Usage，发 DISCARD_CARD 事件
#   7. publish CARD_RESOLVED
#
# Gemini:change.1: 新建——统一使用牌流程，取代裸 erase
# ============================================================

class_name PlayCardEffect
extends GameAction

## 要使用的牌（已在 source 手牌中）
var card: CardData = null

## 目标玩家索引列表
var target_indices: Array = []  # Array[int]

## Gemini:change.10: 牌转化标记（丈八蛇矛：两张手牌当杀）
var convert_cards: Array = []  # Array[CardData]

## Gemini:change.12: 单张转化牌（武圣/龙胆/急救等：一张手牌当另一张使用）
var convert_card: CardData = null

## 卡牌结算中枢引用（由 game_manager 注入，避免循环依赖）
var card_resolver: CardResolver = null


# Gemini:change.1: 从 PlayIntent 构造使用牌动作
static func create_from_intent(
	intent: PlayIntent,
	resolver: CardResolver
) -> PlayCardEffect:
	var action = PlayCardEffect.new()
	action.source_index = intent.source_index
	action.card = intent.card
	action.target_indices = intent.target_indices.duplicate()
	action.card_resolver = resolver
	action.convert_cards = intent.convert_cards.duplicate()
	action.convert_card = intent.convert_card
	action.description = "%d→%s" % [intent.source_index, intent.card.card_name]
	return action


# Gemini:change.1: 执行使用牌的完整流程（async，因为内部卡牌效果可能 await 响应）
func execute(battle_context, _action_queue) -> Dictionary:
	var source = battle_context.get_player(source_index)
	if source == null or not source.is_alive:
		return {"resolved": false, "reason": "invalid_source"}

	if card == null:
		return {"resolved": false, "reason": "null_card"}

	description = "%s 使用【%s】" % [_pname(source_index, battle_context), card.card_name]

	# ----- 步骤0：校验卡牌确实在手牌中（转化牌模式下校验转化牌）-----
	if not convert_cards.is_empty():
		# 丈八蛇矛模式：校验转化牌在手牌中
		for cc in convert_cards:
			if not source.hand_cards.has(cc):
				return {"resolved": false, "reason": "convert_card_not_in_hand"}
	elif convert_card != null:
		# 单张转化模式（武圣/龙胆/急救）：校验转化牌在手牌中
		if not source.hand_cards.has(convert_card):
			return {"resolved": false, "reason": "convert_card_not_in_hand"}
	elif not source.hand_cards.has(card):
		return {"resolved": false, "reason": "card_not_in_hand"}

	# ----- 步骤1：从手牌移除（所有权转移：手牌 → 结算中）-----
	if not convert_cards.is_empty():
		# 丈八蛇矛模式：移除转化牌
		for cc in convert_cards:
			source.hand_cards.erase(cc)
	elif convert_card != null:
		# 单张转化模式：移除实际使用的牌（而非虚拟牌）
		source.hand_cards.erase(convert_card)
	else:
		source.hand_cards.erase(card)

	# ----- 步骤2：若是杀（含火杀/雷杀），增加本回合出杀计数 -----
	# 武靖：若下一张牌无次数限制标记存在，跳过计数
	var wujing_unlimited := SkillWuJing.consume_unlimited(battle_context, source_index)
	var is_sha := (card.card_name == "杀" or card.card_name == "火杀" or card.card_name == "雷杀")
	if is_sha and not wujing_unlimited:
		source.kill_count_this_turn += 1

	# ----- 步骤3：publish CARD_USED（使用前通知，技能可取消整次使用）-----
	var used_event = GameEvent.create(
		GameEvent.Type.CARD_USED,
		source_index,
		target_indices[0] if not target_indices.is_empty() else -1,
		{"card": card, "card_name": card.card_name, "targets": target_indices}
	)
	EventBus.publish(used_event)

	# Gemini:change.10: AOE 锦囊的无懈可击改为逐目标结算时询问（标准规则），
	## 不再在此处一次性询问。每个 AOE effect 内部在 CARD_TARGETED 后自行处理无懈。
	## 单目标锦囊（决斗/过河拆桥/顺手牵羊/借刀杀人）的无懈在各自 effect 的
	## CARD_TARGETED 之后处理（更贴合"成为目标时"的规则时机）。

	# ----- 步骤4：创建并执行卡牌效果 -----
	var effect_action = card_resolver.create_effect(card, source_index, target_indices)
	var effect_result: Dictionary = {"resolved": true}
	if effect_action != null:
		# 卡牌效果可能内部 await 响应链（杀等闪、决斗、南蛮、求桃）
		effect_result = await effect_action.execute(battle_context, null)

	# Gemini:change.10: 和衷 bonus——锦囊结算后检查是否需要额外结算
	if card.card_type == CardData.CardType.TRICK:
		var extra_count: int = 0
		if battle_context != null:
			var src_player = battle_context.get_player(source_index)
			if src_player != null and src_player.has_meta("hezhong_bonus"):
				extra_count = SkillHeZhong.check_and_consume_bonus(src_player, card)
		# 额外结算 N 次
		for _i in range(extra_count):
			var extra_effect = card_resolver.create_effect(card, source_index, target_indices)
			if extra_effect != null:
				await extra_effect.execute(battle_context, null)
			EventBus.publish(GameEvent.create(
				GameEvent.Type.SKILL_RESOLVED, source_index, -1,
				{"skill_name": "和衷", "effect": "extra_resolve", "card_name": card.card_name}
			))

	# ----- 步骤5：使用的牌入弃牌堆（走 Effect 系统，发 DISCARD_CARD 事件）-----
	# Gemini:change.10: 转化牌模式下，转化牌已在步骤1从手牌移除，需要入弃牌堆
	if not convert_cards.is_empty():
		for cc in convert_cards:
			var claimed_cc := false
			for p in battle_context.players:
				if p.hand_cards.has(cc):
					claimed_cc = true
					break
				if p.equip_weapon == cc or p.equip_armor == cc \
						or p.equip_horse_def == cc or p.equip_horse_atk == cc \
						or p.equip_treasure == cc:
					claimed_cc = true
					break
			if not claimed_cc and not battle_context.discard_pile.has(cc):
				DiscardCardEffect.create(
					source_index, source_index, [cc], DiscardCardEffect.DiscardReason.USAGE
				).resolve(battle_context)
	elif convert_card != null:
		# Gemini:change.12: 单张转化模式，convert_card 入弃牌堆
		var claimed_cv := false
		for p in battle_context.players:
			if p.hand_cards.has(convert_card):
				claimed_cv = true
				break
			if p.equip_weapon == convert_card or p.equip_armor == convert_card \
					or p.equip_horse_def == convert_card or p.equip_horse_atk == convert_card \
					or p.equip_treasure == convert_card:
				claimed_cv = true
				break
		if not claimed_cv and not battle_context.discard_pile.has(convert_card):
			DiscardCardEffect.create(
				source_index, source_index, [convert_card], DiscardCardEffect.DiscardReason.USAGE
			).resolve(battle_context)
	else:
		# Gemini:change.3: 奸雄交互修正——若结算过程中某技能已把这张牌收入手牌，不入弃牌堆
		# Gemini:change.13: 延时锦囊修正——若牌已进入判定区（乐/兵/闪电），不入弃牌堆
		var claimed: bool = false
		for p in battle_context.players:
			if p.hand_cards.has(card):
				claimed = true
				break
			if p.equip_weapon == card or p.equip_armor == card \
					or p.equip_horse_def == card or p.equip_horse_atk == card \
					or p.equip_treasure == card:
				claimed = true
				break
			if card in p.judge_cards:
				claimed = true
				break
		if not claimed and not battle_context.discard_pile.has(card):
			DiscardCardEffect.create(
				source_index, source_index, [card], DiscardCardEffect.DiscardReason.USAGE
			).resolve(battle_context)

	# ----- 步骤6：publish CARD_RESOLVED -----
	var resolved_event = GameEvent.create(
		GameEvent.Type.CARD_RESOLVED,
		source_index,
		target_indices[0] if not target_indices.is_empty() else -1,
		{
			"card": card,
			"card_name": card.card_name,
			"effect_result": effect_result,
		}
	)
	EventBus.publish(resolved_event)

	return {"resolved": true, "effect_result": effect_result}
