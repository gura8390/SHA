# ============================================================
# card_effect_wuzhong.gd
# 卡牌效果：无中生有——摸两张牌
# Gemini:change.9: 新建——即时锦囊"无中生有"
# ============================================================

class_name CardEffectWuzhong
extends GameAction

var card: CardData = null


static func create_action(src: int, card_data: CardData) -> CardEffectWuzhong:
	var action = CardEffectWuzhong.new()
	action.source_index = src
	action.target_index = src
	action.card = card_data
	action.description = "%d 无中生有" % src
	return action


func execute(battle_context, _action_queue) -> Dictionary:
	description = "%s 使用【无中生有】" % _pname(source_index, battle_context)

	# 无懈可击检查
	if await WuxieInquiry.inquire(battle_context, source_index, card, -1):
		return {"resolved": false, "reason": "cancelled"}

	DrawCardEffect.create(source_index, source_index, 2).resolve(battle_context)
	return {"resolved": true}
