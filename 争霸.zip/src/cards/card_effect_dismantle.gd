# ============================================================
# card_effect_dismantle.gd
# 卡牌效果：过河拆桥——弃置目标区域内的一张牌（手牌/装备/判定牌）
#            顺手牵羊——获得目标区域内的一张牌（距离1，归自己）
# 两者共用此脚本，按 card_name 区分"弃置"还是"获得"。
#
# Gemini:change.9: 重写——通过控制器选牌（AI 用价值评估，人类弹出选择器）
# ============================================================

class_name CardEffectDismantle
extends GameAction

var card: CardData = null
var target_idx: int = -1


static func create_action(src: int, tgt: int, card_data: CardData) -> CardEffectDismantle:
	var action = CardEffectDismantle.new()
	action.source_index = src
	action.target_index = tgt
	action.target_idx = tgt
	action.card = card_data
	action.description = "%d→%d %s" % [src, tgt, card_data.card_name]  # execute 中用姓名覆盖
	return action


func execute(battle_context, _action_queue) -> Dictionary:
	description = "%s 对 %s 使用【%s】" % [_pname(source_index, battle_context), _pname(target_idx, battle_context), card.card_name]
	var target = battle_context.get_player(target_idx)
	if target == null or not target.is_alive:
		return {"resolved": false, "reason": "invalid_target"}

	var targeted = GameEvent.create(
		GameEvent.Type.CARD_TARGETED, source_index, target_idx,
		{"card": card, "card_name": card.card_name}
	)
	EventBus.publish(targeted)

	# 无懈可击——过河拆桥/顺手牵羊是单目标锦囊，可被无懈抵消
	if await WuxieInquiry.inquire(battle_context, source_index, card, target_idx):
		targeted.is_cancelled = true

	if targeted.is_cancelled:
		return {"resolved": false, "reason": "cancelled"}

	# 收集目标所有可选牌（手牌 + 装备区 + 判定区）
	var available_cards: Array = _collect_available_cards(target)
	if available_cards.is_empty():
		return {"resolved": true, "empty": true}

	# 通过控制器选牌（AI 自动选，人类弹出选择器）
	var taken: CardData = null
	var controller = battle_context.get_controller(source_index)
	if controller != null and controller.has_method("decide_card_pick"):
		var pick_context = "steal" if card.card_name == "顺手牵羊" else "dismantle"
		taken = await controller.decide_card_pick(source_index, target_idx, available_cards, pick_context)
	else:
		# 兜底：取第一张
		taken = available_cards[0]

	if taken == null:
		taken = available_cards[0]

	# 从目标区域移除选中的牌（装备区/判定区需清理，手牌直接 erase）
	_remove_card_from_player(target, taken)

	# 将牌转移到正确的目的地
	if card.card_name == "顺手牵羊":
		# 顺手牵羊：牌归使用者手牌
		var source = battle_context.get_player(source_index)
		if source != null:
			source.hand_cards.append(taken)
		EventBus.publish(GameEvent.create(
			GameEvent.Type.CARD_STOLEN, source_index, target_idx,
			{"card": taken, "reason": "shunshou"}
		))
	else:
		# 过河拆桥：牌入弃牌堆
		battle_context.add_to_discard_pile(taken)
		EventBus.publish(GameEvent.create(
			GameEvent.Type.DISCARD_CARD, source_index, target_idx,
			{"cards": [taken], "reason": "guohe"}
		))

	return {"resolved": true, "taken": taken}


## 收集目标玩家所有可选牌（手牌 + 装备 + 判定区）
func _collect_available_cards(player) -> Array:
	var cards: Array = []
	# 手牌（全部可选）
	cards.append_array(player.hand_cards)
	# 装备区
	if player.equip_weapon != null:
		cards.append(player.equip_weapon)
	if player.equip_armor != null:
		cards.append(player.equip_armor)
	if player.equip_horse_def != null:
		cards.append(player.equip_horse_def)
	if player.equip_horse_atk != null:
		cards.append(player.equip_horse_atk)
	if player.equip_treasure != null:
		cards.append(player.equip_treasure)
	# 判定区
	cards.append_array(player.judge_cards)
	return cards


## 从玩家区域移除指定的牌
func _remove_card_from_player(player, card_to_remove: CardData) -> void:
	# 先检查手牌
	if player.hand_cards.has(card_to_remove):
		player.hand_cards.erase(card_to_remove)
		return
	# 装备区（需发 EQUIP_REMOVED 事件 + 卸载装备技能）
	var slot := ""
	if player.equip_weapon == card_to_remove:
		player.equip_weapon = null
		slot = "weapon"
	elif player.equip_armor == card_to_remove:
		player.equip_armor = null
		slot = "armor"
	elif player.equip_horse_def == card_to_remove:
		player.equip_horse_def = null
		slot = "horse_def"
	elif player.equip_horse_atk == card_to_remove:
		player.equip_horse_atk = null
		slot = "horse_atk"
	elif player.equip_treasure == card_to_remove:
		player.equip_treasure = null
		slot = "treasure"

	if slot != "":
		# 卸载装备携带的技能
		for i in range(player.skills.size() - 1, -1, -1):
			var sk = player.skills[i]
			if sk != null and sk.has_meta("equip_source") and sk.get_meta("equip_source") == card_to_remove:
				if sk.has_method("unregister_events"):
					sk.unregister_events()
				player.skills.remove_at(i)
		# 发布装备移除事件
		EventBus.publish(GameEvent.create(
			GameEvent.Type.EQUIP_REMOVED, player.index, player.index,
			{"card": card_to_remove, "slot": slot}
		))
		return

	# 判定区
	if player.judge_cards.has(card_to_remove):
		player.judge_cards.erase(card_to_remove)
