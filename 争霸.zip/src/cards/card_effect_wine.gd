# ============================================================
# card_effect_wine.gd
# 卡牌效果：酒——出牌阶段使用，本回合下一张【杀】伤害+1（每回合限一次）
# （濒死时使用的"酒当桃"救援由响应流程处理，此处为出牌阶段用法）
# Gemini:change.9: 新建——基本牌"酒"
# ============================================================

class_name CardEffectWine
extends GameAction

var card: CardData = null


static func create_action(src: int, card_data: CardData) -> CardEffectWine:
	var action = CardEffectWine.new()
	action.source_index = src
	action.target_index = src
	action.card = card_data
	action.description = "%d 酒" % src
	return action


func execute(battle_context, _action_queue) -> Dictionary:
	description = "%s 使用【酒】" % _pname(source_index, battle_context)
	var p = battle_context.get_player(source_index)
	if p == null:
		return {"resolved": false, "reason": "invalid_source"}
	# 标记本回合已用酒：下一张杀 +1 伤害（在 CardEffectSha 中消费）
	p.wine_used = true
	return {"resolved": true}
