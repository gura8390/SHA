# ============================================================
# game_action.gd
# 动作基类：代表游戏中一个可执行的原子操作或复合操作
# 动作通过 ActionQueue 排队执行，支持嵌套和链式结算
# 例如：使用南蛮入侵 → 逐个玩家响应 → 造成伤害 → 触发技能
# Gemini:change.1: 初始创建——定义动作基类接口
# ============================================================

class_name GameAction
extends RefCounted

# Gemini:change.1: 动作状态枚举
enum ActionState {
	PENDING,     ## 等待执行
	EXECUTING,   ## 正在执行
	COMPLETED,   ## 执行完成
	CANCELLED,   ## 已取消
}

## 动作当前状态
var state: ActionState = ActionState.PENDING

## 动作来源玩家索引
var source_index: int = -1

## 动作目标玩家索引（-1 表示无特定目标或多目标）
var target_index: int = -1

## 动作优先级（用于插入队列时的排序，越高越先执行）
var priority: int = 0

## 动作描述（用于日志和调试）
var description: String = ""

## 动作附加数据
var action_data: Dictionary = {}

## 子动作列表（复合动作可包含多个子动作）
var sub_actions: Array = []  # Array[GameAction]

## 父动作引用（如果是子动作）
var parent_action: GameAction = null


# Gemini:change.1: 核心方法——执行动作
## 子类必须重写此方法
## @param battle_context: 战场上下文
## @param action_queue: 动作队列引用（用于在执行中插入新动作）
## @return: 执行结果
func execute(_battle_context, _action_queue) -> Dictionary:
	push_error("GameAction.execute() 必须由子类重写！")
	return {}


# Gemini:change.1: 检查动作是否可执行（前置条件校验）
## 子类可重写以添加额外校验
func can_execute(_battle_context) -> bool:
	return state == ActionState.PENDING


# Gemini:change.1: 取消动作
func cancel() -> void:
	state = ActionState.CANCELLED
	# 同时取消所有子动作
	for sub in sub_actions:
		sub.cancel()


# Gemini:change.1: 添加子动作
func add_sub_action(action: GameAction) -> void:
	action.parent_action = self
	sub_actions.append(action)


# Gemini:change.1: 标记完成
func complete() -> void:
	state = ActionState.COMPLETED


func _to_string() -> String:
	return "GameAction[%s] src=%d tgt=%d state=%s" % [
		description,
		source_index,
		target_index,
		ActionState.keys()[state]
	]


# Gemini:change.10: 获取玩家姓名（供 description 使用）
## @param idx: 玩家索引
## @param ctx: 战场上下文（由子类在 execute 中传入）
## @return: 武将名称或 "X号" 兜底
static func _pname(idx: int, ctx) -> String:
	if ctx == null:
		return "%d号" % (idx + 1)
	var p = ctx.get_player(idx)
	if p == null:
		return "%d号" % (idx + 1)
	if p.hero_data != null and p.hero_data.hero_name != "":
		return p.hero_data.hero_name
	return "%d号" % (idx + 1)
