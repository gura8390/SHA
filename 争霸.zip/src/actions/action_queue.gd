# ============================================================
# action_queue.gd
# 动作队列管理器：管理所有待执行动作的排队和顺序执行
# 核心设计：
#   - 支持先进先出（FIFO）基础队列
#   - 支持高优先级动作插队（如技能触发的即时动作）
#   - 支持在当前动作执行过程中插入新动作（嵌套结算）
#   - 通过 await 逐一执行，天然支持异步等待玩家/AI响应
# Gemini:change.1: 初始创建——实现动作队列核心逻辑
# ============================================================

class_name ActionQueue
extends RefCounted

# Gemini:change.1: 待执行动作队列
var _queue: Array = []  # Array[GameAction]

# Gemini:change.1: 当前正在执行的动作（用于嵌套检测）
var _current_action: GameAction = null

# Gemini:change.1: 执行历史（调试用）
var _history: Array = []  # Array[GameAction]

# Gemini:change.1: 是否正在批量执行中
var _is_processing: bool = false

# Gemini:change.1: 战场上下文引用
var _battle_context = null


# Gemini:change.1: 初始化，绑定战场上下文
func setup(battle_context) -> void:
	_battle_context = battle_context


# Gemini:change.1: 向队列尾部添加动作
## 普通动作按先进先出顺序排列
func push_action(action: GameAction) -> void:
	_queue.append(action)
	# 按优先级排序（高优先级在前）
	_queue.sort_custom(_sort_by_priority)


# Gemini:change.1: 向队列头部插入动作（紧急动作，如技能触发）
## 用于在当前结算过程中插入需要立即处理的动作
func push_front(action: GameAction) -> void:
	_queue.push_front(action)


# Gemini:change.1: 执行队列中的下一个动作
## 返回执行结果字典
func execute_next() -> Dictionary:
	if _queue.is_empty():
		return {"completed": true, "reason": "queue_empty"}

	var action: GameAction = _queue.pop_front()

	# 检查动作是否可执行
	if not action.can_execute(_battle_context):
		action.cancel()
		_history.append(action)
		return {"completed": false, "reason": "cannot_execute", "action": action}

	# 执行动作
	_current_action = action
	action.state = GameAction.ActionState.EXECUTING

	var result: Dictionary = await action.execute(_battle_context, self)

	action.complete()
	_current_action = null
	_history.append(action)

	return result


# Gemini:change.1: 执行队列中所有动作直到队列为空
## 这是主要的结算驱动入口
## 每执行一个动作后检查队列是否有新动作被插入
func execute_all() -> void:
	_is_processing = true

	while not _queue.is_empty():
		await execute_next()

	_is_processing = false


# Gemini:change.1: 优先级排序（降序）
func _sort_by_priority(a: GameAction, b: GameAction) -> bool:
	return a.priority > b.priority


# Gemini:change.1: 查询队列是否为空
func is_empty() -> bool:
	return _queue.is_empty()


# Gemini:change.1: 获取当前队列长度
func get_queue_size() -> int:
	return _queue.size()


# Gemini:change.1: 获取当前正在执行的动作
func get_current_action() -> GameAction:
	return _current_action


# Gemini:change.1: 清空队列（用于强制结束或异常处理）
func clear() -> void:
	for action in _queue:
		action.cancel()
	_queue.clear()
	_is_processing = false


# Gemini:change.1: 获取执行历史（调试用）
func get_history() -> Array:
	return _history


# Gemini:change.1: 调试打印当前队列状态
func debug_print() -> void:
	print("===== ActionQueue (size: %d) =====" % _queue.size())
	if _current_action:
		print("  [EXECUTING] %s" % str(_current_action))
	for i in range(_queue.size()):
		print("  [%d] %s" % [i, str(_queue[i])])
	print("==================================")
